
const String URL_PLAY_STORE = "https://play.google.com/store/apps/details?id=com.davidjo.toeic_percent";

const String URL_EMAIL = "waterbottle54@naver.com";