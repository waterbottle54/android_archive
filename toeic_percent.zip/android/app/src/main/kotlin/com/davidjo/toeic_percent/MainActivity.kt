package com.davidjo.toeic_percent

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
