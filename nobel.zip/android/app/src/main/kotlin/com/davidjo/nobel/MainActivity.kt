package com.davidjo.nobel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
