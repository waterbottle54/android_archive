import 'dart:math';
import 'dart:ui';

import 'package:auto_size_text/auto_size_text.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'package:nobel/models/page_model.dart';
import 'package:nobel/shared/constants.dart';
import 'package:share/share.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {

    MediaQueryData mqd = MediaQuery.of(context);
    ScreenUtil.init(context);

    return SafeArea(
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            color: Colors.brown[300],
          ),
          child: Center(
            child: AspectRatio(
              aspectRatio: min<double>(0.65,
                  mqd.size.width / (mqd.size.height - mqd.padding.top)),
              child: CarouselSlider(
                options: CarouselOptions(
                  height: MediaQuery.of(context).size.height,
                  viewportFraction: 1.0,
                  enableInfiniteScroll: false,
                ),
                items: _getFront()
                  ..addAll(pages.map((page) => _getPage(page)))
                  ..addAll(_getBack()),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _getFront() {
    return [
      Container(
        margin: EdgeInsets.symmetric(horizontal: 0.0),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/heart.jpg'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(Colors.white30, BlendMode.softLight),
          ),
        ),
      ),
    ];
  }

  List<Widget> _getBack() {
    return [
      Container(
        margin: EdgeInsets.symmetric(horizontal: 0.w),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/paper.jpg'),
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(Colors.white30, BlendMode.softLight),
          ),
        ),
        child: Column(
          children: [
            Image.asset(
              'assets/buddha.jpg',
              color: Colors.brown[500],
              colorBlendMode: BlendMode.hardLight,
            ),
            Expanded(
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '돼지머리',
                      style: TextStyle(
                        fontSize: 68.h,
                      ),
                    ),
                    SizedBox(height: 36.h),
                    RaisedButton(
                      onPressed: () => Share.share(urlPlayStore),
                      child: Icon(
                        Icons.share,
                        color: Colors.black87,
                      ),
                      color: Colors.brown[200],
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(48.w),
              child: AutoSizeText(
                'ⓒ 2020, David Jo. all rights reserved.',
                maxLines: 1,
                style: TextStyle(
                  fontSize: 36.h,
                ),
              ),
            ),
          ],
        ),
      ),
    ];
  }

  Widget _getPage(PageModel page) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 0.0),
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/paper.jpg'),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(Colors.white30, BlendMode.softLight),
        ),
      ),
      child: Column(
        children: [
          page.urlImage == null
              ? SizedBox()
              : Image.asset(
                  page.urlImage,
                  color: Colors.brown[500],
                  colorBlendMode: BlendMode.hardLight,
                ),
          Padding(
            padding: EdgeInsets.all(48.w),
            child: Text(
              page.text,
              style: TextStyle(
                fontSize: 54.h,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
