

class PageModel {

  String text;
  String urlImage;

  PageModel(String text, String urlImage) {
    this.text = text;
    this.urlImage = urlImage;
  }

}