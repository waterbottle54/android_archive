package com.penelope.voiceofbook.data.voicedoc;

import junit.framework.TestCase;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class VoiceDocTest extends TestCase {

    @Test
    public void testJson() {

        List<Long> midpoints = new ArrayList<>();
        midpoints.add(234L);
        midpoints.add(330L);
        VoiceDoc voiceDoc = new VoiceDoc(
            "sdfsd#324908324#234",
            "littleprince",
            "handsome123",
            3405798572L,
                435L,
                midpoints
        );

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id", voiceDoc.getId());
            jsonObject.put("bookDocId", voiceDoc.getBookDocId());
            jsonObject.put("recorder", voiceDoc.getRecorder());
            jsonObject.put("duration", voiceDoc.getDuration());
            jsonObject.put("midpoints", voiceDoc.getMidpointList());
            System.out.println(jsonObject.toString());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

}