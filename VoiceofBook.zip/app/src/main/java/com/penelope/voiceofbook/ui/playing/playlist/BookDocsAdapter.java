package com.penelope.voiceofbook.ui.playing.playlist;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.databinding.BookDocItemBinding;

import java.util.Locale;
import java.util.Map;

public class BookDocsAdapter extends ListAdapter<BookDoc, BookDocsAdapter.BookDocViewHolder> {

    class BookDocViewHolder extends RecyclerView.ViewHolder {

        private final BookDocItemBinding binding;

        public BookDocViewHolder(BookDocItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(BookDoc model) {

            binding.textViewBookTitle.setText(model.getTitle());
            binding.textViewBookAuthor.setText(model.getAuthor());

            Integer voiceCount = voiceCountMap.get(model.getId());
            String strVoiceCount = String.format(Locale.getDefault(),
                    resources.getString(R.string.voice_count_format),
                    voiceCount == null ? 0 : voiceCount
            );
            binding.textViewVoiceCount.setText(strVoiceCount);

            if (model.getUrlImage() != null) {
                glide.load(model.getUrlImage())
                        .into(binding.imageViewBook);
            } else {
                glide.clear(binding.imageViewBook);
                binding.imageViewBook.setImageBitmap(null);
            }
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private final Resources resources;
    private final RequestManager glide;
    private OnItemSelectedListener onItemSelectedListener;
    private final Map<String, Integer> voiceCountMap;


    public BookDocsAdapter(Resources resources, RequestManager glide, Map<String, Integer> voiceCountMap) {
        super(new DiffUtilCallback());
        this.resources = resources;
        this.glide = glide;
        this.voiceCountMap = voiceCountMap;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public BookDocViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        BookDocItemBinding binding = BookDocItemBinding.inflate(layoutInflater, parent, false);
        return new BookDocViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull BookDocViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<BookDoc> {

        @Override
        public boolean areItemsTheSame(@NonNull BookDoc oldItem, @NonNull BookDoc newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull BookDoc oldItem, @NonNull BookDoc newItem) {
            return oldItem.equals(newItem);
        }
    }

}