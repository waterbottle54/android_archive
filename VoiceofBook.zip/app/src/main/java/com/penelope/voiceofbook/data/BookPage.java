package com.penelope.voiceofbook.data;

import java.util.ArrayList;
import java.util.List;

public class BookPage {

    private final List<String> phrases;

    public BookPage(List<String> phrases) {
        this.phrases = phrases;
    }

    public BookPage() {
        this.phrases = new ArrayList<>();
    }

    public List<String> getPhrases() {
        return phrases;
    }

    public String getText() {
        StringBuilder sb = new StringBuilder();
        for (String phrase : phrases) {
            sb.append(phrase);
        }
        return sb.toString();
    }

    public int getCharacters() {
        int sum = 0;
        for (String phrase : phrases) {
            sum += phrase.length();
        }
        return sum;
    }

    public void addPhrase(String phrase) {
        phrases.add(phrase);
    }

}
