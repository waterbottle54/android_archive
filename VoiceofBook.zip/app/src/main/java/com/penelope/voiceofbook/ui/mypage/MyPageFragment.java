package com.penelope.voiceofbook.ui.mypage;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.data.voicedoc.VoiceDoc;
import com.penelope.voiceofbook.databinding.FragmentMyPageBinding;
import com.penelope.voiceofbook.ui.MainActivity;
import com.penelope.voiceofbook.ui.playing.playlist.BookDocsAdapter;
import com.penelope.voiceofbook.ui.playing.selectvoice.VoiceDocsAdapter;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MyPageFragment extends Fragment {

    private FragmentMyPageBinding binding;
    private MyPageViewModel viewModel;


    public MyPageFragment() {
        super(R.layout.fragment_my_page);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentMyPageBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(MyPageViewModel.class);

        String strGreeting = String.format(Locale.getDefault(),
                getString(R.string.greeting_format),
                viewModel.getUserId()
        );
        binding.textViewGreeting.setText(strGreeting);

        binding.imageViewSignOut.setOnClickListener(v -> viewModel.onSignOutClick());
        binding.imageViewUnregister.setOnClickListener(v -> viewModel.onUnregisterClick());

        VoiceDocsAdapter voiceDocsAdapter = new VoiceDocsAdapter(getResources());
        binding.recyclerRecording.setAdapter(voiceDocsAdapter);
        binding.recyclerRecording.setHasFixedSize(true);
        voiceDocsAdapter.setOnItemSelectedListener(position -> {
            VoiceDoc voiceDoc = voiceDocsAdapter.getCurrentList().get(position);
            viewModel.onVoiceDocClick(voiceDoc);
        });

        viewModel.getVoiceDocs().observe(getViewLifecycleOwner(), voiceDocs -> {
            if (voiceDocs != null) {
                voiceDocsAdapter.submitList(voiceDocs);
                binding.textViewNoRecordings.setVisibility(voiceDocs.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            }
            binding.progressBarRecordings.setVisibility(View.INVISIBLE);
        });

        viewModel.getVoiceCountMap().observe(getViewLifecycleOwner(), countMap -> {

            BookDocsAdapter adapter = new BookDocsAdapter(getResources(), Glide.with(this), countMap);
            binding.recyclerBook.setAdapter(adapter);
            binding.recyclerBook.setHasFixedSize(true);
            adapter.setOnItemSelectedListener(position -> {
                BookDoc bookDoc = adapter.getCurrentList().get(position);
                viewModel.onBookDocClick(bookDoc);
            });

            viewModel.getBookDocs().observe(getViewLifecycleOwner(), bookDocs -> {
                if (bookDocs != null) {
                    adapter.submitList(bookDocs);
                    binding.textViewNoRecentBooks.setVisibility(bookDocs.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                } else {
                    Toast.makeText(requireContext(), "불러오기에 실패했습니다", Toast.LENGTH_SHORT).show();
                }
                binding.progressBarRecentBooks.setVisibility(View.INVISIBLE);
            });
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof MyPageViewModel.Event.ConfirmSignOut) {
                String message = ((MyPageViewModel.Event.ConfirmSignOut)event).message;
                showConfirmSignOutDialog(message);
            } else if (event instanceof MyPageViewModel.Event.NavigateBack) {
                Intent intent = new Intent(requireContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            } else if (event instanceof MyPageViewModel.Event.NavigateToPlayingVoiceScreen) {
                VoiceDoc voiceDoc = ((MyPageViewModel.Event.NavigateToPlayingVoiceScreen) event).voiceDoc;
                BookDoc bookDoc = ((MyPageViewModel.Event.NavigateToPlayingVoiceScreen) event).bookDoc;
                NavDirections action = MyPageFragmentDirections.actionGlobalPlayingVoiceFragment(bookDoc, voiceDoc);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof MyPageViewModel.Event.ConfirmUnregister) {
                String message = ((MyPageViewModel.Event.ConfirmUnregister)event).message;
                showConfirmUnregisterDialog(message);
            } else if (event instanceof MyPageViewModel.Event.NavigateToSelectVoiceScreen) {
                BookDoc bookDoc = ((MyPageViewModel.Event.NavigateToSelectVoiceScreen) event).bookDoc;
                NavDirections action = MyPageFragmentDirections.actionGlobalSelectVoiceFragment(bookDoc);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void showConfirmSignOutDialog(String message) {
        new AlertDialog.Builder(requireContext())
                .setTitle("로그아웃")
                .setMessage(message)
                .setPositiveButton("네", (dialog, which) -> viewModel.onSignOutConfirmed())
                .setNegativeButton("아니오", null)
                .show();
    }

    private void showConfirmUnregisterDialog(String message) {
        new AlertDialog.Builder(requireContext())
                .setTitle("회원탈퇴")
                .setMessage(message)
                .setPositiveButton("네", (dialog, which) -> viewModel.onUnregisterConfirmed())
                .setNegativeButton("아니오", null)
                .show();
    }

}