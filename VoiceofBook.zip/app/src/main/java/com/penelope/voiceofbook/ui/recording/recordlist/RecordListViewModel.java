package com.penelope.voiceofbook.ui.recording.recordlist;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.data.bookdoc.BookDocRepository;
import com.penelope.voiceofbook.data.voicedoc.VoiceDocRepository;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class RecordListViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<BookDoc>> bookDocs;
    private final LiveData<Map<String, Integer>> voiceCountMap;


    @Inject
    public RecordListViewModel(BookDocRepository bookDocRepository, VoiceDocRepository voiceDocRepository) {

        LiveData<List<String>> filenames = bookDocRepository.getBookDocFiles();
        bookDocs = Transformations.switchMap(filenames, bookDocRepository::getBookDocs);
        voiceCountMap = voiceDocRepository.getVoiceDocCountMap();
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<BookDoc>> getBookDocs() {
        return bookDocs;
    }

    public LiveData<Map<String, Integer>> getVoiceCountMap() {
        return voiceCountMap;
    }

    public void onBookDocClick(BookDoc bookDoc) {
        event.setValue(new Event.NavigateToRecordingScreen(bookDoc));
    }


    public static class Event {

        public static class NavigateToRecordingScreen extends Event {
            public final BookDoc bookDoc;

            public NavigateToRecordingScreen(BookDoc bookDoc) {
                this.bookDoc = bookDoc;
            }
        }
    }

}