package com.penelope.voiceofbook.ui.auth.signin;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.api.auth.SignInApi;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.utils.PreferenceUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SignInViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String userId = "";         // 유저 아이디 값
    private String password = "";       // 비밀번호 값

    private final SignInApi signInApi;
    private final SharedPreferences preferences;


    @Inject
    public SignInViewModel(Application application) {
        signInApi = new SignInApi(application);
        preferences = PreferenceManager.getDefaultSharedPreferences(application);
    }

    public LiveData<Event> getEvent() {
        if (PreferenceUtils.getCurrentUser(preferences) != null) {
            event.setValue(new Event.NavigateToHomeScreen());
        } else {
            event.setValue(null);
        }
        return event;
    }


    public void onUserIdChanged(String value) {
        // 아이디 입력값이 변경되었을 때
        userId = value;
    }

    public void onPasswordChanged(String value) {
        // 비밀번호 입력값이 변경되었을 때
        password = value;
    }

    public void onSignInClicked() {

        // 로그인을 요청했을 때 : 로그인 시도하기

        if (userId.length() < 4) {
            // 에러 : 짧은 아이디
            event.setValue(new Event.ShowShortUserIdMessage("아이디를 4글자 이상 입력해주세요"));
            return;
        }
        if (password.length() < 4) {
            // 에러 : 짧은 패스워드
            event.setValue(new Event.ShowShortPasswordMessage("비밀번호를 4글자 이상 입력해주세요"));
            return;
        }

        signInApi.request(userId, password, new SignInApi.SignInListener() {
            @Override
            public void onSuccess(User user) {
                PreferenceUtils.signIn(preferences, user);
                event.setValue(new Event.NavigateToHomeScreen());
            }

            @Override
            public void onFailure() {
                event.setValue(new Event.ShowSignInFailureMessage("회원정보를 확인해주세요"));
            }
        });
    }

    public void onSignUpClicked() {
        event.setValue(new Event.NavigateToSignUpScreen());
    }


    public static class Event {

        public static class ShowShortUserIdMessage extends Event {
            public final String message;
            public ShowShortUserIdMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowShortPasswordMessage extends Event {
            public final String message;
            public ShowShortPasswordMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowSignInFailureMessage extends Event {
            public final String message;
            public ShowSignInFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToSignUpScreen extends Event {}

        public static class NavigateToHomeScreen extends Event {}
    }

}