package com.penelope.voiceofbook.api;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.penelope.voiceofbook.utils.NameUtils;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UploadJsonRequest extends StringRequest {

    private final Map<String, String> map;

    public UploadJsonRequest(String path, JSONObject jsonObject, Response.Listener<String> listener) {
        super(Method.POST, NameUtils.getUploadJsonUrl(), listener, Throwable::printStackTrace);

        map = new HashMap<>();
        map.put("path", path);
        map.put("jsonObject", jsonObject.toString());
    }

    @Nullable
    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return map;
    }
}
