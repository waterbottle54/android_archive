package com.penelope.voiceofbook.utils;

import android.content.SharedPreferences;

import com.penelope.voiceofbook.data.user.User;

public class PreferenceUtils {

    public static void signIn(SharedPreferences preferences, User user) {
        preferences.edit()
                .putString("id", user.getId())
                .putString("password", user.getPassword())
                .putLong("created", user.getCreated())
                .apply();
    }

    public static void signOut(SharedPreferences preferences) {
        preferences.edit()
                .putString("id", null)
                .putString("password", null)
                .putLong("created", 0)
                .apply();
    }

    public static User getCurrentUser(SharedPreferences preferences) {
        String id = preferences.getString("id", null);
        String password = preferences.getString("password", null);
        long created = preferences.getLong("created", 0);

        if (id == null) {
            return null;
        }

        return new User(id, password, created);
    }

}
