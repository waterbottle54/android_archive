package com.penelope.voiceofbook.ui.recording.recordlist;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.databinding.FragmentRecordListBinding;
import com.penelope.voiceofbook.ui.playing.playlist.BookDocsAdapter;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RecordListFragment extends Fragment {

    private FragmentRecordListBinding binding;
    private RecordListViewModel viewModel;


    public RecordListFragment() {
        super(R.layout.fragment_record_list);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentRecordListBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RecordListViewModel.class);

        viewModel.getVoiceCountMap().observe(getViewLifecycleOwner(), countMap -> {

            BookDocsAdapter adapter = new BookDocsAdapter(getResources(), Glide.with(this), countMap);
            binding.recyclerView.setAdapter(adapter);
            binding.recyclerView.setHasFixedSize(true);
            adapter.setOnItemSelectedListener(position -> {
                BookDoc bookDoc = adapter.getCurrentList().get(position);
                viewModel.onBookDocClick(bookDoc);
            });

            viewModel.getBookDocs().observe(getViewLifecycleOwner(), bookDocs -> {
                if (bookDocs != null) {
                    adapter.submitList(bookDocs);
                    binding.textViewNoBooks.setVisibility(bookDocs.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                } else {
                    Toast.makeText(requireContext(), "불러오기에 실패했습니다", Toast.LENGTH_SHORT).show();
                }
                binding.progressBar.setVisibility(View.INVISIBLE);
            });
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof RecordListViewModel.Event.NavigateToRecordingScreen) {
                BookDoc bookDoc = ((RecordListViewModel.Event.NavigateToRecordingScreen) event).bookDoc;
                NavDirections action = RecordListFragmentDirections.actionRecordListFragmentToRecordingFragment(bookDoc);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}