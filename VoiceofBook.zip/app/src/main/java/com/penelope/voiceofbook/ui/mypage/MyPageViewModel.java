package com.penelope.voiceofbook.ui.mypage;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.api.auth.GetRecentApi;
import com.penelope.voiceofbook.api.auth.UnregisterApi;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.data.bookdoc.BookDocRepository;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.data.voicedoc.VoiceDoc;
import com.penelope.voiceofbook.data.voicedoc.VoiceDocRepository;
import com.penelope.voiceofbook.ui.home.HomeViewModel;
import com.penelope.voiceofbook.ui.playing.playlist.PlayListViewModel;
import com.penelope.voiceofbook.utils.PreferenceUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class MyPageViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<VoiceDoc>> voiceDocs;
    private final MutableLiveData<List<BookDoc>> bookDocs = new MutableLiveData<>(new ArrayList<>());
    private final LiveData<Map<String, Integer>> voiceCountMap;

    private final String userId;

    private final BookDocRepository bookDocRepository;
    private final SharedPreferences preferences;
    private final Application application;


    @Inject
    public MyPageViewModel(Application application, VoiceDocRepository voiceDocRepository, BookDocRepository bookDocRepository) {

        this.application = application;
        preferences = PreferenceManager.getDefaultSharedPreferences(application);
        User user = PreferenceUtils.getCurrentUser(preferences);
        assert user != null;

        this.userId = user.getId();

        LiveData<List<String>> files = voiceDocRepository.findVoiceDocFilesByRecorder(userId);
        voiceDocs = Transformations.switchMap(files, voiceDocRepository::getVoiceDocs);

        new GetRecentApi(application).request(user.getId(), new GetRecentApi.GetRecentListener() {
            @Override
            public void onSuccess(String recent) {
                if (recent.isEmpty()) {
                    bookDocs.postValue(new ArrayList<>());
                }
                String[] idList = recent.split(";");
                for (String id : idList) {
                    bookDocRepository.getBookDoc(id + ".json", result -> {
                        List<BookDoc> oldList = bookDocs.getValue();
                        assert oldList != null;
                        List<BookDoc> newList = new ArrayList<>(oldList);
                        newList.add(0, result);
                        bookDocs.postValue(newList);
                    }, e -> {
                    });
                }
            }

            @Override
            public void onFailure() {
                bookDocs.postValue(null);
            }
        });

        voiceCountMap = voiceDocRepository.getVoiceDocCountMap();

        this.bookDocRepository = bookDocRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<VoiceDoc>> getVoiceDocs() {
        return voiceDocs;
    }

    public LiveData<List<BookDoc>> getBookDocs() {
        return bookDocs;
    }

    public LiveData<Map<String, Integer>> getVoiceCountMap() {
        return voiceCountMap;
    }

    public String getUserId() {
        return userId;
    }


    public void onVoiceDocClick(VoiceDoc voiceDoc) {
        bookDocRepository.getBookDoc(voiceDoc.getBookDocId() + ".json",
                result -> event.setValue(new Event.NavigateToPlayingVoiceScreen(voiceDoc, result)),
                e -> {
                }
        );
    }

    public void onSignOutClick() {
        event.setValue(new Event.ConfirmSignOut("로그아웃 하시겠습니까?"));
    }

    public void onSignOutConfirmed() {
        PreferenceUtils.signOut(preferences);
        event.setValue(new Event.NavigateBack());
    }

    public void onUnregisterClick() {
        event.setValue(new Event.ConfirmUnregister("회원 탈퇴 하시겠습니까?"));
    }

    public void onUnregisterConfirmed() {
        new UnregisterApi(application).request(userId, new UnregisterApi.UnregisterListener() {
            @Override
            public void onSuccess() {
                PreferenceUtils.signOut(preferences);
                event.setValue(new Event.NavigateBack());
            }

            @Override
            public void onFailure() {
                Log.d("TAG", "onFailure: unregister");
            }
        });
    }

    public void onBookDocClick(BookDoc bookDoc) {
        event.setValue(new Event.NavigateToSelectVoiceScreen(bookDoc));
    }


    public static class Event {

        public static class NavigateToPlayingVoiceScreen extends Event {
            public final VoiceDoc voiceDoc;
            public final BookDoc bookDoc;

            public NavigateToPlayingVoiceScreen(VoiceDoc voiceDoc, BookDoc bookDoc) {
                this.voiceDoc = voiceDoc;
                this.bookDoc = bookDoc;
            }
        }

        public static class ConfirmSignOut extends Event {
            public final String message;

            public ConfirmSignOut(String message) {
                this.message = message;
            }
        }

        public static class NavigateBack extends Event {
        }

        public static class ConfirmUnregister extends Event {
            public final String message;

            public ConfirmUnregister(String message) {
                this.message = message;
            }
        }

        public static class NavigateToSelectVoiceScreen extends Event {
            public final BookDoc bookDoc;

            public NavigateToSelectVoiceScreen(BookDoc bookDoc) {
                this.bookDoc = bookDoc;
            }
        }
    }

}