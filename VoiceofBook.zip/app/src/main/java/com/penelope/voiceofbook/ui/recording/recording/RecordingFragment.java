package com.penelope.voiceofbook.ui.recording.recording;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.databinding.FragmentRecordingBinding;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RecordingFragment extends Fragment {

    private static final String TAG = "RecordingFragment";

    private FragmentRecordingBinding binding;
    private RecordingViewModel viewModel;
    private ActivityResultLauncher<String[]> audioPermissionLauncher;

    private MediaRecorder mediaRecorder;


    public RecordingFragment() {
        super(R.layout.fragment_recording);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        audioPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    Boolean recordAudio = result.get(Manifest.permission.RECORD_AUDIO);
                    Boolean writeExternal = result.get(Manifest.permission.WRITE_EXTERNAL_STORAGE);
                    if (recordAudio != null && recordAudio && writeExternal != null && writeExternal) {
                        configureMediaRecorder();
                    } else {
                        Toast.makeText(requireContext(), "No Permission, No Recording", Toast.LENGTH_SHORT).show();
                        Navigation.findNavController(requireView()).popBackStack();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentRecordingBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RecordingViewModel.class);

        if (requireContext().checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                && requireContext().checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            configureMediaRecorder();
        } else {
            audioPermissionLauncher.launch(new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            });
        }

        binding.textViewBookTitle.setText(viewModel.getBookTitle());
        binding.textViewBookAuthor.setText(viewModel.getBookAuthor());
        Glide.with(this).load(viewModel.getBookImage()).into(binding.imageViewBook);

        binding.imageViewSave.setOnClickListener(v -> viewModel.onSaveClick());
        binding.imageViewNextPage.setOnClickListener(v -> viewModel.onNextPageClick());
        binding.imageViewRecordPause.setOnClickListener(v -> viewModel.onRecordPauseClick());

        viewModel.getPage().observe(getViewLifecycleOwner(), bookPage -> {
            if (bookPage != null) {
                binding.textViewPage.setText(bookPage.getText());
            }
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.isRecording().observe(getViewLifecycleOwner(), isRecording -> {
            binding.imageViewRecordPause.setImageResource(isRecording ? R.drawable.ic_pause : R.drawable.ic_recording);
            binding.imageViewNextPage.setEnabled(isRecording);
        });

        viewModel.getTotalPages().observe(getViewLifecycleOwner(), totalPages ->
                viewModel.getPageIndex().observe(getViewLifecycleOwner(), pageIndex -> {
                    String strPageIndex = (pageIndex + 1) + "/" + totalPages;
                    binding.textViewPageIndex.setText(strPageIndex);
                })
        );

        viewModel.isLastPage().observe(getViewLifecycleOwner(), isLastPage ->
                binding.imageViewSave.setEnabled(isLastPage));

        viewModel.getDuration().observe(getViewLifecycleOwner(), duration -> {
            long seconds = duration / 1000;
            String strDuration = String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60);
            binding.textViewDuration.setText(strDuration);
        });

        viewModel.isFinished().observe(getViewLifecycleOwner(), isFinished -> {
            if (isFinished) {
                binding.imageViewSave.setEnabled(false);
                binding.imageViewRecordPause.setEnabled(false);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof RecordingViewModel.Event.ShowGeneralMessage) {
                String message = ((RecordingViewModel.Event.ShowGeneralMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof RecordingViewModel.Event.PauseRecording) {
                Log.d(TAG, "PauseRecording: ");
                mediaRecorder.pause();
            } else if (event instanceof RecordingViewModel.Event.ResumeRecording) {
                Log.d(TAG, "ResumeRecording: ");
                mediaRecorder.resume();
            } else if (event instanceof RecordingViewModel.Event.FinishRecording) {
                Log.d(TAG, "FinishRecording: ");
                mediaRecorder.stop();
                mediaRecorder.release();
            } else if (event instanceof RecordingViewModel.Event.StartRecording) {
                Log.d(TAG, "StartRecording: ");
                mediaRecorder.start();
                Snackbar.make(requireView(), "녹음을 시작합니다", Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof RecordingViewModel.Event.UploadVoiceFile) {
                String path = Environment.getExternalStorageDirectory().getPath();
                new UploadFileAsync().execute(path + "/" + viewModel.getVoiceDocId() + ".mp3");
            }
        });

        long tick = 1000;
        new CountDownTimer(86400 * 1000, tick) {
            @Override
            public void onTick(long l) {
                viewModel.onTick(tick);
            }

            @Override
            public void onFinish() {
            }
        }.start();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void configureMediaRecorder() {

        mediaRecorder = new MediaRecorder();
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
        mediaRecorder.setAudioChannels(1);
        mediaRecorder.setAudioEncodingBitRate(128000);
        mediaRecorder.setAudioSamplingRate(48000);

        String path = Environment.getExternalStorageDirectory().getPath();
        mediaRecorder.setOutputFile(path + "/" + viewModel.getVoiceDocId() + ".mp3");
        try {
            mediaRecorder.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @SuppressLint("StaticFieldLeak")
    private class UploadFileAsync extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            try {
                String sourceFileUri = params[0];

                HttpURLConnection conn;
                DataOutputStream dos;
                String lineEnd = "\r\n";
                String twoHyphens = "--";
                String boundary = "*****";
                int bytesRead, bytesAvailable, bufferSize;
                byte[] buffer;
                int maxBufferSize = 1024 * 1024;
                File sourceFile = new File(sourceFileUri);

                if (sourceFile.isFile()) {

                    try {
                        String upLoadServerUri = "http://waterbottle54.dothome.co.kr/UploadFile.php?";

                        // open a URL connection to the Servlet
                        FileInputStream fileInputStream = new FileInputStream(sourceFile);
                        URL url = new URL(upLoadServerUri);

                        // Open a HTTP connection to the URL
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setDoInput(true); // Allow Inputs
                        conn.setDoOutput(true); // Allow Outputs
                        conn.setUseCaches(false); // Don't use a Cached Copy
                        conn.setRequestMethod("POST");
                        conn.setRequestProperty("Connection", "Keep-Alive");
                        conn.setRequestProperty("ENCTYPE",
                                "multipart/form-data");
                        conn.setRequestProperty("Content-Type",
                                "multipart/form-data;boundary=" + boundary);
                        conn.setRequestProperty("bill", sourceFileUri);

                        dos = new DataOutputStream(conn.getOutputStream());

                        dos.writeBytes(twoHyphens + boundary + lineEnd);
                        dos.writeBytes("Content-Disposition: form-data; name=\"bill\";filename=\""
                                + sourceFileUri + "\"" + lineEnd);

                        dos.writeBytes(lineEnd);

                        // create a buffer of maximum size
                        bytesAvailable = fileInputStream.available();

                        bufferSize = Math.min(bytesAvailable, maxBufferSize);
                        buffer = new byte[bufferSize];

                        // read file and write it into form...
                        bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                        while (bytesRead > 0) {

                            dos.write(buffer, 0, bufferSize);
                            bytesAvailable = fileInputStream.available();
                            bufferSize = Math
                                    .min(bytesAvailable, maxBufferSize);
                            bytesRead = fileInputStream.read(buffer, 0,
                                    bufferSize);

                        }

                        // send multipart form data necesssary after file
                        // data...
                        dos.writeBytes(lineEnd);
                        dos.writeBytes(twoHyphens + boundary + twoHyphens
                                + lineEnd);

                        // Responses from the server (code and message)
                        int serverResponseCode = conn.getResponseCode();
                        String serverResponseMessage = conn.getResponseMessage();

                        if (serverResponseCode == 200) {
                            Log.d(TAG, "doInBackground: File upload completed - " + serverResponseMessage);
                        }

                        // close the streams
                        fileInputStream.close();
                        dos.flush();
                        dos.close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return "Executed";
        }

        @Override
        protected void onPostExecute(String result) {
            viewModel.onVoiceFileUploaded();
        }

        @Override
        protected void onPreExecute() {
        }

        @Override
        protected void onProgressUpdate(Void... values) {
        }
    }

}