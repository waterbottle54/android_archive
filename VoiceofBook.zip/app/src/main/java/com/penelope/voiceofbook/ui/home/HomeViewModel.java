package com.penelope.voiceofbook.ui.home;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.utils.PreferenceUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HomeViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final SharedPreferences preferences;

    @Inject
    public HomeViewModel(Application application) {
        preferences = PreferenceManager.getDefaultSharedPreferences(application);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public void onBackClick() {
        event.setValue(new Event.ConfirmSignOut("로그아웃 하시겠습니까?"));
    }

    public void onSignOutConfirmed() {
        PreferenceUtils.signOut(preferences);
        event.setValue(new Event.NavigateBack());
    }


    public static class Event {

        public static class ConfirmSignOut extends Event {
            public final String message;
            public ConfirmSignOut(String message) {
                this.message = message;
            }
        }

        public static class NavigateBack extends Event { }
    }

}