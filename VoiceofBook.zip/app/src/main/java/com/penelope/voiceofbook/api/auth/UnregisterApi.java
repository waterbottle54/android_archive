package com.penelope.voiceofbook.api.auth;

import android.content.Context;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.penelope.voiceofbook.utils.NameUtils;

import java.util.HashMap;
import java.util.Map;

public class UnregisterApi {

    static class UnregisterRequest extends StringRequest {

        private final Map<String, String> map;

        public UnregisterRequest(String id, Response.Listener<String> listener) {
            super(Method.POST, NameUtils.getUnregisterUrl(), listener, Throwable::printStackTrace);

            map = new HashMap<>();
            map.put("id", id);
        }

        @Nullable
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return map;
        }
    }

    public interface UnregisterListener {
        void onSuccess();
        void onFailure();
    }


    private final Context context;

    public UnregisterApi(Context context) {
        this.context = context;
    }

    public void request(String id, UnregisterListener listener) {

        Response.Listener<String> responseListener = response -> {
            listener.onSuccess();
        };

        UnregisterRequest request = new UnregisterRequest(id, responseListener);
        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(request);
    }

}
