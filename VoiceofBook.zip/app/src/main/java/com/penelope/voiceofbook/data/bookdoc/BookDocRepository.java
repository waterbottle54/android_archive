package com.penelope.voiceofbook.data.bookdoc;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.penelope.voiceofbook.api.ListRequest;
import com.penelope.voiceofbook.api.ReadRequest;
import com.penelope.voiceofbook.data.BookPage;
import com.penelope.voiceofbook.utils.OnFailureListener;
import com.penelope.voiceofbook.utils.OnSuccessListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class BookDocRepository {

    private final Application application;

    @Inject
    public BookDocRepository(Application application) {
        this.application = application;
    }

    public void getBookDocFiles(OnSuccessListener<List<String>> onSuccessListener, OnFailureListener onFailureListener) {

        Response.Listener<String> responseListener = response -> {
            try {
                JSONArray jsonArray = new JSONArray(response);
                List<String> bookDocs = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    bookDocs.add(jsonArray.getString(i));
                }
                onSuccessListener.onSuccess(bookDocs);
            } catch (JSONException e) {
                e.printStackTrace();
                onFailureListener.onFailure(e);
            }
        };

        RequestQueue queue = Volley.newRequestQueue(application);
        ListRequest request = new ListRequest("bookdocs", responseListener);
        request.setRetryPolicy(new DefaultRetryPolicy(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }

    public LiveData<List<String>> getBookDocFiles() {
        MutableLiveData<List<String>> files = new MutableLiveData<>();
        getBookDocFiles(files::setValue, e -> files.setValue(null));
        return files;
    }

    public void getBookDoc(String filename, OnSuccessListener<BookDoc> onSuccessListener, OnFailureListener onFailureListener) {

        Response.Listener<String> responseListener = response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                String id = jsonObject.getString("id");
                String title = jsonObject.getString("title");
                String author = jsonObject.getString("author");
                String image = jsonObject.getString("image");
                BookDoc bookDoc = new BookDoc(id, title, author, image);
                onSuccessListener.onSuccess(bookDoc);
            } catch (JSONException e) {
                e.printStackTrace();
                onFailureListener.onFailure(e);
            }
        };

        RequestQueue queue = Volley.newRequestQueue(application);
        ReadRequest request = new ReadRequest("bookdocs/" + filename, responseListener);
        request.setRetryPolicy(new DefaultRetryPolicy(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }

    public LiveData<List<BookDoc>> getBookDocs(List<String> filenames) {

        MutableLiveData<List<BookDoc>> bookDocs = new MutableLiveData<>(new ArrayList<>());

        if (filenames == null) {
            bookDocs.setValue(null);
            return bookDocs;
        }

        for (String filename : filenames) {
            getBookDoc(filename,
                    bookDoc -> {
                        List<BookDoc> bookDocList = bookDocs.getValue();
                        assert bookDocList != null;

                        List<BookDoc> copy = new ArrayList<>(bookDocList);
                        copy.add(bookDoc);
                        bookDocs.setValue(copy);
                    }, e -> {

                    });
        }

        return bookDocs;
    }

    public void getBookText(BookDoc bookDoc, OnSuccessListener<String> onSuccessListener, OnFailureListener onFailureListener) {

        Response.Listener<String> responseListener = onSuccessListener::onSuccess;

        RequestQueue queue = Volley.newRequestQueue(application);
        ReadRequest request = new ReadRequest("texts/" + bookDoc.getId() + ".txt", responseListener);
        request.setRetryPolicy(new DefaultRetryPolicy(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }

    public LiveData<String> getBookText(BookDoc bookDoc) {
        MutableLiveData<String> text = new MutableLiveData<>();
        getBookText(bookDoc, text::setValue, Throwable::printStackTrace);
        return text;
    }

    public LiveData<List<BookPage>> getBookPages(BookDoc bookDoc) {

        LiveData<String> text = getBookText(bookDoc);
        return Transformations.map(text, textValue -> {
            List<BookPage> pageList = new ArrayList<>();
            String[] phrases = textValue.split("\\.");
            BookPage page = new BookPage();
            for (int i = 0; i < phrases.length; i++) {
                String phrase = phrases[i];
                page.addPhrase(phrase + ".");
                if (page.getCharacters() > 100) {
                    pageList.add(page);
                    page = new BookPage();
                } else if (i == phrases.length - 1) {
                    pageList.add(page);
                }
            }
            return pageList;
        });
    }

}
