package com.penelope.voiceofbook.ui.recording.recording;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.data.BookPage;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.data.bookdoc.BookDocRepository;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.data.voicedoc.VoiceDoc;
import com.penelope.voiceofbook.data.voicedoc.VoiceDocRepository;
import com.penelope.voiceofbook.utils.PreferenceUtils;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class RecordingViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final BookDoc bookDoc;

    private final LiveData<List<BookPage>> pages;
    private final LiveData<BookPage> page;
    private final MutableLiveData<Integer> pageIndex = new MutableLiveData<>(0);
    private final LiveData<Integer> totalPages;
    private final LiveData<Boolean> isLastPage;

    private final MutableLiveData<Boolean> isRecording = new MutableLiveData<>(false);
    private final MutableLiveData<Long> duration = new MutableLiveData<>(0L);

    private final List<Long> midpoints = new ArrayList<>();

    private boolean hasStarted;
    private long millisStarted;
    private final MutableLiveData<Boolean> isFinished = new MutableLiveData<>(false);

    private final VoiceDocRepository voiceDocRepository;
    private final SharedPreferences preferences;


    @Inject
    public RecordingViewModel(SavedStateHandle savedStateHandle,
                              Application application,
                              BookDocRepository bookDocRepository,
                              VoiceDocRepository voiceDocRepository) {

        bookDoc = savedStateHandle.get("bookDoc");
        preferences = PreferenceManager.getDefaultSharedPreferences(application);
        this.voiceDocRepository = voiceDocRepository;

        LiveData<String> text = bookDocRepository.getBookText(bookDoc);
        pages = Transformations.map(text, textValue -> {
            List<BookPage> pageList = new ArrayList<>();
            String[] phrases = textValue.split("\\.");
            BookPage page = new BookPage();
            for (int i = 0; i < phrases.length; i++) {
                String phrase = phrases[i];
                page.addPhrase(phrase + ".");
                if (page.getCharacters() > 100) {
                    pageList.add(page);
                    page = new BookPage();
                } else if (i == phrases.length - 1) {
                    pageList.add(page);
                }
            }
            return pageList;
        });

        page = Transformations.switchMap(pages, pageList ->
                Transformations.map(pageIndex, index -> {
                    if (index < 0 || index > pageList.size() - 1) {
                        return null;
                    }
                    return pageList.get(index);
                })
        );

        totalPages = Transformations.map(pages, pageList -> pageList == null ? 0 : pageList.size());
        isLastPage = Transformations.switchMap(totalPages, tp ->
                Transformations.map(pageIndex, index -> {
                    if (tp == null || index == null) {
                        return false;
                    }
                    return (index + 1 == tp);
                })
        );

        millisStarted = System.currentTimeMillis();
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<BookPage> getPage() {
        return page;
    }

    public String getBookTitle() {
        return bookDoc.getTitle();
    }

    public String getBookImage() {
        return bookDoc.getUrlImage();
    }

    public String getBookAuthor() {
        return bookDoc.getAuthor();
    }

    public LiveData<Integer> getPageIndex() {
        return pageIndex;
    }

    public LiveData<Integer> getTotalPages() {
        return totalPages;
    }

    public LiveData<Boolean> isRecording() {
        return isRecording;
    }

    public LiveData<Boolean> isLastPage() {
        return isLastPage;
    }

    public LiveData<Long> getDuration() {
        return duration;
    }

    public String getVoiceDocId() {
        User user = PreferenceUtils.getCurrentUser(preferences);
        if (user == null) {
            return null;
        }
        return new VoiceDoc(bookDoc.getId(), user.getId(), millisStarted, 0, new ArrayList<>()).getId();
    }

    public LiveData<Boolean> isFinished() {
        return isFinished;
    }


    public void onNextPageClick() {

        Boolean isRecordingValue = isRecording.getValue();
        Long durationValue = duration.getValue();
        assert isRecordingValue != null && durationValue != null;
        if (!isRecordingValue) {
            return;
        }

        Integer pageIndexValue = pageIndex.getValue();
        assert pageIndexValue != null;

        List<BookPage> pageListValue = pages.getValue();
        BookPage pageValue = page.getValue();
        if (pageListValue == null || pageValue == null) {
            return;
        }

        if (pageIndexValue < pageListValue.size() - 1) {
            pageIndex.setValue(pageIndexValue + 1);
            midpoints.add(durationValue);
        }
    }

    public void onRecordPauseClick() {

        Boolean isRecordingValue = isRecording.getValue();
        assert isRecordingValue != null;

        isRecordingValue = !isRecordingValue;
        isRecording.setValue(isRecordingValue);

        if (isRecordingValue && !hasStarted) {
            event.setValue(new Event.StartRecording());
            hasStarted = true;
        } else if (isRecordingValue) {
            event.setValue(new Event.ResumeRecording());
        } else {
            event.setValue(new Event.PauseRecording());
        }
    }

    public void onSaveClick() {

        User user = PreferenceUtils.getCurrentUser(preferences);
        Boolean isLastPageValue = isLastPage.getValue();
        Integer totalPagesValue = totalPages.getValue();
        Long durationValue = duration.getValue();
        assert durationValue != null;
        if (isLastPageValue == null || totalPagesValue == null || user == null) {
            return;
        }

        if (!isLastPageValue || midpoints.size() != totalPagesValue - 1) {
            return;
        }

        VoiceDoc voiceDoc = new VoiceDoc(bookDoc.getId(), user.getId(), millisStarted, durationValue, midpoints);
        voiceDocRepository.addVoiceDoc(voiceDoc,
                result -> event.setValue(new Event.UploadVoiceFile()),
                e -> event.setValue(new Event.ShowGeneralMessage("음반 저장에 실패했습니다"))
        );

        event.setValue(new Event.FinishRecording());
        isFinished.setValue(true);
    }

    public void onTick(long millis) {

        Boolean isFinishedValue = isFinished.getValue();
        assert isFinishedValue != null;
        if (isFinishedValue) {
            return;
        }

        Boolean isRecordingValue = isRecording.getValue();
        Long durationValue = duration.getValue();
        assert isRecordingValue != null && durationValue != null;

        if (isRecordingValue) {
            duration.setValue(durationValue + millis);
        }
    }

    public void onVoiceFileUploaded() {
        event.setValue(new Event.ShowGeneralMessage("음성 파일이 업로드되었습니다"));
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class StartRecording extends Event {

        }

        public static class PauseRecording extends Event {

        }

        public static class ResumeRecording extends Event {

        }

        public static class FinishRecording extends Event {

        }

        public static class UploadVoiceFile extends Event {

        }

    }

}







