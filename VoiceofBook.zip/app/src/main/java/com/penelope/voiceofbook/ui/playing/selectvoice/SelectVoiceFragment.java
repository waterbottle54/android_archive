package com.penelope.voiceofbook.ui.playing.selectvoice;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.data.voicedoc.VoiceDoc;
import com.penelope.voiceofbook.databinding.FragmentSelectVoiceBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SelectVoiceFragment extends DialogFragment {

    private FragmentSelectVoiceBinding binding;
    private SelectVoiceViewModel viewModel;


    public SelectVoiceFragment() {
        super(R.layout.fragment_select_voice);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSelectVoiceBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SelectVoiceViewModel.class);

        binding.textViewBookTitle.setText(viewModel.getBookTitle());
        binding.buttonListenTTS.setOnClickListener(v -> viewModel.onListenTTSClick());

        VoiceDocsAdapter adapter = new VoiceDocsAdapter(getResources());
        binding.recyclerViewVoice.setAdapter(adapter);
        binding.recyclerViewVoice.setHasFixedSize(true);
        adapter.setOnItemSelectedListener(position -> {
            VoiceDoc voiceDoc = adapter.getCurrentList().get(position);
            viewModel.onVoiceDocClick(voiceDoc);
        });

        viewModel.getVoiceDocs().observe(getViewLifecycleOwner(), voiceDocs -> {
            if (voiceDocs != null) {
                adapter.submitList(voiceDocs);
                binding.textViewNoVoices.setVisibility(voiceDocs.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            } else {
                Toast.makeText(requireContext(), "불러오기에 실패했습니다", Toast.LENGTH_SHORT).show();
            }
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SelectVoiceViewModel.Event.NavigateToPlayingScreen) {
                BookDoc bookDoc = ((SelectVoiceViewModel.Event.NavigateToPlayingScreen) event).bookDoc;
                NavDirections action = SelectVoiceFragmentDirections.actionSelectVoiceFragmentToPlayingFragment(bookDoc);
                NavHostFragment.findNavController(this).navigate(action);
            } else if (event instanceof SelectVoiceViewModel.Event.NavigateToPlayingVoiceScreen) {
                BookDoc bookDoc = ((SelectVoiceViewModel.Event.NavigateToPlayingVoiceScreen) event).bookDoc;
                VoiceDoc voiceDoc = ((SelectVoiceViewModel.Event.NavigateToPlayingVoiceScreen) event).voiceDoc;
                NavDirections action = SelectVoiceFragmentDirections.actionSelectVoiceFragmentToPlayingVoiceFragment(bookDoc, voiceDoc);
                NavHostFragment.findNavController(this).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}