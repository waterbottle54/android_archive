package com.penelope.voiceofbook.api.auth;

import android.content.Context;
import android.util.Log;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.utils.NameUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignInApi {

    static class SignInRequest extends StringRequest {

        private final Map<String, String> map;

        public SignInRequest(String id, String password, Response.Listener<String> listener) {
            super(Method.POST, NameUtils.getSignInUrl(), listener, Throwable::printStackTrace);

            map = new HashMap<>();
            map.put("id", id);
            map.put("password", password);
        }

        @Nullable
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return map;
        }
    }

    public interface SignInListener {
        void onSuccess(User user);
        void onFailure();
    }


    private final Context context;

    public SignInApi(Context context) {
        this.context = context;
    }

    public void request(String id, String password, SignInListener listener) {

        Response.Listener<String> responseListener = response -> {
            Log.d("TAG", "request: " + response);
            try {
                JSONObject jsonResponse = new JSONObject(response);
                boolean success = jsonResponse.getBoolean("success");

                if (success) {
                    long created = jsonResponse.getLong("created");
                    User user = new User(id, password, created);
                    listener.onSuccess(user);
                } else {
                    listener.onFailure();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                listener.onFailure();
            }
        };

        SignInRequest request = new SignInRequest(id, password, responseListener);
        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(request);
    }

}


