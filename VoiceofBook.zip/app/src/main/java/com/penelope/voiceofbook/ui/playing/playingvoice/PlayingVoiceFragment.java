package com.penelope.voiceofbook.ui.playing.playingvoice;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.databinding.FragmentPlayingVoiceBinding;
import com.penelope.voiceofbook.ui.playing.playing.PlayingViewModel;

import java.io.IOException;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PlayingVoiceFragment extends Fragment {

    private FragmentPlayingVoiceBinding binding;
    private PlayingVoiceViewModel viewModel;

    private MediaPlayer mediaPlayer;


    public PlayingVoiceFragment() {
        super(R.layout.fragment_playing_voice);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPlayingVoiceBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PlayingVoiceViewModel.class);

        binding.textViewBookTitle.setText(viewModel.getBookTitle());
        binding.textViewBookAuthor.setText(viewModel.getBookAuthor());
        Glide.with(this).load(viewModel.getBookImage()).into(binding.imageViewBook);

        binding.imageViewPrevPage.setOnClickListener(v -> viewModel.onPrevPageClick());
        binding.imageViewNextPage.setOnClickListener(v -> viewModel.onNextPageClick());
        binding.imageViewPlayPause.setOnClickListener(v -> viewModel.onPlayPauseClick());

        viewModel.getPage().observe(getViewLifecycleOwner(), bookPage -> {
            if (bookPage != null) {
                binding.textViewPage.setText(bookPage.getText());
                binding.progressBar.setVisibility(View.INVISIBLE);
            }
        });

        viewModel.getTotalPages().observe(getViewLifecycleOwner(), totalPages ->
                viewModel.getPageIndex().observe(getViewLifecycleOwner(), pageIndex -> {
                    String strPageIndex = (pageIndex + 1) + "/" + totalPages;
                    binding.textViewPageIndex.setText(strPageIndex);
                })
        );

        viewModel.isPlaying().observe(getViewLifecycleOwner(), isPlaying ->
                binding.imageViewPlayPause.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play)
        );

        viewModel.getElapsed().observe(getViewLifecycleOwner(), elapsed -> {
            elapsed = Math.min(elapsed, viewModel.getDuration()) / 1000;
            long duration = viewModel.getDuration() / 1000;
            String strTime = String.format(Locale.getDefault(), "%02d:%02d/%02d:%02d",
                    elapsed / 60, elapsed % 60,
                    duration / 60, duration % 60
            );
            binding.textViewTime.setText(strTime);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PlayingVoiceViewModel.Event.ShowBookFinishedMessage) {
                String message = ((PlayingVoiceViewModel.Event.ShowBookFinishedMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
                binding.imageViewPlayPause.setEnabled(false);
                binding.imageViewNextPage.setEnabled(false);
                binding.imageViewPrevPage.setEnabled(false);
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            } else if (event instanceof PlayingVoiceViewModel.Event.PauseSpeech) {
                mediaPlayer.pause();
            } else if (event instanceof PlayingVoiceViewModel.Event.ResumeSpeech) {
                long elapsed = ((PlayingVoiceViewModel.Event.ResumeSpeech) event).elapsed;
                mediaPlayer.seekTo((int)elapsed);
                mediaPlayer.start();
            } else if (event instanceof PlayingVoiceViewModel.Event.SeekTo) {
                long millis = ((PlayingVoiceViewModel.Event.SeekTo) event).millis;
                mediaPlayer.seekTo((int)millis);
            } else if (event instanceof PlayingVoiceViewModel.Event.StartSpeech) {
                requireView().postDelayed(() -> viewModel.onLoaded(), 1000);
                String url = ((PlayingVoiceViewModel.Event.StartSpeech) event).url;
                mediaPlayer = new MediaPlayer();
                try {
                    mediaPlayer.setDataSource(url);
                    mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        long tick = 1000;
        new CountDownTimer(86400 * 1000, tick) {
            @Override
            public void onTick(long l) {
                viewModel.onTick(tick);
            }

            @Override
            public void onFinish() {
            }
        }.start();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mediaPlayer != null) {
            mediaPlayer.pause();
        }
    }
}