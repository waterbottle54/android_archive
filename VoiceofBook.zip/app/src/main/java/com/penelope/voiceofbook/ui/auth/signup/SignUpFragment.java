package com.penelope.voiceofbook.ui.auth.signup;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;
import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.databinding.FragmentSignUpBinding;
import com.penelope.voiceofbook.utils.OnTextChangedListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SignUpFragment extends Fragment {

    private FragmentSignUpBinding binding;
    private SignUpViewModel viewModel;


    public SignUpFragment() {
        super(R.layout.fragment_sign_up);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSignUpBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SignUpViewModel.class);

        // UI 에 리스너 부여

        binding.editTextUserId.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onUserIdChanged(text);
            }
        });
        binding.editTextPassword.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onPasswordChanged(text);
            }
        });
        binding.editTextPasswordConfirm.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onPasswordConfirmChanged(text);
            }
        });
        binding.buttonSignUp.setOnClickListener(v -> viewModel.onSignUpClick());
        binding.textViewSignIn.setOnClickListener(v -> viewModel.onSignInClick());


        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SignUpViewModel.Event.ShowShortUserIdMessage) {
                hideKeyboard(requireView());
                Snackbar.make(requireView(),
                        ((SignUpViewModel.Event.ShowShortUserIdMessage)event).message,
                        Snackbar.LENGTH_SHORT)
                        .show();
            } else if (event instanceof SignUpViewModel.Event.ShowShortPasswordMessage) {
                hideKeyboard(requireView());
                Snackbar.make(requireView(),
                        ((SignUpViewModel.Event.ShowShortPasswordMessage)event).message,
                        Snackbar.LENGTH_SHORT)
                        .show();
            } else if (event instanceof SignUpViewModel.Event.ShowIncorrectPasswordConfirmMessage) {
                hideKeyboard(requireView());
                Snackbar.make(requireView(),
                        ((SignUpViewModel.Event.ShowIncorrectPasswordConfirmMessage)event).message,
                        Snackbar.LENGTH_SHORT)
                        .show();
            } else if (event instanceof SignUpViewModel.Event.ShowSignUpFailureMessage) {
                hideKeyboard(requireView());
                Snackbar.make(requireView(),
                        ((SignUpViewModel.Event.ShowSignUpFailureMessage)event).message,
                        Snackbar.LENGTH_SHORT)
                        .show();
            } else if (event instanceof SignUpViewModel.Event.NavigateToHomeScreen) {
                NavDirections action = SignUpFragmentDirections.actionSignUpFragmentToHomeFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof SignUpViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}