package com.penelope.voiceofbook.data.bookdoc;

import java.io.Serializable;
import java.util.Objects;

public class BookDoc implements Serializable {

    private final String id;
    private final String title;
    private final String author;
    private final String urlImage;

    public BookDoc(String id, String title, String author, String urlImage) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.urlImage = urlImage;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getUrlImage() {
        return urlImage;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BookDoc bookDoc = (BookDoc) o;
        return id.equals(bookDoc.id) && title.equals(bookDoc.title) && author.equals(bookDoc.author) && urlImage.equals(bookDoc.urlImage);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, author, urlImage);
    }
}
