package com.penelope.voiceofbook.data.voicedoc;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class VoiceDoc implements Serializable {

    private final String id;
    private final String bookDocId;
    private final String recorder;
    private final long recorded;
    private final long duration;
    private final List<Long> midpointList;

    public VoiceDoc(String id, String bookDocId, String recorder, long recorded, long duration, List<Long> midpointList) {
        this.id = id;
        this.bookDocId = bookDocId;
        this.recorder = recorder;
        this.recorded = recorded;
        this.duration = duration;
        this.midpointList = midpointList;
    }

    public VoiceDoc(String bookDocId, String recorder, long recorded, long duration, List<Long> midpointList) {
        this.id = bookDocId + "#" + recorder + "#" + recorded;
        this.bookDocId = bookDocId;
        this.recorder = recorder;
        this.recorded = recorded;
        this.duration = duration;
        this.midpointList = midpointList;
    }

    public String getId() {
        return id;
    }

    public String getBookDocId() {
        return bookDocId;
    }

    public String getRecorder() {
        return recorder;
    }

    public long getRecorded() {
        return recorded;
    }

    public long getDuration() {
        return duration;
    }

    public List<Long> getMidpointList() {
        return midpointList;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VoiceDoc voiceDoc = (VoiceDoc) o;
        return recorded == voiceDoc.recorded && duration == voiceDoc.duration && id.equals(voiceDoc.id) && bookDocId.equals(voiceDoc.bookDocId) && recorder.equals(voiceDoc.recorder) && midpointList.equals(voiceDoc.midpointList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, bookDocId, recorder, recorded, duration, midpointList);
    }

    @Override
    public String toString() {
        return "VoiceDoc{" +
                "id='" + id + '\'' +
                ", bookDocId='" + bookDocId + '\'' +
                ", recorder='" + recorder + '\'' +
                ", recorded=" + recorded +
                ", duration=" + duration +
                ", midpointList=" + midpointList +
                '}';
    }
}
