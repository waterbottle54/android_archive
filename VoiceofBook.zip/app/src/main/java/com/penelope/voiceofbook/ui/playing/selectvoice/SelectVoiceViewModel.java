package com.penelope.voiceofbook.ui.playing.selectvoice;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.data.voicedoc.VoiceDoc;
import com.penelope.voiceofbook.data.voicedoc.VoiceDocRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SelectVoiceViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final BookDoc bookDoc;

    private final LiveData<List<VoiceDoc>> voiceDocs;


    @Inject
    public SelectVoiceViewModel(SavedStateHandle savedStateHandle, VoiceDocRepository voiceDocRepository) {

        this.bookDoc = savedStateHandle.get("bookDoc");
        assert bookDoc != null;

        LiveData<List<String>> filenames = voiceDocRepository.findVoiceDocFilesByBookDocId(bookDoc.getId());
        voiceDocs = Transformations.switchMap(filenames, voiceDocRepository::getVoiceDocs);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<VoiceDoc>> getVoiceDocs() {
        return voiceDocs;
    }

    public String getBookTitle() {
        return bookDoc.getTitle();
    }


    public void onVoiceDocClick(VoiceDoc voiceDoc) {
        event.setValue(new Event.NavigateToPlayingVoiceScreen(bookDoc, voiceDoc));
    }

    public void onListenTTSClick() {
        event.setValue(new Event.NavigateToPlayingScreen(bookDoc));
    }


    public static class Event {

        public static class NavigateToPlayingScreen extends Event {
            public final BookDoc bookDoc;
            public NavigateToPlayingScreen(BookDoc bookDoc) {
                this.bookDoc = bookDoc;
            }
        }

        public static class NavigateToPlayingVoiceScreen extends Event {
            public final BookDoc bookDoc;
            public final VoiceDoc voiceDoc;
            public NavigateToPlayingVoiceScreen(BookDoc bookDoc, VoiceDoc voiceDoc) {
                this.bookDoc = bookDoc;
                this.voiceDoc = voiceDoc;
            }
        }

    }

}