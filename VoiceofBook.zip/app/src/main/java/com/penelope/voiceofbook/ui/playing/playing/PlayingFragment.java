package com.penelope.voiceofbook.ui.playing.playing;

import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.databinding.FragmentPlayingBinding;

import java.util.HashMap;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PlayingFragment extends Fragment implements TextToSpeech.OnInitListener {

    private FragmentPlayingBinding binding;
    private PlayingViewModel viewModel;
    private TextToSpeech tts;


    public PlayingFragment() {
        super(R.layout.fragment_playing);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPlayingBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PlayingViewModel.class);
        tts = new TextToSpeech(requireContext(), this);

        binding.textViewBookTitle.setText(viewModel.getBookTitle());
        binding.textViewBookAuthor.setText(viewModel.getBookAuthor());
        Glide.with(this).load(viewModel.getBookImage()).into(binding.imageViewBook);

        binding.imageViewPrevPage.setOnClickListener(v -> viewModel.onPrevPageClick());
        binding.imageViewNextPage.setOnClickListener(v -> viewModel.onNextPageClick());
        binding.imageViewPlayPause.setOnClickListener(v -> viewModel.onPlayPauseClick());

        viewModel.getPage().observe(getViewLifecycleOwner(), bookPage -> {
            if (bookPage != null) {
                binding.textViewPage.setText(bookPage.getText());
            }
        });

        viewModel.getTotalPages().observe(getViewLifecycleOwner(), totalPages ->
                viewModel.getPageIndex().observe(getViewLifecycleOwner(), pageIndex -> {
                    String strPageIndex = (pageIndex + 1) + "/" + totalPages;
                    binding.textViewPageIndex.setText(strPageIndex);
                })
        );

        viewModel.isPlaying().observe(getViewLifecycleOwner(), isPlaying ->
                binding.imageViewPlayPause.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play)
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PlayingViewModel.Event.ShowBookFinishedMessage) {
                String message = ((PlayingViewModel.Event.ShowBookFinishedMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof PlayingViewModel.Event.PauseSpeech) {
                tts.stop();
            } else if (event instanceof PlayingViewModel.Event.ResumeSpeech) {
                String phrase = ((PlayingViewModel.Event.ResumeSpeech) event).phrase;
                if (phrase != null) {
                    speak(phrase);
                }
            }
        });
    }

    @Override
    public void onPause() {

        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }

        super.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onInit(int status) {

        if (status == TextToSpeech.SUCCESS) {
            int result = tts.setLanguage(Locale.KOREA);
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Snackbar.make(requireView(), "구글 TTS 한글 미지원", Snackbar.LENGTH_SHORT).show();
            } else {
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override
                    public void onStart(String s) {
                    }

                    @Override
                    public void onDone(String s) {
                        viewModel.onSpeechDone();
                    }

                    @Override
                    public void onError(String s) {
                        Snackbar.make(requireView(), "TTS 시스템 에러 발생", Snackbar.LENGTH_SHORT).show();
                    }
                });
                viewModel.getPhrase().observe(getViewLifecycleOwner(), phrase -> {
                    Boolean isPlaying = viewModel.isPlaying().getValue();
                    if (phrase != null && isPlaying != null && isPlaying) {
                        binding.progressBar.setVisibility(View.INVISIBLE);
                        speak(phrase);
                    }
                });
            }
        }
    }

    private void speak(String s) {
        Bundle bundle = new Bundle();
        bundle.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC);
        tts.speak(s, TextToSpeech.QUEUE_FLUSH, bundle, "id");
    }

}