package com.penelope.voiceofbook.api.auth;

import android.content.Context;
import android.util.Log;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.utils.NameUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class GetRecentApi {

    static class GetRecentRequest extends StringRequest {

        private final Map<String, String> map;

        public GetRecentRequest(String id, Response.Listener<String> listener) {
            super(Method.POST, NameUtils.getGetRecentUrl(), listener, Throwable::printStackTrace);

            map = new HashMap<>();
            map.put("id", id);
        }

        @Nullable
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return map;
        }
    }

    public interface GetRecentListener {
        void onSuccess(String recent);
        void onFailure();
    }


    private final Context context;

    public GetRecentApi(Context context) {
        this.context = context;
    }

    public void request(String id, GetRecentListener listener) {

        Response.Listener<String> responseListener = response -> {
            try {
                Log.d("TAG", "GetRecentRequest: " + response);

                JSONObject jsonResponse = new JSONObject(response);
                boolean success = jsonResponse.getBoolean("success");

                if (success) {
                    String recent = jsonResponse.getString("recent");
                    listener.onSuccess(recent);
                } else {
                    listener.onFailure();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                listener.onFailure();
            }
        };

        GetRecentRequest request = new GetRecentRequest(id, responseListener);
        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(request);
    }

}
