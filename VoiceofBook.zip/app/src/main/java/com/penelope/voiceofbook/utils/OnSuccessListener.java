package com.penelope.voiceofbook.utils;

public interface OnSuccessListener<T> {
    void onSuccess(T result);
}
