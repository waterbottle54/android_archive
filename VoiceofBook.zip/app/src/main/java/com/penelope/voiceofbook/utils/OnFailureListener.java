package com.penelope.voiceofbook.utils;

public interface OnFailureListener {
    void onFailure(Exception e);
}
