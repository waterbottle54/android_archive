package com.penelope.voiceofbook.ui.playing.selectvoice;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.voiceofbook.R;
import com.penelope.voiceofbook.data.voicedoc.VoiceDoc;
import com.penelope.voiceofbook.databinding.VoiceDocItemBinding;
import com.penelope.voiceofbook.utils.TimeUtils;

import java.time.LocalDate;
import java.util.Locale;

public class VoiceDocsAdapter extends ListAdapter<VoiceDoc, VoiceDocsAdapter.VoiceDocViewHolder> {

    class VoiceDocViewHolder extends RecyclerView.ViewHolder {

        private final VoiceDocItemBinding binding;

        public VoiceDocViewHolder(VoiceDocItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(VoiceDoc model) {

            String strRecorder = String.format(Locale.getDefault(),
                    resources.getString(R.string.recorder_format),
                    model.getRecorder()
            );
            binding.textViewVoiceRecorder.setText(strRecorder);

            LocalDate ld = TimeUtils.getLocalDate(model.getRecorded());
            String strRecorded = String.format(Locale.getDefault(),
                    resources.getString(R.string.yyyy_mm_dd),
                    ld.getYear(), ld.getMonthValue(), ld.getDayOfMonth()
            );
            binding.textViewVoiceRecorded.setText(strRecorded);

            int seconds = (int)(model.getDuration() / 1000);
            String strDuration = String.format(Locale.getDefault(),
                    resources.getString(R.string.duration_format),
                    seconds / 60,
                    seconds % 60
            );
            binding.textViewVoiceDuration.setText(strDuration);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private final Resources resources;
    private OnItemSelectedListener onItemSelectedListener;


    public VoiceDocsAdapter(Resources resources) {
        super(new DiffUtilCallback());
        this.resources = resources;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public VoiceDocViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        VoiceDocItemBinding binding = VoiceDocItemBinding.inflate(layoutInflater, parent, false);
        return new VoiceDocViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull VoiceDocViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<VoiceDoc> {

        @Override
        public boolean areItemsTheSame(@NonNull VoiceDoc oldItem, @NonNull VoiceDoc newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull VoiceDoc oldItem, @NonNull VoiceDoc newItem) {
            return oldItem.equals(newItem);
        }
    }

}