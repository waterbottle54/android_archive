package com.penelope.voiceofbook.api.auth;

import android.content.Context;
import android.util.Log;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.penelope.voiceofbook.utils.NameUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UpdateRecentApi {

    static class UpdateRecentRequest extends StringRequest {

        private final Map<String, String> map;

        public UpdateRecentRequest(String id, String recent, Response.Listener<String> listener) {
            super(Method.POST, NameUtils.getUpdateRecentUrl(), listener, Throwable::printStackTrace);

            map = new HashMap<>();
            map.put("id", id);
            map.put("recent", recent);
        }

        @Nullable
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return map;
        }
    }

    public interface UpdateRecentListener {
        void onSuccess();
        void onFailure();
    }


    private final Context context;

    public UpdateRecentApi(Context context) {
        this.context = context;
    }

    public void request(String id, String recent, UpdateRecentListener listener) {

        Response.Listener<String> responseListener = response -> {
            Log.d("TAG", "UpdateRecentRequest: " + response);
            listener.onSuccess();
        };

        UpdateRecentRequest request = new UpdateRecentRequest(id, recent, responseListener);
        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(request);
    }

}
