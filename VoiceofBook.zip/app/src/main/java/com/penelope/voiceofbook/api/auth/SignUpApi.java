package com.penelope.voiceofbook.api.auth;

import android.content.Context;
import android.util.Log;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.utils.NameUtils;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SignUpApi {

    static class SignUpRequest extends StringRequest {

        private final Map<String, String> map;

        public SignUpRequest(String id, String password, Response.Listener<String> listener) {
            super(Method.POST, NameUtils.getSignUpUrl(), listener, Throwable::printStackTrace);

            map = new HashMap<>();
            map.put("id", id);
            map.put("password", password);
        }

        @Nullable
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return map;
        }
    }

    static class ValidateRequest extends StringRequest {

        private final Map<String, String> map;

        public ValidateRequest(String id, Response.Listener<String> listener) {
            super(Method.POST, NameUtils.getValidateUrl(), listener, Throwable::printStackTrace);
            map = new HashMap<>();
            map.put("id", id);
        }

        @Nullable
        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return map;
        }
    }


    public interface SignUpListener {
        void onSuccess(User user);
        void onFailure();
    }

    private final Context context;

    public SignUpApi(Context context) {
         this.context = context;
    }

    public void request(String id, String password, SignUpListener listener) {

        Response.Listener<String> signUpResponseListener = response -> {
            Log.d("TAG", "signUpResponseListener: " + response);
            try {
                JSONObject jsonResponse = new JSONObject(response);
                boolean success = jsonResponse.getBoolean("success");
                long created = jsonResponse.getLong("created");

                if (success) {
                    listener.onSuccess(new User(id, password, created));
                } else {
                    listener.onFailure();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                listener.onFailure();
            }
        };

        Response.Listener<String> validateResponseListener = response -> {
            Log.d("TAG", "validateResponseListener: " + response);
            try {
                JSONObject jsonResponse = new JSONObject(response);
                boolean success = jsonResponse.getBoolean("success");

                if (success) {
                    SignUpRequest signUpRequest = new SignUpRequest(id, password, signUpResponseListener);
                    RequestQueue queue = Volley.newRequestQueue(context);
                    queue.add(signUpRequest);
                } else {
                    listener.onFailure();
                }
            } catch (JSONException e) {
                e.printStackTrace();
                listener.onFailure();
            }
        };

        ValidateRequest validateRequest = new ValidateRequest(id, validateResponseListener);
        RequestQueue queue = Volley.newRequestQueue(context);
        queue.add(validateRequest);
    }

}
