package com.penelope.voiceofbook.utils;

public class NameUtils {

    public static final String URL_SERVER_BASE = "http://waterbottle54.dothome.co.kr/";

    public static String getSignInUrl() {
        return URL_SERVER_BASE + "Login.php";
    }

    public static String getSignUpUrl() {
        return URL_SERVER_BASE + "Register.php";
    }

    public static String getValidateUrl() {
        return URL_SERVER_BASE + "UserValidate.php";
    }

    public static String getReadUrl() {
        return URL_SERVER_BASE + "Read.php";
    }

    public static String getListUrl() {
        return URL_SERVER_BASE + "List.php";
    }

    public static String getUploadJsonUrl() {
        return URL_SERVER_BASE + "UploadJson.php";
    }

    public static String getUnregisterUrl() {
        return URL_SERVER_BASE + "Unregister.php";
    }

    public static String getGetRecentUrl() {
        return URL_SERVER_BASE + "GetRecent.php";
    }

    public static String getUpdateRecentUrl() {
        return URL_SERVER_BASE + "UpdateRecent.php";
    }

}
