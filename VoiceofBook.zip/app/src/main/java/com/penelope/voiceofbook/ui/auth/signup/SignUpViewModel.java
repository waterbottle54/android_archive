package com.penelope.voiceofbook.ui.auth.signup;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.api.auth.SignUpApi;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.utils.PreferenceUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SignUpViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String userId = "";             // 유저 아이디 값
    private String password = "";           // 비밀번호 값
    private String passwordConfirm = "";    // 비밀번호 확인값

    private final SignUpApi signUpApi;
    private final SharedPreferences preferences;


    @Inject
    public SignUpViewModel(Application application) {
        signUpApi = new SignUpApi(application);
        preferences = PreferenceManager.getDefaultSharedPreferences(application);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    public void onUserIdChanged(String value) {
        // 아이디 입력값이 변경되었을 때
        userId = value;
    }

    public void onPasswordChanged(String value) {
        // 비밀번호 입력값이 변경되었을 때
        password = value;
    }

    public void onPasswordConfirmChanged(String value) {
        // 비밀번호 확인값이 변경되었을 때
        passwordConfirm = value;
    }

    public void onSignUpClick() {

        // 회원가입 요청했을 때 : 회원가입 시도하기

        if (userId.length() < 4) {
            // 에러 : 짧은 아이디
            event.setValue(new Event.ShowShortUserIdMessage("아이디를 4글자 이상 입력해주세요"));
            return;
        }
        if (password.length() < 4) {
            // 에러 : 짧은 패스워드
            event.setValue(new Event.ShowShortPasswordMessage("비밀번호를 4글자 이상 입력해주세요"));
            return;
        }
        if (!passwordConfirm.equals(password)) {
            // 에러 : 비밀번호 확인 불일치
            event.setValue(new Event.ShowIncorrectPasswordConfirmMessage("비밀번호를 정확하게 입력해주세요"));
            return;
        }

        signUpApi.request(userId, password, new SignUpApi.SignUpListener() {
            @Override
            public void onSuccess(User user) {
                PreferenceUtils.signIn(preferences, user);
                event.setValue(new Event.NavigateToHomeScreen());
            }

            @Override
            public void onFailure() {
                event.setValue(new Event.ShowSignUpFailureMessage("이미 존재하는 아이디입니다"));
            }
        });
    }

    public void onSignInClick() {
        event.setValue(new Event.NavigateBack());
    }


    public static class Event {

        public static class ShowShortUserIdMessage extends Event {
            public final String message;

            public ShowShortUserIdMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowShortPasswordMessage extends Event {
            public final String message;

            public ShowShortPasswordMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowIncorrectPasswordConfirmMessage extends Event {
            public final String message;

            public ShowIncorrectPasswordConfirmMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowSignUpFailureMessage extends Event {
            public final String message;

            public ShowSignUpFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToHomeScreen extends Event {
        }

        public static class NavigateBack extends Event {
        }
    }

}