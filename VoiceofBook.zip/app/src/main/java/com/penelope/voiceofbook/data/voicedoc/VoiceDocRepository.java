package com.penelope.voiceofbook.data.voicedoc;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.penelope.voiceofbook.api.ListRequest;
import com.penelope.voiceofbook.api.ReadRequest;
import com.penelope.voiceofbook.api.UploadJsonRequest;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.utils.OnFailureListener;
import com.penelope.voiceofbook.utils.OnSuccessListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class VoiceDocRepository {

    private final Application application;

    @Inject
    public VoiceDocRepository(Application application) {
        this.application = application;
    }

    public void getVoiceDocFiles(OnSuccessListener<List<String>> onSuccessListener, OnFailureListener onFailureListener) {

        Response.Listener<String> responseListener = response -> {
            try {
                JSONArray jsonArray = new JSONArray(response);
                List<String> voiceDocs = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    String voiceDoc = jsonArray.getString(i);
                    if (voiceDoc.split("#").length != 3) {
                        continue;
                    }
                    voiceDocs.add(voiceDoc);
                }
                onSuccessListener.onSuccess(voiceDocs);
            } catch (JSONException e) {
                e.printStackTrace();
                onFailureListener.onFailure(e);
            }
        };

        RequestQueue queue = Volley.newRequestQueue(application);
        ListRequest request = new ListRequest("voicedocs", responseListener);
        request.setRetryPolicy(new DefaultRetryPolicy(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }

    public LiveData<List<String>> getVoiceDocFiles() {
        MutableLiveData<List<String>> files = new MutableLiveData<>();
        getVoiceDocFiles(files::setValue, e -> files.setValue(null));
        return files;
    }


    public void findVoiceDocFilesByBookDocId(String bookDocId, OnSuccessListener<List<String>> onSuccessListener, OnFailureListener onFailureListener) {
        getVoiceDocFiles(
                voiceDocs -> {
                    List<String> filtered = new ArrayList<>();
                    for (String voiceDoc : voiceDocs) {
                        String[] tokenized = voiceDoc.split("#");
                        if (tokenized.length != 3) {
                            continue;
                        }
                        String voiceDocBookDocId = tokenized[0];
                        if (voiceDocBookDocId.equals(bookDocId)) {
                            filtered.add(voiceDoc);
                        }
                    }
                    onSuccessListener.onSuccess(filtered);
                },
                onFailureListener);
    }

    public LiveData<List<String>> findVoiceDocFilesByBookDocId(String bookDocId) {
        MutableLiveData<List<String>> files = new MutableLiveData<>();
        findVoiceDocFilesByBookDocId(bookDocId, files::setValue, e -> files.setValue(null));
        return files;
    }


    public void findVoiceDocFilesByRecorder(String recorder, OnSuccessListener<List<String>> onSuccessListener, OnFailureListener onFailureListener) {
        getVoiceDocFiles(
                voiceDocs -> {
                    List<String> filtered = new ArrayList<>();
                    for (String voiceDoc : voiceDocs) {
                        String[] tokenized = voiceDoc.split("#");
                        if (tokenized.length != 3) {
                            continue;
                        }
                        String voiceDocRecorder = tokenized[1];
                        if (voiceDocRecorder.equals(recorder)) {
                            filtered.add(voiceDoc);
                        }
                    }
                    onSuccessListener.onSuccess(filtered);
                },
                onFailureListener);
    }

    public LiveData<List<String>> findVoiceDocFilesByRecorder(String recorder) {
        MutableLiveData<List<String>> files = new MutableLiveData<>();
        findVoiceDocFilesByRecorder(recorder, files::setValue, e -> files.setValue(null));
        return files;
    }

    public LiveData<Map<String, Integer>> getVoiceDocCountMap() {

        MutableLiveData<List<String>> voiceDocFiles = new MutableLiveData<>();

        getVoiceDocFiles(voiceDocFiles::setValue, e -> voiceDocFiles.setValue(null));

        LiveData<List<VoiceDoc>> voiceDocs = Transformations.switchMap(voiceDocFiles, this::getVoiceDocs);

        return Transformations.map(voiceDocs, voiceDocList -> {
            Map<String, Integer> map = new HashMap<>();
            for (VoiceDoc voiceDoc : voiceDocList) {
                map.merge(voiceDoc.getBookDocId(), 1, Integer::sum);
            }
            return map;
        });
    }

    public void getVoiceDoc(String filename, OnSuccessListener<VoiceDoc> onSuccessListener, OnFailureListener onFailureListener) {

        Response.Listener<String> responseListener = response -> {
            try {
                JSONObject jsonObject = new JSONObject(response);
                String id = jsonObject.getString("id");
                String bookDocId = jsonObject.getString("bookDocId");
                String recorder = jsonObject.getString("recorder");
                long recorded = jsonObject.getLong("recorded");
                long duration = jsonObject.getLong("duration");
                JSONArray midpoints = jsonObject.getJSONArray("midpoints");
                List<Long> midpointList = new ArrayList<>();
                for (int i = 0; i < midpoints.length(); i++) {
                    midpointList.add(midpoints.getLong(i));
                }

                VoiceDoc voiceDoc = new VoiceDoc(id, bookDocId, recorder, recorded, duration, midpointList);
                onSuccessListener.onSuccess(voiceDoc);

                Log.d("TAG", "getVoiceDoc: " + voiceDoc.toString());
            } catch (JSONException e) {
                e.printStackTrace();
                onFailureListener.onFailure(e);
            }
        };

        RequestQueue queue = Volley.newRequestQueue(application);
        ReadRequest request = new ReadRequest("voicedocs/" + filename, responseListener);
        request.setRetryPolicy(new DefaultRetryPolicy(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }

    public LiveData<List<VoiceDoc>> getVoiceDocs(List<String> filenames) {

        MutableLiveData<List<VoiceDoc>> voiceDocs = new MutableLiveData<>(new ArrayList<>());

        if (filenames == null) {
            voiceDocs.setValue(null);
            return voiceDocs;
        }

        for (String filename : filenames) {
            getVoiceDoc(filename,
                    voiceDoc -> {
                        List<VoiceDoc> voiceDocList = voiceDocs.getValue();
                        assert voiceDocList != null;

                        List<VoiceDoc> copy = new ArrayList<>(voiceDocList);
                        copy.add(voiceDoc);
                        voiceDocs.setValue(copy);
                    }, e -> {

                    });
        }

        return voiceDocs;
    }


    public void addVoiceDoc(VoiceDoc voiceDoc, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        Response.Listener<String> responseListener = response -> {
            onSuccessListener.onSuccess(null);
        };

        JSONObject voiceDocObject = new JSONObject();
        try {
            voiceDocObject.put("id", voiceDoc.getId());
            voiceDocObject.put("bookDocId", voiceDoc.getBookDocId());
            voiceDocObject.put("recorder", voiceDoc.getRecorder());
            voiceDocObject.put("recorded", voiceDoc.getRecorded());
            voiceDocObject.put("duration", voiceDoc.getDuration());
            voiceDocObject.put("midpoints", new JSONArray(voiceDoc.getMidpointList()));
        } catch (JSONException e) {
            e.printStackTrace();
            onFailureListener.onFailure(e);
            return;
        }

        RequestQueue queue = Volley.newRequestQueue(application);
        UploadJsonRequest request = new UploadJsonRequest("voicedocs/" + voiceDoc.getId() + ".json", voiceDocObject, responseListener);
        request.setRetryPolicy(new DefaultRetryPolicy(0, -1, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        queue.add(request);
    }

}
