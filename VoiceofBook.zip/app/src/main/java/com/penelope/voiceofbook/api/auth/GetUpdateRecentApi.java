package com.penelope.voiceofbook.api.auth;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GetUpdateRecentApi {

    public interface GetUpdateRecentApiListener {
        void onSuccess();
        void onFailure();
    }

    private final Context context;

    public GetUpdateRecentApi(Context context) {
        this.context = context;
    }

    public void request(String userId, String bookDocId, GetUpdateRecentApiListener listener) {

        new GetRecentApi(context).request(userId, new GetRecentApi.GetRecentListener() {
            @Override
            public void onSuccess(String recent) {

                List<String> recentList = new ArrayList<>();

                if (recent != null && !recent.isEmpty()) {
                    String[] tokens = recent.split(";");
                    recentList.addAll(Arrays.asList(tokens));
                    if (recentList.size() >= 3) {
                        recentList = recentList.subList(1, 3);
                    }
                }
                recentList.add(bookDocId);

                StringBuilder newRecent = new StringBuilder();
                for (int i = 0; i < recentList.size(); i++) {
                    newRecent.append(recentList.get(i)).append(";");
                }

                new UpdateRecentApi(context).request(userId, newRecent.toString(), new UpdateRecentApi.UpdateRecentListener() {
                    @Override
                    public void onSuccess() {
                        listener.onSuccess();
                    }

                    @Override
                    public void onFailure() {
                        listener.onFailure();
                    }
                });
            }

            @Override
            public void onFailure() {
                listener.onFailure();
            }
        });
    }


}
