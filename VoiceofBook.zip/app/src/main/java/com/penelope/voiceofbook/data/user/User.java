package com.penelope.voiceofbook.data.user;

public class User {

    private final String id;
    private final String password;
    private final long created;

    public User(String id, String password, long created) {
        this.id = id;
        this.password = password;
        this.created = created;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public long getCreated() {
        return created;
    }
}
