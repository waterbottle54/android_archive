package com.penelope.voiceofbook.api;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.penelope.voiceofbook.utils.NameUtils;

import java.util.HashMap;
import java.util.Map;

public class ListRequest extends StringRequest {

    private final Map<String, String> map;

    public ListRequest(String path, Response.Listener<String> listener) {
        super(Method.POST, NameUtils.getListUrl(), listener, Throwable::printStackTrace);

        map = new HashMap<>();
        map.put("path", path);
    }

    @Nullable
    @Override
    protected Map<String, String> getParams() throws AuthFailureError {
        return map;
    }
}
