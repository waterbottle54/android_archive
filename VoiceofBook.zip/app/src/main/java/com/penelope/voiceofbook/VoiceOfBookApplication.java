package com.penelope.voiceofbook;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class VoiceOfBookApplication extends Application {
}
