package com.penelope.voiceofbook.ui.playing.playing;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.voiceofbook.api.auth.GetRecentApi;
import com.penelope.voiceofbook.api.auth.GetUpdateRecentApi;
import com.penelope.voiceofbook.api.auth.UpdateRecentApi;
import com.penelope.voiceofbook.data.BookPage;
import com.penelope.voiceofbook.data.bookdoc.BookDoc;
import com.penelope.voiceofbook.data.bookdoc.BookDocRepository;
import com.penelope.voiceofbook.data.user.User;
import com.penelope.voiceofbook.data.voicedoc.VoiceDoc;
import com.penelope.voiceofbook.utils.PreferenceUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PlayingViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final BookDoc bookDoc;

    private final LiveData<List<BookPage>> pages;
    private final LiveData<BookPage> page;
    private final LiveData<String> phrase;
    private final MutableLiveData<Integer> pageIndex = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> phraseIndex = new MutableLiveData<>(0);
    private final LiveData<Integer> totalPages;

    private final MutableLiveData<Boolean> isPlaying = new MutableLiveData<>(true);


    @Inject
    public PlayingViewModel(SavedStateHandle savedStateHandle, Application application, BookDocRepository bookDocRepository) {

        bookDoc = savedStateHandle.get("bookDoc");
        assert bookDoc != null;

        pages = bookDocRepository.getBookPages(bookDoc);
        page = Transformations.switchMap(pages, pageList ->
                Transformations.map(pageIndex, index -> {
                    if (index < 0 || index > pageList.size() - 1) {
                        return null;
                    }
                    return pageList.get(index);
                })
        );

        phrase = Transformations.switchMap(page, pageValue ->
                Transformations.map(phraseIndex, index -> {
                    if (index < 0 || index > pageValue.getPhrases().size() - 1) {
                        return null;
                    }
                    return pageValue.getPhrases().get(index);
                })
        );

        totalPages = Transformations.map(pages, pageList -> pageList == null ? 0 : pageList.size());

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(application);
        User user = PreferenceUtils.getCurrentUser(preferences);
        assert user != null;

        new GetUpdateRecentApi(application).request(user.getId(), bookDoc.getId(), new GetUpdateRecentApi.GetUpdateRecentApiListener() {
            @Override
            public void onSuccess() {
            }

            @Override
            public void onFailure() {
            }
        });
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<BookPage> getPage() {
        return page;
    }

    public LiveData<String> getPhrase() {
        return phrase;
    }

    public String getBookTitle() {
        return bookDoc.getTitle();
    }

    public String getBookImage() {
        return bookDoc.getUrlImage();
    }

    public String getBookAuthor() {
        return bookDoc.getAuthor();
    }

    public LiveData<Integer> getPageIndex() {
        return pageIndex;
    }

    public LiveData<Integer> getTotalPages() {
        return totalPages;
    }

    public LiveData<Boolean> isPlaying() {
        return isPlaying;
    }


    public void onSpeechDone() {

        Integer phraseIndexValue = phraseIndex.getValue();
        Integer pageIndexValue = pageIndex.getValue();
        assert phraseIndexValue != null && pageIndexValue != null;

        List<BookPage> pageListValue = pages.getValue();
        BookPage pageValue = page.getValue();
        String phraseValue = phrase.getValue();
        if (pageListValue == null || pageValue == null || phraseValue == null) {
            return;
        }

        phraseIndexValue++;
        if (phraseIndexValue > pageValue.getPhrases().size() - 1) {
            pageIndexValue++;
            phraseIndexValue = 0;
            if (pageIndexValue > pageListValue.size() - 1) {
                event.postValue(new Event.ShowBookFinishedMessage("책이 모두 끝났습니다"));
                return;
            }
        }

        pageIndex.postValue(pageIndexValue);
        phraseIndex.postValue(phraseIndexValue);
    }

    public void onPrevPageClick() {

        Integer pageIndexValue = pageIndex.getValue();
        assert pageIndexValue != null;

        BookPage pageValue = page.getValue();
        if (pageValue == null) {
            return;
        }

        if (pageIndexValue > 0) {
            pageIndex.setValue(pageIndexValue - 1);
            phraseIndex.setValue(0);
        }
    }

    public void onNextPageClick() {

        Integer pageIndexValue = pageIndex.getValue();
        assert pageIndexValue != null;

        List<BookPage> pageListValue = pages.getValue();
        BookPage pageValue = page.getValue();
        if (pageListValue == null || pageValue == null) {
            return;
        }

        if (pageIndexValue < pageListValue.size() - 1) {
            pageIndex.setValue(pageIndexValue + 1);
            phraseIndex.setValue(0);
        }
    }

    public void onPlayPauseClick() {

        Boolean isPlayingValue = isPlaying.getValue();
        assert isPlayingValue != null;

        if (isPlayingValue) {
            event.setValue(new Event.PauseSpeech());
        } else {
            String phrase = this.phrase.getValue();
            event.setValue(new Event.ResumeSpeech(phrase));
        }

        isPlaying.setValue(!isPlayingValue);
    }


    public static class Event {

        public static class ShowBookFinishedMessage extends Event {
            public final String message;
            public ShowBookFinishedMessage(String message) {
                this.message = message;
            }
        }

        public static class PauseSpeech extends Event {
        }

        public static class ResumeSpeech extends Event {
            public final String phrase;
            public ResumeSpeech(String phrase) {
                this.phrase = phrase;
            }
        }
    }

}