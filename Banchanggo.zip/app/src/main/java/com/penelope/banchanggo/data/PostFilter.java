package com.penelope.banchanggo.data;

public enum PostFilter {
    RECENT, LOW_PRICE, HIGH_PRICE,
}
