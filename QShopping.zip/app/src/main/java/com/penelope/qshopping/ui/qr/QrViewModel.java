package com.penelope.qshopping.ui.qr;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.qshopping.data.PreferenceData;
import com.penelope.qshopping.data.mart.Mart;
import com.penelope.qshopping.data.mart.MartRepository;
import com.penelope.qshopping.data.mart.Product;
import com.penelope.qshopping.data.pick.Pick;
import com.penelope.qshopping.data.pick.PickDao;
import com.penelope.qshopping.utils.SharedPreferenceStringLiveData;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class QrViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<Mart> currentMart;

    private final PickDao pickDao;
    private final MartRepository martRepository;
    private final PreferenceData preferenceData;


    @Inject
    public QrViewModel(PreferenceData preferenceData, MartRepository martRepository, PickDao pickDao) {

        // 현재 장보기 중인 마트 id 와 마트 객체(currentMart)를 획득한다
        SharedPreferenceStringLiveData currentMartId = preferenceData.getCurrentMartIdLive();
        currentMart = Transformations.switchMap(currentMartId, martRepository::getMartLive);

        this.pickDao = pickDao;
        this.martRepository = martRepository;
        this.preferenceData = preferenceData;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Mart> getCurrentMart() {
        return currentMart;
    }


    public void onScanClick() {

        Mart martValue = currentMart.getValue();
        if (martValue == null) {
            // 마트 QR 스캔 이벤트를 발생시킨다
            event.setValue(new Event.ScanMart());
        } else {
            // 물품 QR 스캔 이벤트를 발생시킨다
            event.setValue(new Event.ScanProduct());
        }
    }

    public void onScanResult(String text) {

        if (text == null || text.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("QR 코드를 인식하지 못했습니다"));
            return;
        }

        Mart martValue = currentMart.getValue();

        if (martValue == null) {
            // QR 스캔값을 마트 id 로 하여 마트를 검색한다
            String martId = text.trim();
            martRepository.searchMart(martId,
                    mart -> {
                        if (mart != null) {
                            preferenceData.setCurrentMartId(martId);
                        } else {
                            event.setValue(new Event.ShowGeneralMessage("등록되지 않은 마트입니다"));
                        }
                    },
                    e -> {
                        e.printStackTrace();
                        event.setValue(new Event.ShowGeneralMessage("마트 조회에 실패했습니다"));
                    });
        } else {
            // QR 스캔값을 물품 id 로 하여 물품을 검색한다
            String productId = text.trim();
            Product productToFind = null;
            for (Product product : martValue.getProducts()) {
                if (product.getId().equals(productId)) {
                    productToFind = product;
                    break;
                }
            }
            if (productToFind != null) {
                event.setValue(new Event.PromptPickCount(productToFind));
            } else {
                event.setValue(new Event.ShowGeneralMessage("마트에 등록된 물품이 아닙니다"));
            }
        }
    }

    public void onPickCountResult(Product product, int count) {

        new Thread(() -> {
            // 장바구니 항목을 db 에 추가한다
            Pick pick = new Pick(product.getId(), count);
            pickDao.addPick(pick);
            event.postValue(new Event.ShowGeneralMessage("장바구니에 추가되었습니다"));

            // 장바구니 총액이 한도를 넘은 경우 알림 이벤트를 발생시킨다
            String martId = preferenceData.getCurrentMartId();
            martRepository.getTotalPrice(martId,
                    totalPrice -> {
                        int upperLimit = preferenceData.getUpperLimit();
                        if (totalPrice > upperLimit) {
                            event.postValue(new Event.NotifyExceedingUpperLimit(upperLimit));
                        }
                    },
                    Throwable::printStackTrace);
        }).start();
    }

    public void onExitMartClick() {

        Mart martValue = currentMart.getValue();
        if (martValue != null) {
            // 마트에서 나갈 것인지 확인한다
            event.setValue(new Event.ConfirmExitMart(martValue));
        }
    }

    public void onExitMartConfirm() {

        Mart martValue = currentMart.getValue();
        if (martValue != null) {
            // 현재 마트를 null 로 설정한다
            preferenceData.setCurrentMartId(null);
            // 장바구니를 비운다
            new Thread(pickDao::deleteAllPicks).start();
        }
    }

    public void onPayResult(boolean success) {
        if (success) {
            event.setValue(new Event.ShowGeneralMessage("결제가 완료되었습니다. 이용해주셔서 감사합니다"));
        }
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class ScanMart extends Event {
        }

        public static class ScanProduct extends Event {
        }

        public static class ConfirmExitMart extends Event {
            public final Mart currentMart;
            public ConfirmExitMart(Mart currentMart) {
                this.currentMart = currentMart;
            }
        }

        public static class PromptPickCount extends Event {
            public final Product product;
            public PromptPickCount(Product product) {
                this.product = product;
            }
        }

        public static class NotifyExceedingUpperLimit extends Event {
            public final int upperLimit;
            public NotifyExceedingUpperLimit(int upperLimit) {
                this.upperLimit = upperLimit;
            }
        }
    }

}