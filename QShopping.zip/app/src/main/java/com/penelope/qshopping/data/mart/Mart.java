package com.penelope.qshopping.data.mart;

import java.util.List;

// 마트 클래스
public class Mart {

    private String id;                  // 마트 id
    private String name;                // 마트 이름
    private String imageUrl;            // 마트 이미지 url
    private List<Product> products;     // 마트 품목 리스트


    public Mart() {
    }

    public Mart(String id, String name, String imageUrl, List<Product> products) {
        this.id = id;
        this.name = name;
        this.imageUrl = imageUrl;
        this.products = products;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public List<Product> getProducts() {
        return products;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setProducts(List<Product> products) {
        this.products = products;
    }
}
