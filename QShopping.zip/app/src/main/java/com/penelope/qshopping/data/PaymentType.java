package com.penelope.qshopping.data;

public enum PaymentType {
    CREDIT_CARD, TRANSFER, NAVER_PAY
}
