package com.penelope.qshopping.data.pick;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PickDao {

    @Query("SELECT * FROM picks ORDER BY created DESC")
    LiveData<List<Pick>> getPicksLive();

    @Query("SELECT * FROM picks ORDER BY created DESC")
    List<Pick> getPicks();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addPick(Pick pick);

    @Delete
    void deletePick(Pick pick);

    @Query("DELETE FROM picks")
    void deleteAllPicks();

}
