package com.penelope.qshopping.data.pick;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Pick.class}, version = 1, exportSchema = false)
public abstract class PickDatabase extends RoomDatabase {

    public abstract PickDao pickDao();
}
