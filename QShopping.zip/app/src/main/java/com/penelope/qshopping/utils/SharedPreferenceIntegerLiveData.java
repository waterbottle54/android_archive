package com.penelope.qshopping.utils;

import android.content.SharedPreferences;

public class SharedPreferenceIntegerLiveData extends SharedPreferenceLiveData<Integer> {

    public SharedPreferenceIntegerLiveData(SharedPreferences preferences, String key, Integer defValue) {
        super(preferences, key, defValue);
    }

    @Override
    Integer getValueFromPreferences(String key, Integer defValue) {
        return sharedPrefs.getInt("upper_limit", defValue);
    }
}