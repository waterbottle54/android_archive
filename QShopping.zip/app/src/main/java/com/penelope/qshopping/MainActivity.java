package com.penelope.qshopping;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;

import com.penelope.qshopping.databinding.ActivityMainBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MainActivity extends AppCompatActivity {

    public static final String ACTION_LIMIT = "com.penelope.qshopping.action_limit";

    private NavHostFragment navHostFragment;
    private NavController navController;
    private BroadcastReceiver limitReceiver;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 뷰 바인딩을 실행한다
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentContainer);
        if (navHostFragment != null) {
            // 네비게이션 컨트롤러를 바텀 네비게이션 뷰 (하단 메뉴바) 와 연동한다
            navController = navHostFragment.getNavController();
            NavigationUI.setupWithNavController(binding.bottomNavigationView, navController);
            // 장바구니 한도초과 노티피케이션을 클릭해서 액티비티가 띄워진 경우 장바구니 프래그먼트를 보여준다
            if (getIntent() != null) {
                int fragmentToShow = getIntent().getIntExtra("fragment", 0);
                if (fragmentToShow == R.id.cartFragment) {
                    binding.bottomNavigationView.setSelectedItemId(R.id.cartFragment);
                }
            }
        }

        // 장바구니 한도 초과에 대한 방송 수신자를 정의한다
        limitReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // 장바구니 한도 초과를 알리는 노티피케이션을 띄운다
                String message = intent.getStringExtra("message");
                createLimitNotification(message);
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 방송 수신자 등록
        registerReceiver(limitReceiver, new IntentFilter(ACTION_LIMIT));
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 방송 수신자 해제
        unregisterReceiver(limitReceiver);
    }

    @Override
    public boolean onSupportNavigateUp() {
        return (navController.navigateUp() || super.onSupportNavigateUp());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        // QR 코드 스캔 결과가 전달됨
        // 현재 QR 프래그먼트가 띄워져 있을때만 결과를 전달한다
        NavDestination destination = navController.getCurrentDestination();
        assert destination != null;

        if (destination.getId() == R.id.qrFragment) {
            Fragment fragment = navHostFragment.getChildFragmentManager().getFragments().get(0);
            fragment.onActivityResult(requestCode, resultCode, data);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void createLimitNotification(String message) {

        // 장바구니 한도 초과를 알리는 노티피케이션을 띄운다

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("fragment", R.id.cartFragment);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 1, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new Notification.Builder(this, QShoppingApplication.CHANNEL_ID_LIMIT)
                .setContentIntent(contentIntent)
                .setContentTitle("씀씀이 초과")
                .setContentText(message)
                .setSmallIcon(R.drawable.ic_limit_notification)
                .build();

        notificationManager.notify(1, notification);
    }

}
