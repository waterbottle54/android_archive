package com.penelope.qshopping.ui.pay;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.penelope.qshopping.R;
import com.penelope.qshopping.data.PaymentType;
import com.penelope.qshopping.databinding.FragmentPayBinding;
import com.penelope.qshopping.ui.cart.PicksAdapter;
import com.penelope.qshopping.utils.TermUtil;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PayFragment extends Fragment {

    private FragmentPayBinding binding;
    private PayViewModel viewModel;


    public PayFragment() {
        super(R.layout.fragment_pay);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩 실행
        binding = FragmentPayBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PayViewModel.class);

        // 결제수단 라디오버튼 변경시 뷰모델에 통보
        binding.radioGroupPayment.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioButtonCard) {
                viewModel.onPaymentTypeChange(PaymentType.CREDIT_CARD);
            } else if (checkedId == R.id.radioButtonTransfer) {
                viewModel.onPaymentTypeChange(PaymentType.TRANSFER);
            } else if (checkedId == R.id.radioButtonNaverPay) {
                viewModel.onPaymentTypeChange(PaymentType.NAVER_PAY);
            }
        });

        // 결제버튼 클릭시 뷰모델에 통보
        binding.fabPay.setOnClickListener(v -> viewModel.onPayClick());

        // 장바구니 항목 리사이클러 뷰 업데이트
        viewModel.getProductMap().observe(getViewLifecycleOwner(), productMap -> {
            if (productMap != null) {

                // 리사이클러 뷰 초기화
                PicksAdapter adapter = new PicksAdapter(productMap, Glide.with(this), false);
                binding.recyclerPick.setAdapter(adapter);
                binding.recyclerPick.setHasFixedSize(true);

                // 리사이클러 뷰 업데이트
                viewModel.getPicks().observe(getViewLifecycleOwner(), picks -> {
                    if (picks != null) {
                        adapter.submitList(picks);
                    }
                    binding.progressBar2.setVisibility(View.INVISIBLE);
                });
            }
        });

        // 합계금액 업데이트
        viewModel.getTotalPrice().observe(getViewLifecycleOwner(), totalPrice -> {
            if (totalPrice != null) {
                String strTotalPrice = "결제금액: " + TermUtil.price(totalPrice);
                binding.textViewTotalPrice.setText(strTotalPrice);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PayViewModel.Event.ConfirmPay) {
                // 결제를 진행할지 묻는 대화상자를 띄운다
                PaymentType paymentType = ((PayViewModel.Event.ConfirmPay) event).paymentType;
                int totalPrice = ((PayViewModel.Event.ConfirmPay) event).totalPrice;
                showConfirmPayDialog(paymentType, totalPrice);
            } else if (event instanceof PayViewModel.Event.NavigateBackWithResult) {
                // 결제가 완료되면 홈 화면(QrFragment)으로 이동한다
                boolean success = ((PayViewModel.Event.NavigateBackWithResult) event).success;
                Bundle result = new Bundle();
                result.putBoolean("success", success);
                getParentFragmentManager().setFragmentResult("pay_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void showConfirmPayDialog(PaymentType paymentType, int totalPrice) {

        // 결제를 진행할지 묻는 대화상자를 띄운다

        String message = String.format(Locale.getDefault(), "%s로 %s 결제를 진행합니다",
                TermUtil.paymentType(paymentType), TermUtil.price(totalPrice));

        new AlertDialog.Builder(requireContext())
                .setTitle("결제")
                .setMessage(message)
                .setPositiveButton("결제", (dialog, which) -> viewModel.onPayConfirm())
                .setNegativeButton("취소", null)
                .show();
    }

}