package com.penelope.qshopping.ui.cart;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.qshopping.data.PreferenceData;
import com.penelope.qshopping.data.mart.Mart;
import com.penelope.qshopping.data.mart.MartRepository;
import com.penelope.qshopping.data.mart.Product;
import com.penelope.qshopping.data.pick.Pick;
import com.penelope.qshopping.data.pick.PickDao;
import com.penelope.qshopping.utils.SharedPreferenceStringLiveData;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class CartViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<Pick>> picks;
    private final LiveData<Mart> currentMart;
    private final LiveData<Map<String, Product>> productMap;

    private final LiveData<Integer> totalPrice;
    private final LiveData<Integer> upperLimit;

    private final PickDao pickDao;


    @Inject
    public CartViewModel(PreferenceData preferenceData, PickDao pickDao, MartRepository martRepository) {

        picks = pickDao.getPicksLive();

        // 현재 장보기 중인 마트(currentMart)를 획득하고, 해당 마트의 물품 목록(productMap)을 획득한다
        SharedPreferenceStringLiveData currentMartId = preferenceData.getCurrentMartIdLive();
        currentMart = Transformations.switchMap(currentMartId, martRepository::getMartLive);
        productMap = Transformations.switchMap(currentMartId, martRepository::getProductMapLive);

        // 합계 금액과 한도 금액을 추적한다
        totalPrice = Transformations.switchMap(currentMartId, martRepository::getTotalPriceLive);
        upperLimit = preferenceData.getUpperLimitLive();

        this.pickDao = pickDao;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Pick>> getPicks() {
        return picks;
    }

    public LiveData<Mart> getCurrentMart() {
        return currentMart;
    }

    public LiveData<Map<String, Product>> getProductMap() {
        return productMap;
    }

    public LiveData<Integer> getTotalPrice() {
        return totalPrice;
    }

    public LiveData<Integer> getUpperLimit() {
        return upperLimit;
    }


    public void onDeletePickClick(Pick pick) {
        new Thread(() -> pickDao.deletePick(pick)).start();
    }

    public void onPayClick() {
        event.setValue(new Event.NavigateToPayScreen());
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToPayScreen extends Event {
        }
    }

}