package com.penelope.qshopping.ui.option;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qshopping.data.PreferenceData;
import com.penelope.qshopping.utils.NumberUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class OptionViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<Integer> upperLimit;

    private final PreferenceData preferenceData;


    @Inject
    public OptionViewModel(PreferenceData preferenceData) {

        upperLimit = preferenceData.getUpperLimitLive();

        this.preferenceData = preferenceData;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Integer> getUpperLimit() {
        return upperLimit;
    }


    public void onOnesChange(int ones) {

        Integer upperLimitValue = upperLimit.getValue();
        assert upperLimitValue != null;

        int simple = upperLimitValue / 10000;
        int hundreds = NumberUtils.getHundreds(simple);
        int tens = NumberUtils.getTens(simple);

        onDigitChange(hundreds, tens, ones);
    }

    public void onTensChange(int tens) {

        Integer upperLimitValue = upperLimit.getValue();
        assert upperLimitValue != null;

        int simple = upperLimitValue / 10000;
        int hundreds = NumberUtils.getHundreds(simple);
        int ones = NumberUtils.getOnes(simple);

        onDigitChange(hundreds, tens, ones);
    }

    public void onHundredsChange(int hundreds) {

        Integer upperLimitValue = upperLimit.getValue();
        assert upperLimitValue != null;

        int simple = upperLimitValue / 10000;
        int tens = NumberUtils.getTens(simple);
        int ones = NumberUtils.getOnes(simple);

        onDigitChange(hundreds, tens, ones);
    }

    private void onDigitChange(int hundreds, int tens, int ones) {
        int newLimit = (hundreds * 100 + tens * 10 + ones) * 10000;
        preferenceData.setUpperLimit(newLimit);
    }


    public static class Event {

    }

}