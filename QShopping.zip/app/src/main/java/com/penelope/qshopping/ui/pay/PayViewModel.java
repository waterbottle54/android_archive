package com.penelope.qshopping.ui.pay;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qshopping.data.PaymentType;
import com.penelope.qshopping.data.PreferenceData;
import com.penelope.qshopping.data.mart.MartRepository;
import com.penelope.qshopping.data.mart.Product;
import com.penelope.qshopping.data.pick.Pick;
import com.penelope.qshopping.data.pick.PickDao;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PayViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<Pick>> picks;
    private final LiveData<Map<String, Product>> productMap;
    private final LiveData<Integer> totalPrice;
    private PaymentType paymentType = PaymentType.CREDIT_CARD;


    @Inject
    public PayViewModel(PreferenceData preferenceData, PickDao pickDao, MartRepository martRepository) {

        // 장바구니 목록을 획득한다
        picks = pickDao.getPicksLive();

        // 현재 장보기 중인 마트(currentMartId)를 획득하고
        // 해당 마트의 물품 목록(productMap) 및 결제해야 할 금액(totalPrice)을 획득한다
        String currentMartId = preferenceData.getCurrentMartId();
        productMap = martRepository.getProductMapLive(currentMartId);
        totalPrice = martRepository.getTotalPriceLive(currentMartId);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Pick>> getPicks() {
        return picks;
    }

    public LiveData<Map<String, Product>> getProductMap() {
        return productMap;
    }

    public LiveData<Integer> getTotalPrice() {
        return totalPrice;
    }


    public void onPaymentTypeChange(PaymentType value) {
        paymentType = value;
    }

    public void onPayClick() {

        Integer totalPriceValue = totalPrice.getValue();
        if (totalPriceValue == null) {
            return;
        }

        event.setValue(new Event.ConfirmPay(paymentType, totalPriceValue));
    }

    public void onPayConfirm() {
        event.setValue(new Event.NavigateBackWithResult(true));
    }


    public static class Event {

        public static class ConfirmPay extends Event {
            public final PaymentType paymentType;
            public final int totalPrice;
            public ConfirmPay(PaymentType paymentType, int totalPrice) {
                this.paymentType = paymentType;
                this.totalPrice = totalPrice;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;
            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }
    }

}