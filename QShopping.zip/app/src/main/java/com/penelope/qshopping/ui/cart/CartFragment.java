package com.penelope.qshopping.ui.cart;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.penelope.qshopping.R;
import com.penelope.qshopping.data.pick.Pick;
import com.penelope.qshopping.databinding.FragmentCartBinding;
import com.penelope.qshopping.utils.TermUtil;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class CartFragment extends Fragment {

    private FragmentCartBinding binding;
    private CartViewModel viewModel;


    public CartFragment() {
        super(R.layout.fragment_cart);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩 실행
        binding = FragmentCartBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(CartViewModel.class);

        // 결제 버튼이 클릭되면 뷰모델에 통보
        binding.fabPay.setOnClickListener(v -> viewModel.onPayClick());

        // 장바구니 항목 리사이클러 뷰 업데이트
        viewModel.getProductMap().observe(getViewLifecycleOwner(), productMap -> {
            if (productMap != null) {

                // 리사이클러 뷰 초기화
                PicksAdapter adapter = new PicksAdapter(productMap, Glide.with(this), true);
                binding.recyclerPick.setAdapter(adapter);
                binding.recyclerPick.setHasFixedSize(true);
                adapter.setOnItemSelectedListener(new PicksAdapter.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(int position) {
                    }

                    @Override
                    public void onDeleteClick(int position) {
                        // 장바구니 항목 삭제 클릭 시 뷰모델에 통보
                        Pick pick = adapter.getCurrentList().get(position);
                        viewModel.onDeletePickClick(pick);
                    }
                });

                // 리사이클러 뷰 업데이트
                viewModel.getPicks().observe(getViewLifecycleOwner(), picks -> {
                    if (picks != null) {
                        adapter.submitList(picks);
                        binding.textViewNoPicks.setVisibility(picks.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                    }
                    binding.progressBar.setVisibility(View.INVISIBLE);
                });
            } else {
                binding.progressBar.setVisibility(View.INVISIBLE);
            }
            binding.textViewNotInMart.setVisibility(productMap == null ? View.VISIBLE : View.INVISIBLE);
        });

        // 현재 마트 이름 업데이트
        viewModel.getCurrentMart().observe(getViewLifecycleOwner(), mart -> {
            if (mart != null) {
                String strMartName = mart.getName() + " 장바구니";
                binding.textViewMartName.setText(strMartName);
            } else {
                binding.textViewMartName.setText("장바구니");
            }
        });

        // 현재 금액을 업데이트한다
        viewModel.getUpperLimit().observe(getViewLifecycleOwner(), upperLimit ->
                viewModel.getTotalPrice().observe(getViewLifecycleOwner(), totalPrice -> {
                    assert upperLimit != null;
                    if (totalPrice != null) {
                        String strTotalPrice = TermUtil.price(totalPrice);
                        binding.textViewTotalPrice.setText(strTotalPrice);
                        // 프로그레스바에 한도금액 대비 장바구니 합계금액을 표시한다
                        binding.progressBarPrice.setMax(upperLimit);
                        binding.progressBarPrice.setProgress(totalPrice);
                        // 한도 도달 정도에 따라 프로그레스바 색상을 변경한다
                        double rate = (double) totalPrice / upperLimit;
                        int color;
                        if (rate >= 1) {
                            color = getResources().getColor(android.R.color.holo_red_dark, null);
                        } else if (rate > 0.9) {
                            color = getResources().getColor(android.R.color.holo_orange_dark, null);
                        } else if (rate > 0.8) {
                            color = getResources().getColor(android.R.color.holo_orange_light, null);
                        } else {
                            color = getResources().getColor(android.R.color.holo_blue_dark, null);
                        }
                        binding.progressBarPrice.getProgressDrawable().setColorFilter(color,android.graphics.PorterDuff.Mode.MULTIPLY);
                    }
                    binding.cardTotalPrice.setVisibility(totalPrice != null ? View.VISIBLE : View.INVISIBLE);
                }));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof CartViewModel.Event.ShowGeneralMessage) {
                // 뷰모델의 메세지를 출력한다
                String message = ((CartViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof CartViewModel.Event.NavigateToPayScreen) {
                // 결제 화면 (PayFragment) 로 이동한다
                NavDirections navDirections = CartFragmentDirections.actionCartFragmentToPayFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}