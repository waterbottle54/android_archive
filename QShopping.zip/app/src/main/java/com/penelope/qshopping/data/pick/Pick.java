package com.penelope.qshopping.data.pick;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import com.penelope.qshopping.data.mart.Product;

import java.util.Objects;

@Entity(tableName = "picks")
public class Pick {

    @NonNull
    @PrimaryKey
    private final String productId;
    private final int count;
    private final long created;

    public Pick(@NonNull String productId, int count, long created) {
        this.productId = productId;
        this.count = count;
        this.created = created;
    }

    @Ignore
    public Pick(@NonNull String productId, int count) {
        this.productId = productId;
        this.count = count;
        this.created = System.currentTimeMillis();
    }

    @NonNull
    public String getProductId() {
        return productId;
    }

    public int getCount() {
        return count;
    }

    public long getCreated() {
        return created;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pick pick = (Pick) o;
        return count == pick.count && created == pick.created && productId.equals(pick.productId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(productId, count, created);
    }
}
