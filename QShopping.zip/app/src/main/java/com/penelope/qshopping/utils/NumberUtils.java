package com.penelope.qshopping.utils;

public class NumberUtils {

    public static int getHundreds(int value) {
        return value / 100;
    }

    public static int getTens(int value) {
        return (value - getHundreds(value) * 100) / 10;
    }

    public static int getOnes(int value) {
        return (value - getHundreds(value) * 100 - getTens(value) * 10);
    }

}
