package com.penelope.qshopping.ui.cart;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.penelope.qshopping.data.mart.Product;
import com.penelope.qshopping.data.pick.Pick;
import com.penelope.qshopping.databinding.PickItemBinding;
import com.penelope.qshopping.utils.TermUtil;

import java.util.Locale;
import java.util.Map;

public class PicksAdapter extends ListAdapter<Pick, PicksAdapter.PickViewHolder> {

    class PickViewHolder extends RecyclerView.ViewHolder {

        private final PickItemBinding binding;

        public PickViewHolder(PickItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.textViewDeletePick.setVisibility(showControlUI ? View.VISIBLE : View.GONE);

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });

            binding.textViewDeletePick.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onDeleteClick(position);
                }
            });
        }

        public void bind(Pick model) {

            Product product = productMap.get(model.getProductId());

            if (product != null) {
                // 물품 이미지 띄우기
                glide.load(product.getImageUrl()).into(binding.imageViewProduct);
                // 물품 이름 띄우기
                binding.textViewProductName.setText(product.getName());
                // 장바구니 항목의 개수, 총 가격 띄우기
                String strCountAndTotalPrice = String.format(Locale.getDefault(), "%d개, %s",
                        model.getCount(), TermUtil.price(model.getCount() * product.getPrice()));
                binding.textViewCountAndTotalPrice.setText(strCountAndTotalPrice);
            }
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);

        void onDeleteClick(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final Map<String, Product> productMap;
    private final RequestManager glide;
    private final boolean showControlUI;

    public PicksAdapter(Map<String, Product> productMap, RequestManager glide, boolean showControlUI) {
        super(new DiffUtilCallback());
        this.productMap = productMap;
        this.glide = glide;
        this.showControlUI = showControlUI;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public PickViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        PickItemBinding binding = PickItemBinding.inflate(layoutInflater, parent, false);
        return new PickViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PickViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Pick> {

        @Override
        public boolean areItemsTheSame(@NonNull Pick oldItem, @NonNull Pick newItem) {
            return oldItem.getProductId().equals(newItem.getProductId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Pick oldItem, @NonNull Pick newItem) {
            return oldItem.equals(newItem);
        }
    }

}