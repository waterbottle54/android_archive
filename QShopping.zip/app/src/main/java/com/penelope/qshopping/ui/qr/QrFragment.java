package com.penelope.qshopping.ui.qr;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.penelope.qshopping.MainActivity;
import com.penelope.qshopping.R;
import com.penelope.qshopping.data.mart.Mart;
import com.penelope.qshopping.data.mart.Product;
import com.penelope.qshopping.databinding.DialogPickCountBinding;
import com.penelope.qshopping.databinding.FragmentQrBinding;
import com.penelope.qshopping.utils.TermUtil;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class QrFragment extends Fragment {

    private FragmentQrBinding binding;
    private QrViewModel viewModel;

    // QR 코드 스캐너
    private IntentIntegrator intentIntegrator;


    public QrFragment() {
        super(R.layout.fragment_qr);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // QR 코드 스캐너를 초기화한다
        intentIntegrator = new IntentIntegrator(requireActivity());
        intentIntegrator.setOrientationLocked(true);

        // 뷰 바인딩 실행
        binding = FragmentQrBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(QrViewModel.class);

        // 버튼 클릭시 뷰모델에 통보한다
        binding.fabScan.setOnClickListener(v -> viewModel.onScanClick());
        binding.fabExitMart.setOnClickListener(v -> viewModel.onExitMartClick());

        // 현재 입장한 마트에 따라 UI 를 업데이트한다
        viewModel.getCurrentMart().observe(getViewLifecycleOwner(), mart -> {
            binding.groupInMart.setVisibility(mart != null ? View.VISIBLE : View.INVISIBLE);
            binding.groupOutMart.setVisibility(mart != null ? View.INVISIBLE : View.VISIBLE);
            if (mart != null) {
                // 마트 이름 표시
                String strMartName = String.format(Locale.getDefault(),
                        "%s에서 장보기 중입니다", mart.getName());
                binding.textViewMartName.setText(strMartName);

                // 마트 사진 표시
                Glide.with(this).load(mart.getImageUrl()).into(binding.imageViewMart);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof QrViewModel.Event.ShowGeneralMessage) {
                // 뷰모델의 메세지를 출력한다
                String message = ((QrViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
            if (event instanceof QrViewModel.Event.ScanMart) {
                // 마트 QR 을 스캔한다
                intentIntegrator.setPrompt("마트의 QR 을 스캔해주세요");
                intentIntegrator.initiateScan();
            } else if (event instanceof QrViewModel.Event.ScanProduct) {
                // 물품 QR 을 스캔한다
                intentIntegrator.setPrompt("물품의 QR 을 스캔해주세요");
                intentIntegrator.initiateScan();
            } else if (event instanceof QrViewModel.Event.ConfirmExitMart) {
                // 현재 마트에서 나갈지 확인하는 대화상자를 띄운다
                Mart currentMart = ((QrViewModel.Event.ConfirmExitMart) event).currentMart;
                showConfirmExitMartDialog(currentMart);
            } else if (event instanceof QrViewModel.Event.PromptPickCount) {
                // 장바구니에 담을 물품 개수를 선택하는 대화상자를 띄운다
                Product product = ((QrViewModel.Event.PromptPickCount) event).product;
                showPromptPickCountDialog(product);
            } else if (event instanceof QrViewModel.Event.NotifyExceedingUpperLimit) {
                // 장바구니 한도 초과 방송을 송출한다
                int upperLimit = ((QrViewModel.Event.NotifyExceedingUpperLimit) event).upperLimit;
                String message = String.format(Locale.getDefault(), "장바구니 한도 %s을 초과했습니다",
                        TermUtil.price(upperLimit));
                Intent broadcastIntent = new Intent(MainActivity.ACTION_LIMIT);
                broadcastIntent.putExtra("message", message);
                requireContext().sendBroadcast(broadcastIntent);
            }
        });

        // PayFragment 에서 결제가 완료되면 뷰모델에 통보한다
        getParentFragmentManager().setFragmentResultListener("pay_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("success");
                    viewModel.onPayResult(success);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        // 인식된 QR 코드를 텍스트로 변환하여 뷰모델에 통보한다
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (result != null) {
            viewModel.onScanResult(result.getContents());
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void showConfirmExitMartDialog(Mart currentMart) {

        // 현재 마트에서 나갈지 확인하는 대화상자를 띄운다
        new AlertDialog.Builder(requireContext())
                .setTitle("마트 나가기")
                .setMessage(currentMart.getName() + "에서 나가시겠습니까? 장바구니가 초기화됩니다")
                .setPositiveButton("나가기", (dialog, which) -> viewModel.onExitMartConfirm())
                .setNegativeButton("취소", null)
                .show();
    }

    private void showPromptPickCountDialog(Product product) {

        DialogPickCountBinding binding = DialogPickCountBinding.inflate(getLayoutInflater());
        MutableLiveData<Integer> count = new MutableLiveData<>();

        // 장바구니에 담을 물품 개수를 선택하는 대화상자를 생성한다
        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(binding.getRoot())
                .create();

        // 물품의 정보를 띄운다
        Glide.with(this).load(product.getImageUrl()).into(binding.imageViewProduct);
        binding.textViewProductName.setText(product.getName());
        binding.textViewProductPrice.setText(TermUtil.price(product.getPrice()));

        // 물품개수 넘버피커 초기화
        binding.numberPickerCount.setValue(1);
        binding.numberPickerCount.setMinValue(1);
        binding.numberPickerCount.setMaxValue(30);
        binding.numberPickerCount.setOnValueChangedListener((picker, oldVal, newVal) -> {
            count.setValue(newVal);
        });

        // 물품개수에 따라 합계 금액 업데이트
        count.observe(getViewLifecycleOwner(), c -> {
            int totalPrice = c * product.getPrice();
            String strPrice = "합계 " + TermUtil.price(totalPrice);
            binding.textViewTotalPrice.setText(strPrice);
        });
        count.setValue(binding.numberPickerCount.getValue());

        // 담기 버튼이 클릭되면 개수 값을 뷰모델에 통보한다
        assert count.getValue() != null;
        binding.textViewAddPick.setOnClickListener(v -> {
            viewModel.onPickCountResult(product, count.getValue());
            dialog.dismiss();
        });

        binding.textViewCancel.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

}