package com.penelope.qshopping.utils;

import android.content.SharedPreferences;

public class SharedPreferenceStringLiveData extends SharedPreferenceLiveData<String> {

    public SharedPreferenceStringLiveData(SharedPreferences preferences, String key, String defValue) {
        super(preferences, key, defValue);
    }

    @Override
    String getValueFromPreferences(String key, String defValue) {
        return sharedPrefs.getString(key, defValue);
    }
}

