package com.penelope.qshopping.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.penelope.qshopping.utils.SharedPreferenceIntegerLiveData;
import com.penelope.qshopping.utils.SharedPreferenceStringLiveData;

import javax.inject.Inject;

public class PreferenceData {

    private final SharedPreferences preferences;
    private final SharedPreferenceStringLiveData currentMartId;
    private final SharedPreferenceIntegerLiveData upperLimit;

    @Inject
    public PreferenceData(Context context) {
        preferences = PreferenceManager.getDefaultSharedPreferences(context);
        currentMartId = new SharedPreferenceStringLiveData(preferences, "current_mart", null);
        upperLimit = new SharedPreferenceIntegerLiveData(preferences, "upper_limit", 1000000);
    }

    public SharedPreferenceStringLiveData getCurrentMartIdLive() {
        return currentMartId;
    }

    public String getCurrentMartId() {
        return preferences.getString("current_mart", null);
    }

    public SharedPreferenceIntegerLiveData getUpperLimitLive() {
        return upperLimit;
    }

    public int getUpperLimit() {
        return preferences.getInt("upper_limit", 1000000);
    }

    public void setCurrentMartId(String martId) {
        preferences.edit().putString("current_mart", martId).apply();
    }

    public void setUpperLimit(int price) {
        preferences.edit().putInt("upper_limit", price).apply();
    }

}
