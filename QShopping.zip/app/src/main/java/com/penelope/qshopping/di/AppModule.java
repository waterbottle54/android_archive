package com.penelope.qshopping.di;

import android.app.Application;

import androidx.room.Room;

import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.qshopping.data.PreferenceData;
import com.penelope.qshopping.data.pick.PickDao;
import com.penelope.qshopping.data.pick.PickDatabase;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn(SingletonComponent.class)
public class AppModule {

    @Provides
    public FirebaseFirestore provideFirestore() {
        return FirebaseFirestore.getInstance();
    }

    @Provides
    @Singleton
    public PickDatabase providePickDatabase(Application application) {
        return Room.databaseBuilder(application, PickDatabase.class, "pick_database")
                        .fallbackToDestructiveMigration()
                        .build();
    }

    @Provides
    public PickDao providePickDao(PickDatabase pickDatabase) {
        return pickDatabase.pickDao();
    }

    @Provides
    @Singleton
    public PreferenceData providePreferenceData(Application application) {
        return new PreferenceData(application);
    }

}
