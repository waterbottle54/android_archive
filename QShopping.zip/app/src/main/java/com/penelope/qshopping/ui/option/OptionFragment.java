package com.penelope.qshopping.ui.option;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.penelope.qshopping.R;
import com.penelope.qshopping.databinding.FragmentOptionBinding;
import com.penelope.qshopping.utils.NumberUtils;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class OptionFragment extends Fragment {

    private FragmentOptionBinding binding;
    private OptionViewModel viewModel;


    public OptionFragment() {
        super(R.layout.fragment_option);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentOptionBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(OptionViewModel.class);

        binding.numberPickerOnes.setMinValue(1);
        binding.numberPickerOnes.setMaxValue(9);
        binding.numberPickerTens.setMinValue(0);
        binding.numberPickerTens.setMaxValue(9);
        binding.numberPickerHundreds.setMinValue(0);
        binding.numberPickerHundreds.setMaxValue(9);

        binding.numberPickerOnes.setOnValueChangedListener((picker, oldVal, newVal) ->
                viewModel.onOnesChange(newVal));

        binding.numberPickerTens.setOnValueChangedListener((picker, oldVal, newVal) ->
                viewModel.onTensChange(newVal));

        binding.numberPickerHundreds.setOnValueChangedListener((picker, oldVal, newVal) ->
                viewModel.onHundredsChange(newVal));

        viewModel.getUpperLimit().observe(getViewLifecycleOwner(), upperLimit -> {
            int simple = upperLimit / 10000;
            int hundreds = NumberUtils.getHundreds(simple);
            int tens = NumberUtils.getTens(simple);
            int ones = NumberUtils.getOnes(simple);
            binding.numberPickerHundreds.setValue(hundreds);
            binding.numberPickerTens.setValue(tens);
            binding.numberPickerOnes.setValue(ones);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}