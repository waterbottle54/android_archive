package com.penelope.qshopping.utils;

import com.penelope.qshopping.data.PaymentType;

import java.text.NumberFormat;

public class TermUtil {

    public static String price(int price) {
        return NumberFormat.getInstance().format(price) + "원";
    }

    public static String paymentType(PaymentType type) {
        switch (type) {
            case CREDIT_CARD: return "신용카드";
            case TRANSFER: return "계좌이체";
            case NAVER_PAY: return "네이버페이";
        }
        return null;
    }

}
