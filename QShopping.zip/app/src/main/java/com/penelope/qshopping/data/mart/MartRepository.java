package com.penelope.qshopping.data.mart;

import androidx.annotation.WorkerThread;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.qshopping.data.pick.Pick;
import com.penelope.qshopping.data.pick.PickDao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class MartRepository {

    private final CollectionReference martCollection;
    private final PickDao pickDao;


    @Inject
    public MartRepository(FirebaseFirestore firestore, PickDao pickDao) {
        this.martCollection = firestore.collection("marts");
        this.pickDao = pickDao;
    }

    public void searchMart(String martId, OnSuccessListener<Mart> onSuccessListener, OnFailureListener onFailureListener) {

        if (martId == null) {
            onSuccessListener.onSuccess(null);
            return;
        }

        martCollection.document(martId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot != null) {
                        onSuccessListener.onSuccess(documentSnapshot.toObject(Mart.class));
                    } else {
                        onSuccessListener.onSuccess(null);
                    }
                })
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<Mart> getMartLive(String martId) {

        MutableLiveData<Mart> mart = new MutableLiveData<>();
        if (martId == null) {
            mart.setValue(null);
            return mart;
        }

        martCollection.document(martId)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        error.printStackTrace();
                        mart.setValue(null);
                        return;
                    }
                    if (value != null) {
                        mart.setValue(value.toObject(Mart.class));
                    } else {
                        mart.setValue(null);
                    }
                });

        return mart;
    }

    public LiveData<Map<String, Product>> getProductMapLive(String martId) {

        return Transformations.map(getMartLive(martId), mart -> {
            if (mart != null) {
                Map<String, Product> map = new HashMap<>();
                for (Product product : mart.getProducts()) {
                    map.put(product.getId(), product);
                }
                return map;
            }
            return null;
        });
    }

    public void getProductMap(String martId,
                              OnSuccessListener<Map<String, Product>> onSuccessListener,
                              OnFailureListener onFailureListener) {
        searchMart(martId,
                mart -> {
                    if (mart != null) {
                        Map<String, Product> map = new HashMap<>();
                        for (Product product : mart.getProducts()) {
                            map.put(product.getId(), product);
                        }
                        onSuccessListener.onSuccess(map);
                    } else {
                        onSuccessListener.onSuccess(null);
                    }
                },
                onFailureListener);
    }

    public LiveData<Integer> getTotalPriceLive(String martId) {

        LiveData<Map<String, Product>> productMap = getProductMapLive(martId);
        LiveData<List<Pick>> picks = pickDao.getPicksLive();

        return Transformations.switchMap(productMap, map ->
                Transformations.map(picks, pickList -> {
                    if (map == null || pickList == null) {
                        return 0;
                    }
                    int sum = 0;
                    for (Pick pick : pickList) {
                        Product product = map.get(pick.getProductId());
                        if (product != null) {
                            sum += product.getPrice() * pick.getCount();
                        }
                    }
                    return sum;
                }));
    }

    @WorkerThread
    public void getTotalPrice(String martId,
                              OnSuccessListener<Integer> onSuccessListener,
                              OnFailureListener onFailureListener) {

        List<Pick> picks = pickDao.getPicks();
        getProductMap(martId,
                productMap -> {
                    if (productMap == null || picks == null) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    int sum = 0;
                    for (Pick pick : picks) {
                        Product product = productMap.get(pick.getProductId());
                        if (product != null) {
                            sum += product.getPrice() * pick.getCount();
                        }
                    }
                    onSuccessListener.onSuccess(sum);
                },
                onFailureListener);
    }

}




