package com.penelope.qshopping;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class QShoppingApplication extends Application {

    public static final String CHANNEL_NAME_LIMIT = "limit";
    public static final String CHANNEL_ID_LIMIT = "com.penelope.qshopping.channel_limit";


    @Override
    public void onCreate() {
        super.onCreate();

        // 노티피케이션 채널을 생성한다
        createNotificationChannel();
    }

    private void createNotificationChannel() {

        NotificationManager manager = getSystemService(NotificationManager.class);

        NotificationChannel limitChannel = new NotificationChannel(
                CHANNEL_ID_LIMIT,
                CHANNEL_NAME_LIMIT,
                NotificationManager.IMPORTANCE_HIGH
        );

        manager.createNotificationChannel(limitChannel);
    }

}
