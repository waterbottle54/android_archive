package com.won1996.empty1.data.record

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow


@Dao
interface RecordDao {

    @Query("SELECT * FROM records ORDER BY created DESC")
    fun getRecords(): Flow<List<Record>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun addRecord(record: Record)
}