package com.won1996.empty1

import androidx.lifecycle.ViewModel
import com.won1996.empty1.data.record.RecordDao
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(private val recordDao: RecordDao): ViewModel() {

    val recordList = recordDao.getRecords()


}