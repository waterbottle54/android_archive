package com.won1996.empty1.data.record

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity("records")
data class Record(
    val year: Int = 0,
    val month: Int = 0,
    val day: Int = 0,
    val weight: Double = 0.0,
    val created: Long = 0,
) {
    @PrimaryKey
    var id = "$year-$month-$day"
}