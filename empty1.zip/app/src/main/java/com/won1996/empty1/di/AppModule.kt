package com.won1996.empty1.di

import android.app.Application
import androidx.room.Room
import com.won1996.empty1.data.record.RecordDao
import com.won1996.empty1.data.record.RecordDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
class AppModule {

    @Provides
    fun provideRecordDatabase(application: Application): RecordDatabase {
        return Room.databaseBuilder(application, RecordDatabase::class.java, "record_database")
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    fun provideRecordDao(db: RecordDatabase): RecordDao {
        return db.recordDao()
    }
}
