package com.won1996.empty1

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class EmptyApplication : Application() {
}