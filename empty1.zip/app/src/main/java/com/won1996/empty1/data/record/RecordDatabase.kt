package com.won1996.empty1.data.record

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Record::class], exportSchema = false, version = 1)
abstract class RecordDatabase : RoomDatabase() {

    abstract fun recordDao(): RecordDao

}