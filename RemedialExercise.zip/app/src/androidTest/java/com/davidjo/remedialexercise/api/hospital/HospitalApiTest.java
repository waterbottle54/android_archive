package com.davidjo.remedialexercise.api.hospital;

import junit.framework.TestCase;

public class HospitalApiTest extends TestCase {



}