package com.davidjo.remedialexercise.api.hospital;

import android.util.Log;

import androidx.annotation.WorkerThread;

import com.davidjo.remedialexercise.data.hospital.Hospital;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import javax.inject.Inject;

public class HospitalApi {

    // 병원 정보 API 호출을 위한 OPEN API URL 및 구성요소
    public static final String URL_FORMAT = "http://apis.data.go.kr/B551182/hospInfoService1/getHospBasisList1?serviceKey=[SERVICE_KEY]&numOfRows=[NUM]&xPos=[XPOS]&yPos=[YPOS]&radius=[RAD]&dgsbjtCd=[PART]";
    public static final String PLACEHOLDER_KEY = "[SERVICE_KEY]";
    public static final String PLACEHOLDER_NUM = "[NUM]";
    public static final String PLACEHOLDER_LONGITUDE = "[XPOS]";
    public static final String PLACEHOLDER_LATITUDE = "[YPOS]";
    public static final String PLACEHOLDER_RADIUS = "[RAD]";
    public static final String PLACEHOLDER_PART = "[PART]";
    public static final String PART_ORTHOPEDICS = "08";

    // OPEN API 서비스 키
    public static final String SERVICE_KEY = "MtVBdtw16Ez1YFEXjvMpB0Zws4eaThA35edKG44NT6A0P3gsproUZBkpaFUUVrHmaPUzkazSncH9iukFY%2BdQfw%3D%3D";


    @WorkerThread
    public static List<Hospital> get(double latitude, double longitude, double radius) {

        try {
            // 위도, 경도, 반경으로 URL 을 구성한다
            String strUrl = URL_FORMAT
                    .replace(PLACEHOLDER_KEY, SERVICE_KEY)
                    .replace(PLACEHOLDER_LATITUDE, String.valueOf(latitude))
                    .replace(PLACEHOLDER_LONGITUDE, String.valueOf(longitude))
                    .replace(PLACEHOLDER_RADIUS, String.valueOf(radius))
                    .replace(PLACEHOLDER_PART, PART_ORTHOPEDICS)
                    .replace(PLACEHOLDER_NUM, String.valueOf(20));

            // 오픈 API 를 연결하고 XML 자료 (input stream) 을 파싱하여 병원 목록을 리턴한다
            URL url = new URL(strUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            return HospitalXmlParser.parse(conn.getInputStream());

        } catch (XmlPullParserException | IOException e) {
            e.printStackTrace();
        }

        return null;
    }

}
