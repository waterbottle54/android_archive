package com.davidjo.remedialexercise.ui.video;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.BodyPart;
import com.davidjo.remedialexercise.data.exercise.Exercise;
import com.davidjo.remedialexercise.databinding.FragmentVideoBinding;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class VideoFragment extends BottomSheetDialogFragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_video, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩, 뷰모델을 초기화한다
        FragmentVideoBinding binding = FragmentVideoBinding.bind(view);
        VideoViewModel viewModel = new ViewModelProvider(this).get(VideoViewModel.class);

        // 아규먼트로 전달된 신체부위를 획득한다
        BodyPart bodyPart = BodyPart.NECK;
        if (getArguments() != null) {
            bodyPart = VideoFragmentArgs.fromBundle(getArguments()).getBodyPart();
        }

        // 유튜브 플레이어를 뷰 라이프사이클과 연동하여 리소스를 제어한다
        getLifecycle().addObserver(binding.youtubePlayer);

        // 뷰모델에서 받은 운동 목록을 조회하여 첫 번째 운동을 UI 에 보여준다
        viewModel.getExercises(bodyPart).observe(getViewLifecycleOwner(), exercises -> {
            if (!exercises.isEmpty()) {
                Exercise exercise = exercises.get(0);
                binding.textViewExerciseName.setText(exercise.getName());
                binding.textViewExerciseDescription.setText(exercise.getDescription());
                binding.textViewExerciseProvider.setText(exercise.getProvider());

                // 운동 영상의 유튜브 ID 를 전달하여 유튜브 영상을 유튜브 플레이어에 띄운다
                binding.youtubePlayer.addYouTubePlayerListener(new AbstractYouTubePlayerListener() {
                    @Override
                    public void onReady(@NonNull YouTubePlayer youTubePlayer) {
                        youTubePlayer.loadVideo(exercise.getYoutubeVideoId(), 0);
                    }
                });
            }
        });
    }

}




