package com.davidjo.remedialexercise.data.exercise;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.davidjo.remedialexercise.data.BodyPart;

import java.util.List;

@Dao
public interface ExerciseDao {

    // 신체 부위와 관련된 모든 재활운동 목록을 DB 에서 구해준다
    @Query("SELECT * FROM exercise_table WHERE bodyPart == :target")
    LiveData<List<Exercise>> getExercises(BodyPart target);

    // 새로운 재활운동을 DB 에 저장한다
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Exercise exercise);

}
