package com.davidjo.remedialexercise.ui.promptbodypart;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.davidjo.remedialexercise.data.BodyPart;

import retrofit2.http.Body;

public class PromptBodyPartViewModel extends ViewModel {

    private final MutableLiveData<BodyPart> bodyPart = new MutableLiveData<>(null); // 현재 선택된 신체부위
    private final MutableLiveData<Event> event = new MutableLiveData<>(null);       // 뷰모델의 명령

    public LiveData<BodyPart> getBodyPart() {
        return bodyPart;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    // 신체 부위 선택 시, 신체부위 객체를 업데이트한다
    public void onBodyPartSelected(BodyPart part) {
        bodyPart.setValue(part);
    }

    public void onConfirmClicked() {
        // 확정 버튼 클릭 시, 해당 신체부위 값과 함께 데스티네이션 프래그먼트로 이동하도록 한다
        if (bodyPart.getValue() != null) {
            event.setValue(new Event.NavigateToDestination(bodyPart.getValue()));
        } else {
            event.setValue(new Event.ShowGeneralMessage("신체 부위를 선택하세요"));
        }
    }

    // 프래그먼트에 보내는 명령
    public static class Event {

        public static class NavigateToDestination extends Event {
            public final BodyPart bodyPart;
            public NavigateToDestination(BodyPart bodyPart) {
                this.bodyPart = bodyPart;
            }
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }
    }

}
