package com.davidjo.remedialexercise.ui.statistic;

import android.util.Pair;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

import com.davidjo.remedialexercise.data.training.Training;
import com.davidjo.remedialexercise.data.training.TrainingDao;
import com.davidjo.remedialexercise.util.ChartFilter;
import com.davidjo.remedialexercise.util.TimeUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class StatisticViewModel extends ViewModel {

    private final LiveData<List<Training>> trainings;       // DB에 저장된 운동 기록 정보들

    // 운동 기록으로부터 운동 시간을 추출한 리스트
    private final MutableLiveData<List<Pair<LocalDate, Integer>>> minutesList = new MutableLiveData<>();

    // 현재 연, 월, 일 필터
    private final MutableLiveData<ChartFilter> filter = new MutableLiveData<>(ChartFilter.DAILY);

    private final Observer<List<Training>> trainingsObserver;
    private final Observer<ChartFilter> filterObserver;


    @Inject
    public StatisticViewModel(TrainingDao trainingDao) {

        trainings = trainingDao.getTrainings();

        // 운동 기록으로부터 운동 시간을 추출한다
        trainingsObserver = trainings -> {
            ChartFilter filter = this.filter.getValue();
            if (trainings != null && filter != null) {
                minutesList.setValue(getTrainingMinutes(trainings, filter));
            }
        };
        trainings.observeForever(trainingsObserver);

        // 연, 월, 일 필터 변경 시 기간을 변경하여 운동 시간을 추출한다
        filterObserver = filter -> {
            List<Training> trainings = this.trainings.getValue();
            if (filter != null && trainings != null) {
                minutesList.setValue(getTrainingMinutes(trainings, filter));
            }
        };
        filter.observeForever(filterObserver);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        trainings.removeObserver(trainingsObserver);
        filter.observeForever(filterObserver);
    }

    public LiveData<List<Pair<LocalDate, Integer>>> getMinutesList() {
        return minutesList;
    }

    public LiveData<ChartFilter> getChartFilter() {
        return filter;
    }


    public void onChartFilterSelected(ChartFilter chartFilter) {
        filter.setValue(chartFilter);
    }

    // 운동기록 목록과 연,월,일 필터로부터 차트 구성 요소를 리턴한다
    private List<Pair<LocalDate, Integer>> getTrainingMinutes(List<Training> trainings, ChartFilter filter) {

        List<Pair<LocalDate, Integer>> minutesList = new ArrayList<>();
        LocalDate today = LocalDate.now();

        switch (filter) {
            case DAILY:     // 일 단위 필터
                for (int days = 6; days >= 0; days--) {
                    // 1주간의 운동시간을 추출한다
                    LocalDate date = today.minusDays(days);
                    int minutes = 0;
                    for (Training training : trainings) {
                        long created = training.getCreatedTime();
                        if (TimeUtils.getLocalDate(created).equals(date)) {
                            minutes += training.getMinutes();
                        }
                    }
                    minutesList.add(new Pair<>(date, minutes));
                }
                break;
            case MONTHLY:   // 월 단위 필터
                for (int months = 6; months >= 0; months--) {
                    // 6개월간의 운동시간을 추출한다
                    LocalDate date = today.minusMonths(months);
                    int minutes = 0;
                    for (Training training : trainings) {
                        LocalDate created = TimeUtils.getLocalDate(training.getCreatedTime());
                        if (TimeUtils.isYearMonthTheSame(date, created)) {
                            minutes += training.getMinutes();
                        }
                    }
                    minutesList.add(new Pair<>(date, minutes));
                }
                break;
            case YEARLY:    // 연 단위 필터
                for (int years = 6; years >= 0; years--) {
                    // 6년간의 운동시간을 추출한다
                    LocalDate date = today.minusYears(years);
                    int minutes = 0;
                    for (Training training : trainings) {
                        LocalDate created = TimeUtils.getLocalDate(training.getCreatedTime());
                        if (date.getYear() == created.getYear()) {
                            minutes += training.getMinutes();
                        }
                    }
                    minutesList.add(new Pair<>(date, minutes));
                }
                break;
        }

        return minutesList;
    }


}
