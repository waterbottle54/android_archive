package com.davidjo.remedialexercise.data.hospital;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.davidjo.remedialexercise.api.hospital.HospitalApi;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class HospitalRepository {

    @Inject
    public HospitalRepository() {
    }

    // 위치 (위도, 경도) 와 반경을 받아서, 해당 위치의 해당 반경 이내에 있는 병원 목록을 리턴한다
    // HospitalApi 클래스가 내부적으로 OpenAPI 와 연결해 정보를 제공해 준다

    public LiveData<List<Hospital>> getHospitals(double latitude, double longitude, double radius) {

        MutableLiveData<List<Hospital>> hospitals = new MutableLiveData<>();

        // 네트워크 통신은 시간 지연이 있으므로 백그라운드 스레드에서 실행된다
        new Thread(() -> {
            List<Hospital> hospitalList = HospitalApi.get(latitude, longitude, radius);
            hospitals.postValue(hospitalList);
        }).start();

        return hospitals;
    }

}
