package com.davidjo.remedialexercise.ui.training.home;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.exercise.Exercise;
import com.davidjo.remedialexercise.services.TrainingService;
import com.davidjo.remedialexercise.databinding.FragmentTrainingBinding;
import com.davidjo.remedialexercise.util.TimeUtils;
import com.google.android.material.snackbar.Snackbar;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer;
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener;

import java.util.List;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class TrainingFragment extends Fragment implements ServiceConnection {

    private static final String TAG = "TrainingFragment";

    private Context context;
    private FragmentTrainingBinding binding;
    private TrainingViewModel viewModel;
    private TrainingService trainingService;
    private final MutableLiveData<Boolean> isBound = new MutableLiveData<>(false);
    private YouTubePlayer youTubePlayer;

    public TrainingFragment() {
        super(R.layout.fragment_training);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        this.context = context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩과 뷰모델을 초기화한다
        binding = FragmentTrainingBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(TrainingViewModel.class);

        // 계획 포기, 계획 완료 버튼 클릭 시 뷰모델에 통보한다
        binding.fabDiscardPlan.setOnClickListener(v -> viewModel.onDiscardPlanClick());
        binding.fabCompletePlan.setOnClickListener(v -> viewModel.onCompletePlanClick());

        // 유튜브 플레이어를 뷰 라이프사이클과 연동하여 리소스를 관리한다
        getLifecycle().addObserver(binding.youtubePlayer);
        binding.youtubePlayer.getYouTubePlayerWhenReady(youTubePlayer -> {
            // 유튜브 플레이어 로딩 완료
            this.youTubePlayer = youTubePlayer;
            Log.d(TAG, "getYouTubePlayerWhenReady: ");
        });

        // 디-데이를 UI에 업데이트한다
        viewModel.getDayPlus().observe(getViewLifecycleOwner(), dayPlus -> {
            if (dayPlus != null) {
                String strDayPlus = String.format(Locale.getDefault(), getString(R.string.day_plus),
                        dayPlus >= 0 ? "+" : "", dayPlus);
                binding.textViewDayPlus.setText(strDayPlus);
            } else {
                binding.textViewDayPlus.setText("");
            }
        });

        // 시작/일시정지 버튼을 활성화 / 비활성화한다
        viewModel.isStartable().observe(getViewLifecycleOwner(), isStartable -> {
            binding.fabStartPauseRepetition.setEnabled(isStartable);
            binding.fabStartPauseRepetition.setClickable(isStartable);
        });

        // 종료까지 남은 기간을 UI 에 업데이트한다
        viewModel.getDaysLeft().observe(getViewLifecycleOwner(), daysLeft -> {
            if (daysLeft != null) {
                String strDaysLeft = String.format(Locale.getDefault(), getString(R.string.days_left), daysLeft);
                binding.textViewDaysLeft.setText(strDaysLeft);
            } else {
                binding.textViewDaysLeft.setText("");
            }
            binding.fabCompletePlan.setEnabled(daysLeft != null && daysLeft == 0);
        });

        // 재활운동 계획 포기 버튼을 활성화 / 비활성화한다
        viewModel.getPlan().observe(getViewLifecycleOwner(), plan ->
                binding.fabDiscardPlan.setEnabled(plan != null));

        // 오늘 해야 할 반복 횟수를 UI 에 업데이트한다
        viewModel.getTotalRepetition().observe(getViewLifecycleOwner(), totalRepetition -> {
            if (totalRepetition != null) {
                binding.textViewRepetitionTotal.setText(String.valueOf(totalRepetition));
            } else {
                binding.textViewRepetitionTotal.setText("");
            }
        });

        // 현재 진행한 반복 횟수를 UI 에 업데이트한다
        viewModel.getCurrentRepetition().observe(getViewLifecycleOwner(), currentRepetition -> {
            if (currentRepetition != null) {
                binding.textViewRepetitionDone.setText(String.valueOf(currentRepetition));
            } else {
                binding.textViewRepetitionDone.setText("");
            }
        });

        // 1회당 실시해야 할 운동 시간(분)을 UI 에 업데이트한다
        viewModel.getMinutesPerRepetition().observe(getViewLifecycleOwner(), minutes -> {
            if (minutes != null) {
                binding.textViewTimeRemaining.setText(TimeUtils.formatMinutesSeconds(minutes * 60));
            } else {
                binding.textViewTimeRemaining.setText("-:-");
            }
        });

        // 뷰모델에서 통보한 명령을 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof TrainingViewModel.Event.ShowNoPlanMessage) {
                // 작성된 재활운동 계획이 없으면 메세지를 보이고 이전 프래그먼트로 돌아간다
                TrainingViewModel.Event.ShowNoPlanMessage showNoPlanMessage =
                        (TrainingViewModel.Event.ShowNoPlanMessage) event;
                new AlertDialog.Builder(context)
                        .setMessage(showNoPlanMessage.message)
                        .setPositiveButton("확인", (dialog, which) ->
                                Navigation.findNavController(requireView()).popBackStack()).show();
            } else if (event instanceof TrainingViewModel.Event.ShowDiscardPlanConfirmMessage) {
                // 계획 포기를 다시 한 번 확인한다
                TrainingViewModel.Event.ShowDiscardPlanConfirmMessage showDiscardPlanConfirmMessage =
                        (TrainingViewModel.Event.ShowDiscardPlanConfirmMessage) event;
                Snackbar.make(requireView(), showDiscardPlanConfirmMessage.message, Snackbar.LENGTH_SHORT)
                        .setAction("포기", v -> viewModel.onDiscardPlanConfirm())
                        .show();
            } else if (event instanceof TrainingViewModel.Event.NavigateToSurveyScreen) {
                // 설문 프래그먼트로 이동한다
                NavDirections action = TrainingFragmentDirections.actionTrainingFragmentToSurveyFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof TrainingViewModel.Event.StartTrainingService) {
                // 운동 서비스를 시작한다
                if (!TrainingService.isServiceStarted) {
                    startTrainingService();
                }
            }
        });

        // 서비스 바인딩 여부에 따라 UI 를 제어한다
        isBound.observe(getViewLifecycleOwner(), isBound -> {
            if (isBound) {
                // 서비스 바인딩이 되어 있는 경우, 운동 진행 중이므로 버튼을 활성화한다
                binding.fabStartPauseRepetition.setOnClickListener(v -> trainingService.toggleCountdownTimer());
                binding.fabStopRepetition.setEnabled(true);
                binding.fabStopRepetition.setOnClickListener(v -> trainingService.stopCountdownTimer());
                binding.groupPlayer.setVisibility(View.VISIBLE);

                // 현재 시간초, 일시정지 여부를 UI 에 업데이트한다
                trainingService.getSeconds().observe(getViewLifecycleOwner(), seconds ->
                        binding.textViewTimeRemaining.setText(TimeUtils.formatMinutesSeconds(seconds))
                );
                trainingService.isPaused().observe(getViewLifecycleOwner(), isPaused ->
                        binding.fabStartPauseRepetition.setImageDrawable(
                                ContextCompat.getDrawable(context, isPaused ? R.drawable.ic_start : R.drawable.ic_pause))
                );

                // 진행중인 운동의 동영상을 유튜브 플레이어에 띄운다
                List<Exercise> exercises = viewModel.getExercises();
                if (exercises != null && !exercises.isEmpty()) {
                    Exercise exercise = exercises.get(0);
                    if (youTubePlayer == null) {
                        binding.youtubePlayer.getYouTubePlayerWhenReady(youTubePlayer -> {
                            this.youTubePlayer = youTubePlayer;
                            youTubePlayer.loadVideo(exercise.getYoutubeVideoId(), 0);
                        });
                    } else {
                        youTubePlayer.loadVideo(exercise.getYoutubeVideoId(), 0);
                    }
                }

            } else {
                // 서비스 바인딩이 없을 경우 운동 진행중이 아니므로 버튼을 비활성화한다
                binding.fabStartPauseRepetition.setOnClickListener(v -> viewModel.onStartRepetitionClick());
                binding.fabStartPauseRepetition.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.ic_start));
                binding.fabStopRepetition.setEnabled(false);
                binding.fabStopRepetition.setClickable(false);
                binding.groupPlayer.setVisibility(View.GONE);

                Integer minutes = viewModel.getMinutesPerRepetition().getValue();
                if (minutes != null) {
                    binding.textViewTimeRemaining.setText(TimeUtils.formatMinutesSeconds(minutes * 60));
                }

                // 유튜브 플레이어를 중단한다
                if (youTubePlayer != null) {
                    youTubePlayer.pause();
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        // 서비스 바인딩을 실시한다
        if (TrainingService.isServiceStarted) {
            Intent intent = new Intent(context, TrainingService.class);
            context.bindService(intent, this, Activity.BIND_AUTO_CREATE);
        } else {
            isBound.setValue(false);
        }

        // 방송 수신자를 등록한다
        context.registerReceiver(finishedReceiver, new IntentFilter(TrainingService.BR_FINISHED));
    }

    @Override
    public void onPause() {
        super.onPause();

        // 서비스 바인딩을 중단한다
        if (TrainingService.isServiceStarted) {
            context.unbindService(this);
        }

        // 방송 수신자를 해제한다
        context.unregisterReceiver(finishedReceiver);
    }

    @Override
    public void onServiceConnected(ComponentName name, IBinder service) {
        // 서비스 바인딩 완료
        trainingService = ((TrainingService.TrainingBinder) service).getService();
        isBound.setValue(true);
    }

    @Override
    public void onServiceDisconnected(ComponentName name) {
        onServiceUnbound();
    }

    private void onServiceUnbound() {
        // 서비스 바인딩 취소
        trainingService = null;
        isBound.setValue(false);
    }

    public void startTrainingService() {
        // 운동 서비스를 시작한다. 인텐트로 재활운동 계획을 전달한다. 포그라운드 서비스로 실행한다
        if (viewModel.getPlan().getValue() != null) {
            Intent intent = new Intent(context, TrainingService.class);
            intent.putExtra(TrainingService.EXTRA_PLAN, viewModel.getPlan().getValue());
            context.startForegroundService(intent);
            context.bindService(intent, this, Activity.BIND_AUTO_CREATE);
        }
    }

    // 방송 수신자
    private final BroadcastReceiver finishedReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // 운동 종료 방송 수신 시, 서비스 바인딩을 해제한다
            TrainingFragment.this.context.unbindService(TrainingFragment.this);
            onServiceUnbound();
        }
    };

}
