package com.davidjo.remedialexercise.data.training;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface TrainingDao {

    // DB 에 기록된 모든 운동 기록을 조회한다
    @Query("SELECT * FROM training_table")
    LiveData<List<Training>> getTrainings();

    // 특정 재활운동계획에 소속되고 특정 기간에 실시된 운동기록을 조회한다
    @Query("SELECT * FROM training_table WHERE planId == :planId AND createdTime >= :startTime AND createdTime <= :endTime")
    LiveData<List<Training>> getTrainings(int planId, long startTime, long endTime);

    // 운동기록을 추가한다
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Training training);

}
