package com.davidjo.remedialexercise.ui.diagnosis.home;

import android.content.Context;
import android.os.Bundle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.BodyPart;
import com.davidjo.remedialexercise.databinding.FragmentDiagnosisBinding;
import com.davidjo.remedialexercise.util.NameUtils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class DiagnosisFragment extends Fragment {

    private FragmentDiagnosisBinding binding;
    private DiagnosisViewModel viewModel;
    private Context context;


    public DiagnosisFragment() {
        super(R.layout.fragment_diagnosis);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        this.context = context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩, 뷰 모델을 초기화한다
        binding = FragmentDiagnosisBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(DiagnosisViewModel.class);

        // 진단 답변 입력을 위한 위젯 (UI) 를 초기화한다
        buildDiagnosisUI();

        // 진단 답변 제출 버튼을 클릭하면 뷰모델에 통보한다
        binding.fabSubmitDiagnosis.setOnClickListener(v -> viewModel.onSubmitClicked());

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

            NavDirections action;

            if (event instanceof DiagnosisViewModel.Event.NavigateSuccessScreen) {
                // 진단 성공 프래그먼트로 이동한다
                DiagnosisViewModel.Event.NavigateSuccessScreen navigateSuccessScreen =
                        (DiagnosisViewModel.Event.NavigateSuccessScreen) event;
                action = DiagnosisFragmentDirections.actionDiagnosisFragmentToDiagnosisSuccessFragment(
                        navigateSuccessScreen.bodyPart
                );
                Navigation.findNavController(view).navigate(action);

            } else if (event instanceof DiagnosisViewModel.Event.NavigateFailureScreen) {
                // 진단 실패 프래그먼트로 이동한다
                DiagnosisViewModel.Event.NavigateFailureScreen navigateFailureScreen =
                        (DiagnosisViewModel.Event.NavigateFailureScreen) event;
                action = DiagnosisFragmentDirections.actionDiagnosisFragmentToDiagnosisFailureFragment(
                        navigateFailureScreen.message
                );
                Navigation.findNavController(view).navigate(action);

            } else if (event instanceof DiagnosisViewModel.Event.ShowMonthsInputUI) {
                // 개월 수 입력 UI (스피너) 를 보여준다
                DiagnosisViewModel.Event.ShowMonthsInputUI showMonthsInputUI =
                        (DiagnosisViewModel.Event.ShowMonthsInputUI) event;
                binding.groupMonthsAfterSurgery.setVisibility(showMonthsInputUI.show ?
                        View.VISIBLE : View.GONE);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    private void buildDiagnosisUI() {

        // 스피너를 초기화한다
        buildBodyPartSpinner();
        buildPainLevelSpinner();
        buildMonthsSpinner();

        // 체크박스를 초기화한다
        binding.checkBoxGotSurgery.setOnCheckedChangeListener((buttonView, isChecked) ->
                viewModel.onGotSurgeryChecked(isChecked));

        binding.checkBoxMultiplePain.setOnCheckedChangeListener((buttonView, isChecked) ->
                viewModel.onMultiplePainChecked(isChecked));

        // 답변이 변경되면 체크박스도 업데이트한다
        viewModel.getAnswer().observe(getViewLifecycleOwner(), answer -> {
            binding.checkBoxGotSurgery.setChecked(answer.gotSurgery);
            binding.checkBoxMultiplePain.setChecked(answer.multiplePain);
        });
    }

    private void buildBodyPartSpinner() {

        // 신체부위 스피너를 초기화한다
        List<BodyPart> bodyParts = Arrays.asList(BodyPart.values());
        List<String> bodyPartNames = bodyParts.stream().map(NameUtils::getBodyPartName).collect(Collectors.toList());
        Map<BodyPart, Integer> bodyPartMap = new HashMap<>();
        for (int i = 0; i < bodyParts.size(); i++) {
            bodyPartMap.put(bodyParts.get(i), i);
        }
        ArrayAdapter<String> bodyPartAdapter = new ArrayAdapter<>(context, android.R.layout.simple_spinner_dropdown_item, bodyPartNames);
        binding.spinnerBodyPart.setAdapter(bodyPartAdapter);
        binding.spinnerBodyPart.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // 스피너에서 항목 선택 시 뷰모델에 통보한다
                viewModel.onBodyPartSelected(bodyParts.get(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // 답변 변경 시 스피너도 업데이트한다
        viewModel.getAnswer().observe(getViewLifecycleOwner(), answer -> {
            Integer bodyPartSelection = bodyPartMap.get(answer.bodyPart);
            binding.spinnerBodyPart.setSelection(bodyPartSelection != null ? bodyPartSelection : 0);
        });
    }

    private void buildPainLevelSpinner() {

        // 통증 레벨 스피너를 초기화한다
        int[] painLevels = {1, 2, 3, 4, 5};
        String[] painLevelNames = {"매우 약함", "약함", "보통", "심함", "매우 심함"};
        Map<Integer, Integer> painLevelMap = new HashMap<>();
        for (int i = 0; i < painLevels.length; i++) {
            painLevelMap.put(painLevels[i], i);
        }

        ArrayAdapter<String> painLevelAdapter = new ArrayAdapter<>(context, android.R.layout.simple_spinner_dropdown_item, painLevelNames);
        binding.spinnerPainLevel.setAdapter(painLevelAdapter);
        binding.spinnerPainLevel.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // 통증 레벨 선택 시 뷰모델에 통보한다
                viewModel.onPainLevelSelected(painLevels[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // 답변 변경 시 스피너도 업데이트한다
        viewModel.getAnswer().observe(getViewLifecycleOwner(), answer -> {
            Integer painLevelSelection = painLevelMap.get(answer.painLevel);
            binding.spinnerPainLevel.setSelection(painLevelSelection != null ? painLevelSelection : 0);
        });
    }

    private void buildMonthsSpinner() {

        // 수술 후 개월 수 스피너를 초기화한다
        int[] months = {0, 5, 11, 12};
        String[] monthNames = {"1개월 미만", "6개월 미만", "1년 미만", "1년 이상"};
        Map<Integer, Integer> monthsMap = new HashMap<>();
        for (int i = 0; i < months.length; i++) {
            monthsMap.put(months[i], i);
        }
        ArrayAdapter<String> monthsAdapter = new ArrayAdapter<>(context,
                android.R.layout.simple_spinner_dropdown_item,
                monthNames);
        binding.spinnerMonthsAfterSurgery.setAdapter(monthsAdapter);
        binding.spinnerMonthsAfterSurgery.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // 개월수가 선택되면 뷰모델에 통보
                viewModel.onMonthsAfterSurgerySelected(months[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // 답변 변경 시 스피너도 업데이트한다
        viewModel.getAnswer().observe(getViewLifecycleOwner(), answer -> {
            Integer monthsSelection = monthsMap.get(answer.monthsAfterSurgery);
            binding.spinnerMonthsAfterSurgery.setSelection(monthsSelection != null ? monthsSelection : 0);
        });
    }

}






