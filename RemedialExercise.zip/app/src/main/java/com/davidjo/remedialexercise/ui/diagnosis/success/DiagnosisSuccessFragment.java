package com.davidjo.remedialexercise.ui.diagnosis.success;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.BodyPart;
import com.davidjo.remedialexercise.databinding.FragmentDiagnosisSuccessBinding;
import com.davidjo.remedialexercise.util.NameUtils;

import java.util.Locale;

public class DiagnosisSuccessFragment extends Fragment {



    public DiagnosisSuccessFragment() {
        super(R.layout.fragment_diagnosis_success);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩을 초기화한다
        FragmentDiagnosisSuccessBinding binding = FragmentDiagnosisSuccessBinding.bind(view);

        // 아규먼트로부터 전달된 신체부위를 획득하여 텍스트 뷰에 보여준다
        if (getArguments() != null) {
            BodyPart bodyPart = DiagnosisSuccessFragmentArgs.fromBundle(getArguments()).getBodyPart();
            String str = String.format(Locale.getDefault(),
                    getString(R.string.would_you_start_rehab),
                    NameUtils.getBodyPartName(bodyPart)
            );
            binding.textViewWouldYouStartRehab.setText(str);

            // 재활운동 시작 클릭 시 재활운동 프래그먼트를 시작한다
            binding.fabStartRehab.setOnClickListener(v -> {
                NavDirections action = DiagnosisSuccessFragmentDirections.actionDiagnosisSuccessFragmentToInitiateFragment(bodyPart);
                Navigation.findNavController(view).navigate(action);
            });
        }
    }

}


