package com.davidjo.remedialexercise.data.plan;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface PlanDao {

    // 종료되지 않은 실행 중인 재활계획을 DB 에서 가져온다
    @Query("SELECT * FROM plan_table WHERE closed == 0")
    LiveData<Plan> getOngoingPlan();

    // 새로운 재활운동 계획을 DB 에 저장한다
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Plan plan);

    // 재활운동 계획을 업데이트한다
    @Update
    void update(Plan plan);

    // 재활운동 계획을 종료한다
    @Query("UPDATE plan_table SET closed = 1 WHERE id == :id")
    void close(int id);

    // 재활운동 계획을 삭제한다
    @Delete
    void delete(Plan plan);

}
