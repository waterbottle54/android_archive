package com.davidjo.remedialexercise.ui.initiate.goods;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.BodyPart;
import com.davidjo.remedialexercise.databinding.FragmentGoodsBinding;
import com.davidjo.remedialexercise.util.NameUtils;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import java.util.Locale;

public class GoodsFragment extends BottomSheetDialogFragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_goods, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩을 초기화한다
        FragmentGoodsBinding binding = FragmentGoodsBinding.bind(view);

        // 아규먼트로 전달된 신체부위를 확인한다
        BodyPart bodyPart = BodyPart.NECK;
        if (getArguments() != null) {
            bodyPart = GoodsFragmentArgs.fromBundle(getArguments()).getBodyPart();
        }

        binding.progressBar.setVisibility(View.VISIBLE);

        // 웹 뷰가 로딩되면 프로그레스바를 지운다
        binding.webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                binding.progressBar.setVisibility(View.INVISIBLE);
            }
        });

        // 신체부위의 이름으로부터 쿠팡 URL 을 구성하고 브라우저를 시작한다
        String url = String.format(Locale.getDefault(),
                getString(R.string.url_goods),
                NameUtils.getBodyPartName(bodyPart) + " 운동"
        );
        binding.webView.loadUrl(url);
    }

}
