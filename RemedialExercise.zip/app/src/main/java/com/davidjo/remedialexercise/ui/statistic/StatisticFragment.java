package com.davidjo.remedialexercise.ui.statistic;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.databinding.FragmentStatisticBinding;
import com.davidjo.remedialexercise.util.ChartFilter;
import com.davidjo.remedialexercise.util.NameUtils;
import com.davidjo.remedialexercise.util.TimeUtils;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class StatisticFragment extends Fragment {

    private Context context;
    private FragmentStatisticBinding binding;
    private StatisticViewModel viewModel;

    public StatisticFragment() {
        super(R.layout.fragment_statistic);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩, 뷰모델을 초기화한다
        binding = FragmentStatisticBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(StatisticViewModel.class);

        // 차트를 초기화한다
        initializeChart();

        // 연,월,일 스피너를 초기화한다
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                context, android.R.layout.simple_spinner_dropdown_item,
                Arrays.stream(ChartFilter.values()).map(NameUtils::getChartFilterName).collect(Collectors.toList())
        );
        binding.spinnerFilter.setAdapter(adapter);

        binding.spinnerFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // 스피너 연, 월, 일 선택 시 뷰모델에 통보한다
                viewModel.onChartFilterSelected(ChartFilter.values()[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        // 연, 월, 일 필터 변경 시 스피너도 업데이트한다
        viewModel.getChartFilter().observe(getViewLifecycleOwner(), filter ->
                binding.spinnerFilter.setSelection(filter.ordinal())
        );

        // 운동 시간 리스트가 전달되면, 차트에 운동 시간을 꺽인선 그래프로 업데이트한다
        viewModel.getMinutesList().observe(getViewLifecycleOwner(), minutesList -> {

            // 현재 연, 월, 일 필터
            ChartFilter filter = viewModel.getChartFilter().getValue();

            if (minutesList == null || filter == null) {
                return;
            }

            // 운동 시간을 차트에 입력될 수 있는 형태의 Entry 로 구성한다
            List<Entry> entries = new ArrayList<>();
            for (int i = 0; i < minutesList.size(); i++) {
                entries.add(new Entry((float) i, (float) minutesList.get(i).second));
            }

            // 차트에 필터 이름을 표시한다
            String label = String.format(Locale.getDefault(),
                    getString(R.string.training_minutes_by),
                    NameUtils.getChartFilterName(filter));

            // 꺽인선 그래프 데이터셋과 데이터를 구성한다
            LineDataSet lineDataSet = new LineDataSet(entries, label);
            styleDataSet(lineDataSet);
            LineData lineData = new LineData(lineDataSet);

            // X축 레이블을 필터 (연, 월, 일) 값에 따라 달리 표시한다
            binding.lineChart.getXAxis().setValueFormatter(new ValueFormatter() {
                @Override
                public String getAxisLabel(float value, AxisBase axis) {
                    LocalDate localDate = minutesList.get((int) value).first;
                    switch (filter) {
                        case DAILY:
                            return TimeUtils.formatMonthDay(localDate);
                        case MONTHLY:
                            return TimeUtils.formatYearMonth(localDate);
                        case YEARLY:
                            return String.valueOf(localDate.getYear());
                    }
                    return "";
                }
            });

            // 꺽인선 그래프 데이터를 전달하여 표시한다
            binding.lineChart.setData(lineData);
            binding.lineChart.invalidate();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void initializeChart() {

        // 차트의 외형 (배경색, 설명) 을 초기화한다
        binding.lineChart.setBackgroundColor(Color.WHITE);
        Description description = binding.lineChart.getDescription();
        description.setEnabled(false);

        // X 축의 빈도와 위치를 설정한다
        XAxis xAxis = binding.lineChart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        // Y축의 최소값과 레이블 표시 여부를 설정한다
        YAxis leftAxis = binding.lineChart.getAxisLeft();
        leftAxis.setAxisMinimum(0f);
        leftAxis.setDrawLabels(false);

        // Y축의 우측 축은 숨긴다
        YAxis rightAxis = binding.lineChart.getAxisRight();
        rightAxis.setEnabled(false);
    }

    private void styleDataSet(LineDataSet lineDataSet) {

        // 데이터셋 (꺾인선 그래프 선) 의 외형을 초기화한다
        lineDataSet.setLineWidth(3f);
        lineDataSet.setCircleRadius(6f);

        // 색상을 부여한다
        int chartColor = getResources().getColor(R.color.colorChart, null);
        lineDataSet.setColor(chartColor);
        lineDataSet.setCircleColor(chartColor);

        lineDataSet.setValueTextSize(12f);
    }


}










