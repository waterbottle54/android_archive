package com.davidjo.remedialexercise.ui.initiate.plan;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.util.Pair;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.plan.Plan;
import com.davidjo.remedialexercise.databinding.BottomSheetRuleBinding;
import com.davidjo.remedialexercise.databinding.FragmentPlanBinding;
import com.davidjo.remedialexercise.util.TimeUtils;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.snackbar.Snackbar;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PlanFragment extends Fragment {

    private Context context;
    private FragmentPlanBinding binding;
    private PlanViewModel viewModel;

    private BottomSheetDialog ruleDialog;           // 재활운동 규칙 대화상자
    private BottomSheetRuleBinding ruleBinding;     // 재활운동 규칙 대화상자의 뷰 바인딩 객체


    public PlanFragment() {
        super(R.layout.fragment_plan);
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩, 대화상자를 초기화한다
        binding = FragmentPlanBinding.bind(view);
        ruleBinding = BottomSheetRuleBinding.inflate(getLayoutInflater());
        viewModel = new ViewModelProvider(this).get(PlanViewModel.class);

        // 규칙 대화상자를 초기화한다
        buildRuleDialog();

        // 날짜 선택 대화상자를 띄운다
        binding.textViewSchedule.setOnClickListener(v -> showDateRangePicker());

        // 규칙 대화상자를 띄운다
        binding.textViewRule.setOnClickListener(v -> ruleDialog.show());

        // 계획을 DB에 저장한다
        binding.fabSavePlan.setOnClickListener(v -> viewModel.onSavePlanClicked());

        // 재활운동 정보 변경 시 UI (날짜, 규칙) 도 업데이트한다
        viewModel.getPlan().observe(getViewLifecycleOwner(), plan -> {

            String strSchedule = String.format(Locale.getDefault(),
                    getString(R.string.schedule_format),
                    TimeUtils.getDateString(getResources(), plan.getStartTime()),
                    TimeUtils.getDateString(getResources(), plan.getEndTime())
            );
            binding.textViewSchedule.setText(strSchedule);

            String strRule = String.format(Locale.getDefault(),
                    getString(R.string.rule_format),
                    plan.getMinutesPerRepetition(),
                    plan.getRepetitions()
            );
            binding.textViewRule.setText(strRule);

            ruleBinding.numberPickerRepetitions.setValue(plan.getRepetitions());
            ruleBinding.numberPickerMinutes.setValue(plan.getMinutesPerRepetition());
        });

        // 뷰모델의 메세지를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PlanViewModel.Event.ShowWrongDateMessage) {
                // 잘못된 날짜를 선택했을 시 경고한다
                PlanViewModel.Event.ShowWrongDateMessage showWrongDateMessage =
                        (PlanViewModel.Event.ShowWrongDateMessage) event;
                Snackbar.make(requireView(), showWrongDateMessage.message, Snackbar.LENGTH_LONG)
                        .setAction("다시 설정하기", v -> showDateRangePicker())
                        .show();
            } else if (event instanceof PlanViewModel.Event.NavigateBackWithResult) {
                // 작성이 완료된 경우 이전 프래그먼트로 돌아간다. fragment result 를 true 로 설정한다
                Bundle result = new Bundle();
                result.putBoolean("plan_result", true);
                getParentFragmentManager().setFragmentResult("plan_request", result);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof PlanViewModel.Event.ShowExistingPlanMessageAndDisableSavePlan) {
                // 이미 계획이 있는 경우 계획 수정 의사를 묻는 스낵바를 보여준다
                PlanViewModel.Event.ShowExistingPlanMessageAndDisableSavePlan showExistingPlanMessageAndDisableSavePlan =
                        (PlanViewModel.Event.ShowExistingPlanMessageAndDisableSavePlan) event;
                Snackbar.make(requireView(), showExistingPlanMessageAndDisableSavePlan.message, Snackbar.LENGTH_INDEFINITE)
                        .setAction("계획 수정하기", v -> viewModel.onModifyPlanClicked())
                        .show();
                binding.fabSavePlan.setEnabled(false);
            } else if (event instanceof PlanViewModel.Event.EnableSavePlan) {
                // 계획 수정 버튼을 활성화한다
                binding.fabSavePlan.setEnabled(true);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        ruleBinding = null;
    }

    private void buildRuleDialog() {

        // 대화상자에 뷰를 설정한다
        ruleDialog = new BottomSheetDialog(context);
        ruleDialog.setContentView(ruleBinding.getRoot());

        // 반복, 시간 UI 에 초기값을 입력한다
        ruleBinding.numberPickerRepetitions.setMinValue(1);
        ruleBinding.numberPickerRepetitions.setMaxValue(10);
        ruleBinding.numberPickerMinutes.setMinValue(1);
        ruleBinding.numberPickerMinutes.setMaxValue(30);

        // 규칙 변경 버튼 클릭 시 뷰모델에 변경된 부분을 통보한다
        ruleBinding.fabConfirmRule.setOnClickListener(v -> {
            viewModel.onRuleSelected(
                    ruleBinding.numberPickerRepetitions.getValue(),
                    ruleBinding.numberPickerMinutes.getValue()
            );
            // 대화상자 종료
            ruleDialog.dismiss();
        });
    }

    private void showDateRangePicker() {

        // 현재 계획 정보
        Plan plan = viewModel.getPlan().getValue();
        if (plan == null) {
            return;
        }

        // 날짜 선택 대화상자를 생성한다. 초기 기입 날짜는 현재 계획의 날짜로 설정한다
        MaterialDatePicker<Pair<Long, Long>> dateRangePicker =
                MaterialDatePicker.Builder.dateRangePicker()
                        .setSelection(new Pair<>(plan.getStartTime(), plan.getEndTime()))
                        .build();
        dateRangePicker.show(getChildFragmentManager(), "date_range_picker");

        // 날짜 확정 시 뷰모델에 변경된 날짜를 통보한다
        dateRangePicker.addOnPositiveButtonClickListener(selection ->
                viewModel.onTimeSelected(selection.first, selection.second));
    }

}
