package com.davidjo.remedialexercise.data.diagnosis;

public class DiagnosticResult {

    public final boolean positive;  // 진단 결과. yes 이면 양성 (문제 있음)
    public final String message;    // 진단 결과에 따른 주의 메세지

    public DiagnosticResult(boolean positive, String message) {
        this.positive = positive;
        this.message = message;
    }

}
