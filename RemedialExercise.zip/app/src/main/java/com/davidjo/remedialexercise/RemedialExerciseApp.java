package com.davidjo.remedialexercise;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import com.naver.maps.map.a.g;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class RemedialExerciseApp extends Application {

    public static final String CHANNEL_NAME = "Training Service";
    public static final String CHANNEL_FOREGROUND = "com.davidjo.remedialexercise.training_service";
    public static final String CHANNEL_TIME_OVER = "com.davidjo.remedialexercise.time_over";

    @Override
    public void onCreate() {
        super.onCreate();

        // 노티피케이션을 위해 채널을 생성한다
        createNotificationChannel();
    }

    private void createNotificationChannel() {

        // 포그라운드 노티피케이션 채널을 생성한다
        NotificationChannel foregroundChannel = new NotificationChannel(
                CHANNEL_FOREGROUND,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
        );

        // 운동 시간 종료 알림 노티피케이션을 생성한다
        NotificationChannel timeOverChannel = new NotificationChannel(
                CHANNEL_TIME_OVER,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
        );

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(foregroundChannel);
        manager.createNotificationChannel(timeOverChannel);
    }

}
