package com.davidjo.remedialexercise.ui.diagnosis.failure;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.databinding.FragmentDiagnosisFailureBinding;

public class DiagnosisFailureFragment extends Fragment {

    public DiagnosisFailureFragment() {
        super(R.layout.fragment_diagnosis_failure);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩을 초기화한다
        FragmentDiagnosisFailureBinding binding = FragmentDiagnosisFailureBinding.bind(view);

        // 진단 실패 메세지 (원인) 를 아규먼트에서 받아서, 텍스트뷰에 띄운다
        if (getArguments() != null) {
            String message = DiagnosisFailureFragmentArgs.fromBundle(getArguments()).getMessage();
            binding.textViewDiagnosisFailureReason.setText(message);
        }

        // 병원 보기 버튼을 선택하면, 병원 프래그먼트를 시작한다
        binding.fabShowHospitals.setOnClickListener(v -> {
            NavDirections action = DiagnosisFailureFragmentDirections
                    .actionDiagnosisFailureFragmentToHospitalsFragment();
            Navigation.findNavController(view).navigate(action);
        });
    }

}
