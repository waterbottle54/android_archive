package com.davidjo.remedialexercise.data.exercise;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.davidjo.remedialexercise.data.BodyPart;

@Entity(tableName = "exercise_table")
public class Exercise {

    @PrimaryKey
    @NonNull
    private final String name;              // 운동명
    private final String description;       // 운동 설명
    private final String provider;          // 제공 기관 (병원 등)
    private final String youtubeVideoId;    // 유튜브 비디오 ID (URL 끝의 일련기호)
    private final BodyPart bodyPart;        // 운동 관련 신체부위

    public Exercise(@NonNull String name, String description, String provider, String youtubeVideoId, BodyPart bodyPart) {
        this.name = name;
        this.description = description;
        this.provider = provider;
        this.youtubeVideoId = youtubeVideoId;
        this.bodyPart = bodyPart;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getProvider() {
        return provider;
    }

    public String getYoutubeVideoId() {
        return youtubeVideoId;
    }

    public BodyPart getBodyPart() {
        return bodyPart;
    }

}
