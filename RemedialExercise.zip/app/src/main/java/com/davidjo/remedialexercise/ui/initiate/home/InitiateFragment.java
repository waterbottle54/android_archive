package com.davidjo.remedialexercise.ui.initiate.home;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.BodyPart;
import com.davidjo.remedialexercise.databinding.FragmentInitiateBinding;
import com.google.android.material.snackbar.Snackbar;

public class InitiateFragment extends Fragment {

    public InitiateFragment() {
        super(R.layout.fragment_initiate);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩을 초기화한다
        FragmentInitiateBinding binding = FragmentInitiateBinding.bind(view);

        // 아규먼트로부터 신체부위를 확인한다. 전달된 값이 없으면 목으로 초기화한다
        BodyPart bodyPart = getArguments() == null ? BodyPart.NECK
                : InitiateFragmentArgs.fromBundle(getArguments()).getBodyPart();

        // 버튼 클릭 시 해당 프래그먼트로 이동한다
        binding.cardViewLearnRehab.setOnClickListener(v -> {    // 재활운동 알아보기
            NavDirections action = InitiateFragmentDirections.actionInitiateFragmentToVideoFragment(bodyPart);
            Navigation.findNavController(view).navigate(action);
        });

        binding.cardViewLearnGoods.setOnClickListener(v -> {    // 재활운동 상품 알아보기
            NavDirections action = InitiateFragmentDirections.actionInitiateFragmentToGoodsFragment(bodyPart);
            Navigation.findNavController(view).navigate(action);
        });

        binding.cardViewMakePlan.setOnClickListener(v -> {      // 재활운동 계획 세우기
            NavDirections action = InitiateFragmentDirections.actionInitiateFragmentToPlanFragment(bodyPart);
            Navigation.findNavController(view).navigate(action);
        });

        // 재활운동 계획이 작성되었을 시, 스낵바를 보여준다
        getParentFragmentManager().setFragmentResultListener(
                "plan_request",
                getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("plan_result");
                    if (success) {
                        Snackbar.make(requireView(), "재활운동 계획이 작성되었습니다", Snackbar.LENGTH_SHORT).show();
                    }
                });
    }

}
