package com.davidjo.remedialexercise.ui.home;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    public static final String DESTINATION_INITIATE_FRAGMENT = "initiate_fragment";
    public static final String DESTINATION_LEARN_FRAGMENT = "learn_fragment";

    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩 초기화
        FragmentHomeBinding binding = FragmentHomeBinding.bind(view);

        // 메뉴 5개 클릭 시 각 메뉴에 맞는 프래그먼트로 이동한다
        binding.cardDoDiagnosis.setOnClickListener(v -> {       // 진단하기
            NavDirections action = HomeFragmentDirections.actionIntroFragmentToSymptomsFragment();
            Navigation.findNavController(view).navigate(action);
        });

        binding.cardPlanRehab.setOnClickListener(v -> {         // 재활운동 계획 세우기
            NavDirections action = HomeFragmentDirections
                    .actionHomeFragmentToPromptBodyPartFragment(DESTINATION_INITIATE_FRAGMENT);
            Navigation.findNavController(view).navigate(action);
        });

        binding.cardLearnRehab.setOnClickListener(v -> {        // 재활운동 알아보기
            NavDirections action = HomeFragmentDirections
                    .actionHomeFragmentToPromptBodyPartFragment(DESTINATION_LEARN_FRAGMENT);
            Navigation.findNavController(view).navigate(action);
        });
        binding.cardDoRehab.setOnClickListener(v -> {           // 재활운동 실시하기
            NavDirections action = HomeFragmentDirections.actionHomeFragmentToTrainingFragment();
            Navigation.findNavController(view).navigate(action);
        });
        binding.cardShowStatistics.setOnClickListener(v -> {    // 통계
            NavDirections action = HomeFragmentDirections.actionHomeFragmentToStatisticFragment();
            Navigation.findNavController(view).navigate(action);
        });
    }

}
