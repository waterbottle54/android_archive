package com.davidjo.remedialexercise.ui.diagnosis.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.davidjo.remedialexercise.data.BodyPart;
import com.davidjo.remedialexercise.data.diagnosis.Diagnosis;
import com.davidjo.remedialexercise.data.diagnosis.DiagnosticAnswer;
import com.davidjo.remedialexercise.data.diagnosis.DiagnosticResult;

public class DiagnosisViewModel extends ViewModel {

    // 현재 유저의 진단 답변
    private final MutableLiveData<DiagnosticAnswer> answer = new MutableLiveData<>(new DiagnosticAnswer());

    // 프래그먼트에 보내는 명령
    private final MutableLiveData<Event> event = new MutableLiveData<>(null);

    public LiveData<DiagnosticAnswer> getAnswer() {
        return answer;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    // 신체 부위가 선택되었을 때 답변을 업데이트한다
    public void onBodyPartSelected(BodyPart bodyPart) {
        DiagnosticAnswer newAnswer = answer.getValue() != null ? answer.getValue() : new DiagnosticAnswer();
        newAnswer.bodyPart = bodyPart;
        answer.setValue(newAnswer);
    }

    // 통증 레벨이 선택되면 답변을 업데이트한다
    public void onPainLevelSelected(int painLevel) {
        DiagnosticAnswer newAnswer = answer.getValue() != null ? answer.getValue() : new DiagnosticAnswer();
        newAnswer.painLevel = painLevel;
        answer.setValue(newAnswer);
    }

    // 수술 후 개월수가 선택되면 답변을 업데이트한다
    public void onMonthsAfterSurgerySelected(int months) {
        DiagnosticAnswer newAnswer = answer.getValue() != null ? answer.getValue() : new DiagnosticAnswer();
        newAnswer.monthsAfterSurgery = months;
        answer.setValue(newAnswer);
    }

    // 수술 여부가 선택되면 답변을 업데이트한다
    public void onGotSurgeryChecked(boolean checked) {
        DiagnosticAnswer newAnswer = answer.getValue() != null ? answer.getValue() : new DiagnosticAnswer();
        newAnswer.gotSurgery = checked;
        answer.setValue(newAnswer);

        event.setValue(new Event.ShowMonthsInputUI(newAnswer.gotSurgery));
    }

    // 복합 통증 여부가 선택되면 답변을 업데이트한다
    public void onMultiplePainChecked(boolean checked) {
        DiagnosticAnswer newAnswer = answer.getValue() != null ? answer.getValue() : new DiagnosticAnswer();
        newAnswer.multiplePain = checked;
        answer.setValue(newAnswer);
    }

    // 답변 제출이 클릭되면, 진단 결과를 받은 후 각기 다른 프래그먼트를 시작한다
    public void onSubmitClicked() {

        DiagnosticAnswer answer = this.answer.getValue();
        if (answer == null) {
            return;
        }

        DiagnosticResult result = Diagnosis.getResult(answer);

        if (result.positive) {
            event.setValue(new Event.NavigateSuccessScreen(answer.bodyPart));
        } else {
            event.setValue(new Event.NavigateFailureScreen(result.message));
        }
    }

    // 프래그먼트에 보내는 명령
    public static class Event {

        // 진단 성공 프래그먼트로 이동
        public static class NavigateSuccessScreen extends Event {
            public final BodyPart bodyPart;

            public NavigateSuccessScreen(BodyPart bodyPart) {
                this.bodyPart = bodyPart;
            }
        }

        // 진단 실패 프래그먼트로 이동
        public static class NavigateFailureScreen extends Event {
            public final String message;

            public NavigateFailureScreen(String message) {
                this.message = message;
            }
        }

        // 개월 수 UI (스피너) 보이기
        public static class ShowMonthsInputUI extends Event {

            public final boolean show;

            public ShowMonthsInputUI(boolean show) {
                this.show = show;
            }
        }
    }

}
