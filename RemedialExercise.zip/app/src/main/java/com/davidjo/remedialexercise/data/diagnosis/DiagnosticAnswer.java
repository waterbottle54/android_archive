package com.davidjo.remedialexercise.data.diagnosis;

import com.davidjo.remedialexercise.data.BodyPart;

public class DiagnosticAnswer {     // 진단에 대한 답변

    public BodyPart bodyPart;       // 통증이 있는 신체부위
    public int painLevel;           // 통증의 정도
    public boolean gotSurgery;      // 수술 여부
    public int monthsAfterSurgery;  // 수술 후 지난 개월수
    public boolean multiplePain;    // 복합 통증 여부

    public DiagnosticAnswer() {
        bodyPart = BodyPart.NECK;
        painLevel = 1;
        gotSurgery = false;
        monthsAfterSurgery = 5;
        multiplePain = false;
    }
}
