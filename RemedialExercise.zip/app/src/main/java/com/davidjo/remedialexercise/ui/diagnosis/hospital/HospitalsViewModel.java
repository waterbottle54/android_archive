package com.davidjo.remedialexercise.ui.diagnosis.hospital;

import android.location.Location;
import android.util.Log;
import android.view.animation.Transformation;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.davidjo.remedialexercise.data.hospital.Hospital;
import com.davidjo.remedialexercise.data.hospital.HospitalRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HospitalsViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>(null);

    // 마지막 업데이트 위치
    private final MutableLiveData<Location> anchorLocation = new MutableLiveData<>();

    // 병원 목록
    private final LiveData<List<Hospital>> hospitals;


    @Inject
    public HospitalsViewModel(HospitalRepository repository) {

        // 병원 목록이 위치에 따라 업데이트되도록 설정한다
        hospitals = Transformations.switchMap(anchorLocation, location -> {
            if (location != null) {
                return repository.getHospitals(location.getLatitude(), location.getLongitude(), 5000);
            }
            return null;
        });
    }


    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Hospital>> getHospitals() {
        return hospitals;
    }

    public void onLocationChange(Location location) {

        Location anchor = anchorLocation.getValue();

        // 위치가 처음 업데이트 되는 경우나, 100m 이상 이동한 경우, 기준 위치를 업데이트한다 (병원 목록도 업데이트됨)
        if (anchor == null || anchor.distanceTo(location) >= 100) {
            anchorLocation.setValue(location);
        }
    }


    public static class Event {

    }

}




