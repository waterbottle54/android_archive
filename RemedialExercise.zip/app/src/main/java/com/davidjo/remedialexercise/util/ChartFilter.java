package com.davidjo.remedialexercise.util;

public enum ChartFilter {
    YEARLY, MONTHLY, DAILY
}

