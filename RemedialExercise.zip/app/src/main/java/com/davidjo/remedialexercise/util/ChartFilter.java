package com.davidjo.remedialexercise.util;

public enum ChartFilter {   // 연, 월, 일 필터
    YEARLY, MONTHLY, DAILY
}

