package com.davidjo.remedialexercise.ui.promptbodypart;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.fragment.NavHostFragment;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.BodyPart;
import com.davidjo.remedialexercise.databinding.FragmentPromptBodyPartBinding;
import com.davidjo.remedialexercise.ui.home.HomeFragment;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.snackbar.Snackbar;

import retrofit2.http.Body;


public class PromptBodyPartFragment extends BottomSheetDialogFragment {

    private FragmentPromptBodyPartBinding binding;
    private PromptBodyPartViewModel viewModel;

    private String destination;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_prompt_body_part, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩, 뷰모델을 초기화한다
        binding = FragmentPromptBodyPartBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PromptBodyPartViewModel.class);

        // 아규먼트로부터 데스티네이션 (다음으로 갈 프래그먼트) 을 획득한다
        if (getArguments() != null) {
            destination = PromptBodyPartFragmentArgs.fromBundle(getArguments()).getDestination();
        }

        if (destination == null) {
            return;
        }

        // 신체부위 위의 Aura 이미지가 클릭될 시, 클릭된 신체부위를 뷰모델에 통보한다
        binding.imageViewAnkle.setOnClickListener(v -> viewModel.onBodyPartSelected(BodyPart.ANKLE));
        binding.imageViewKnee.setOnClickListener(v -> viewModel.onBodyPartSelected(BodyPart.KNEE));
        binding.imageViewBack.setOnClickListener(v -> viewModel.onBodyPartSelected(BodyPart.BACK));
        binding.imageViewNeck.setOnClickListener(v -> viewModel.onBodyPartSelected(BodyPart.NECK));
        binding.imageViewShoulder.setOnClickListener(v -> viewModel.onBodyPartSelected(BodyPart.SHOULDER));
        binding.imageViewWrist.setOnClickListener(v -> viewModel.onBodyPartSelected(BodyPart.WRIST));

        // 확정 버튼이 클릭되면 뷰모델에 통보한다
        binding.fabConfirmBodyPart.setOnClickListener(v -> viewModel.onConfirmClicked());

        // 선택된 신체부위가 변경되면, 신체부위 위의 Aura 이미지 중 선택된 부위에 해당하는 이미지를 하이라이트한다.
        viewModel.getBodyPart().observe(getViewLifecycleOwner(), bodyPart -> {
            binding.imageViewAnkle.setImageResource(R.drawable.aura);
            binding.imageViewKnee.setImageResource(R.drawable.aura);
            binding.imageViewBack.setImageResource(R.drawable.aura);
            binding.imageViewNeck.setImageResource(R.drawable.aura);
            binding.imageViewShoulder.setImageResource(R.drawable.aura);
            binding.imageViewWrist.setImageResource(R.drawable.aura);
            if (bodyPart != null) {
                switch (bodyPart) {
                    case NECK:
                        binding.imageViewNeck.setImageResource(R.drawable.aura_highlighted);
                        break;
                    case SHOULDER:
                        binding.imageViewShoulder.setImageResource(R.drawable.aura_highlighted);
                        break;
                    case WRIST:
                        binding.imageViewWrist.setImageResource(R.drawable.aura_highlighted);
                        break;
                    case BACK:
                        binding.imageViewBack.setImageResource(R.drawable.aura_highlighted);
                        break;
                    case KNEE:
                        binding.imageViewKnee.setImageResource(R.drawable.aura_highlighted);
                        break;
                    case ANKLE:
                        binding.imageViewAnkle.setImageResource(R.drawable.aura_highlighted);
                        break;
                }
            }
        });

        // 뷰모델의 명령을 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            // 선택된 신체부위와 함께 데스티네이션으로 이동한다
            if (event instanceof PromptBodyPartViewModel.Event.NavigateToDestination) {
                BodyPart bodyPart = ((PromptBodyPartViewModel.Event.NavigateToDestination) event).bodyPart;
                navigateToDestination(bodyPart);
            } else if (event instanceof PromptBodyPartViewModel.Event.ShowGeneralMessage) {
                // 뷰모델 메세지를 보여준다
                String message = ((PromptBodyPartViewModel.Event.ShowGeneralMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void navigateToDestination(BodyPart bodyPart) {

        NavDirections action;

        // 선택된 신체부위와 함께 데스티네이션 프래그먼트로 이동한다
        switch (destination) {
            case HomeFragment.DESTINATION_INITIATE_FRAGMENT:
                action = PromptBodyPartFragmentDirections
                        .actionPromptBodyPartFragmentToInitiateFragment(bodyPart);
                break;
            case HomeFragment.DESTINATION_LEARN_FRAGMENT:
                action = PromptBodyPartFragmentDirections
                        .actionPromptBodyPartFragmentToVideoFragment(bodyPart);
                break;
            default:
                return;
        }

        NavHostFragment.findNavController(this).navigate(action);
    }

}
