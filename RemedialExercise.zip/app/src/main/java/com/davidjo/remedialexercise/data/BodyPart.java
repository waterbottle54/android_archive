package com.davidjo.remedialexercise.data;

public enum BodyPart {
    NECK, SHOULDER, WRIST, BACK, KNEE, ANKLE;
}
