package com.davidjo.remedialexercise.data;

public enum BodyPart {  // 신체부위
    NECK, SHOULDER, WRIST, BACK, KNEE, ANKLE;
}
