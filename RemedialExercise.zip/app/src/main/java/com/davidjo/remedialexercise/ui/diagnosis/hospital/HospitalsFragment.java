package com.davidjo.remedialexercise.ui.diagnosis.hospital;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.data.hospital.Hospital;
import com.davidjo.remedialexercise.databinding.FragmentHospitalsBinding;
import com.google.android.material.snackbar.Snackbar;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.LocationTrackingMode;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.OverlayImage;
import com.naver.maps.map.util.FusedLocationSource;

import java.util.ArrayList;
import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HospitalsFragment extends Fragment implements OnMapReadyCallback, NaverMap.OnLocationChangeListener {

    public static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    private Context context;
    private HospitalsViewModel viewModel;
    FragmentHospitalsBinding binding;

    private NaverMap map;   // 네이버 맵
    private final List<Marker> markers = new ArrayList<>(); // 마커

    private FusedLocationSource fusedLocationSource;    // GPS 소스
    private ActivityResultLauncher<String> locationPermissionLauncher;


    public HospitalsFragment() {
        super(R.layout.fragment_hospitals);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // GPS 소스를 초기화한다
        fusedLocationSource = new FusedLocationSource(this, LOCATION_PERMISSION_REQUEST_CODE);

        // 위치 퍼미션 런처를 정의한다
        locationPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                result -> {
                    if (fusedLocationSource.onRequestPermissionsResult(
                            LOCATION_PERMISSION_REQUEST_CODE,
                            new String[] { Manifest.permission.ACCESS_FINE_LOCATION },
                            new int[] { result ? PackageManager.PERMISSION_GRANTED : PackageManager.PERMISSION_DENIED }
                    )) {
                        // 퍼미션 거절
                        if (!fusedLocationSource.isActivated()) {
                            map.setLocationTrackingMode(LocationTrackingMode.None);
                            return;
                        }
                        // 퍼미션 승인 시 네이버 맵 초기설정 진행
                        configureMap();
                    }
                }
        );
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        this.context = context;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩, 뷰 모델을 초기화한다
        binding = FragmentHospitalsBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HospitalsViewModel.class);

        // 네이버 맵을 획득한다
        MapFragment mapFragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // 병원 목록이 업데이트되면 UI (마커) 도 업데이트한다
        viewModel.getHospitals().observe(getViewLifecycleOwner(), hospitals -> {
            if (hospitals != null) {
                updateMarkers(hospitals);
            } else {
                Snackbar.make(requireView(), "병원 정보를 불러오지 못했습니다", Snackbar.LENGTH_SHORT).show();
            }
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
        });
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {

        map = naverMap;

        // 퍼미션 여부를 확인하고 초기설정을 진행한다
        if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            configureMap();
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    private void configureMap() {

        // 네이버 맵 초기설정을 진행한다
        map.addOnLocationChangeListener(this);
        map.setLocationSource(fusedLocationSource);
        map.setLocationTrackingMode(LocationTrackingMode.Follow);
        map.getUiSettings().setLocationButtonEnabled(true);
    }

    @Override
    public void onLocationChange(@NonNull Location location) {

        // 위치가 변경되었을 때 뷰모델에 통보한다
        viewModel.onLocationChange(location);
    }

    private void updateMarkers(List<Hospital> hospitals) {

        // 병원 목록에 따라 마커를 지우고 다시 생성한다
        for (Marker marker : markers) {
            marker.setMap(null);
        }
        markers.clear();

        for (Hospital hospital : hospitals) {
            LatLng latLng = new LatLng(hospital.getLatitude(), hospital.getLongitude());
            OverlayImage icon = OverlayImage.fromResource(R.drawable.ic_hospital_red);
            Marker marker = new Marker(latLng, icon);
            marker.setCaptionText(hospital.getName());
            marker.setMap(map);
            markers.add(marker);
        }
    }

}
