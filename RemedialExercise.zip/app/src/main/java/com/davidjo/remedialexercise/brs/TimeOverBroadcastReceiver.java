package com.davidjo.remedialexercise.brs;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.davidjo.remedialexercise.R;
import com.davidjo.remedialexercise.RemedialExerciseApp;
import com.davidjo.remedialexercise.services.TrainingService;
import com.davidjo.remedialexercise.ui.MainActivity;

public class TimeOverBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        // 노티피케이션 (알림) 을 생성한다
        Notification notification;

        // 노티피케이션을 클릭하면 메인 액티비티가 실행되도록 펜딩 인텐트를 구성한다
        Intent activityIntent = new Intent(context, MainActivity.class);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                activityIntent,
                PendingIntent.FLAG_CANCEL_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // 텍스트, 아이콘, 펜딩 인텐트를 이용하여 노티피케이션을 만든다
        notification = new Notification.Builder(context, RemedialExerciseApp.CHANNEL_TIME_OVER)
                .setContentIntent(pendingIntent)
                .setContentText("재활운동 완료")
                .setSmallIcon(R.drawable.ic_notification_icon)
                .setContentText("재활운동 1회 완료하셨습니다")
                .setTicker("재활운동 1회 완료하셨습니다")
                .setOnlyAlertOnce(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build();

        // 노티피케이션을 띄운다
        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(TrainingService.NOTIFICATION_FOREGROUND + 1, notification);
    }
}
