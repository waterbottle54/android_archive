package com.cool.withcook.ui.mealkit;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class MealKitViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    public static final String URL_COUPANG = "https://www.coupang.com/np/search?component=&q=%EB%B0%80%ED%82%A4%ED%8A%B8";

    private final MutableLiveData<Event> event = new MutableLiveData<>();


    @Inject
    public MealKitViewModel() {

    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }

    public void onCartClick() {
        event.setValue(new Event.BrowseShoppingSite(URL_COUPANG));
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class BrowseShoppingSite extends Event {
            public final String url;
            public BrowseShoppingSite(String url) {
                this.url = url;
            }
        }
    }

}