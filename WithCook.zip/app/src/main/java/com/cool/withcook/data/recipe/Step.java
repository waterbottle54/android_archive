package com.cool.withcook.data.recipe;

import java.util.Objects;

// 단계 자료형 (ex. 손질하기)

public class Step {

    private String id;
    private String title;       // 단계 이름
    private String content;     // 단계 설명

    public Step() {
    }

    public Step(String recipeId, String title, String content) {
        this.title = title;
        this.content = content;
        this.id = recipeId + "#" + title;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Step step = (Step) o;
        return id.equals(step.id) && title.equals(step.title) && content.equals(step.content);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, content);
    }

}
