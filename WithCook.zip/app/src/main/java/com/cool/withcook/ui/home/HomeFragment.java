package com.cool.withcook.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.withcook.R;
import com.cool.withcook.data.Category;
import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.cool.withcook.databinding.FragmentHomeBinding;
import com.cool.withcook.util.NameUtils;
import com.cool.withcook.util.ui.AuthFragment;
import com.cool.withcook.util.ui.CardsAdapter;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Locale;
import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeFragment extends AuthFragment implements DetailedRecipesAdapter.OnItemSelectedListener {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;
    private DetailedRecipesAdapter recipesAdapter;


    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentHomeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        CardsAdapter categoryAdapter = new CardsAdapter();
        binding.recyclerCategory.setAdapter(categoryAdapter);
        binding.recyclerCategory.setHasFixedSize(true);

        Map<String, Category> categoryMap = NameUtils.getCategoryMap(getResources());
        categoryAdapter.setOnItemSelectedListener(position -> {
            String categoryName = categoryAdapter.getCurrentList().get(position);
            viewModel.onCategoryChange(categoryMap.get(categoryName));
        });
        categoryAdapter.submitList(NameUtils.getCategoryNames(getResources()));

        viewModel.getCategory().observe(getViewLifecycleOwner(), category -> {
            String strCategory = String.format(Locale.getDefault(),
                    getString(R.string.recipes_in_category),
                    NameUtils.getCategoryName(getResources(), category));
            binding.textViewCategoryTitle.setText(strCategory);
        });

        viewModel.getRecipeAlbum().observe(getViewLifecycleOwner(), album ->
                viewModel.getCommentCountMap().observe(getViewLifecycleOwner(), commentCountMap -> {
                    recipesAdapter = new DetailedRecipesAdapter(album, commentCountMap);
                    binding.recyclerRecipe.setAdapter(recipesAdapter);
                    binding.recyclerRecipe.setHasFixedSize(true);
                    recipesAdapter.setOnItemSelectedListener(this);

                    viewModel.getRecipes().observe(getViewLifecycleOwner(), recipes -> {
                        if (recipes != null) {
                            recipesAdapter.submitList(recipes);
                            binding.textViewNoRecipes.setVisibility(recipes.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                        }
                        binding.progressBar.setVisibility(View.INVISIBLE);
                    });
                })
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof HomeViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof HomeViewModel.Event.NavigateToRecipeScreen) {
                DetailedRecipe recipe = ((HomeViewModel.Event.NavigateToRecipeScreen) event).recipe;
                NavDirections action = HomeFragmentDirections.actionGlobalRecipeFragment(recipe);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public void onItemSelected(int position) {
        DetailedRecipe detailedRecipe = recipesAdapter.getCurrentList().get(position);
        viewModel.onRecipeClick(detailedRecipe);
    }

}




