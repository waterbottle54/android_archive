package com.cool.withcook.data.detailedcomment;

import android.graphics.Bitmap;
import android.view.animation.Transformation;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.cool.withcook.data.comment.Comment;
import com.cool.withcook.data.comment.CommentRepository;
import com.cool.withcook.data.user.User;
import com.cool.withcook.data.user.UserRepository;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class DetailedCommentRepository {

    private final CommentRepository commentRepository;
    private final UserRepository userRepository;


    @Inject
    public DetailedCommentRepository(CommentRepository commentRepository, UserRepository userRepository) {
        this.commentRepository = commentRepository;
        this.userRepository = userRepository;
    }

    // 특정 레시피에 달린 Comment 로 가져온 후 DetailedComment 로 바꾸어 리턴해줌

    public LiveData<List<DetailedComment>> getDetailedComment(String recipeId) {

        LiveData<List<Comment>> comments = commentRepository.getComments(recipeId);
        LiveData<Map<String, User>> userMap = userRepository.getUserMap();

        return Transformations.switchMap(comments, commentList ->
                Transformations.map(userMap, map -> {
                    List<DetailedComment> detailedCommentList = new ArrayList<>();
                    for (Comment comment : commentList) {
                        User user = map.get(comment.getWriterId());
                        detailedCommentList.add(new DetailedComment(comment, user));
                    }
                    return detailedCommentList;
                })
        );
    }

}
