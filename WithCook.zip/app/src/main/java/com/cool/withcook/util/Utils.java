package com.cool.withcook.util;

import android.content.res.Resources;

import com.cool.withcook.R;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Locale;

public class Utils {

    public static String getEmailFromUserId(String userId) {
        return String.format(Locale.getDefault(), "%s@greenworld.com", userId);
    }

    public static LocalDate getLocalDate(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static String formatDate(Resources res, LocalDate date) {
        return String.format(Locale.getDefault(),
                res.getString(R.string.date_format),
                date.getYear(),
                date.getMonth().getValue(),
                date.getDayOfMonth()
        );
    }

    public static String formatDate(Resources res, long epochDays) {
        LocalDate date = LocalDate.ofEpochDay(epochDays);
        return formatDate(res, date);
    }

}