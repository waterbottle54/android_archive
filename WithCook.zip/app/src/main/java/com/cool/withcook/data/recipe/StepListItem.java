package com.cool.withcook.data.recipe;

import android.graphics.Bitmap;

import java.util.Objects;

// 단계 리사이클러뷰에서 사용될 모델 자료형

public class StepListItem {

    private final String title;     // 단계 이름
    private final String content;   // 단계 설명
    private final Bitmap image;     // 단계 이미지

    public StepListItem(String title, String content, Bitmap image) {
        this.title = title;
        this.content = content;
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public Bitmap getImage() {
        return image;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        StepListItem that = (StepListItem) o;
        return title.equals(that.title) && content.equals(that.content) && Objects.equals(image, that.image);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, content, image);
    }

}
