package com.cool.withcook.ui.addrecipe.addstep;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.cool.withcook.data.recipe.Step;
import com.cool.withcook.ui.addrecipe.addrecipe.AddRecipeViewModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class AddStepViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String title = "";
    private String content = "";
    private MutableLiveData<Bitmap> image = new MutableLiveData<>();


    @Inject
    public AddStepViewModel(FirebaseFirestore firestore) {

    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }

    public void onTitleChanged(String text) {
        this.title = text;
    }

    public void onContentChanged(String text) {
        this.content = text;
    }

    public void onUploadImageClick() {

        event.setValue(new Event.PrompImage());
    }

    public void onImageChanged(Bitmap bitmap) {
        if (bitmap != null) {
            image.setValue(bitmap);
        } else {
            event.setValue(new Event.ShowImageSelectFailureMessage("이미지 업로드에 실패했습니다"));
        }
    }

    public void onSubmitClick() {

        if (title.trim().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("제목을 입력해주세요"));
            return;
        }

        if (content.trim().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("설명을 입력해주세요"));
            return;
        }

        event.setValue(new Event.NavigateBackWithResult(title, content, image.getValue()));
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class PrompImage extends Event { }

        public static class ShowImageSelectFailureMessage extends Event {
            public final String message;

            public ShowImageSelectFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowInvalidInputMessage extends Event {
            public final String message;

            public ShowInvalidInputMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final String title;
            public final String content;
            public final Bitmap bitmap;

            public NavigateBackWithResult(String title, String content, Bitmap bitmap) {
                this.title = title;
                this.content = content;
                this.bitmap = bitmap;
            }
        }
    }

}