package com.cool.withcook.util;

import android.content.res.Resources;

import com.cool.withcook.R;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;

public class TimeUtils {

    public static String getTimeString(Resources resources, long millis) {

        LocalDateTime localDate = Instant.ofEpochMilli(millis)
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();

        int month = localDate.getMonthValue();
        int dayOfMonth = localDate.getDayOfMonth();
        int hour = localDate.getHour();
        int minute = localDate.getMinute();

        return String.format(Locale.getDefault(),
                resources.getString(R.string.date_time_format),
                month, dayOfMonth, hour, minute
        );
    }


}
