package com.cool.withcook.data.comment;

import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class CommentRepository {

    private final CollectionReference recipeCollection;

    @Inject
    public CommentRepository(FirebaseFirestore firestore) {
        this.recipeCollection = firestore.collection("recipes");
    }

    // DB 에 댓글을 추가하는 메소드

    public void addComment(Comment comment, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        CollectionReference commentsCollection = recipeCollection
                .document(comment.getRecipeId())
                .collection("comments");

        commentsCollection.document(comment.getId())
                .set(comment)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    // DC 에서 특정 레시피에 달린 댓글을 가져오는 메소드

    public LiveData<List<Comment>> getComments(String recipeId) {

        CollectionReference commentsCollection = recipeCollection
                .document(recipeId)
                .collection("comments");

        MutableLiveData<List<Comment>> comments = new MutableLiveData<>();

        commentsCollection.orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (value == null || error != null) {
                        comments.setValue(null);
                        return;
                    }

                    List<Comment> commentList = new ArrayList<>();
                    for (DocumentSnapshot snapshot : value) {
                        Comment comment = snapshot.toObject(Comment.class);
                        if (comment != null) {
                            commentList.add(comment);
                        }
                    }

                    comments.setValue(commentList);
                });

        return comments;
    }

    // DB 에서 특정 레시피에 달린 댓글을 가져오는 메소드 (리스너로 구현)

    public void getComments(String recipeId, OnSuccessListener<List<Comment>> onSuccessListener) {
        LiveData<List<Comment>> comments = getComments(recipeId);
        comments.observeForever(onSuccessListener::onSuccess);
    }

    // DB 에서 레시피-댓글리스트 맵을 가져오는 메소드
    // 예시 맵 : { 글1 : 글1에 달린 댓글들, 글2: 글2에 달린 댓글들, ... }

    public LiveData<Map<String, List<Comment>>> getCommentMap(List<String> recipeIdList) {

        MutableLiveData<Map<String, List<Comment>>> commentMap = new MutableLiveData<>(new HashMap<>());

        for (String recipeId : recipeIdList) {
            getComments(recipeId,
                    commentList -> {
                        if (commentList != null) {
                            Map<String, List<Comment>> oldMap = commentMap.getValue();
                            assert oldMap != null;
                            Map<String, List<Comment>> map = new HashMap<>(oldMap);
                            map.put(recipeId, commentList);
                            commentMap.setValue(map);
                        }
                    }
            );
        }

        return commentMap;
    }

}


