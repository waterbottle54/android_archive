package com.cool.withcook.ui.recipe;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.withcook.R;
import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.cool.withcook.data.recipe.Step;
import com.cool.withcook.data.recipe.StepListItem;
import com.cool.withcook.databinding.FragmentRecipeBinding;
import com.cool.withcook.ui.addrecipe.addrecipe.StepListItemsAdapter;
import com.cool.withcook.ui.mealkit.MealKitViewModel;
import com.cool.withcook.util.ui.AuthFragment;
import com.cool.withcook.util.ui.CardsAdapter;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RecipeFragment extends AuthFragment {

    private FragmentRecipeBinding binding;
    private RecipeViewModel viewModel;


    public RecipeFragment() {
        super(R.layout.fragment_recipe);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentRecipeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RecipeViewModel.class);

        binding.textViewRecipeTitle.setText(viewModel.getRecipeTitle());
        binding.textViewRecipeWriter.setText(viewModel.getWriterNickname());
        binding.textViewLike.setOnClickListener(v -> viewModel.onLikeClick());
        binding.textViewShowComment.setOnClickListener(v -> viewModel.onShowCommentClick());

        CardsAdapter ingredientsAdapter = new CardsAdapter();
        binding.recyclerViewIngredient.setAdapter(ingredientsAdapter);
        binding.recyclerViewIngredient.setHasFixedSize(true);
        ingredientsAdapter.submitList(viewModel.getIngredients());

        CardsAdapter saucesAdapter = new CardsAdapter();
        binding.recyclerViewSauce.setAdapter(saucesAdapter);
        binding.recyclerViewSauce.setHasFixedSize(true);
        saucesAdapter.submitList(viewModel.getSauces());

        binding.groupMeetingRoom.setVisibility(viewModel.hasMeetingRoom() ? View.VISIBLE : View.GONE);
        if (viewModel.hasMeetingRoom()) {
            binding.textViewUrlMeetingRoom.setText(viewModel.getMeetingRoomUrl());
            binding.textViewUrlMeetingRoom.setOnClickListener(v -> viewModel.onMeetingRoomUrlClick());
        }

        viewModel.getRecipeImage().observe(getViewLifecycleOwner(), image -> {
            binding.imageViewRecipe.setImageBitmap(image);
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getStepAlbum().observe(getViewLifecycleOwner(), album -> {

            StepListItemsAdapter adapter = new StepListItemsAdapter();
            binding.recyclerViewStep.setAdapter(adapter);
            binding.recyclerViewStep.setHasFixedSize(true);

            List<StepListItem> items = new ArrayList<>();
            for (Step step : viewModel.getSteps()) {
                StepListItem item = new StepListItem(step.getTitle(), step.getContent(), album.get(step.getId()));
                items.add(item);
            }

            adapter.submitList(items);
        });

        viewModel.getCommentCount().observe(getViewLifecycleOwner(), commentCount ->
                binding.textViewRecipeNumberComments.setText(String.valueOf(commentCount))
        );

        viewModel.getNumberOfLikes().observe(getViewLifecycleOwner(), numLikes ->
                binding.textViewRecipeLikes.setText(String.valueOf(numLikes))
        );

        viewModel.hasLiked().observe(getViewLifecycleOwner(), hasLiked ->
                binding.imageViewLike.setImageResource(hasLiked ? R.drawable.ic_favorite_fill : R.drawable.ic_favorite));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof RecipeViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof RecipeViewModel.Event.NavigateToCommentsScreen) {
                DetailedRecipe recipe = ((RecipeViewModel.Event.NavigateToCommentsScreen) event).recipe;
                NavDirections action = RecipeFragmentDirections.actionRecipeFragmentToCommentsFragment(recipe);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof RecipeViewModel.Event.ShowCannotLikeOwnRecipe) {
                String message = ((RecipeViewModel.Event.ShowCannotLikeOwnRecipe) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof RecipeViewModel.Event.BrowseMeetingRoom) {
                String url = ((RecipeViewModel.Event.BrowseMeetingRoom) event).url;
                browseWebsite(url);
            } else if (event instanceof RecipeViewModel.Event.ShowInvalidUrlMessage) {
                String message = ((RecipeViewModel.Event.ShowInvalidUrlMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }


    private void browseWebsite(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

}