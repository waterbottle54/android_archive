package com.cool.withcook.data;

public enum Category {
    KOREAN, JAPANESE, CHINESE, WESTERN, FAST_FOOD,
}
