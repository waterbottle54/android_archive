package com.cool.withcook.ui.comments;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.cool.withcook.R;
import com.cool.withcook.databinding.FragmentCommentsBinding;
import com.cool.withcook.util.OnTextChangedListener;
import com.cool.withcook.util.ui.AuthFragment;
import com.google.firebase.auth.FirebaseAuth;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class CommentsFragment extends AuthFragment {

    private FragmentCommentsBinding binding;
    private CommentsViewModel viewModel;


    public CommentsFragment() {
        super(R.layout.fragment_comments);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentCommentsBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(CommentsViewModel.class);

        binding.editTextComment.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onCommentChange(text);
            }
        });

        binding.imageViewSubmitComment.setOnClickListener(v -> {
            viewModel.onSubmitClick();
            binding.editTextComment.setText("");
            hideKeyboard(requireView());
        });

        DetailedCommentsAdapter commentsAdapter = new DetailedCommentsAdapter(getResources());
        binding.recyclerComment.setAdapter(commentsAdapter);
        binding.recyclerComment.setHasFixedSize(true);

        viewModel.getComments().observe(getViewLifecycleOwner(), comments -> {
            commentsAdapter.submitList(comments);
            binding.progressBar.setVisibility(View.INVISIBLE);
            binding.textViewNoComments.setVisibility(comments.isEmpty() ? View.VISIBLE : View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof CommentsViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}