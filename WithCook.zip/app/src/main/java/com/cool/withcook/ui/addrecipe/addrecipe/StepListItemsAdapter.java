package com.cool.withcook.ui.addrecipe.addrecipe;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.cool.withcook.data.recipe.StepListItem;
import com.cool.withcook.databinding.StepItemBinding;

public class StepListItemsAdapter extends ListAdapter<StepListItem, StepListItemsAdapter.StepListItemViewHolder> {

    class StepListItemViewHolder extends RecyclerView.ViewHolder {

        private final StepItemBinding binding;

        public StepListItemViewHolder(StepItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(StepListItem model) {

            binding.textViewStepTitle.setText(model.getTitle());
            binding.textViewStepContent.setText(model.getContent());
            binding.imageViewStepImage.setImageBitmap(model.getImage());
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public StepListItemsAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public StepListItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        StepItemBinding binding = StepItemBinding.inflate(layoutInflater, parent, false);
        return new StepListItemViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull StepListItemViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<StepListItem> {

        @Override
        public boolean areItemsTheSame(@NonNull StepListItem oldItem, @NonNull StepListItem newItem) {
            return oldItem.equals(newItem);
        }

        @Override
        public boolean areContentsTheSame(@NonNull StepListItem oldItem, @NonNull StepListItem newItem) {
            return oldItem.equals(newItem);
        }
    }

}