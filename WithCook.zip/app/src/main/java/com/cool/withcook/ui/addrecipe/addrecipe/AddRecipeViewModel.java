package com.cool.withcook.ui.addrecipe.addrecipe;

import android.graphics.Bitmap;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.cool.withcook.data.Category;
import com.cool.withcook.data.image.ImageRepository;
import com.cool.withcook.data.recipe.Ingredient;
import com.cool.withcook.data.recipe.Recipe;
import com.cool.withcook.data.recipe.RecipeRepository;
import com.cool.withcook.data.recipe.Step;
import com.cool.withcook.data.recipe.StepListItem;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class AddRecipeViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String userId;

    private String title = "";
    private Category category = Category.KOREAN;
    private final MutableLiveData<Bitmap> image = new MutableLiveData<>();
    private final MutableLiveData<List<String>> ingredients = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<String>> sauces = new MutableLiveData<>(new ArrayList<>());
    private String urlMeetingRoom = "";

    private final MutableLiveData<List<StepListItem>> stepListItems = new MutableLiveData<>(new ArrayList<>());

    private final RecipeRepository recipeRepository;
    private final ImageRepository imageRepository;


    @Inject
    public AddRecipeViewModel(RecipeRepository recipeRepository, ImageRepository imageRepository) {

        this.recipeRepository = recipeRepository;
        this.imageRepository = imageRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public Category getCategory() {
        return category;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }

    public LiveData<List<String>> getIngredients() {
        return ingredients;
    }

    public LiveData<List<String>> getSauces() {
        return sauces;
    }

    public LiveData<List<StepListItem>> getStemListItems() {
        return stepListItems;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId = firebaseAuth.getCurrentUser().getUid();
        }
    }

    public void onTitleChanged(String text) {
        this.title = text;
    }

    public void onCategoryChanged(Category category) {
        this.category = category;
    }

    public void onImageUploadClick() {

        event.setValue(new Event.PrompImage());
    }

    public void onImageChanged(Bitmap bitmap) {
        if (bitmap != null) {
            image.setValue(bitmap);
        } else {
            event.setValue(new Event.ShowImageSelectFailureMessage("이미지 업로드에 실패했습니다"));
        }
    }

    public void onAddIngredientClick() {
        event.setValue(new Event.PromptIngredient());
    }

    public void onAddSauceClick() {
        event.setValue(new Event.PromptSauce());
    }

    public void onIngredientAdded(String ingredient) {

        assert ingredients.getValue() != null;
        List<String> newIngredients = new ArrayList<>(ingredients.getValue());
        newIngredients.add(ingredient);

        ingredients.setValue(newIngredients);
    }

    public void onSauceAdded(String sauce) {

        assert sauces.getValue() != null;
        List<String> newSauces = new ArrayList<>(sauces.getValue());
        newSauces.add(sauce);

        sauces.setValue(newSauces);
    }

    public void onAddStepClick() {

        event.setValue(new Event.NavigateToAddStepScreen());
    }

    public void onMeetingRoomUrlChanged(String text) {
        this.urlMeetingRoom = text;
    }

    public void onSubmitClick() {

        if (title.trim().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("제목을 입력해주세요"));
            return;
        }

        assert ingredients.getValue() != null;
        if (ingredients.getValue().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("재료를 추가해주세요"));
            return;
        }

        assert stepListItems.getValue() != null;
        if (stepListItems.getValue().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("설명을 추가해주세요"));
            return;
        }

        Ingredient ingredient = new Ingredient(ingredients.getValue(), sauces.getValue(), 1);

        Recipe recipe = new Recipe(userId, title, category, ingredient, urlMeetingRoom);
        Map<String, Bitmap> stepAlbum = new HashMap<>();

        for (StepListItem stepListItem : stepListItems.getValue()) {
            Step newStep = recipe.addStep(stepListItem.getTitle(), stepListItem.getContent());
            stepAlbum.put(newStep.getId(), stepListItem.getImage());
        }

        recipeRepository.addRecipe(recipe,
                unused -> {
                    if (image.getValue() != null) {
                        imageRepository.addRecipeImage(recipe.getId(), image.getValue(),
                                unused1 -> uploadStepImages(stepAlbum,
                                        unused2 -> event.setValue(new Event.NavigateBackWithResult(true))),
                                e -> {
                                }
                        );
                    } else {
                        event.setValue(new Event.NavigateBackWithResult(true));
                    }
                },
                e -> {
                    event.setValue(new Event.ShowSubmitFailureMessage(e.getMessage()));
                    Log.d("TAG", e.toString());
                }
        );
    }

    public void onAddStepResult(String title, String content, Bitmap image) {

        StepListItem stepListItem = new StepListItem(title, content, image);

        assert stepListItems.getValue() != null;
        List<StepListItem> newList = new ArrayList<>(stepListItems.getValue());
        newList.add(stepListItem);

        stepListItems.setValue(newList);
    }


    private void uploadStepImages(Map<String, Bitmap> stepAlbum, OnSuccessListener<Void> onSuccessListener) {

        AtomicInteger numUploaded = new AtomicInteger();

        for (Map.Entry<String, Bitmap> entry : stepAlbum.entrySet()) {
            String stepId = entry.getKey();
            Bitmap image = entry.getValue();
            imageRepository.addStepImage(stepId, image, unused -> {
                if (numUploaded.incrementAndGet() == stepAlbum.entrySet().size()) {
                    onSuccessListener.onSuccess(null);
                }
            }, e -> {
            });
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class PrompImage extends Event {
        }

        public static class ShowImageSelectFailureMessage extends Event {
            public final String message;

            public ShowImageSelectFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class PromptIngredient extends Event {
        }

        public static class PromptSauce extends Event {
        }

        public static class NavigateToAddStepScreen extends Event {
        }

        public static class ShowInvalidInputMessage extends Event {
            public final String message;

            public ShowInvalidInputMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowSubmitFailureMessage extends Event {
            public final String message;

            public ShowSubmitFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;

            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }
    }

}