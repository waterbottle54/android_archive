package com.cool.withcook.ui.home;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.cool.withcook.data.user.User;
import com.cool.withcook.databinding.RecipeItemBinding;

import java.util.Map;

public class DetailedRecipesAdapter extends ListAdapter<DetailedRecipe, DetailedRecipesAdapter.DetailedRecipeViewHolder> {

    class DetailedRecipeViewHolder extends RecyclerView.ViewHolder {

        private final RecipeItemBinding binding;

        public DetailedRecipeViewHolder(RecipeItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(DetailedRecipe model) {

            binding.textViewRecipeTitle.setText(model.getTitle());
            binding.textViewRecipeLikes.setText(String.valueOf(model.getLikes().size()));

            User writer = model.getWriter();
            if (writer != null) {
                binding.textViewRecipeWriter.setText(writer.getNickname());
            } else {
                binding.textViewRecipeWriter.setText("");
            }

            binding.imageViewRecipe.setImageBitmap(album.get(model.getId()));

            Integer commentCount = commentCountMap.get(model.getId());
            binding.textViewRecipeNumberComments.setText(String.valueOf(commentCount != null ? commentCount : 0));

            binding.imageViewZoom.setVisibility(
                    (model.getMeetingRoomUrl() == null || model.getMeetingRoomUrl().isEmpty()) ? View.INVISIBLE : View.VISIBLE);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final Map<String, Bitmap> album;
    private final Map<String, Integer> commentCountMap;

    public DetailedRecipesAdapter(Map<String, Bitmap> album, Map<String, Integer> commentCountMap) {
        super(new DiffUtilCallback());
        this.album = album;
        this.commentCountMap = commentCountMap;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public DetailedRecipeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        RecipeItemBinding binding = RecipeItemBinding.inflate(layoutInflater, parent, false);
        return new DetailedRecipeViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DetailedRecipeViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<DetailedRecipe> {

        @Override
        public boolean areItemsTheSame(@NonNull DetailedRecipe oldItem, @NonNull DetailedRecipe newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull DetailedRecipe oldItem, @NonNull DetailedRecipe newItem) {
            return oldItem.equals(newItem);
        }
    }

}