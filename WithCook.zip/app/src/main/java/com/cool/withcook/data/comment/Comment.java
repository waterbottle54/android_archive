package com.cool.withcook.data.comment;

import java.util.Objects;

// 댓글 자료형

public class Comment {

    private String id;
    private String recipeId;    // 작성된 레시피 아이디
    private String writerId;    // 작성자
    private String content;     // 내용
    private long created;       // 작성시간 (epoch millis)

    public Comment() {
    }

    public Comment(String recipeId, String writerId, String content) {
        this.recipeId = recipeId;
        this.writerId = writerId;
        this.content = content;
        this.created = System.currentTimeMillis();
        this.id = recipeId + "#" + writerId + "#" + created;
    }

    public Comment(Comment other) {
        this.recipeId = other.recipeId;
        this.writerId = other.writerId;
        this.content = other.content;
        this.created = other.created;
        this.id = other.id;
    }

    public String getId() {
        return id;
    }

    public String getRecipeId() {
        return recipeId;
    }

    public String getWriterId() {
        return writerId;
    }

    public String getContent() {
        return content;
    }

    public long getCreated() {
        return created;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setRecipeId(String recipeId) {
        this.recipeId = recipeId;
    }

    public void setWriterId(String writerId) {
        this.writerId = writerId;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setCreated(long created) {
        this.created = created;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Comment comment = (Comment) o;
        return created == comment.created && id.equals(comment.id) && recipeId.equals(comment.recipeId) && writerId.equals(comment.writerId) && content.equals(comment.content);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, recipeId, writerId, content, created);
    }
}
