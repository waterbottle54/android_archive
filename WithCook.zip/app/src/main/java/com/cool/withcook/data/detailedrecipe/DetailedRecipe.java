package com.cool.withcook.data.detailedrecipe;

import com.cool.withcook.data.recipe.Recipe;
import com.cool.withcook.data.user.User;

import java.io.Serializable;
import java.util.Objects;

// 작성자 회원정보와 연동된 레시피 자료형

public class DetailedRecipe extends Recipe implements Serializable {

    private final User writer;

    public DetailedRecipe(Recipe recipe, User writer) {
        super(recipe);
        this.writer = writer;
    }

    public User getWriter() {
        return writer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        DetailedRecipe that = (DetailedRecipe) o;
        return Objects.equals(writer, that.writer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), writer);
    }

}
