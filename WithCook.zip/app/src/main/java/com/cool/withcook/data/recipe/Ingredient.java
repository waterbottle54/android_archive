package com.cool.withcook.data.recipe;

import java.io.Serializable;
import java.util.List;

// 재료 자료형

public class Ingredient implements Serializable {

    private List<String> ingredients;       // 주재료
    private List<String> sauces;            // 소스
    private int servings;                   // n인분 (디폴트 1인분)

    public Ingredient() {
    }

    public Ingredient(List<String> ingredients, List<String> sauces, int servings) {
        this.ingredients = ingredients;
        this.sauces = sauces;
        this.servings = servings;
    }

    public List<String> getIngredients() {
        return ingredients;
    }

    public List<String> getSauces() {
        return sauces;
    }

    public int getServings() {
        return servings;
    }

    public void setIngredients(List<String> ingredients) {
        this.ingredients = ingredients;
    }

    public void setSauces(List<String> sauces) {
        this.sauces = sauces;
    }

    public void setServings(int servings) {
        this.servings = servings;
    }
}
