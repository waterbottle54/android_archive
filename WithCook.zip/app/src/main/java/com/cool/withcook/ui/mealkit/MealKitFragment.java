package com.cool.withcook.ui.mealkit;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.cool.withcook.R;
import com.cool.withcook.databinding.FragmentMealKitBinding;
import com.cool.withcook.util.ui.AuthFragment;
import com.google.firebase.auth.FirebaseAuth;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MealKitFragment extends AuthFragment {

    private FragmentMealKitBinding binding;
    private MealKitViewModel viewModel;


    public MealKitFragment() {
        super(R.layout.fragment_meal_kit);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentMealKitBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(MealKitViewModel.class);

        binding.webView.setWebViewClient(new WebViewClient());
        binding.webView.setWebChromeClient(new WebChromeClient());
        binding.webView.loadUrl(MealKitViewModel.URL_COUPANG);

        binding.fabCart.setOnClickListener(v -> viewModel.onCartClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof MealKitViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof MealKitViewModel.Event.BrowseShoppingSite) {
                String url = ((MealKitViewModel.Event.BrowseShoppingSite) event).url;
                browseWebsite(url);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }


    private void browseWebsite(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(intent);
    }

}