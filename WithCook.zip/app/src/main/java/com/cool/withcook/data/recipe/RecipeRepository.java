package com.cool.withcook.data.recipe;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.cool.withcook.data.Category;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

public class RecipeRepository {

    private final CollectionReference recipesCollection;

    @Inject
    public RecipeRepository(FirebaseFirestore firestore) {

        recipesCollection = firestore.collection("recipes");
    }

    // DB 에 레시피를 추가하는 메소드

    public void addRecipe(Recipe recipe, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        recipesCollection.document(recipe.getId())
                .set(recipe)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    // DB 에 특정 카테고리에 속하는 레시피들을 가져오는 메소드

    public LiveData<List<Recipe>> getRecipes(Category category) {

        MutableLiveData<List<Recipe>> recipes = new MutableLiveData<>(new ArrayList<>());

        recipesCollection.orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) ->  {
                    if (value == null || error != null) {
                        recipes.setValue(null);
                        return;
                    }

                    List<Recipe> recipeList = new ArrayList<>();
                    for (DocumentSnapshot snapshot : value) {
                        Recipe recipe = snapshot.toObject(Recipe.class);
                        if (recipe == null) {
                            continue;
                        }
                        if (recipe.getCategory() == category) {
                            recipeList.add(recipe);
                        }
                    }

                    recipes.setValue(recipeList);
                });

        return recipes;
    }

    // DB 에서 추천수 30 이상인 레시피를 상위에서부터 3개 가져오는 메소드

    public LiveData<List<Recipe>> getBestRecipes() {

        MutableLiveData<List<Recipe>> recipes = new MutableLiveData<>(new ArrayList<>());

        recipesCollection.orderBy("likes", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) ->  {
                    if (value == null || error != null) {
                        recipes.setValue(null);
                        return;
                    }

                    List<Recipe> recipeList = new ArrayList<>();
                    for (DocumentSnapshot snapshot : value) {
                        Recipe recipe = snapshot.toObject(Recipe.class);
                        if (recipe == null) {
                            continue;
                        }
                        if (recipe.getLikes().size() >= 30) {
                            recipeList.add(recipe);
                            if (recipeList.size() >= 3) {
                                break;
                            }
                        }
                    }

                    recipes.setValue(recipeList);
                });

        return recipes;
    }

    // DB 에서 query 문자열로 시작하는 제목을 가진 레시피들을 가져오는 메소드

    public LiveData<List<Recipe>> getQueryRecipes(String query) {

        MutableLiveData<List<Recipe>> recipes = new MutableLiveData<>(new ArrayList<>());
        if (query.trim().isEmpty()) {
            return recipes;
        }

        recipesCollection.orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) ->  {
                    if (value == null || error != null) {
                        recipes.setValue(null);
                        return;
                    }

                    List<Recipe> recipeList = new ArrayList<>();
                    for (DocumentSnapshot snapshot : value) {
                        Recipe recipe = snapshot.toObject(Recipe.class);
                        if (recipe == null) {
                            continue;
                        }
                        if (recipe.getTitle().toLowerCase().startsWith(query.toLowerCase())) {
                            recipeList.add(recipe);
                        }
                    }

                    recipes.setValue(recipeList);
                });

        return recipes;
    }

    // DB 에서 특정 레시피에 좋아요를 누르거나 취소하는 메소드

    public void likeOrUnlikeRecipe(String recipeId, String userId, OnSuccessListener<List<String>> onSuccessListener) {

        recipesCollection.document(recipeId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    Recipe recipe = documentSnapshot.toObject(Recipe.class);
                    if (recipe == null) {
                        return;
                    }
                    List<String> likes = recipe.getLikes();
                    if (likes.contains(userId)) {
                        likes.remove(userId);
                    } else {
                        likes.add(userId);
                    }
                    recipesCollection.document(recipeId).update("likes", likes)
                            .addOnSuccessListener(unused -> onSuccessListener.onSuccess(likes));
                });
    }

}
