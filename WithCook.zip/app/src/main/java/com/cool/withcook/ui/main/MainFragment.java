package com.cool.withcook.ui.main;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.cool.withcook.R;
import com.cool.withcook.databinding.FragmentMainBinding;
import com.cool.withcook.util.ui.AuthFragment;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MainFragment extends AuthFragment {

    private FragmentMainBinding binding;
    private MainViewModel viewModel;
    private NavController navController;


    public MainFragment() {
        super(R.layout.fragment_main);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                viewModel.onBackClick();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentMainBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        NavHostFragment navHostFragment =
                (NavHostFragment) getChildFragmentManager().findFragmentById(R.id.nav_host_fragment);

        assert navHostFragment != null;
        navController = navHostFragment.getNavController();
        NavigationUI.setupWithNavController(binding.bottomNav, navController);

        navController.addOnDestinationChangedListener((controller, destination, arguments) ->
                binding.bottomNav.setVisibility(destination.getId() == R.id.addRecipeFragment ? View.GONE : View.VISIBLE)
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof MainViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof MainViewModel.Event.ConfirmSignOut) {
                String message = ((MainViewModel.Event.ConfirmSignOut)event).message;
                showConfirmSignOutDialog(message);
            }
        });

        setHasOptionsMenu(true);

        getParentFragmentManager().setFragmentResultListener("add_recipe_fragment", getViewLifecycleOwner(), (requestKey, result) -> {
            boolean success = result.getBoolean("success");
            if (success) {
                Snackbar.make(requireView(), "레시피가 작성되었습니다", Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int itemId = item.getItemId();

        if (itemId == android.R.id.home) {
            viewModel.onBackClick();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showConfirmSignOutDialog(String message) {

        new AlertDialog.Builder(context)
                .setTitle("로그아웃")
                .setMessage(message)
                .setPositiveButton("네", (dialog, which) -> viewModel.onSignOutConfirmed())
                .setNegativeButton("아니오", null)
                .show();
    }


}