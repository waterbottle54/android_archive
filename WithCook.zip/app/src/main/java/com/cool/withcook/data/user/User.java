package com.cool.withcook.data.user;

public class User {

    private String uid;
    private String nickname;
    private long created;

    public User() {
    }

    public User(String uid, String nickname) {
        this.uid = uid;
        this.nickname = nickname;
        this.created = System.currentTimeMillis();
    }

    public String getUid() {
        return uid;
    }

    public String getNickname() {
        return nickname;
    }

    public long getCreated() {
        return created;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setCreated(long created) {
        this.created = created;
    }
}
