package com.cool.withcook.ui.search;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.withcook.R;
import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.cool.withcook.databinding.FragmentSearchBinding;
import com.cool.withcook.ui.home.DetailedRecipesAdapter;
import com.cool.withcook.util.OnTextChangedListener;
import com.cool.withcook.util.ui.AuthFragment;
import com.google.firebase.auth.FirebaseAuth;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SearchFragment extends AuthFragment implements DetailedRecipesAdapter.OnItemSelectedListener {

    private FragmentSearchBinding binding;
    private SearchViewModel viewModel;
    private DetailedRecipesAdapter recipesAdapter;


    public SearchFragment() {
        super(R.layout.fragment_search);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSearchBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SearchViewModel.class);

        binding.editTextQuery.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onQueryChange(text);
            }
        });

        viewModel.getRecipeAlbum().observe(getViewLifecycleOwner(), album ->
                viewModel.getCommentCountMap().observe(getViewLifecycleOwner(), commentCountMap -> {
                    recipesAdapter = new DetailedRecipesAdapter(album, commentCountMap);
                    binding.recyclerRecipe.setAdapter(recipesAdapter);
                    binding.recyclerRecipe.setHasFixedSize(true);
                    recipesAdapter.setOnItemSelectedListener(this);

                    viewModel.getRecipes().observe(getViewLifecycleOwner(), recipes -> {
                        if (recipes != null) {
                            recipesAdapter.submitList(recipes);
                            binding.textViewNoQueryResult.setVisibility(recipes.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                        }
                        binding.progressBar.setVisibility(View.INVISIBLE);
                    });
                })
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SearchViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SearchViewModel.Event.ShowProgressBar) {
                binding.progressBar.setVisibility(View.VISIBLE);
            } else if (event instanceof SearchViewModel.Event.NavigateToRecipeScreen) {
                DetailedRecipe recipe = ((SearchViewModel.Event.NavigateToRecipeScreen) event).recipe;
                NavDirections action = SearchFragmentDirections.actionGlobalRecipeFragment(recipe);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public void onItemSelected(int position) {
        DetailedRecipe detailedRecipe = recipesAdapter.getCurrentList().get(position);
        viewModel.onRecipeClick(detailedRecipe);
    }

}