package com.cool.withcook.data.detailedrecipe;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.cool.withcook.data.Category;
import com.cool.withcook.data.recipe.Recipe;
import com.cool.withcook.data.recipe.RecipeRepository;
import com.cool.withcook.data.user.User;
import com.cool.withcook.data.user.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class DetailedRecipeRepository {

    private final RecipeRepository recipeRepository;
    private final UserRepository userRepository;

    @Inject
    public DetailedRecipeRepository(RecipeRepository recipeRepository, UserRepository userRepository) {
        this.recipeRepository = recipeRepository;
        this.userRepository = userRepository;
    }

    // RecipeRepository 의 getDetailedRecipes(Category category) 에 대응되는 메소드

    public LiveData<List<DetailedRecipe>> getDetailedRecipes(Category category) {
        return convertToDetailedRecipes(recipeRepository.getRecipes(category));
    }

    // RecipeRepository 의 getBestRecipes() 에 대응되는 메소드

    public LiveData<List<DetailedRecipe>> getBestRecipes() {
        return convertToDetailedRecipes(recipeRepository.getBestRecipes());
    }

    // RecipeRepository 의 getQueryRecipes(String query) 에 대응되는 메소드

    public LiveData<List<DetailedRecipe>> getQueryRecipes(String query) {
        return convertToDetailedRecipes(recipeRepository.getQueryRecipes(query));
    }

    // 특정 Recipe 들을 받아서 DetailedRecipe 로 바꿔주는 메소드

    private LiveData<List<DetailedRecipe>> convertToDetailedRecipes(LiveData<List<Recipe>> recipes) {

        LiveData<Map<String, User>> userMap = userRepository.getUserMap();

        return Transformations.switchMap(recipes, recipeList ->
                Transformations.map(userMap, userMapValue -> {
                    List<DetailedRecipe> detailedRecipeList = new ArrayList<>();
                    for (Recipe recipe : recipeList) {
                        User writer = userMapValue.get(recipe.getWriterId());
                        DetailedRecipe detailedRecipe = new DetailedRecipe(recipe, writer);
                        detailedRecipeList.add(detailedRecipe);
                    }
                    return detailedRecipeList;
                })
        );
    }

}









