package com.cool.withcook.ui.halloffame;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.withcook.R;
import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.cool.withcook.databinding.FragmentHallOfFameBinding;
import com.cool.withcook.ui.home.DetailedRecipesAdapter;
import com.cool.withcook.util.ui.AuthFragment;
import com.google.firebase.auth.FirebaseAuth;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HallOfFameFragment extends AuthFragment implements DetailedRecipesAdapter.OnItemSelectedListener {

    private FragmentHallOfFameBinding binding;
    private HallOfFameViewModel viewModel;
    private DetailedRecipesAdapter recipesAdapter;


    public HallOfFameFragment() {
        super(R.layout.fragment_hall_of_fame);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentHallOfFameBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HallOfFameViewModel.class);

        viewModel.getRecipeAlbum().observe(getViewLifecycleOwner(), album ->
                viewModel.getCommentCountMap().observe(getViewLifecycleOwner(), commentCountMap -> {
                    recipesAdapter = new DetailedRecipesAdapter(album, commentCountMap);
                    binding.recyclerRecipe.setAdapter(recipesAdapter);
                    binding.recyclerRecipe.setHasFixedSize(true);
                    recipesAdapter.setOnItemSelectedListener(this);

                    viewModel.getRecipes().observe(getViewLifecycleOwner(), recipes -> {
                        if (recipes != null) {
                            recipesAdapter.submitList(recipes);
                            binding.textViewNoBestRecipes.setVisibility(recipes.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                        }
                        binding.progressBar.setVisibility(View.INVISIBLE);
                    });
                })
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof HallOfFameViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof HallOfFameViewModel.Event.NavigateToRecipeScreen) {
                DetailedRecipe recipe = ((HallOfFameViewModel.Event.NavigateToRecipeScreen) event).recipe;
                NavDirections action = HallOfFameFragmentDirections.actionGlobalRecipeFragment(recipe);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public void onItemSelected(int position) {
        DetailedRecipe detailedRecipe = recipesAdapter.getCurrentList().get(position);
        viewModel.onRecipeClick(detailedRecipe);
    }

}