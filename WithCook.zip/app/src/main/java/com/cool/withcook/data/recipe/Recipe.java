package com.cool.withcook.data.recipe;

import com.cool.withcook.data.Category;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

// 레시피 자료형

public class Recipe implements Serializable {

    private String id;
    private String writerId;        // 작성자 아이디
    private String title;           // 제목
    private Category category;      // 카테고리
    private Ingredient ingredient;  // 재료
    private List<Step> steps;       // 단계들
    private String meetingRoomUrl;  // 화상회의실 링크
    private List<String> likes;     // 좋아요 누른 회원 아이디 리스트
    private long created;           // 작성시간 (epoch millis)


    public Recipe() {
    }

    public Recipe(String writerId, String title, Category category, Ingredient ingredient, String meetingRoomUrl) {
        this.writerId = writerId;
        this.title = title;
        this.category = category;
        this.ingredient = ingredient;
        this.meetingRoomUrl = meetingRoomUrl;
        this.likes = new ArrayList<>();
        this.created = System.currentTimeMillis();
        this.id = writerId + "#" + created;
        this.steps = new ArrayList<>();
    }
    
    public Recipe(Recipe other) {
        this.writerId = other.writerId;
        this.title = other.title;
        this.category = other.category;
        this.ingredient = other.ingredient;
        this.meetingRoomUrl = other.meetingRoomUrl;
        this.likes = other.likes;
        this.created = other.created;
        this.id = other.id;
        this.steps = other.steps;
    }

    public String getId() {
        return id;
    }

    public String getWriterId() {
        return writerId;
    }

    public String getTitle() {
        return title;
    }

    public Category getCategory() {
        return category;
    }

    public Ingredient getIngredient() {
        return ingredient;
    }

    public List<Step> getSteps() {
        return steps;
    }

    public long getCreated() {
        return created;
    }

    public String getMeetingRoomUrl() {
        return meetingRoomUrl;
    }

    public List<String> getLikes() {
        return likes;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setWriterId(String writerId) {
        this.writerId = writerId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setIngredient(Ingredient ingredient) {
        this.ingredient = ingredient;
    }

    public void setSteps(List<Step> steps) {
        this.steps = steps;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public void setMeetingRoomUrl(String meetingRoomUrl) {
        this.meetingRoomUrl = meetingRoomUrl;
    }

    public void setLikes(List<String> likes) {
        this.likes = likes;
    }


    public Step addStep(String title, String content) {
        Step step = new Step(id, title, content);
        steps.add(step);
        return step;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Recipe recipe = (Recipe) o;
        return created == recipe.created && id.equals(recipe.id) && writerId.equals(recipe.writerId) && title.equals(recipe.title) && category == recipe.category && ingredient.equals(recipe.ingredient) && steps.equals(recipe.steps) && Objects.equals(meetingRoomUrl, recipe.meetingRoomUrl) && likes.equals(recipe.likes);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, writerId, title, category, ingredient, steps, meetingRoomUrl, likes, created);
    }

}
