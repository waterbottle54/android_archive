package com.cool.withcook.ui.addrecipe.addrecipe;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.withcook.R;
import com.cool.withcook.data.Category;
import com.cool.withcook.databinding.FragmentAddRecipeBinding;
import com.cool.withcook.databinding.IngredientDialogBinding;
import com.cool.withcook.databinding.SauceDialogBinding;
import com.cool.withcook.util.BitmapUtils;
import com.cool.withcook.util.NameUtils;
import com.cool.withcook.util.OnTextChangedListener;
import com.cool.withcook.util.ui.AuthFragment;
import com.cool.withcook.util.ui.CardsAdapter;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;
import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class AddRecipeFragment extends AuthFragment {

    private FragmentAddRecipeBinding binding;
    private AddRecipeViewModel viewModel;

    private ActivityResultLauncher<Intent> imageActivityLauncher;
    private ActivityResultLauncher<String[]> requestPermissionLauncher;

    public AddRecipeFragment() {
        super(R.layout.fragment_add_recipe);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        imageActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK
                            && result.getData() != null) {
                        // 비트맵 획득
                        Bitmap bitmap = null;
                        if (result.getData().getExtras() != null) {
                            // 카메라 결과 획득
                            bitmap = (Bitmap) result.getData().getExtras().get("data");
                        } else {
                            // 갤러리(포토) 결과 획득
                            Uri uri = result.getData().getData();
                            if (uri != null) {
                                String path = BitmapUtils.getRealPathFromUri(requireContext(), uri);
                                bitmap = BitmapUtils.getBitmapFromPath(path);
                            }
                        }
                        viewModel.onImageChanged(bitmap);
                    }
                }
        );

        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    Boolean permissionExternalStorage = result.get(Manifest.permission.READ_EXTERNAL_STORAGE);
                    Boolean permissionCamera = result.get(Manifest.permission.CAMERA);

                    if (permissionExternalStorage != null && permissionExternalStorage
                            && permissionCamera != null && permissionCamera) {
                        showImageDialog();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentAddRecipeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(AddRecipeViewModel.class);

        binding.editTextRecipeTitle.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onTitleChanged(text);
            }
        });

        buildCategorySpinner();

        binding.fabUploadImage.setOnClickListener(v -> viewModel.onImageUploadClick());

        binding.imageViewAddIngredient.setOnClickListener(v -> {
            viewModel.onAddIngredientClick();
            binding.editTextRecipeTitle.clearFocus();
        });

        CardsAdapter ingredientsAdapter = new CardsAdapter();
        binding.recyclerViewIngredient.setHasFixedSize(true);
        binding.recyclerViewIngredient.setAdapter(ingredientsAdapter);

        binding.imageViewAddSauce.setOnClickListener(v -> {
            viewModel.onAddSauceClick();
            binding.editTextRecipeTitle.clearFocus();
        });

        CardsAdapter saucesAdapter = new CardsAdapter();
        binding.recyclerViewSauce.setHasFixedSize(true);
        binding.recyclerViewSauce.setAdapter(saucesAdapter);

        binding.imageViewAddStep.setOnClickListener(v -> viewModel.onAddStepClick());

        StepListItemsAdapter stepListItemsAdapter = new StepListItemsAdapter();
        binding.recyclerViewStep.setHasFixedSize(true);
        binding.recyclerViewStep.setAdapter(stepListItemsAdapter);

        binding.editTextUrlMeetingRoom.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onMeetingRoomUrlChanged(text);
            }
        });

        binding.fabSubmitRecipe.setOnClickListener(v -> viewModel.onSubmitClick());

        viewModel.getImage().observe(getViewLifecycleOwner(), image -> {
            binding.imageViewRecipe.setImageBitmap(image);
            binding.textViewNoImage.setVisibility(View.INVISIBLE);
        });

        viewModel.getIngredients().observe(getViewLifecycleOwner(), ingredientsAdapter::submitList);

        viewModel.getSauces().observe(getViewLifecycleOwner(), saucesAdapter::submitList);

        viewModel.getStemListItems().observe(getViewLifecycleOwner(), stepListItems -> {
            stepListItemsAdapter.submitList(stepListItems);
            if (!stepListItems.isEmpty()) {
                binding.textViewNoStep.setVisibility(View.INVISIBLE);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof AddRecipeViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof AddRecipeViewModel.Event.PrompImage) {
                promptImage();
            } else if (event instanceof AddRecipeViewModel.Event.ShowImageSelectFailureMessage) {
                String message = ((AddRecipeViewModel.Event.ShowImageSelectFailureMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof AddRecipeViewModel.Event.PromptIngredient) {
                promptIngredient();
            } else if (event instanceof AddRecipeViewModel.Event.PromptSauce) {
                promptSauce();
            } else if (event instanceof AddRecipeViewModel.Event.NavigateToAddStepScreen) {
                NavDirections action = AddRecipeFragmentDirections.actionAddRecipeFragmentToAddStepFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof AddRecipeViewModel.Event.ShowInvalidInputMessage) {
                String message = ((AddRecipeViewModel.Event.ShowInvalidInputMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof AddRecipeViewModel.Event.ShowSubmitFailureMessage) {
                String message = ((AddRecipeViewModel.Event.ShowSubmitFailureMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof AddRecipeViewModel.Event.NavigateBackWithResult) {
                boolean success = ((AddRecipeViewModel.Event.NavigateBackWithResult) event).success;
                Bundle result = new Bundle();
                result.putBoolean("success", success);
                getParentFragmentManager().setFragmentResult("add_recipe_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });

        getParentFragmentManager().setFragmentResultListener("add_step_fragment", getViewLifecycleOwner(), (requestKey, result) -> {
            String stepTitle = result.getString("title");
            String stepContent = result.getString("content");
            Bitmap stepImage = result.getParcelable("image");
            viewModel.onAddStepResult(stepTitle, stepContent, stepImage);
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }


    private void buildCategorySpinner() {

        List<String> categoryNames = NameUtils.getCategoryNames(getResources());
        Map<String, Category> categoryMap = NameUtils.getCategoryMap(getResources());

        SpinnerAdapter spinnerAdapter =
                new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, categoryNames);
        binding.spinnerRecipeCategory.setAdapter(spinnerAdapter);
        binding.spinnerRecipeCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Category category = categoryMap.get(categoryNames.get(i));
                viewModel.onCategoryChanged(category);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        Category selectedCategory = viewModel.getCategory();
        binding.spinnerRecipeCategory.setSelection(selectedCategory.ordinal());

    }

    private void promptImage() {

        if (requireContext().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && requireContext().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showImageDialog();
        } else {
            requestPermissionLauncher.launch(
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}
            );
        }
    }

    private void showImageDialog() {

        // 업로드 방법 선택 대화상자 보이기
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chooser = Intent.createChooser(galleryIntent, "사진 업로드");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        imageActivityLauncher.launch(chooser);
    }

    private void promptIngredient() {

        IngredientDialogBinding dialogBinding = IngredientDialogBinding.inflate(getLayoutInflater());

        new AlertDialog.Builder(requireContext())
                .setView(dialogBinding.getRoot())
                .setPositiveButton("추가", (dialogInterface, i) ->
                        viewModel.onIngredientAdded(dialogBinding.editTextIngredient.getText().toString()))
                .setNegativeButton("취소", null)
                .show();
    }

    private void promptSauce() {

        SauceDialogBinding dialogBinding = SauceDialogBinding.inflate(getLayoutInflater());

        new AlertDialog.Builder(requireContext())
                .setView(dialogBinding.getRoot())
                .setPositiveButton("추가", (dialogInterface, i) ->
                        viewModel.onSauceAdded(dialogBinding.editTextSauce.getText().toString()))
                .setNegativeButton("취소", null)
                .show();
    }

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}