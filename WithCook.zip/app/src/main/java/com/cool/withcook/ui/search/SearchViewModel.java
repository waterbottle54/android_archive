package com.cool.withcook.ui.search;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.cool.withcook.data.comment.Comment;
import com.cool.withcook.data.comment.CommentRepository;
import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.cool.withcook.data.detailedrecipe.DetailedRecipeRepository;
import com.cool.withcook.data.image.ImageRepository;
import com.cool.withcook.data.recipe.Recipe;
import com.cool.withcook.ui.home.HomeViewModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SearchViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> query = new MutableLiveData<>();

    private final LiveData<List<DetailedRecipe>> recipes;

    private final LiveData<Map<String, Bitmap>> recipeAlbum;
    private final LiveData<Map<String, Integer>> commentCountMap;


    @Inject
    public SearchViewModel(DetailedRecipeRepository detailedRecipeRepository, ImageRepository imageRepository, CommentRepository commentRepository) {

        recipes = Transformations.switchMap(query, detailedRecipeRepository::getQueryRecipes);

        recipeAlbum = Transformations.switchMap(recipes, recipeList -> {
            List<String> recipeIdList = recipeList.stream().map(Recipe::getId).collect(Collectors.toList());
            return imageRepository.getRecipeAlbum(recipeIdList);
        });

        LiveData<Map<String, List<Comment>>> commentMap = Transformations.switchMap(recipes, recipeList -> {
            List<String> recipeIdList = recipeList.stream().map(Recipe::getId).collect(Collectors.toList());
            return commentRepository.getCommentMap(recipeIdList);
        });

        commentCountMap = Transformations.map(commentMap, map -> {
            Map<String, Integer> countMap = new HashMap<>();
            for (Map.Entry<String, List<Comment>> entry : map.entrySet()) {
                countMap.put(entry.getKey(), entry.getValue().size());
            }
            return countMap;
        });
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<DetailedRecipe>> getRecipes() {
        return recipes;
    }

    public LiveData<Map<String, Bitmap>> getRecipeAlbum() {
        return recipeAlbum;
    }

    public LiveData<Map<String, Integer>> getCommentCountMap() {
        return commentCountMap;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }

    public void onQueryChange(String text) {
        query.setValue(text);
    }

    public void onRecipeClick(DetailedRecipe detailedRecipe) {
        if (detailedRecipe != null) {
            event.setValue(new Event.NavigateToRecipeScreen(detailedRecipe));
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowProgressBar extends Event {}

        public static class NavigateToRecipeScreen extends Event {
            public final DetailedRecipe recipe;

            public NavigateToRecipeScreen(DetailedRecipe recipe) {
                this.recipe = recipe;
            }
        }
    }

}