package com.cool.withcook.ui.comments;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.cool.withcook.data.detailedcomment.DetailedComment;
import com.cool.withcook.databinding.CommentItemBinding;
import com.cool.withcook.util.TimeUtils;

public class DetailedCommentsAdapter extends ListAdapter<DetailedComment, DetailedCommentsAdapter.DetailedCommentViewHolder> {

    class DetailedCommentViewHolder extends RecyclerView.ViewHolder {

        private final CommentItemBinding binding;

        public DetailedCommentViewHolder(CommentItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(DetailedComment model) {

            binding.textViewCommentWriter.setText(model.getUser().getNickname());
            binding.textViewCommentContent.setText(model.getContent());

            String strDateTime = TimeUtils.getTimeString(resources, model.getCreated());
            binding.textViewCommentDateTime.setText(strDateTime);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final Resources resources;


    public DetailedCommentsAdapter(Resources resources) {
        super(new DiffUtilCallback());
        this.resources = resources;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public DetailedCommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        CommentItemBinding binding = CommentItemBinding.inflate(layoutInflater, parent, false);
        return new DetailedCommentViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DetailedCommentViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<DetailedComment> {

        @Override
        public boolean areItemsTheSame(@NonNull DetailedComment oldItem, @NonNull DetailedComment newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull DetailedComment oldItem, @NonNull DetailedComment newItem) {
            return oldItem.equals(newItem);
        }
    }

}