package com.cool.withcook.data.image;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class ImageRepository {

    private static final int MEGABYTES = 1024 * 1024;

    private final StorageReference recipeImages;
    private final StorageReference stepImages;


    @Inject
    public ImageRepository(FirebaseStorage storage) {

        recipeImages = storage.getReference("recipes");
        stepImages = storage.getReference("steps");
    }

    // DB 에 특정 레시피의 대표 이미지 (비트맵) 를 추가하는 메소드

    public void addRecipeImage(String recipeId, Bitmap bitmap,
                               OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        recipeImages.child(recipeId + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }

    // DB 에서 특정 레시피의 대표 이미지 (비트맵) 을 가져오는 메소드

    public void getRecipeImage(String recipeId,
                               OnSuccessListener<Bitmap> onSuccessListener,
                               OnFailureListener onFailureListener
    ) {
        recipeImages.child(recipeId + ".jpg")
                .getBytes(10 * MEGABYTES)
                .addOnSuccessListener(bytes -> {
                    Bitmap image = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    onSuccessListener.onSuccess(image);
                })
                .addOnFailureListener(onFailureListener);
    }

    // getRecipeImage() 의 LiveData 버젼

    public LiveData<Bitmap> getRecipeImageLiveData(String recipeId) {

        MutableLiveData<Bitmap> bitmap = new MutableLiveData<>();
        getRecipeImage(recipeId, bitmap::setValue, e -> bitmap.setValue(null));
        return bitmap;
    }

    // DB 에서 주어진 레시피들의 대표 이미지들을 (레시피 아이디 : 비트맵) 형식의 맵으로 가져오는 메소드

    public LiveData<Map<String, Bitmap>> getRecipeAlbum(List<String> recipeIdList) {

        MutableLiveData<Map<String, Bitmap>> album = new MutableLiveData<>(new HashMap<>());

        for (String recipeId : recipeIdList) {
            getRecipeImage(recipeId,
                    bitmap -> {
                        if (bitmap != null) {
                            Map<String, Bitmap> oldMap = album.getValue();
                            assert oldMap != null;
                            Map<String, Bitmap> map = new HashMap<>(oldMap);
                            map.put(recipeId, bitmap);
                            album.setValue(map);
                        }
                    },
                    e -> { }
            );
        }

        return album;
    }

    // DB 에 레시피의 각 Step 이미지를 추가하는 메소드

    public void addStepImage(String stepId, Bitmap bitmap,
                             OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        stepImages.child(stepId + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }

    // DB 에서 레시피의 Step 이미지를 가져오는 메소드

    public void getStepImage(String stepId,
                               OnSuccessListener<Bitmap> onSuccessListener,
                               OnFailureListener onFailureListener
    ) {
        stepImages.child(stepId + ".jpg")
                .getBytes(10 * MEGABYTES)
                .addOnSuccessListener(bytes -> {
                    Bitmap image = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    onSuccessListener.onSuccess(image);
                })
                .addOnFailureListener(onFailureListener);
    }

    // DB 에서 주어진 스텝들의 스텝 이미지들을 (스텝 아이디 : 비트맵) 형식의 맵으로 가져오는 메소드

    public LiveData<Map<String, Bitmap>> getStepAlbum(List<String> stepIdList) {

        MutableLiveData<Map<String, Bitmap>> album = new MutableLiveData<>(new HashMap<>());

        for (String stepId : stepIdList) {
            getStepImage(stepId,
                    bitmap -> {
                        if (bitmap != null) {
                            Map<String, Bitmap> oldMap = album.getValue();
                            assert oldMap != null;
                            Map<String, Bitmap> map = new HashMap<>(oldMap);
                            map.put(stepId, bitmap);
                            album.setValue(map);
                        }
                    },
                    e -> { }
            );
        }

        return album;
    }

}
