package com.cool.withcook;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class WithCookApplication extends Application {


}
