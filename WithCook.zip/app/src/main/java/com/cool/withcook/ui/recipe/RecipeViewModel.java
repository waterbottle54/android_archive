package com.cool.withcook.ui.recipe;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.cool.withcook.data.comment.CommentRepository;
import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.cool.withcook.data.image.ImageRepository;
import com.cool.withcook.data.recipe.RecipeRepository;
import com.cool.withcook.data.recipe.Step;
import com.cool.withcook.ui.mealkit.MealKitViewModel;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class RecipeViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> userId = new MutableLiveData<>();

    private final DetailedRecipe recipe;
    private final LiveData<Bitmap> recipeImage;
    private final LiveData<Map<String, Bitmap>> stepAlbum;
    private final LiveData<Integer> commentCount;
    private final MutableLiveData<List<String>> recipeLikes = new MutableLiveData<>();
    private final LiveData<Integer> likes;
    private final LiveData<Boolean> liked;

    private final RecipeRepository recipeRepository;


    @Inject
    public RecipeViewModel(SavedStateHandle savedStateHandle, ImageRepository imageRepository, CommentRepository commentRepository, RecipeRepository recipeRepository) {

        recipe = savedStateHandle.get("recipe");

        assert recipe != null;
        recipeImage = imageRepository.getRecipeImageLiveData(recipe.getId());

        List<String> stepIdList = getSteps().stream().map(Step::getId).collect(Collectors.toList());
        stepAlbum = imageRepository.getStepAlbum(stepIdList);

        commentCount = Transformations.map(commentRepository.getComments(recipe.getId()), List::size);

        likes = Transformations.map(recipeLikes, List::size);
        liked = Transformations.switchMap(recipeLikes, likes ->
                Transformations.map(userId, likes::contains));
        recipeLikes.setValue(recipe.getLikes());

        this.recipeRepository = recipeRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Bitmap> getRecipeImage() {
        return recipeImage;
    }

    public String getRecipeTitle() {
        return recipe.getTitle();
    }

    public String getWriterNickname() {
        return recipe.getWriter().getNickname();
    }

    public LiveData<Integer> getNumberOfLikes() {
        return likes;
    }

    public LiveData<Boolean> hasLiked() {
        return liked;
    }

    public List<String> getIngredients() {
        return recipe.getIngredient().getIngredients();
    }

    public List<String> getSauces() {
        return recipe.getIngredient().getSauces();
    }

    public List<Step> getSteps() {
        return recipe.getSteps();
    }

    public LiveData<Map<String, Bitmap>> getStepAlbum() {
        return stepAlbum;
    }

    public LiveData<Integer> getCommentCount() {
        return commentCount;
    }

    public boolean hasMeetingRoom() {
        return (recipe.getMeetingRoomUrl() != null && !recipe.getMeetingRoomUrl().trim().isEmpty());
    }

    public String getMeetingRoomUrl() {
        return recipe.getMeetingRoomUrl();
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId.setValue(firebaseAuth.getCurrentUser().getUid());
        }
    }

    public void onShowCommentClick() {
        event.setValue(new Event.NavigateToCommentsScreen(recipe));
    }

    public void onLikeClick() {

        assert userId.getValue() != null;
        if (userId.getValue().equals(recipe.getWriterId())) {
            event.setValue(new Event.ShowCannotLikeOwnRecipe("본인의 글에는 좋아요를 누를 수 없어요"));
            return;
        }

        recipeRepository.likeOrUnlikeRecipe(recipe.getId(), userId.getValue(),
                likes -> {
                    recipe.setLikes(likes);
                    recipeLikes.setValue(likes);
                }
        );
    }

    public void onMeetingRoomUrlClick() {
        String url = recipe.getMeetingRoomUrl();
        if (url.startsWith("http://") || url.startsWith("https://")) {
            event.setValue(new Event.BrowseMeetingRoom(recipe.getMeetingRoomUrl()));
        } else {
            event.setValue(new Event.ShowInvalidUrlMessage("잘못된 URL 링크입니다"));
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToCommentsScreen extends Event {
            public final DetailedRecipe recipe;

            public NavigateToCommentsScreen(DetailedRecipe recipe) {
                this.recipe = recipe;
            }
        }

        public static class ShowCannotLikeOwnRecipe extends Event {
            public final String message;

            public ShowCannotLikeOwnRecipe(String message) {
                this.message = message;
            }
        }

        public static class BrowseMeetingRoom extends Event {
            public final String url;
            public BrowseMeetingRoom(String url) {
                this.url = url;
            }
        }

        public static class ShowInvalidUrlMessage extends Event {
            public final String message;

            public ShowInvalidUrlMessage(String message) {
                this.message = message;
            }
        }
    }

}