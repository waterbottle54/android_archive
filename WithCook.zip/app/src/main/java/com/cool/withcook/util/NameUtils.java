package com.cool.withcook.util;

import android.content.res.Resources;

import com.cool.withcook.R;
import com.cool.withcook.data.Category;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class NameUtils {

    public static String getCategoryName(Resources resources, Category category) {
        switch (category) {
            case KOREAN: return resources.getString(R.string.korean_food);
            case JAPANESE: return resources.getString(R.string.japanese_food);
            case CHINESE: return resources.getString(R.string.chinese_food);
            case WESTERN: return resources.getString(R.string.western_food);
            case FAST_FOOD: return resources.getString(R.string.fast_food);
        }
        return "";
    }

    public static List<String> getCategoryNames(Resources resources) {
        return Arrays.stream(Category.values())
                .map(category -> NameUtils.getCategoryName(resources, category))
                .collect(Collectors.toList());
    }

    public static Map<String, Category> getCategoryMap(Resources resources) {
        Map<String, Category> categoryMap = new HashMap<>();
        for (Category category : Category.values()) {
            String categoryName = NameUtils.getCategoryName(resources, category);
            categoryMap.put(categoryName, category);
        }
        return categoryMap;
    }


}
