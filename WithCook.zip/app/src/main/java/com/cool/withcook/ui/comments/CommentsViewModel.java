package com.cool.withcook.ui.comments;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.cool.withcook.data.comment.Comment;
import com.cool.withcook.data.comment.CommentRepository;
import com.cool.withcook.data.detailedcomment.DetailedComment;
import com.cool.withcook.data.detailedcomment.DetailedCommentRepository;
import com.cool.withcook.data.detailedrecipe.DetailedRecipe;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class CommentsViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String userId;

    private final DetailedRecipe recipe;

    private String content = "";

    private LiveData<List<DetailedComment>> comments;

    private CommentRepository commentRepository;


    @Inject
    public CommentsViewModel(SavedStateHandle savedStateHandle,
                             DetailedCommentRepository detailedCommentRepository,
                             CommentRepository commentRepository) {

        recipe = savedStateHandle.get("recipe");

        assert recipe != null;
        comments = detailedCommentRepository.getDetailedComment(recipe.getId());

        this.commentRepository = commentRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<DetailedComment>> getComments() {
        return comments;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId = firebaseAuth.getCurrentUser().getUid();
        }
    }

    public void onCommentChange(String text) {
        this.content = text;
    }

    public void onSubmitClick() {

        if (content.trim().isEmpty()) {
            return;
        }

        if (userId == null) {
            return;
        }

        Comment comment = new Comment(recipe.getId(), userId, content);
        commentRepository.addComment(comment,
                unused -> {
                },
                e -> {
                });
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }
    }

}