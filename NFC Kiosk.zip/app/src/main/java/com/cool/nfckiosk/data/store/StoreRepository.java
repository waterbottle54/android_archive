package com.cool.nfckiosk.data.store;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import javax.inject.Inject;

public class StoreRepository {

    private final CollectionReference storeCollection;

    @Inject
    public StoreRepository(FirebaseFirestore firestore) {
        storeCollection = firestore.collection("stores");
    }

    public LiveData<Store> getStore(String userId) {
        MutableLiveData<Store> store = new MutableLiveData<>();
        storeCollection.whereEqualTo("adminId", userId).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        DocumentSnapshot snapshot = queryDocumentSnapshots.getDocuments().get(0);
                        store.setValue(snapshot.toObject(Store.class));
                    }
                });
        return store;
    }


}
