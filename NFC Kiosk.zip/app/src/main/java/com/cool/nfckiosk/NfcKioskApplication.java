package com.cool.nfckiosk;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class NfcKioskApplication extends Application {
}
