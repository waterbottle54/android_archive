package com.penelope.seatforyou.utils;

public class AuthUtils {

    public static String emailize(String phone) {
        return phone + "@seatforu.com";
    }

}
