package com.penelope.seatforyou;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class SeatForYouApplication extends Application {
}
