package com.seventears.petsns.ui.chatbot;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.comment.Comment;
import com.seventears.petsns.data.comment.DetailedComment;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.data.user.UserRepository;
import com.seventears.petsns.util.TimeUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ChatBotViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> userId = new MutableLiveData<>();

    private final MutableLiveData<List<DetailedComment>> comments = new MutableLiveData<>(new ArrayList<>());

    private User user;

    private final UserRepository userRepository;

    @Inject
    public ChatBotViewModel(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<String> getUserId() {
        return userId;
    }

    public LiveData<List<DetailedComment>> getComments() {
        return comments;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            String id = firebaseAuth.getCurrentUser().getUid();
            userId.setValue(id);
            userRepository.getUser(id,
                    u -> {
                        if (user == null) {
                            user = u;
                            addBotMessage("안녕하세요");
                        } else {
                            user = u;
                        }
                    }
                    , e -> user = null
            );
        }
    }

    public void onSubmitMessage(String message) {

        if (addUserMessage(message)) {

            if (message.contains("안녕") || message.contains("반가워") || message.contains("ㅎㅇ")) {
                addBotMessage("안녕하세요. 무엇을 도와드릴까요?");
                return;
            }

            if (message.contains("시간") || message.contains("시각") || message.contains("몇시") || message.contains("몇 시")) {
                String strTime = TimeUtils.getTimeString(System.currentTimeMillis());
                String strMessage = String.format(Locale.getDefault(),
                        "현재 시간은 %s 입니다", strTime);
                addBotMessage(strMessage);
                return;
            }

            if (message.contains("날짜") || message.contains("며칠")) {
                String strTime = TimeUtils.getTimeString(System.currentTimeMillis());
                String strMessage = String.format(Locale.getDefault(),
                        "오늘 날짜는 %s 입니다", strTime);
                addBotMessage(strMessage);
                return;
            }

            if (message.contains("병원")) {
                addBotMessage("근처 동물병원 정보을 알려드리겠습니다");
                event.postValue(new Event.NavigateToHospitalScreen());
                return;
            }

            if (message.contains("팔로워")) {
                addBotMessage("팔로워 정보을 알려드리겠습니다");
                event.postValue(new Event.NavigateToFollowersScreen());
                return;
            }

            addBotMessage("무엇을 도와드릴까요?");
        }
    }


    private boolean addUserMessage(String message) {

        if (message.trim().isEmpty() || user == null) {
            Log.d("TAG", "addUserMessage: return");
            return false;
        }

        DetailedComment myComment = new DetailedComment(
                new Comment(user.getId() + "#0", user.getId(), message),
                user
        );

        List<DetailedComment> commentList = comments.getValue();
        assert commentList != null;

        commentList.add(myComment);
        comments.setValue(new ArrayList<>(commentList));

        return true;
    }

    private void addBotMessage(String message) {

        if (message.trim().isEmpty() || user == null) {
            return;
        }

        DetailedComment myComment = new DetailedComment(
                new Comment(user.getId() + "#0", "0", message),
                new User("0", "챗봇", true, 1000)
        );

        List<DetailedComment> commentList = comments.getValue();
        assert commentList != null;

        commentList.add(myComment);
        comments.setValue(new ArrayList<>(commentList));
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToHospitalScreen extends Event {
        }

        public static class NavigateToFollowersScreen extends Event {
        }
    }

}