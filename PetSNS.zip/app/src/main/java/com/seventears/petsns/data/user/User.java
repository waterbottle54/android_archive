package com.seventears.petsns.data.user;

import java.io.Serializable;
import java.util.Objects;

public class User implements Serializable {

    private String id;
    private String nickname;    // 닉네임
    private boolean isMale;     // 남성, 여성 여부
    private int age;            // 나이
    private long created;       // 가입 시간

    public User() {
    }

    public User(String id, String nickname, boolean isMale, int age) {
        this.id = id;
        this.nickname = nickname;
        this.isMale = isMale;
        this.age = age;
        this.created = System.currentTimeMillis();
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setMale(boolean male) {
        isMale = male;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public String getId() {
        return id;
    }

    public String getNickname() {
        return nickname;
    }

    public boolean isMale() {
        return isMale;
    }

    public int getAge() {
        return age;
    }

    public long getCreated() {
        return created;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return isMale == user.isMale && age == user.age && created == user.created && id.equals(user.id) && nickname.equals(user.nickname);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nickname, isMale, age, created);
    }
}
