package com.seventears.petsns.ui.profile;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.image.ImageRepository;
import com.seventears.petsns.data.user.User;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ProfileViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String nickname;
    private final boolean isMale;
    private final int age;
    private final LiveData<Bitmap> profileImage;


    @Inject
    public ProfileViewModel(SavedStateHandle savedStateHandle, ImageRepository imageRepository) {

        User user = savedStateHandle.get("user");
        assert user != null;

        nickname = user.getNickname();
        isMale = user.isMale();
        age = user.getAge();
        profileImage = imageRepository.getProfileImageLiveData(user.getId());
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getNickname() {
        return nickname;
    }

    public boolean isMale() {
        return isMale;
    }

    public int getAge() {
        return age;
    }

    public LiveData<Bitmap> getProfileImage() {
        return profileImage;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }


    public static class Event {
        public static class NavigateBack extends Event {
        }
    }

}