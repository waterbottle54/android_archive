package com.seventears.petsns.ui.follower.addfollower;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.image.ImageRepository;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.data.user.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class AddFollowerViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> userId = new MutableLiveData<>();

    private final LiveData<List<User>> users;
    private final LiveData<Map<String, Bitmap>> album;

    private final UserRepository userRepository;


    @Inject
    public AddFollowerViewModel(UserRepository userRepository,
                                ImageRepository imageRepository) {

        LiveData<List<User>> allUsers = userRepository.getUsersLiveData();
        LiveData<List<String>> followers = Transformations.switchMap(userId, userRepository::getFollowers);

        users = Transformations.switchMap(userId, id ->
                Transformations.switchMap(followers, followerList ->
                        Transformations.map(allUsers, allUserList -> {
                            List<User> userList = new ArrayList<>();
                            for (User user : allUserList) {
                                if (user.getId().equals(id) || followerList.contains(user.getId())) {
                                    continue;
                                }
                                userList.add(user);
                            }
                            return userList;
                        }))
        );

        album = Transformations.switchMap(users, userList -> {
            List<String> idList = userList.stream()
                    .map(User::getId)
                    .collect(Collectors.toList());
            return imageRepository.getProfileAlbum(idList);
        });

        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<User>> getUsers() {
        return users;
    }

    public LiveData<Map<String, Bitmap>> getAlbum() {
        return album;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId.setValue(firebaseAuth.getCurrentUser().getUid());
        }
    }

    public void onUserClick(User user) {

        String userIdValue = userId.getValue();
        if (userIdValue == null) {
            return;
        }

        userRepository.addFollower(userIdValue, user.getId(), unused ->
                event.setValue(new Event.ShowGeneralMessage(user.getNickname() + "님이 추가되었습니다"))
        );
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }
    }

}