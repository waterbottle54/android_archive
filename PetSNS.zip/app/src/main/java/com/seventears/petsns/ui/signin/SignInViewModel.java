package com.seventears.petsns.ui.signin;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.data.user.UserRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SignInViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final UserRepository userRepository;


    @Inject
    public SignInViewModel(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() != null) {
            String id = firebaseAuth.getCurrentUser().getUid();
            userRepository.getUser(id, user -> {
                        if (user != null) {
                            event.setValue(new Event.NavigateToHomeScreen());
                            return;
                        }
                        User newUser = new User(id, id.substring(0, 5), true, 20);
                        userRepository.addUser(newUser,
                                unused -> event.setValue(new Event.NavigateToHomeScreen()),
                                e -> {
                                }
                        );
                    }, e -> {
                    }
            );
        }
    }

    public void onSignInClick() {
        event.setValue(new Event.SignIn());
    }


    public static class Event {

        public static class SignIn extends Event {
        }

        public static class NavigateToHomeScreen extends Event {
        }
    }

}