package com.seventears.petsns.ui.hospital;

import android.location.Location;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.hospital.Hospital;
import com.seventears.petsns.data.hospital.HospitalRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HospitalViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<Location> lastLocation = new MutableLiveData<>();
    private final LiveData<List<Hospital>> hospitals;

    // 앵커 로케이션 : 데이터를 마지막으로 업데이트 한 로케이션
    // 현재 로케이션이 앵커로부터 일정 거리 이상 벗어나면 데이터를 다시 업데이트한다
    private Location anchorLocation;


    @Inject
    public HospitalViewModel(HospitalRepository hospitalRepository) {

        hospitals = Transformations.switchMap(lastLocation, location ->
                hospitalRepository.getHospitals(location.getLatitude(), location.getLongitude(), 2000));
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Hospital>> getHospitals() {
        return hospitals;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }

    public void onLocationChange(Location location) {

        // 위치가 100m 이상 변경되었거나 또는 위치가 처음으로 설정될 때, lastLocation 를 변경한다
        if (anchorLocation == null || location.distanceTo(anchorLocation) > 100) {
            anchorLocation = location;
            lastLocation.setValue(location);
            event.setValue(new Event.ShowProgressBar());
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowProgressBar extends Event {
        }
    }

}