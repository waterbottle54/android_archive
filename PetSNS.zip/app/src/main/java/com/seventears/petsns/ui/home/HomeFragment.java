package com.seventears.petsns.ui.home;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentHomeBinding;
import com.seventears.petsns.services.NoticeService;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeFragment extends AuthFragment {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;


    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                viewModel.onBackClick();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentHomeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding.cardFunction.setOnClickListener(v -> viewModel.onFunctionClick());
        binding.cardSns.setOnClickListener(v -> viewModel.onSnsClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof HomeViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof HomeViewModel.Event.ConfirmSignOut) {
                String message = ((HomeViewModel.Event.ConfirmSignOut)event).message;
                showConfirmSignOutDialog(message);
            } else if (event instanceof HomeViewModel.Event.StartNoticeService) {
                String userId = ((HomeViewModel.Event.StartNoticeService) event).userId;
                if (!isServiceRunning(NoticeService.class)) {
                    startChatNotificationService(userId);
                }
            } else if (event instanceof HomeViewModel.Event.NavigateToFunctionScreen) {
                NavDirections action = HomeFragmentDirections.actionHomeFragmentToFunctionFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof HomeViewModel.Event.NavigateToSnsScreen) {
                NavDirections action = HomeFragmentDirections.actionHomeFragmentToSnsFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });

        setHasOptionsMenu(true);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int itemId = item.getItemId();

        if (itemId == android.R.id.home) {
            viewModel.onBackClick();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showConfirmSignOutDialog(String message) {
        new AlertDialog.Builder(context)
                .setTitle("로그아웃")
                .setMessage(message)
                .setPositiveButton("네", (dialog, which) -> viewModel.onSignOutConfirmed())
                .setNegativeButton("아니오", null)
                .show();
    }


    private void startChatNotificationService(String userId) {
        // 서비스 시작
        Intent serviceIntent = new Intent(requireContext(), NoticeService.class);
        serviceIntent.putExtra(NoticeService.EXTRA_USER_ID, userId);
        requireContext().startService(serviceIntent);
    }

    private boolean isServiceRunning(Class<?> serviceClass) {
        // 서비스 가동여부 확인
        ActivityManager manager = (ActivityManager) requireContext().getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

}