package com.seventears.petsns.ui.follower.addfollower;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.databinding.FragmentAddFollowerBinding;
import com.seventears.petsns.ui.follower.followers.UsersAdapter;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class AddFollowerFragment extends AuthFragment {

    private FragmentAddFollowerBinding binding;
    private AddFollowerViewModel viewModel;


    public AddFollowerFragment() {
        super(R.layout.fragment_add_follower);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentAddFollowerBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(AddFollowerViewModel.class);

        viewModel.getAlbum().observe(getViewLifecycleOwner(), album -> {

            UsersAdapter adapter = new UsersAdapter(Glide.with(this), album);
            binding.recyclerUser.setAdapter(adapter);
            binding.recyclerUser.setHasFixedSize(true);

            adapter.setOnItemSelectedListener(position -> {
                User follower = adapter.getCurrentList().get(position);
                viewModel.onUserClick(follower);
            });

            viewModel.getUsers().observe(getViewLifecycleOwner(), users -> {
                adapter.submitList(users);
                binding.progressBar.setVisibility(View.INVISIBLE);
                binding.textViewNoUsers.setVisibility(users.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            });
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof AddFollowerViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof AddFollowerViewModel.Event.ShowGeneralMessage) {
                String message = ((AddFollowerViewModel.Event.ShowGeneralMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}