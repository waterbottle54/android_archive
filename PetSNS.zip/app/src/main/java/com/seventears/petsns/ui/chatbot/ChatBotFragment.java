package com.seventears.petsns.ui.chatbot;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentChatBotBinding;
import com.seventears.petsns.ui.chat.CommentsAdapter;
import com.seventears.petsns.util.AuthFragment;
import com.stfalcon.chatkit.messages.MessageInput;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ChatBotFragment extends AuthFragment implements
        MessageInput.InputListener,
        MessageInput.TypingListener {

    private FragmentChatBotBinding binding;
    private ChatBotViewModel viewModel;

    private CommentsAdapter commentsAdapter;


    public ChatBotFragment() {
        super(R.layout.fragment_chat_bot);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentChatBotBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ChatBotViewModel.class);

        binding.input.setInputListener(this);

        viewModel.getUserId().observe(getViewLifecycleOwner(), id -> {
            commentsAdapter = new CommentsAdapter(id,
                    BitmapFactory.decodeResource(getResources(), R.drawable.ic_bot));
            binding.recyclerComment.setAdapter(commentsAdapter);
            binding.recyclerComment.setHasFixedSize(true);
        });

        viewModel.getComments().observe(getViewLifecycleOwner(), comments -> {
            if (commentsAdapter != null) {
                commentsAdapter.submitList(comments);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ChatBotViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof ChatBotViewModel.Event.NavigateToHospitalScreen) {
                requireView().postDelayed(() -> {
                    NavDirections action = ChatBotFragmentDirections.actionGlobalHospitalFragment();
                    Navigation.findNavController(requireView()).navigate(action);
                }, 1000);
            } else if (event instanceof ChatBotViewModel.Event.NavigateToFollowersScreen) {
                requireView().postDelayed(() -> {
                    NavDirections action = ChatBotFragmentDirections.actionGlobalFollowersFragment();
                    Navigation.findNavController(requireView()).navigate(action);
                }, 1000);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public boolean onSubmit(CharSequence input) {
        viewModel.onSubmitMessage(input.toString());
        hideKeyboard(requireView());
        return true;
    }

    @Override
    public void onStartTyping() {

    }

    @Override
    public void onStopTyping() {

    }

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}