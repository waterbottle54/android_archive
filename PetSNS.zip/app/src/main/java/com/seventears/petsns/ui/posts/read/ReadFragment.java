package com.seventears.petsns.ui.posts.read;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentReadBinding;
import com.seventears.petsns.util.AuthFragment;
import com.seventears.petsns.util.TimeUtils;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ReadFragment extends AuthFragment {

    private FragmentReadBinding binding;
    private ReadViewModel viewModel;


    public ReadFragment() {
        super(R.layout.fragment_read);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentReadBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ReadViewModel.class);

        binding.textViewPostTitle.setText(viewModel.getTitle());
        binding.textViewPostContents.setText(viewModel.getContents());
        binding.textViewWriter.setText(viewModel.getNickname());

        String strDateTime = String.format(Locale.getDefault(), "%s, %s",
                TimeUtils.getDateString(viewModel.getCreated()),
                TimeUtils.getTimeString(viewModel.getCreated())
        );
        binding.textViewPostDate.setText(strDateTime);

        viewModel.getPostImage().observe(getViewLifecycleOwner(), postImage -> {
            binding.imageViewPost.setImageBitmap(postImage);
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getUserImage().observe(getViewLifecycleOwner(), userImage ->
                binding.imageViewWriterProfile.setImageBitmap(userImage));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ReadViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}