package com.seventears.petsns.ui.profile;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentProfileBinding;
import com.seventears.petsns.util.AuthFragment;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ProfileFragment extends AuthFragment {

    private FragmentProfileBinding binding;
    private ProfileViewModel viewModel;


    public ProfileFragment() {
        super(R.layout.fragment_profile);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentProfileBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        binding.textViewNickname.setText(viewModel.getNickname());
        binding.textViewGender.setText(viewModel.isMale() ? "남성" : "여성");

        String strAge = String.format(Locale.getDefault(), "%d세", viewModel.getAge());
        binding.textViewAge.setText(strAge);

        viewModel.getProfileImage().observe(getViewLifecycleOwner(), profileImage -> {
            binding.imageViewProfileImage.setImageBitmap(profileImage);
            binding.progressBarProfile.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ProfileViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}