package com.seventears.petsns.ui.posts.posts;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.seventears.petsns.data.detailedpost.DetailedPost;
import com.seventears.petsns.databinding.PostItemBinding;
import com.seventears.petsns.util.TimeUtils;

import java.util.Map;

public class DetailedPostsAdapter extends ListAdapter<DetailedPost, DetailedPostsAdapter.DetailedPostViewHolder> {

    class DetailedPostViewHolder extends RecyclerView.ViewHolder {

        private final PostItemBinding binding;

        public DetailedPostViewHolder(PostItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(DetailedPost model) {

            binding.textViewPostTitle.setText(model.getTitle());
            binding.textViewPostWriter.setText(model.getWriter().getNickname());

            String strDate = TimeUtils.getDateString(TimeUtils.getLocalDate(model.getCreated()));
            binding.textViewDate.setText(strDate);

            String strTime = TimeUtils.getTimeString(model.getCreated());
            binding.textViewTime.setText(strTime);

            // Set images
            Bitmap postImage = postAlbum.get(model.getId());
            binding.imageViewPost.setImageBitmap(postImage);

            Bitmap userImage = userAlbum.get(model.getWriterId());
            binding.imageViewWriterProfile.setImageBitmap(userImage);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;

    private final Map<String, Bitmap> postAlbum;
    private final Map<String, Bitmap> userAlbum;


    public DetailedPostsAdapter(Map<String, Bitmap> postAlbum, Map<String, Bitmap> userAlbum) {
        super(new DiffUtilCallback());
        this.postAlbum = postAlbum;
        this.userAlbum = userAlbum;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public DetailedPostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        PostItemBinding binding = PostItemBinding.inflate(layoutInflater, parent, false);
        return new DetailedPostViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DetailedPostViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<DetailedPost> {

        @Override
        public boolean areItemsTheSame(@NonNull DetailedPost oldItem, @NonNull DetailedPost newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull DetailedPost oldItem, @NonNull DetailedPost newItem) {
            return oldItem.equals(newItem);
        }
    }

}