package com.seventears.petsns.ui.home;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HomeViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final FirebaseAuth auth = FirebaseAuth.getInstance();


    @Inject
    public HomeViewModel() {

    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            event.setValue(new Event.StartNoticeService(firebaseAuth.getCurrentUser().getUid()));
        }
    }

    public void onBackClick() {
        event.setValue(new Event.ConfirmSignOut("로그아웃 하시겠습니까?"));
    }

    public void onSignOutConfirmed() {
        auth.signOut();
    }

    public void onFunctionClick() {
        event.setValue(new Event.NavigateToFunctionScreen());
    }

    public void onSnsClick() {
        event.setValue(new Event.NavigateToSnsScreen());
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToFunctionScreen extends Event {
        }

        public static class NavigateToSnsScreen extends Event {
        }

        public static class ConfirmSignOut extends Event {
            public final String message;
            public ConfirmSignOut(String message) {
                this.message = message;
            }
        }

        public static class StartNoticeService extends Event {
            public final String userId;
            public StartNoticeService(String userId) {
                this.userId = userId;
            }
        }
    }

}