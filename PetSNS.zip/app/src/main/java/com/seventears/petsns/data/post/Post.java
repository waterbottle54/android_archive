package com.seventears.petsns.data.post;

import java.io.Serializable;
import java.util.Objects;

public class Post implements Serializable {

    private String id;
    private String writerId;
    private String title;
    private String content;
    private long created;

    public Post() {
    }

    public Post(String writerId, String title, String content) {
        this.writerId = writerId;
        this.title = title;
        this.content = content;
        this.created = System.currentTimeMillis();
        this.id = writerId + "#" + created;
    }

    public Post(Post other) {
        this.id = other.id;
        this.writerId = other.writerId;
        this.title = other.title;
        this.content = other.content;
        this.created = other.created;
    }

    public String getId() {
        return id;
    }

    public String getWriterId() {
        return writerId;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public long getCreated() {
        return created;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setWriterId(String writerId) {
        this.writerId = writerId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Post post = (Post) o;
        return created == post.created && id.equals(post.id) && writerId.equals(post.writerId) && title.equals(post.title) && content.equals(post.content);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, writerId, title, content, created);
    }

}
