package com.seventears.petsns.ui.posts.upload;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.post.Post;
import com.seventears.petsns.data.image.ImageRepository;
import com.seventears.petsns.data.post.PostRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class UploadViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String userId;

    private String title = "";
    private String contents = "";
    private final MutableLiveData<Bitmap> image = new MutableLiveData<>();

    private final PostRepository postRepository;
    private final ImageRepository imageRepository;


    @Inject
    public UploadViewModel(PostRepository postRepository, ImageRepository imageRepository) {
        this.postRepository = postRepository;
        this.imageRepository = imageRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId = firebaseAuth.getCurrentUser().getUid();
        }
    }

    public void onTitleChanged(String text) {
        this.title = text;
    }

    public void onContentsChanged(String text) {
        this.contents = text;
    }

    public void onImageUploadClick() {

        event.setValue(new Event.PrompImage());
    }

    public void onImageChanged(Bitmap bitmap) {
        if (bitmap != null) {
            image.setValue(bitmap);
        } else {
            event.setValue(new Event.ShowImageSelectFailureMessage("이미지 업로드에 실패했습니다"));
        }
    }

    public void onSubmitClick() {

        if (title.trim().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("제목을 입력해주세요"));
            return;
        }

        if (contents.trim().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("내용을 입력해주세요"));
            return;
        }

        Post post = new Post(userId, title, contents);

        postRepository.addPost(post,
                unused -> {
                    if (image.getValue() != null) {
                        imageRepository.addPostImage(post.getId(), image.getValue(),
                                unused1 -> event.setValue(new Event.NavigateBackWithResult(true)),
                                e -> {
                                }
                        );
                    } else {
                        event.setValue(new Event.NavigateBackWithResult(true));
                    }
                });
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class PrompImage extends Event {
        }

        public static class ShowImageSelectFailureMessage extends Event {
            public final String message;

            public ShowImageSelectFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowInvalidInputMessage extends Event {
            public final String message;

            public ShowInvalidInputMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;

            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }
    }

}