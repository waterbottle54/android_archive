package com.seventears.petsns.ui.follower.followers;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.databinding.UserItemBinding;
import com.seventears.petsns.util.TimeUtils;

import java.time.LocalDate;
import java.util.Locale;
import java.util.Map;

public class UsersAdapter extends ListAdapter<User, UsersAdapter.UserViewHolder> {

    class UserViewHolder extends RecyclerView.ViewHolder {

        private final UserItemBinding binding;

        public UserViewHolder(UserItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(User model) {
            binding.textViewNickname.setText(model.getNickname());

            String strAgeGender = String.format(Locale.getDefault(),
                    "%d세, %s",
                    model.getAge(),
                    model.isMale() ? "남성" : "여성"
            );
            binding.textViewAgeGender.setText(strAgeGender);

            LocalDate date = TimeUtils.getLocalDate(model.getCreated());
            String strDate = String.format(Locale.getDefault(),
                    "%s 가입",
                    TimeUtils.getDateString(date)
            );
            binding.textViewDateSignedUp.setText(strDate);

            Bitmap image = album.get(model.getId());
            glide.load(image)
                    .skipMemoryCache(true)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .into(binding.imageViewProfile);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final RequestManager glide;
    private final Map<String, Bitmap> album;


    public UsersAdapter(RequestManager glide, Map<String, Bitmap> album) {
        super(new DiffUtilCallback());
        this.glide = glide;
        this.album = album;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        UserItemBinding binding = UserItemBinding.inflate(layoutInflater, parent, false);
        return new UserViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<User> {

        @Override
        public boolean areItemsTheSame(@NonNull User oldItem, @NonNull User newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull User oldItem, @NonNull User newItem) {
            return oldItem.equals(newItem);
        }
    }

}