package com.seventears.petsns.ui.posts.searchuser;

import android.graphics.Bitmap;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.image.ImageRepository;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.data.user.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SearchUserViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> userId = new MutableLiveData<>();

    private final MutableLiveData<String> query = new MutableLiveData<>("");

    private final LiveData<List<User>> users;
    private final LiveData<Map<String, Bitmap>> album;


    @Inject
    public SearchUserViewModel(UserRepository userRepository,
                               ImageRepository imageRepository) {

        LiveData<List<User>> allUsers = userRepository.getUsersLiveData();

        users = Transformations.switchMap(userId, id ->
                Transformations.switchMap(query, queryString ->
                        Transformations.map(allUsers, allUserList -> {
                            Log.d("TAG", "SearchUserViewModel: ");
                            List<User> userList = new ArrayList<>();
                            for (User user : allUserList) {
                                if (user.getId().equals(id)) {
                                    continue;
                                }
                                if (queryString.equals("")) {
                                    userList.add(user);
                                } else if (user.getNickname().toLowerCase()
                                        .contains(queryString.toLowerCase())) {
                                    userList.add(user);
                                }
                            }
                            return userList;
                        })
                )
        );

        album = Transformations.switchMap(users, userList -> {
            List<String> idList = userList.stream()
                    .map(User::getId)
                    .collect(Collectors.toList());
            return imageRepository.getProfileAlbum(idList);
        });
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<User>> getUsers() {
        return users;
    }

    public LiveData<Map<String, Bitmap>> getAlbum() {
        return album;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId.setValue(firebaseAuth.getCurrentUser().getUid());
        }
    }

    public void onUserClick(User user) {
        event.setValue(new Event.NavigateToProfileScreen(user));
    }

    public void onSearchClick(String query) {
        this.query.setValue(query);
        Log.d("TAG", "onSearchClick: ");
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToProfileScreen extends Event {
            public final User user;

            public NavigateToProfileScreen(User user) {
                this.user = user;
            }
        }
    }

}