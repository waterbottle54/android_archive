package com.seventears.petsns.ui.hospital;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.data.hospital.Hospital;
import com.seventears.petsns.databinding.FragmentHospitalBinding;
import com.seventears.petsns.util.AuthFragment;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.LocationTrackingMode;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.OverlayImage;
import com.naver.maps.map.util.FusedLocationSource;

import java.util.ArrayList;
import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HospitalFragment extends AuthFragment implements OnMapReadyCallback, NaverMap.OnLocationChangeListener {

    public static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    private FragmentHospitalBinding binding;
    private HospitalViewModel viewModel;

    private NaverMap map;
    private final List<Marker> markers = new ArrayList<>();

    private FusedLocationSource fusedLocationSource;
    private ActivityResultLauncher<String> locationPermissionLauncher;


    public HospitalFragment() {
        super(R.layout.fragment_hospital);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        fusedLocationSource = new FusedLocationSource(this, LOCATION_PERMISSION_REQUEST_CODE);

        // 위치 퍼미션 런처 정의
        locationPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                result -> {
                    if (fusedLocationSource.onRequestPermissionsResult(
                            LOCATION_PERMISSION_REQUEST_CODE,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            new int[]{result ? PackageManager.PERMISSION_GRANTED : PackageManager.PERMISSION_DENIED}
                    )) {
                        if (!fusedLocationSource.isActivated()) {
                            map.setLocationTrackingMode(LocationTrackingMode.None);
                            return;
                        }
                        configureMap();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentHospitalBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HospitalViewModel.class);

        // 네이버 맵 획득
        MapFragment mapFragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
        assert mapFragment != null;

        viewModel.getHospitals().observe(getViewLifecycleOwner(), hospitals -> {
            if (hospitals != null) {
                updateMarkers(hospitals);
            }
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof HospitalViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof HospitalViewModel.Event.ShowProgressBar) {
                binding.progressBar.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {

        map = naverMap;

        if (requireContext().checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            configureMap();
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    private void configureMap() {

        map.addOnLocationChangeListener(this);
        map.setLocationSource(fusedLocationSource);
        map.setLocationTrackingMode(LocationTrackingMode.Follow);
        map.getUiSettings().setLocationButtonEnabled(true);

        map.moveCamera(CameraUpdate.zoomTo(15));
    }

    @Override
    public void onLocationChange(@NonNull Location location) {
        viewModel.onLocationChange(location);
    }

    private void updateMarkers(List<Hospital> hospitals) {

        // 기존 마커 제거
        for (Marker marker : markers) {
            marker.setMap(null);
        }
        markers.clear();

        // 각 동물병원에 대응되는 마커 설치
        for (Hospital hospital : hospitals) {
            LatLng latLng = new LatLng(hospital.getLatitude(), hospital.getLongitude());
            Marker marker = new Marker(latLng);
            marker.setCaptionText(hospital.getPlaceName());
            marker.setIcon(OverlayImage.fromResource(R.drawable.ic_hospital_red));
            marker.setMap(map);

            // 마커가 클릭될 시 뷰모델에 통보
            marker.setOnClickListener(overlay -> {
                //viewModel.onStationMarkerClick(hospital);
                return true;
            });

            markers.add(marker);
        }
    }

}