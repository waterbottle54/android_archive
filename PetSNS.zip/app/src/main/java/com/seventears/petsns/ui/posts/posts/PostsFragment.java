package com.seventears.petsns.ui.posts.posts;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.data.detailedpost.DetailedPost;
import com.seventears.petsns.databinding.FragmentPostsBinding;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PostsFragment extends AuthFragment {

    private FragmentPostsBinding binding;
    private PostsViewModel viewModel;


    public PostsFragment() {
        super(R.layout.fragment_posts);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPostsBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PostsViewModel.class);

        viewModel.getPostAlbum().observe(getViewLifecycleOwner(), postAlbum ->
                viewModel.getUserAlbum().observe(getViewLifecycleOwner(), userAlbum -> {

                    DetailedPostsAdapter adapter = new DetailedPostsAdapter(postAlbum, userAlbum);
                    binding.recyclerPost.setAdapter(adapter);
                    binding.recyclerPost.setHasFixedSize(true);

                    adapter.setOnItemSelectedListener(position -> {
                        DetailedPost post = adapter.getCurrentList().get(position);
                        viewModel.onPostClick(post);
                    });

                    viewModel.getPosts().observe(getViewLifecycleOwner(), posts -> {
                        if (posts != null) {
                            adapter.submitList(posts);
                            binding.textViewNoPosts.setVisibility(posts.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                        }
                        binding.progressBar.setVisibility(View.INVISIBLE);
                    });
                })
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PostsViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof PostsViewModel.Event.NavigateToReadScreen) {
                DetailedPost post = ((PostsViewModel.Event.NavigateToReadScreen) event).post;
                NavDirections action = PostsFragmentDirections.actionGlobalReadFragment(post);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}