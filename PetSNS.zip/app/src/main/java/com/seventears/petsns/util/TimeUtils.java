package com.seventears.petsns.util;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;

public class TimeUtils {

    public static LocalDate getLocalDate(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static String getDateString(LocalDate date) {

        int year = date.getYear();
        int month = date.getMonthValue();
        int dayOfMonth = date.getDayOfMonth();
        return String.format(Locale.getDefault(),
                "%d-%02d-%02d",
                year % 100, month, dayOfMonth
        );
    }

    public static String getDateString(long millis) {
        return getDateString(getLocalDate(millis));
    }


    public static String getTimeString(long millis) {

        LocalDateTime localDate = Instant.ofEpochMilli(millis)
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();

        int hour = localDate.getHour();
        int minute = localDate.getMinute();
        boolean isMorning = hour < 12;

        return String.format(Locale.getDefault(), "%s %02d : %02d",
                isMorning ? "오전" : "오후",
                hour % 12,
                minute);
    }

}
