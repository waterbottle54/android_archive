package com.seventears.petsns.data.post;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class PostRepository {

    private final CollectionReference postsCollection;

    @Inject
    public PostRepository(FirebaseFirestore firestore) {

        postsCollection = firestore.collection("posts");
    }

    public LiveData<List<Post>> getPosts(List<String> userIdList) {

        MutableLiveData<List<Post>> posts = new MutableLiveData<>();

        postsCollection.orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (value == null || error != null) {
                        posts.setValue(null);
                        return;
                    }
                    List<Post> postList = new ArrayList<>();

                    for (DocumentSnapshot snapshot: value) {
                        Post post = snapshot.toObject(Post.class);
                        if (post != null && userIdList.contains(post.getWriterId())) {
                            postList.add(post);
                        }
                    }

                    posts.setValue(postList);
                });

        return posts;
    }

    public void addPost(Post post, OnSuccessListener<Void> onSuccessListener) {

        postsCollection.document(post.getId())
                .set(post)
                .addOnSuccessListener(onSuccessListener);
    }


}





