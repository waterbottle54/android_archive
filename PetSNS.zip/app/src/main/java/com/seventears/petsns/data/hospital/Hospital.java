package com.seventears.petsns.data.hospital;

public class Hospital {

    private final String id;
    private final String placeName;
    private final String categoryName;
    private final String phone;
    private final String roadAddressName;
    private final double longitude;
    private final double latitude;
    private final double distanceInMeters;

    public Hospital(String id, String placeName, String categoryName, String phone, String roadAddressName, double longitude, double latitude, double distanceInMeters) {
        this.id = id;
        this.placeName = placeName;
        this.categoryName = categoryName;
        this.phone = phone;
        this.roadAddressName = roadAddressName;
        this.longitude = longitude;
        this.latitude = latitude;
        this.distanceInMeters = distanceInMeters;
    }

    public String getId() {
        return id;
    }

    public String getPlaceName() {
        return placeName;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String getPhone() {
        return phone;
    }

    public String getRoadAddressName() {
        return roadAddressName;
    }

    public double getLongitude() {
        return longitude;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getDistanceInMeters() {
        return distanceInMeters;
    }
}
