package com.seventears.petsns.ui.posts.search;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.data.detailedpost.DetailedPost;
import com.seventears.petsns.databinding.FragmentSearchBinding;
import com.seventears.petsns.ui.posts.posts.DetailedPostsAdapter;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SearchFragment extends AuthFragment {

    private FragmentSearchBinding binding;
    private SearchViewModel viewModel;


    public SearchFragment() {
        super(R.layout.fragment_search);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSearchBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SearchViewModel.class);

        binding.fabSearch.setOnClickListener(v -> viewModel.onSearchClick());

        viewModel.getPostAlbum().observe(getViewLifecycleOwner(), postAlbum ->
                viewModel.getUserAlbum().observe(getViewLifecycleOwner(), userAlbum -> {

                    DetailedPostsAdapter adapter = new DetailedPostsAdapter(postAlbum, userAlbum);
                    binding.recyclerPost.setAdapter(adapter);
                    binding.recyclerPost.setHasFixedSize(true);

                    adapter.setOnItemSelectedListener(position -> {
                        DetailedPost post = adapter.getCurrentList().get(position);
                        viewModel.onPostClick(post);
                    });

                    viewModel.getPosts().observe(getViewLifecycleOwner(), posts -> {
                        if (posts != null) {
                            adapter.submitList(posts);
                            binding.textViewNoPosts.setVisibility(posts.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                        }
                        binding.progressBar.setVisibility(View.INVISIBLE);
                    });
                })
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SearchViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SearchViewModel.Event.NavigateToReadScreen) {
                DetailedPost post = ((SearchViewModel.Event.NavigateToReadScreen) event).post;
                NavDirections action = SearchFragmentDirections.actionGlobalReadFragment(post);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof SearchViewModel.Event.NavigateToSearchUserScreen) {
                NavDirections action = SearchFragmentDirections.actionSearchFragmentToSearchUserFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}