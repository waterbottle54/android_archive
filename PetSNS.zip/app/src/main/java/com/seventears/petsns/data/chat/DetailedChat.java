package com.seventears.petsns.data.chat;

import com.seventears.petsns.data.user.User;

import java.util.Objects;

public class DetailedChat extends Chat {

    private final User host;            // 호스트 유저
    private final User guest;           // 게스트 유저

    public DetailedChat(Chat chat, User host, User guest) {
        super(chat);
        this.host = host;
        this.guest = guest;
    }

    public User getHost() {
        return host;
    }

    public User getGuest() {
        return guest;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DetailedChat that = (DetailedChat) o;
        return host.equals(that.host) && guest.equals(that.guest);
    }

    @Override
    public int hashCode() {
        return Objects.hash(host, guest);
    }
}
