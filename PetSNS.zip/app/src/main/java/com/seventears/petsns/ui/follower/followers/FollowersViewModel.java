package com.seventears.petsns.ui.follower.followers;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.image.ImageRepository;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.data.user.UserRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class FollowersViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> userId = new MutableLiveData<>();

    private final LiveData<List<User>> followers;

    private final LiveData<Map<String, Bitmap>> album;


    @Inject
    public FollowersViewModel(UserRepository userRepository,
                              ImageRepository imageRepository) {

        LiveData<List<String>> followerIds = Transformations.switchMap(userId, userRepository::getFollowers);

        followers = Transformations.switchMap(followerIds, userRepository::getUsersLiveData);

        album = Transformations.switchMap(followers, userList -> {
            List<String> idList = userList.stream()
                    .map(User::getId)
                    .collect(Collectors.toList());
            return imageRepository.getProfileAlbum(idList);
        });
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<User>> getFollowers() {
        return followers;
    }

    public LiveData<Map<String, Bitmap>> getAlbum() {
        return album;
    }


    public void onFollowerClick(User follower) {

        String userIdValue = userId.getValue();
        if (userIdValue == null) {
            return;
        }

        boolean order = (userIdValue.compareTo(follower.getId()) > 0);
        String hostId = order ? userIdValue : follower.getId();
        String guestId = order ? follower.getId() : userIdValue;
        String chatId = hostId + "#" + guestId;

        event.setValue(new Event.NavigateToChatScreen(chatId, hostId, guestId, userIdValue));
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId.setValue(firebaseAuth.getCurrentUser().getUid());
        }
    }

    public void onAddFollowerClick() {
        event.setValue(new Event.NavigateToAddFollowerScreen());
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToChatScreen extends Event {
            public final String chatId;
            public final String hostId;
            public final String guestId;
            public final String userId;

            public NavigateToChatScreen(String chatId, String hostId, String guestId, String userId) {
                this.chatId = chatId;
                this.hostId = hostId;
                this.guestId = guestId;
                this.userId = userId;
            }
        }

        public static class NavigateToAddFollowerScreen extends Event { }
    }

}