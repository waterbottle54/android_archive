package com.seventears.petsns.ui.sns;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentSnsBinding;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SnsFragment extends AuthFragment {

    private FragmentSnsBinding binding;
    private SnsViewModel viewModel;


    public SnsFragment() {
        super(R.layout.fragment_sns);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSnsBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SnsViewModel.class);

        binding.cardFeed.setOnClickListener(v -> viewModel.onMyFeedClick());
        binding.cardUpload.setOnClickListener(v -> viewModel.onUploadClick());
        binding.cardHome.setOnClickListener(v -> viewModel.onPostsClick());
        binding.cardSearch.setOnClickListener(v -> viewModel.onSearchClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SnsViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SnsViewModel.Event.NavigateToMyFeedScreen) {
                NavDirections action = SnsFragmentDirections.actionSnsFragmentToFeedFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof SnsViewModel.Event.NavigateToUploadScreen) {
                NavDirections action = SnsFragmentDirections.actionSnsFragmentToUploadFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof SnsViewModel.Event.NavigateToPostsScreen) {
                NavDirections action = SnsFragmentDirections.actionSnsFragmentToPostsFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof SnsViewModel.Event.NavigateToSearchScreen) {
                NavDirections action = SnsFragmentDirections.actionSnsFragmentToSearchFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}