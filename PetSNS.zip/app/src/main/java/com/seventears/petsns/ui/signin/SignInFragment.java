package com.seventears.petsns.ui.signin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentSignInBinding;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SignInFragment extends AuthFragment {

    private FragmentSignInBinding binding;
    private SignInViewModel viewModel;

    private GoogleSignInOptions gso;
    private ActivityResultLauncher<Intent> signInLauncher;


    public SignInFragment() {
        super(R.layout.fragment_sign_in);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("558788338497-1g7r80914vrmlpdk4r3s8958d8lvc5rh.apps.googleusercontent.com")
                .requestEmail()
                .build();

        signInLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getData() != null) {
                        GoogleSignInResult signInResult = Auth.GoogleSignInApi.getSignInResultFromIntent(result.getData());
                        if (signInResult != null && signInResult.isSuccess()) {
                            GoogleSignInAccount account = signInResult.getSignInAccount();
                            if (account != null) {
                                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                                FirebaseAuth.getInstance().signInWithCredential(credential);
                            }
                        }
                    }
                });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSignInBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SignInViewModel.class);

        GoogleSignInClient googleSignInClient = GoogleSignIn.getClient(requireContext(), gso);

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SignInViewModel.Event.NavigateToHomeScreen) {
                NavDirections action = SignInFragmentDirections.actionSignInFragmentToHomeFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof SignInViewModel.Event.SignIn) {
                Intent signInIntent = googleSignInClient.getSignInIntent();
                signInLauncher.launch(signInIntent);
            }
        });

        binding.buttonSignIn.setOnClickListener(v -> viewModel.onSignInClick());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}