package com.seventears.petsns.ui.posts.posts;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.detailedpost.DetailedPostRepository;
import com.seventears.petsns.data.post.Post;
import com.seventears.petsns.data.image.ImageRepository;
import com.seventears.petsns.data.detailedpost.DetailedPost;
import com.seventears.petsns.data.user.UserRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PostsViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> userId = new MutableLiveData<>();

    private final LiveData<List<DetailedPost>> posts;

    private final LiveData<Map<String, Bitmap>> postAlbum;
    private final LiveData<Map<String, Bitmap>> userAlbum;


    @Inject
    public PostsViewModel(UserRepository userRepository,
                          DetailedPostRepository detailedPostRepository,
                          ImageRepository imageRepository) {

        LiveData<List<String>> followers = Transformations.switchMap(userId, userRepository::getFollowers);

        posts = Transformations.switchMap(followers, detailedPostRepository::getDetailedPosts);

        LiveData<List<String>> postIds = Transformations.map(posts, postList ->
                postList.stream().map(Post::getId).collect(Collectors.toList())
        );
        postAlbum = Transformations.switchMap(postIds, imageRepository::getPostAlbum);

        userAlbum = Transformations.switchMap(followers, imageRepository::getProfileAlbum);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<DetailedPost>> getPosts() {
        return posts;
    }

    public LiveData<Map<String, Bitmap>> getPostAlbum() {
        return postAlbum;
    }

    public LiveData<Map<String, Bitmap>> getUserAlbum() {
        return userAlbum;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            userId.setValue(firebaseAuth.getCurrentUser().getUid());
        }
    }

    public void onPostClick(DetailedPost post) {
        event.setValue(new Event.NavigateToReadScreen(post));
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToReadScreen extends Event {
            public final DetailedPost post;

            public NavigateToReadScreen(DetailedPost post) {
                this.post = post;
            }
        }
    }

}