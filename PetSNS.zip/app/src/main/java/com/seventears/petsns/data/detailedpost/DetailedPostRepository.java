package com.seventears.petsns.data.detailedpost;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.seventears.petsns.data.post.Post;
import com.seventears.petsns.data.post.PostRepository;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.data.user.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class DetailedPostRepository {

    private final PostRepository postRepository;
    private final UserRepository userRepository;

    @Inject
    public DetailedPostRepository(PostRepository postRepository, UserRepository userRepository) {
        this.postRepository = postRepository;
        this.userRepository = userRepository;
    }

    public LiveData<List<DetailedPost>> getDetailedPosts(List<String> userId) {
        LiveData<List<Post>> posts = postRepository.getPosts(userId);
        LiveData<Map<String, User>> usersMap = userRepository.getUsersMap();
        return Transformations.switchMap(posts, postList ->
                Transformations.map(usersMap, map -> {
                    List<DetailedPost> detailedPostList = new ArrayList<>();
                    for (Post post : postList) {
                        User writer = map.get(post.getWriterId());
                        detailedPostList.add(new DetailedPost(post, writer));
                    }
                    return detailedPostList;
                })
        );
    }

}
