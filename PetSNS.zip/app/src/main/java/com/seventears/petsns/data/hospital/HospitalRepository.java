package com.seventears.petsns.data.hospital;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.seventears.petsns.api.hospital.HospitalApi;

import java.util.List;

import javax.inject.Inject;

public class HospitalRepository {

    @Inject
    public HospitalRepository() {

    }

    public LiveData<List<Hospital>> getHospitals(double latitude, double longitude, double radius) {

        MutableLiveData<List<Hospital>> hospitals = new MutableLiveData<>();

        new Thread(() -> {
            HospitalApi api = new HospitalApi();
            List<Hospital> hospitalList = null;
            List<Hospital> subList;
            for (int page = 1;; page++) {
                subList = api.getHospitals(page, "동물병원", latitude, longitude, radius);
                if (subList != null) {
                    if (hospitalList == null) {
                        hospitalList = subList;
                    } else {
                        hospitalList.addAll(subList);
                    }
                }
                if (subList == null || subList.isEmpty()) {
                    break;
                }
            }
            hospitals.postValue(hospitalList);
        }).start();

        return hospitals;
    }

}
