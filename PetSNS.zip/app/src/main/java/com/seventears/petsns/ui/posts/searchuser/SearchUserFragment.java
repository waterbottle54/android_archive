package com.seventears.petsns.ui.posts.searchuser;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SearchView;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.databinding.FragmentSearchUserBinding;
import com.seventears.petsns.ui.follower.followers.UsersAdapter;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SearchUserFragment extends AuthFragment {

    private FragmentSearchUserBinding binding;
    private SearchUserViewModel viewModel;


    public SearchUserFragment() {
        super(R.layout.fragment_search_user);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSearchUserBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SearchUserViewModel.class);

        binding.searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                viewModel.onSearchClick(newText);
                return true;
            }
        });

        viewModel.getAlbum().observe(getViewLifecycleOwner(), album -> {

            UsersAdapter adapter = new UsersAdapter(Glide.with(this), album);
            binding.recyclerUser.setAdapter(adapter);
            binding.recyclerUser.setHasFixedSize(true);

            adapter.setOnItemSelectedListener(position -> {
                User follower = adapter.getCurrentList().get(position);
                viewModel.onUserClick(follower);
            });

            viewModel.getUsers().observe(getViewLifecycleOwner(), users -> {
                adapter.submitList(users);
                binding.progressBar.setVisibility(View.INVISIBLE);
                binding.textViewNoUsers.setVisibility(users.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            });
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SearchUserViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SearchUserViewModel.Event.NavigateToProfileScreen) {
                User user = ((SearchUserViewModel.Event.NavigateToProfileScreen) event).user;
                NavDirections action = SearchUserFragmentDirections.actionGlobalProfileFragment(user);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}