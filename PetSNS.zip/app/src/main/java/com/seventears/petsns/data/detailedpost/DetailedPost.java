package com.seventears.petsns.data.detailedpost;

import com.seventears.petsns.data.post.Post;
import com.seventears.petsns.data.user.User;

import java.util.Objects;

public class DetailedPost extends Post {

    private final User writer;

    public DetailedPost(Post other, User writer) {
        super(other);
        this.writer = writer;
    }

    public User getWriter() {
        return writer;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        DetailedPost that = (DetailedPost) o;
        return writer.equals(that.writer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), writer);
    }
}
