package com.seventears.petsns.ui.feed.feed;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.common.collect.Lists;
import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.detailedpost.DetailedPost;
import com.seventears.petsns.data.detailedpost.DetailedPostRepository;
import com.seventears.petsns.data.image.ImageRepository;
import com.seventears.petsns.data.post.Post;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.data.user.UserRepository;
import com.seventears.petsns.ui.MainActivity;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class FeedViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> userId = new MutableLiveData<>();

    private final LiveData<User> user;
    private final LiveData<String> nickname;
    private final LiveData<Boolean> isMale;
    private final LiveData<Integer> age;
    private final MutableLiveData<Bitmap> profileImage = new MutableLiveData<>();

    private final LiveData<List<DetailedPost>> posts;
    private final LiveData<Map<String, Bitmap>> postAlbum;
    private final LiveData<Map<String, Bitmap>> userAlbum;

    private final ImageRepository imageRepository;


    @Inject
    public FeedViewModel(UserRepository userRepository,
                         DetailedPostRepository detailedPostRepository,
                         ImageRepository imageRepository) {

        user = Transformations.switchMap(userId, userRepository::getUserLiveData);
        nickname = Transformations.map(user, User::getNickname);
        isMale = Transformations.map(user, User::isMale);
        age = Transformations.map(user, User::getAge);

        posts = Transformations.switchMap(userId, id ->
                detailedPostRepository.getDetailedPosts(Lists.newArrayList(id))
        );

        LiveData<List<String>> postIds = Transformations.map(posts, postList ->
                postList.stream().map(Post::getId).collect(Collectors.toList())
        );
        postAlbum = Transformations.switchMap(postIds, imageRepository::getPostAlbum);

        userAlbum = Transformations.switchMap(userId, id ->
                imageRepository.getProfileAlbum(Lists.newArrayList(id))
        );

        this.imageRepository = imageRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<String> getNickname() {
        return nickname;
    }

    public LiveData<Boolean> isMale() {
        return isMale;
    }

    public LiveData<Integer> getAge() {
        return age;
    }

    public LiveData<Bitmap> getProfileImage() {
        return profileImage;
    }

    public LiveData<List<DetailedPost>> getPosts() {
        return posts;
    }

    public LiveData<Map<String, Bitmap>> getPostAlbum() {
        return postAlbum;
    }

    public LiveData<Map<String, Bitmap>> getUserAlbum() {
        return userAlbum;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            String id = firebaseAuth.getCurrentUser().getUid();
            userId.setValue(id);
            imageRepository.getProfileImage(id, profileImage::setValue, e -> profileImage.setValue(null));
        }
    }

    public void onEditProfileClick() {

        if (user.getValue() == null) {
            return;
        }

        event.setValue(new Event.NavigateToEditProfileScreen(user.getValue()));
    }

    public void onEditProfileResult(int result) {

        if (result == MainActivity.RESULT_EDIT_PROFILE_OK) {
            if (userId.getValue() != null) {
                imageRepository.getProfileImage(userId.getValue(), profileImage::setValue, e -> profileImage.setValue(null));
            }
            event.setValue(new Event.ShowProfileEditedMessage("프로필이 변경되었습니다"));
        }
    }

    public void onPostClick(DetailedPost post) {
        event.setValue(new Event.NavigateToReadScreen(post));
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToEditProfileScreen extends Event {
            public final User user;

            public NavigateToEditProfileScreen(User user) {
                this.user = user;
            }
        }

        public static class ShowProfileEditedMessage extends Event {
            public final String message;

            public ShowProfileEditedMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToReadScreen extends Event {
            public final DetailedPost post;

            public NavigateToReadScreen(DetailedPost post) {
                this.post = post;
            }
        }
    }

}