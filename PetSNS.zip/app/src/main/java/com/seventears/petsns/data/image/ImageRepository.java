package com.seventears.petsns.data.image;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class ImageRepository {

    private static final int MEGABYTES = 1024 * 1024;

    private final StorageReference profileImagesReference;
    private final StorageReference postImagesReference;


    @Inject
    public ImageRepository(StorageReference storageReference) {
        profileImagesReference = storageReference.child("profileImages");
        postImagesReference = storageReference.child("postImages");
    }

    public void getProfileImage(String userId,
                                OnSuccessListener<Bitmap> onSuccessListener,
                                OnFailureListener onFailureListener
    ) {
        // userId 로 검색된 이미지 획득

        profileImagesReference.child(userId + ".jpg")
                .getBytes(10 * MEGABYTES)
                .addOnSuccessListener(bytes -> {
                    Bitmap image = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    onSuccessListener.onSuccess(image);
                })
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<Bitmap> getProfileImageLiveData(String userId) {

        // getProfileImage 의 LiveData 버전

        MutableLiveData<Bitmap> bitmap = new MutableLiveData<>();
        getProfileImage(userId, bitmap::setValue, e -> bitmap.setValue(null));
        return bitmap;
    }

    public void addProfileImage(String userId, Bitmap bitmap,
                                OnSuccessListener<Void> onSuccessListener,
                                OnFailureListener onFailureListener
    ) {

        // userId 유저의 프로필 이미지 설정

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        profileImagesReference.child(userId + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }


    public LiveData<Map<String, Bitmap>> getProfileAlbum(List<String> idList) {

        // idList 에 포함된 유저들의 프로필 이미지 획득

        MutableLiveData<Map<String, Bitmap>> album = new MutableLiveData<>();
        Map<String, Bitmap> map = new HashMap<>();
        album.setValue(map);

        for (String id : idList) {
            getProfileImage(id,
                    bitmap -> {
                        if (bitmap != null) {
                            map.put(id, bitmap);
                            album.setValue(map);
                        }
                    },
                    e -> {
                    }
            );
        }

        return album;
    }



    public void getPostImage(String postId,
                                OnSuccessListener<Bitmap> onSuccessListener,
                                OnFailureListener onFailureListener
    ) {
        // userId 로 검색된 이미지 획득
        postImagesReference.child(postId + ".jpg")
                .getBytes(10 * MEGABYTES)
                .addOnSuccessListener(bytes -> {
                    Bitmap image = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    onSuccessListener.onSuccess(image);
                })
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<Bitmap> getPostImageLiveData(String userId) {

        // getProfileImage 의 LiveData 버전
        MutableLiveData<Bitmap> bitmap = new MutableLiveData<>();
        getPostImage(userId, bitmap::setValue, e -> bitmap.setValue(null));
        return bitmap;
    }

    public void addPostImage(String postId, Bitmap bitmap,
                                OnSuccessListener<Void> onSuccessListener,
                                OnFailureListener onFailureListener
    ) {

        // userId 유저의 프로필 이미지 설정

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        postImagesReference.child(postId + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<Map<String, Bitmap>> getPostAlbum(List<String> idList) {

        // idList 에 포함된 유저들의 프로필 이미지 획득

        MutableLiveData<Map<String, Bitmap>> album = new MutableLiveData<>();
        Map<String, Bitmap> map = new HashMap<>();
        album.setValue(map);

        for (String id : idList) {
            getPostImage(id,
                    bitmap -> {
                        if (bitmap != null) {
                            map.put(id, bitmap);
                            album.setValue(map);
                        }
                    },
                    e -> {
                    }
            );
        }

        return album;
    }

}






