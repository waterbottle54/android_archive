package com.seventears.petsns.ui.follower.followers;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.databinding.FragmentFollowersBinding;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class FollowersFragment extends AuthFragment {

    private FragmentFollowersBinding binding;
    private FollowersViewModel viewModel;


    public FollowersFragment() {
        super(R.layout.fragment_followers);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentFollowersBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(FollowersViewModel.class);

        binding.fabAddFollower.setOnClickListener(v -> viewModel.onAddFollowerClick());

        viewModel.getAlbum().observe(getViewLifecycleOwner(), album -> {

            UsersAdapter adapter = new UsersAdapter(Glide.with(this), album);
            binding.recyclerFollower.setAdapter(adapter);
            binding.recyclerFollower.setHasFixedSize(true);

            adapter.setOnItemSelectedListener(position -> {
                User follower = adapter.getCurrentList().get(position);
                viewModel.onFollowerClick(follower);
            });

            viewModel.getFollowers().observe(getViewLifecycleOwner(), users -> {
                adapter.submitList(users);
                binding.progressBar.setVisibility(View.INVISIBLE);
                binding.textViewNoFollowers.setVisibility(users.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            });
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof FollowersViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof FollowersViewModel.Event.NavigateToChatScreen) {
                FollowersViewModel.Event.NavigateToChatScreen e = (FollowersViewModel.Event.NavigateToChatScreen) event;
                NavDirections action = FollowersFragmentDirections.actionFollowersFragmentToChatFragment(
                        e.chatId, e.hostId, e.guestId, e.userId);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof FollowersViewModel.Event.NavigateToAddFollowerScreen) {
                NavDirections action = FollowersFragmentDirections.actionFollowersFragmentToAddFollowerFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}