package com.seventears.petsns.ui.posts.read;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.data.detailedpost.DetailedPost;
import com.seventears.petsns.data.image.ImageRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ReadViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String title;
    private final String contents;
    private final String nickname;
    private final long created;

    private final LiveData<Bitmap> postImage;
    private final LiveData<Bitmap> userImage;


    @Inject
    public ReadViewModel(SavedStateHandle savedStateHandle, ImageRepository imageRepository) {

        DetailedPost post = savedStateHandle.get("post");
        assert post != null;

        title = post.getTitle();
        contents = post.getContent();
        nickname = post.getWriter().getNickname();
        created = post.getCreated();

        postImage = imageRepository.getPostImageLiveData(post.getId());
        userImage = imageRepository.getProfileImageLiveData(post.getWriterId());
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getTitle() {
        return title;
    }

    public String getContents() {
        return contents;
    }

    public String getNickname() {
        return nickname;
    }

    public long getCreated() {
        return created;
    }

    public LiveData<Bitmap> getPostImage() {
        return postImage;
    }

    public LiveData<Bitmap> getUserImage() {
        return userImage;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }


    public static class Event {
        public static class NavigateBack extends Event {
        }
    }

}