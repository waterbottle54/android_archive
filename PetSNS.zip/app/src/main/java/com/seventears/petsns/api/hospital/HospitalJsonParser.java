package com.seventears.petsns.api.hospital;

import com.seventears.petsns.data.hospital.Hospital;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class HospitalJsonParser {

    public static List<Hospital> parse(JSONObject response) {

        List<Hospital> hospitalList = new ArrayList<>();

        try {

            JSONObject meta = response.getJSONObject("meta");
            if (meta.getBoolean("is_end")) {
                return null;
            }

            JSONArray documents = response.getJSONArray("documents");

            for (int i = 0; i < documents.length(); i++) {

                JSONObject document = documents.getJSONObject(i);
                String id = document.getString("id");
                String placeName = document.getString("place_name");
                String categoryName = document.getString("category_name");
                String phone = document.getString("phone");
                String roadAddressName = document.getString("road_address_name");
                String strLatitude = document.getString("y").trim();
                String strLongitude = document.getString("x").trim();
                String strDistance = document.getString("distance").trim();

                if (strDistance.isEmpty() || strLatitude.isEmpty() || strLongitude.isEmpty()) {
                    continue;
                }
                double distance = Double.parseDouble(strDistance);
                double latitude = Double.parseDouble(strLatitude);
                double longitude = Double.parseDouble(strLongitude);

                Hospital hospital = new Hospital(id, placeName, categoryName, phone, roadAddressName, longitude, latitude, distance);
                hospitalList.add(hospital);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return hospitalList;
    }

}
