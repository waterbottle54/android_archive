package com.seventears.petsns.ui.feed.feed;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.data.detailedpost.DetailedPost;
import com.seventears.petsns.data.user.User;
import com.seventears.petsns.databinding.FragmentFeedBinding;
import com.seventears.petsns.ui.MainActivity;
import com.seventears.petsns.ui.posts.posts.DetailedPostsAdapter;
import com.seventears.petsns.ui.posts.posts.PostsFragmentDirections;
import com.seventears.petsns.util.AuthFragment;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class FeedFragment extends AuthFragment {

    private FragmentFeedBinding binding;
    private FeedViewModel viewModel;


    public FeedFragment() {
        super(R.layout.fragment_feed);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentFeedBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(FeedViewModel.class);

        binding.fabEditProfile.setOnClickListener(v -> viewModel.onEditProfileClick());

        viewModel.getProfileImage().observe(getViewLifecycleOwner(), bitmap -> {
            if (bitmap != null) {
                binding.imageViewProfileImage.setImageBitmap(bitmap);
            }
            binding.progressBarProfile.setVisibility(View.INVISIBLE);
        });

        viewModel.getNickname().observe(getViewLifecycleOwner(), nickname ->
                binding.textViewNickname.setText(nickname));

        viewModel.isMale().observe(getViewLifecycleOwner(), isMale ->
                binding.textViewGender.setText(isMale ? "남성" : "여성"));

        viewModel.getAge().observe(getViewLifecycleOwner(), age ->
                binding.textViewAge.setText(
                        String.format(Locale.getDefault(), "%d세", age))
        );

        viewModel.getPostAlbum().observe(getViewLifecycleOwner(), postAlbum ->
                viewModel.getUserAlbum().observe(getViewLifecycleOwner(), userAlbum -> {

                    DetailedPostsAdapter adapter = new DetailedPostsAdapter(postAlbum, userAlbum);
                    binding.recyclerPost.setAdapter(adapter);
                    binding.recyclerPost.setHasFixedSize(true);

                    adapter.setOnItemSelectedListener(position -> {
                        DetailedPost post = adapter.getCurrentList().get(position);
                        viewModel.onPostClick(post);
                    });

                    viewModel.getPosts().observe(getViewLifecycleOwner(), posts -> {
                        if (posts != null) {
                            adapter.submitList(posts);
                            binding.textViewNoPostsMine.setVisibility(posts.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                        }
                        binding.progressBarRecycler.setVisibility(View.INVISIBLE);
                    });
                })
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof FeedViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof FeedViewModel.Event.NavigateToEditProfileScreen) {
                User user = ((FeedViewModel.Event.NavigateToEditProfileScreen) event).user;
                NavDirections action = FeedFragmentDirections.actionFeedFragmentToEditProfileFragment(user);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof FeedViewModel.Event.NavigateToReadScreen) {
                DetailedPost post = ((FeedViewModel.Event.NavigateToReadScreen) event).post;
                NavDirections action = PostsFragmentDirections.actionGlobalReadFragment(post);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });

        getParentFragmentManager().setFragmentResultListener(MainActivity.REQUEST_EDIT_PROFILE, getViewLifecycleOwner(),
                (requestKey, bundle) -> {
                    int result = bundle.getInt(MainActivity.RESULT_EDIT_PROFILE);
                    viewModel.onEditProfileResult(result);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}