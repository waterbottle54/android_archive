package com.seventears.petsns.ui.feed.editprofile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentEditProfileBinding;
import com.seventears.petsns.ui.MainActivity;
import com.seventears.petsns.util.BitmapUtils;
import com.seventears.petsns.util.OnTextChangedListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class EditProfileFragment extends Fragment {

    private FragmentEditProfileBinding binding;
    private EditProfileViewModel viewModel;

    private ActivityResultLauncher<Intent> imageActivityLauncher;
    private ActivityResultLauncher<String[]> requestPermissionLauncher;


    public EditProfileFragment() {
        super(R.layout.fragment_edit_profile);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                viewModel.onBackPressed();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);

        imageActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK
                            && result.getData() != null) {
                        // 비트맵 획득
                        Bitmap bitmap = null;
                        if (result.getData().getExtras() != null) {
                            // 카메라 결과 획득
                            bitmap = (Bitmap) result.getData().getExtras().get("data");
                        } else {
                            // 갤러리(포토) 결과 획득
                            Uri uri = result.getData().getData();
                            if (uri != null) {
                                String path = BitmapUtils.getRealPathFromUri(requireContext(), uri);
                                bitmap = BitmapUtils.getBitmapFromPath(path);
                            }
                        }
                        viewModel.onImageSelected(bitmap);
                    }
                }
        );

        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    Boolean permissionExternalStorage = result.get(Manifest.permission.READ_EXTERNAL_STORAGE);
                    Boolean permissionCamera = result.get(Manifest.permission.CAMERA);

                    if (permissionExternalStorage != null && permissionExternalStorage
                            && permissionCamera != null && permissionCamera) {
                        showImageDialog();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentEditProfileBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(EditProfileViewModel.class);

        binding.editTextNickname.setText(viewModel.getNickname());
        binding.radioGroupGender.check(viewModel.isMale() ? R.id.radio_button_male : R.id.radio_button_female);
        binding.editTextAge.setText(String.valueOf(viewModel.getAge()));

        binding.editTextNickname.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onNicknameChanged(text);
            }
        });
        binding.editTextAge.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onAgeChanged(text);
            }
        });
        binding.radioGroupGender.setOnCheckedChangeListener((radioGroup, i) ->
                viewModel.onGenderChanged(i == R.id.radio_button_male));

        binding.fabSelectImage.setOnClickListener(v -> viewModel.onSelectImageClick());
        binding.fabSubmit.setOnClickListener(v -> viewModel.onSubmitClick());

        binding.progressBar.setVisibility(View.VISIBLE);

        viewModel.getBitmap().observe(getViewLifecycleOwner(), bitmap -> {
            if (bitmap != null) {
                binding.imageViewProfileImage.setImageBitmap(bitmap);
            }
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof EditProfileViewModel.Event.ShowInvalidInputMessage) {
                String message = ((EditProfileViewModel.Event.ShowInvalidInputMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof EditProfileViewModel.Event.NavigateBackWithResult) {
                int result = ((EditProfileViewModel.Event.NavigateBackWithResult) event).result;
                Bundle bundle = new Bundle();
                bundle.putInt(MainActivity.RESULT_EDIT_PROFILE, result);
                getParentFragmentManager().setFragmentResult(MainActivity.REQUEST_EDIT_PROFILE, bundle);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof EditProfileViewModel.Event.PromptImage) {
                promptImage();
            } else if (event instanceof EditProfileViewModel.Event.ShowImageSelectFailureMessage) {
                String message = ((EditProfileViewModel.Event.ShowImageSelectFailureMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void promptImage() {

        if (requireContext().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && requireContext().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showImageDialog();
        } else {
            requestPermissionLauncher.launch(
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}
            );
        }
    }

    private void showImageDialog() {

        // 업로드 방법 선택 대화상자 보이기
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chooser = Intent.createChooser(galleryIntent, "사진 업로드");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        imageActivityLauncher.launch(chooser);
    }

}





