package com.seventears.petsns.ui.function;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.seventears.petsns.R;
import com.seventears.petsns.databinding.FragmentFunctionBinding;
import com.seventears.petsns.util.AuthFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class FunctionFragment extends AuthFragment {

    private FragmentFunctionBinding binding;
    private FunctionViewModel viewModel;


    public FunctionFragment() {
        super(R.layout.fragment_function);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentFunctionBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(FunctionViewModel.class);

        binding.cardHospital.setOnClickListener(v -> viewModel.onGpsClick());
        binding.cardFollowers.setOnClickListener(v -> viewModel.onFollowersClick());
        binding.cardChatBot.setOnClickListener(v -> viewModel.onChatBotClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof FunctionViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof FunctionViewModel.Event.NavigateToHospitalScreen) {
                NavDirections action = FunctionFragmentDirections.actionFunctionFragmentToHospitalFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof FunctionViewModel.Event.NavigateToFollowersScreen) {
                NavDirections action = FunctionFragmentDirections.actionFunctionFragmentToFollowersFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }  else if (event instanceof FunctionViewModel.Event.NavigateToChatBotScreen) {
                NavDirections action = FunctionFragmentDirections.actionFunctionFragmentToChatBotFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}