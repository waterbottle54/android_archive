package com.seventears.petsns.ui.sns;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SnsViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();


    @Inject
    public SnsViewModel(FirebaseFirestore firestore) {

    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }

    public void onMyFeedClick() {
        event.setValue(new Event.NavigateToMyFeedScreen());
    }

    public void onUploadClick() {
        event.setValue(new Event.NavigateToUploadScreen());
    }

    public void onPostsClick() {
        event.setValue(new Event.NavigateToPostsScreen());
    }

    public void onSearchClick() {
        event.setValue(new Event.NavigateToSearchScreen());
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToMyFeedScreen extends Event {}

        public static class NavigateToUploadScreen extends Event {}

        public static class NavigateToPostsScreen extends Event {}

        public static class NavigateToSearchScreen extends Event {}

    }

}