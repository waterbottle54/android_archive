package com.davidjo.missilegame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class FailureActivity extends AppCompatActivity {

    private ImageView mImageView;
    private View mTextLayout;
    private boolean mCanTap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_failure);

        hideSystemUI();

        mImageView = findViewById(R.id.image_failure);
        mTextLayout = findViewById(R.id.layout_failure);

        mImageView.post(new Runnable() {
            @Override
            public void run() {
                mImageView.startAnimation(initImageFadeInAnimation());
            }
        });
    }

    private void hideSystemUI() {
        // Make full screen.
        View contentView = findViewById(android.R.id.content);
        contentView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    private Animation initImageFadeInAnimation() {

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_in_slow);

        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) { }

            @Override
            public void onAnimationEnd(Animation animation) {
                mImageView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mImageView.startAnimation(initImageFadeOutAnimation());
                    }
                }, 3000);
            }

            @Override
            public void onAnimationRepeat(Animation animation) { }
        });

        return anim;
    }

    private Animation initImageFadeOutAnimation() {
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_out_slow);

        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) { }

            @Override
            public void onAnimationEnd(Animation animation) {
                mTextLayout.startAnimation(initTextFadeInAnimation());
                mCanTap = true;
            }

            @Override
            public void onAnimationRepeat(Animation animation) { }
        });

        return anim;
    }

    private Animation initTextFadeInAnimation() {
        return AnimationUtils.loadAnimation(this, R.anim.fade_in);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (mCanTap) {
            finish();
            return true;
        }

        return super.onTouchEvent(event);
    }

}
