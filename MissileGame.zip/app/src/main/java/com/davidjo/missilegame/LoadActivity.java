package com.davidjo.missilegame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LoadActivity extends AppCompatActivity implements GameItemAdapter.OnItemClickListener {

    private GameItemAdapter mAdapter;
    private List<GameItemAdapter.GameItem> mGameList;
    private RecyclerView mRecycler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load);

        ImageButton exitButton = findViewById(R.id.btn_exit);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exit();
            }
        });

        mRecycler = findViewById(R.id.recycler_view);
        mRecycler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadGameList();
                if (!checkEmpty()) {
                    mRecycler.startAnimation(AnimationUtils.loadAnimation(
                            LoadActivity.this, R.anim.fade_in_slow));
                    buildRecycler();
                }
            }
        }, 200);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        // Make full screen.
        View contentView = findViewById(android.R.id.content);
        contentView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    private void loadGameList() {
        mGameList = new ArrayList<>();

        String[] fileList = fileList();
        for (String fileName : fileList) {
            try {
                mGameList.add(readGameFile(fileName));
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
    }

    private void buildRecycler() {

        mRecycler = findViewById(R.id.recycler_view);
        mRecycler.setLayoutManager(new GridLayoutManager(this, 2));
        mRecycler.setHasFixedSize(true);

        mAdapter = new GameItemAdapter(this, mGameList);
        mAdapter.setOnItemClickListener(this);
        mRecycler.setAdapter(mAdapter);

        ProgressBar progressBar = findViewById(R.id.load_progress);
        progressBar.setVisibility(View.INVISIBLE);
    }

    @Override
    public void onItemClick(int position) {

        // Finish activity with selected game data.
        GameItemAdapter.GameItem gameItem = mGameList.get(position);
        GameManager.SerializationData gameData = new GameManager.SerializationData(gameItem.game);

        Intent data = new Intent();
        data.putExtra(MainActivity.EXTRA_GAME_CREATED_DATE, gameItem.date);
        data.putExtra(MainActivity.EXTRA_GAME_MANAGER_DATA, gameData);

        setResult(RESULT_OK, data);
        finish();
    }

    @Override
    public void onItemLongClick(final int position) {

        // Show alert dialog which asks whether to delete the item.
        new AlertDialog.Builder(this)
                .setTitle("Delete Game")
                .setMessage("Do you really want to delete the game?")
                .setNegativeButton(android.R.string.cancel, null)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // If clicked OK, delete item and file.
                        mGameList.remove(position);
                        mAdapter.notifyItemRemoved(position);
                        deleteFile(fileList()[position]);
                        checkEmpty();
                    }
                })
                .show();
    }

    private void exit() {
        setResult(RESULT_CANCELED);
        finish();
    }

    private GameItemAdapter.GameItem readGameFile(String fileName)
            throws IOException, ClassNotFoundException {

        Date date;
        GameManager.SerializationData data;

        // Open the file.
        FileInputStream fis = openFileInput(fileName);
        ObjectInputStream ois = new ObjectInputStream(fis);

        // Read from the file.
        date = (Date) ois.readObject();
        data = (GameManager.SerializationData) ois.readObject();

        // Close the file.
        fis.close();
        ois.close();

        return new GameItemAdapter.GameItem(new GameManager(data), date);
    }

    private boolean checkEmpty() {
        if (!mGameList.isEmpty())
            return false;

        TextView noGameText = findViewById(R.id.txt_no_game_data);
        noGameText.startAnimation(AnimationUtils.loadAnimation(this, R.anim.fade_in));

        ProgressBar progressBar = findViewById(R.id.load_progress);
        progressBar.setVisibility(View.INVISIBLE);

        return true;
    }

}
