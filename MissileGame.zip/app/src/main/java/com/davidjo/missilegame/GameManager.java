package com.davidjo.missilegame;

import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.Region;
import android.os.Bundle;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

@SuppressWarnings("WeakerAccess, unused, UnusedReturnValue")
public class GameManager {

    public static final int LAUNCHER_GRID_ROWS = 7;
    public static final int LAUNCHER_GRID_COLUMNS = 2;

    public static final int LAUNCHER_TYPE_M8000 = 0;
    public static final int LAUNCHER_TYPE_WF500 = 1;
    public static final int MISSILE_TYPE_NUCLEAR = 0;
    public static final int MISSILE_TYPE_ANTIGRAVITY = 1;
    public static final int MAGNETIC_SHIELD = 100;

    public static final int[] PRICE_LAUNCHER = {500, 1000};
    public static final float[] BASE_POWER = {50, 10};
    public static final long[] BASE_DELAY = {2000, 1500};
    public static final float[] BASE_THRUST = {1500, 1500};
    public static final float ANTIGRAVITY_RATIO = 0.7f;
    public static final float ANTIGRAVITY_RANGE = 300;
    public static final float SPLASH_RANGE = 400;

    public static final int UPGRADE_POWER = 0;
    public static final int UPGRADE_DELAY = 1;
    public static final int UPGRADE_THRUST = 2;
    public static final int UPGRADE_EXPLOSION = 3;

    public static final int EVENT_PLANET_DESTROYED = 100;
    public static final int EVENT_MISSILE_DESTROYED = 101;
    public static final int EVENT_EARTH_HIT = 102;
    public static final int EVENT_GAME_FAILED = 103;
    public static final int EVENT_PAY = 104;
    public static final int EVENT_REFUND = 108;
    public static final int EVENT_STAGE_UP = 105;
    public static final int EVENT_STAGE_STARTED = 106;
    public static final int EVENT_GAIN = 107;

    public static final String EVENT_ARG_X = "davidjo.missilegame.event_arg_x";
    public static final String EVENT_ARG_Y = "davidjo.missilegame.event_arg_y";
    public static final String EVENT_ARG_MISSILE_TYPE = "davidjo.missilegame.event_arg_missile_type";
    public static final String EVENT_ARG_FLAGS = "davidjo.missilegame.event_arg_missile_flag";
    public static final int EVENT_FLAG_EXPLOSION = 0x00000001;

    // Game Objects
    private Planet mEarth;
    private List<Planet> mArPlanet;
    private List<Missile> mArMissile;
    private List<Launcher> mArLauncher;

    // Game Assets / Upgrades
    private int mOre;
    private UpgradeManager mUpgradeManager;

    // Game Variables
    private RectF mBoundary;
    private int mStage;
    private boolean mStartStage;
    private int mRecallRemains;
    private long mRecallTimeRemaining;
    private int mFocusedLauncher;
    private boolean mGameFailed;
    private boolean mMagneticShield;
    private int mMagneticShieldChances;

    private boolean[][] mInstallData;

    // Event Queue
    private Queue<Event> mEventQueue;


    // Constructors

    public GameManager(float boundaryWidth, float boundaryHeight) {
        initialize(boundaryWidth, boundaryHeight, null);
    }

    public GameManager(SerializationData serializationData) {
        initialize(0, 0, serializationData);
    }

    private void initialize(float boundaryWidth, float boundaryHeight,
                            SerializationData data) {

        // Initialize game variables.
        mFocusedLauncher = -1;
        mInstallData = new boolean[LAUNCHER_GRID_ROWS][LAUNCHER_GRID_COLUMNS];

        if (data == null) {
            mBoundary = new RectF(0, 0, boundaryWidth, boundaryHeight);

            // Create game objects.
            mEarth = new Planet(mBoundary.height() / 1.5f, getEarthMaxHitPoint());
            mEarth.setHPosition(-mEarth.getRadius() / 2);
            mEarth.setVPosition(mBoundary.height() / 2);
            mEarth.setSpinSpeed(3);
            mArPlanet = new ArrayList<>();
            mArMissile = new ArrayList<>();
            mArLauncher = new ArrayList<>();

            // Initialize game assets / upgrades.
            mOre = PRICE_LAUNCHER[LAUNCHER_TYPE_M8000];
            mUpgradeManager = new UpgradeManager();

            // Initialize game variables.
            mStage = 0;
            initStage(false);
            mMagneticShield = false;
            mMagneticShieldChances = 1;

        } else {
            mBoundary = new RectF(0, 0, data.boundaryWidth, data.boundaryHeight);

            // Initialize game objects.
            mEarth = new Planet(data.earthData);
            mArMissile = new ArrayList<>();
            mArPlanet = new ArrayList<>();
            mArLauncher = new ArrayList<>();

            for (Missile.SerializationData missileData : data.missilesData) {
                mArMissile.add(new Missile(missileData));
            }
            for (Planet.SerializationData planetData : data.planetsData) {
                mArPlanet.add(new Planet(planetData));
            }
            for (Launcher.SerializationData launcherData : data.launcherData) {
                mArLauncher.add(new Launcher(launcherData));
            }

            // Initialize game assets / upgrades.
            mOre = data.ore;
            mUpgradeManager = new UpgradeManager(data.upgradeManager);
            applyUpgrades();

            // Initialize game variables
            mStage = data.stage;
            mStartStage = data.startStage;
            mRecallRemains = data.recallRemains;
            mRecallTimeRemaining = data.recallTimeRemaining;
            for (int row = 0; row < LAUNCHER_GRID_ROWS; row++) {
                System.arraycopy(data.installData[row], 0,
                        mInstallData[row], 0, LAUNCHER_GRID_COLUMNS);
            }
            mMagneticShield = data.magneticShield;
            mMagneticShieldChances = data.mMagneticShieldChances;
        }

        // Create event queue.
        mEventQueue = new LinkedList<>();
    }

    // Accessors

    public float getBoundaryWidth() {
        return mBoundary.right;
    }

    public float getBoundaryHeight() {
        return mBoundary.bottom;
    }

    public int getStage() {
        return mStage;
    }

    public Event pollEvent() {
        return mEventQueue.poll();
    }

    public Planet getEarthObj() {
        return mEarth;
    }

    public Planet getPlanetObj(int idx) {
        return mArPlanet.get(idx);
    }

    public Missile getMissileObj(int idx) {
        return mArMissile.get(idx);
    }

    public Launcher getLauncherObj(int idx) {
        return mArLauncher.get(idx);
    }

    public int getPlanetNumber() {
        return mArPlanet.size();
    }

    public int getMissileNumber() {
        return mArMissile.size();
    }

    public int getLauncherNumber() {
        return mArLauncher.size();
    }

    public int getFocusedLauncher() {
        return mFocusedLauncher;
    }

    public int getOre() {
        return mOre;
    }

    public int getUpgradeLevel(int type) {
        switch (type) {
            case UPGRADE_POWER:
                return mUpgradeManager.levelPower;
            case UPGRADE_DELAY:
                return mUpgradeManager.levelDelay;
            case UPGRADE_THRUST:
                return mUpgradeManager.levelThrust;
            case UPGRADE_EXPLOSION:
                return mUpgradeManager.levelExplosion;
        }
        return 0;
    }

    public int getUpgradePrice(int type) {
        switch (type) {
            case UPGRADE_POWER:
                return mUpgradeManager.getPowerPrice();
            case UPGRADE_DELAY:
                return mUpgradeManager.getDelayPrice();
            case UPGRADE_THRUST:
                return mUpgradeManager.getThrustPrice();
            case UPGRADE_EXPLOSION:
                return mUpgradeManager.getExplosionPrice();
        }
        return 0;
    }

    public float getEarthMaxHitPoint() {
        return 3;
    }

    public float getLauncherGridHeight() {
        return mBoundary.height() / LAUNCHER_GRID_ROWS;
    }

    public float getLauncherGridWidth() {
        return getLauncherGridHeight();
    }

    public int getMagneticShieldChances() {
        return mMagneticShieldChances;
    }

    // Inquiries

    public boolean isEventQueueEmpty() {
        return mEventQueue.isEmpty();
    }

    public boolean isStageStarted() {
        return mStartStage;
    }

    public boolean isStageFinished() {

        if (isGameFailed()) {
            return false;
        }

        switch (mStage) {
            case 0:
                return (mArLauncher.size() > 0);
            case 1:
            default:
                return (mRecallRemains == 0 && mArPlanet.isEmpty());
        }
    }

    public boolean hasFocusedLauncher() {
        if (mFocusedLauncher == -1)
            return false;

        Launcher launcher = mArLauncher.get(mFocusedLauncher);
        return launcher != null;
    }

    public boolean isGameFailed() {
        return (mEarth.getHitPoint() <= 0);
    }

    public boolean hasMagneticShield() {
        return mMagneticShield;
    }

    // Actions

    public void update(float framerate) {

        mEarth.update(framerate);
        updateMissiles(framerate);
        updatePlanets(framerate);
        updateLaunchers(framerate);

        if (mRecallRemains > 0 && mStartStage) {
            mRecallTimeRemaining -= 1000 / framerate;
            if (mRecallTimeRemaining <= 0) {
                recallPlanet();
            }
        }

        if (isStageFinished()) {
            mOre += getIncentiveByStage(mStage);
            mEventQueue.add(new Event(EVENT_GAIN, null));

            initStage(true);
            mEventQueue.add(new Event(EVENT_STAGE_UP, null));
        }
    }

    public void startStage() {
        mStartStage = true;
        mEventQueue.add(new Event(EVENT_STAGE_STARTED, null));
    }

    public boolean pay(int price) {
        if (mOre >= price) {
            mOre -= price;
            mEventQueue.add(new Event(EVENT_PAY, null));
            return true;
        }
        return false;
    }

    public void refund(int price) {
        mOre += price;
        mEventQueue.add(new Event(EVENT_REFUND, null));
    }

    public boolean install(int type, int row, int col) {

        if (mInstallData[row][col])
            return false;

        mInstallData[row][col] = true;

        float xStart = mEarth.getHPosition() + mEarth.getRadius();
        float x = xStart + getLauncherGridWidth() * (col + 0.5f);
        float y = getLauncherGridHeight() * (row + 0.5f);

        long delay;
        float power;
        int missileType;

        switch (type) {
            default:
            case LAUNCHER_TYPE_M8000:
                missileType = MISSILE_TYPE_NUCLEAR;
                break;
            case LAUNCHER_TYPE_WF500:
                missileType = MISSILE_TYPE_ANTIGRAVITY;
                break;
        }

        Launcher launcher = new Launcher(
                getLauncherGridWidth() / 1.5f, getLauncherGridHeight() / 1.5f,
                (long) (BASE_DELAY[type] * mUpgradeManager.getDelayCoef()),
                BASE_POWER[type] * mUpgradeManager.getPowerCoef(),
                BASE_THRUST[type] * mUpgradeManager.getThrustCoef(),
                mUpgradeManager.getExplosionCoef(),
                type, missileType);

        launcher.setHPosition(x);
        launcher.setVPosition(y);

        mArLauncher.add(launcher);
        return true;
    }

    public void upgrade(int type) {
        switch (type) {
            case UPGRADE_POWER:
                mUpgradeManager.levelPower++;
                applyUpgrades();
                break;
            case UPGRADE_DELAY:
                mUpgradeManager.levelDelay++;
                applyUpgrades();
                break;
            case UPGRADE_THRUST:
                mUpgradeManager.levelThrust++;
                applyUpgrades();
                break;
            case UPGRADE_EXPLOSION:
                mUpgradeManager.levelExplosion++;
                applyUpgrades();
                break;
        }
    }

    public void aim(float x, float y) {
        if (hasFocusedLauncher()) {
            Launcher launcher = mArLauncher.get(mFocusedLauncher);
            launcher.aim(x, y);
        }
    }

    public void installMagneticShield() {
        if (mMagneticShieldChances > 0) {
            mMagneticShield = true;
            mMagneticShieldChances--;
        }
    }

    // Procedures

    private void initStage(boolean up) {
        if (up) {
            mStage++;
        }
        mRecallRemains = getPlanetNumberByStage(mStage);
        mRecallTimeRemaining = 3000;
        mStartStage = false;
    }

    private void recallPlanet() {

        Planet newPlanet = generatePlanet(mStage);
        newPlanet.setHPosition(mBoundary.right + newPlanet.getRadius());
        newPlanet.setVPosition(mBoundary.top + newPlanet.getRadius() +
                (float) Math.random() * (mBoundary.height() - newPlanet.getRadius() * 2));

        mArPlanet.add(newPlanet);
        mRecallRemains--;
        mRecallTimeRemaining = getPlanetRecallPeriodByStage(mStage);
    }

    private void updatePlanets(float framerate) {

        PointF pntTemp = new PointF();

        // update planet objects
        for (int i = 0; i < mArPlanet.size(); i++) {

            // get each planet object
            Planet planet = mArPlanet.get(i);
            if (planet == null)
                continue;

            // update the planet
            planet.update(framerate);

            // check the hit point of the planet.
            if (planet.getHitPoint() <= 0) {
                // remove the planet, and move to the next planet.
                mArPlanet.set(i, null);

                Bundle eventArgs = new Bundle();
                eventArgs.putFloat(EVENT_ARG_X, planet.getHPosition());
                eventArgs.putFloat(EVENT_ARG_Y, planet.getVPosition());
                mEventQueue.add(new Event(EVENT_PLANET_DESTROYED, eventArgs));

                // Increase ore.
                mOre += getGainByStage(mStage);
                mEventQueue.add(new Event(EVENT_GAIN, null));
                continue;
            }

            // Check if the planet has hit the earth
            if (planet.touches(mEarth, pntTemp)) {
                mArPlanet.set(i, null);

                if (mMagneticShield) {
                    mMagneticShield = false;

                    Bundle eventArgs = new Bundle();
                    eventArgs.putFloat(EVENT_ARG_X, planet.getHPosition());
                    eventArgs.putFloat(EVENT_ARG_Y, planet.getVPosition());
                    mEventQueue.add(new Event(EVENT_PLANET_DESTROYED, eventArgs));

                    continue;
                }

                mEarth.damage(pntTemp.x, pntTemp.y, 2 * planet.getRadius(),
                        planet.getSpeedHDirection(), planet.getSpeedVDirection());

                Bundle eventArgs = new Bundle();
                eventArgs.putFloat(EVENT_ARG_X, pntTemp.x);
                eventArgs.putFloat(EVENT_ARG_Y, pntTemp.y);
                mEventQueue.add(new Event(EVENT_EARTH_HIT, eventArgs));

                mEarth.setHitPoint(mEarth.getHitPoint() - 1);
                if (isGameFailed()) {
                    if (!mGameFailed) {
                        mEventQueue.add(new Event(EVENT_GAME_FAILED, null));
                    }
                    mGameFailed = true;
                }
                continue;
            }

            // check if the planet has gone out of the boundary
            if (planet.getHPosition() + planet.getRadius() < mBoundary.left) {
                // if so, remove the planet, and move to the next planet.
                mArPlanet.set(i, null);
            }

            // end of updating each planet.
        }

        // clean up deleted planets from the list
        mArPlanet.remove(null);
    }

    private void updateMissiles(float framerate) {

        PointF posTemp = new PointF();
        Region regionTemp = new Region();

        // update missile objects
        for (int i = 0; i < mArMissile.size(); i++) {

            // get each missile object
            Missile missile = mArMissile.get(i);
            if (missile == null)
                continue;

            // update the missile
            missile.update(framerate);

            // check if the missile has gone out of the boundary
            if (!mBoundary.contains(missile.getHPosition(), missile.getVPosition())) {
                // if so, remove the missile from the list, and move to the next missile.
                mArMissile.set(i, null);
                continue;
            }

            // check if the antigravity missile has arrived to its target position
            if (missile.getType() == MISSILE_TYPE_ANTIGRAVITY) {
                if (missile.getHPosition() >= missile.getHPosTarget()) {
                    // Apply antigravity to nearby planets
                    applyAntigravity(missile.getHPosTarget(), missile.getVPosTarget());

                    // remove the missile from the list
                    mArMissile.set(i, null);

                    Bundle eventArgs = new Bundle();
                    eventArgs.putFloat(EVENT_ARG_X, missile.getHPosition());
                    eventArgs.putFloat(EVENT_ARG_Y, missile.getVPosition());
                    eventArgs.putInt(EVENT_ARG_MISSILE_TYPE, missile.getType());
                    mEventQueue.add(new Event(EVENT_MISSILE_DESTROYED, eventArgs));
                    continue;
                }
            }

            // check if the missile has hit any of planets
            for (int k = 0; k < mArPlanet.size(); k++) {

                // get each planet object
                Planet planet = mArPlanet.get(k);
                if (planet == null)
                    continue;

                if (missile.touches(planet, posTemp)) {
                    // if the missile hit the planet, damage the planet
                    float hitRad = planet.getRadius()
                            * (missile.getPower() / planet.getHitPoint());

                    planet.damage(posTemp.x, posTemp.y, hitRad,
                            missile.getSpeedHDirection(), missile.getSpeedVDirection());

                    planet.setHitPoint(planet.getHitPoint() - missile.getPower());

                    // Apply antigravity to nearby planets
                    if (missile.getType() == MISSILE_TYPE_ANTIGRAVITY) {
                        applyAntigravity(missile.getHPosition(), missile.getVPosition());
                    }

                    // Apply splash damage to nearby planets
                    if (mUpgradeManager.levelExplosion > 0) {
                        applySplashDamage(missile.getHPosition(), missile.getVPosition(),
                                missile.getPower() * mUpgradeManager.getExplosionCoef(),
                                planet);
                    }

                    // remove the missile from the list
                    mArMissile.set(i, null);

                    Bundle eventArgs = new Bundle();
                    eventArgs.putFloat(EVENT_ARG_X, missile.getHPosition());
                    eventArgs.putFloat(EVENT_ARG_Y, missile.getVPosition());
                    eventArgs.putInt(EVENT_ARG_MISSILE_TYPE, missile.getType());
                    if (mUpgradeManager.levelExplosion > 0) {
                        eventArgs.putInt(EVENT_ARG_FLAGS, EVENT_FLAG_EXPLOSION);
                    }
                    mEventQueue.add(new Event(EVENT_MISSILE_DESTROYED, eventArgs));
                    break;
                }
            }

            // end of updating each missile objects
        }

        // clean up deleted missiles from the list
        mArMissile.remove(null);
    }

    private void updateLaunchers(float framerate) {

        for (int i = 0; i < mArLauncher.size(); i++) {
            Launcher launcher = mArLauncher.get(i);
            if (launcher == null)
                continue;

            launcher.update(framerate);

            // Assign this launcher as focused.
            if (mFocusedLauncher == -1 && launcher.isReloaded()) {
                mFocusedLauncher = i;
            }

            // Launch missile if this is focused and ready.
            if (mFocusedLauncher == i && launcher.isAimReady()) {
                Missile missile = launcher.launch();
                if (launcher.getType() == LAUNCHER_TYPE_WF500) {
                    missile.setTarget(launcher.getHPosTarget(), launcher.getVPosTarget());
                }
                mArMissile.add(missile);
                mFocusedLauncher = -1;
            }
        }
    }

    private void applyUpgrades() {

        for (int i = 0; i < mArLauncher.size(); i++) {
            Launcher launcher = mArLauncher.get(i);
            if (launcher == null)
                continue;

            launcher.setPower(BASE_POWER[launcher.getType()] * mUpgradeManager.getPowerCoef());
            launcher.setDelay(
                    (long) (BASE_DELAY[launcher.getType()] * mUpgradeManager.getDelayCoef()));
            launcher.setThrust(BASE_THRUST[launcher.getType()] * mUpgradeManager.getThrustCoef());
            launcher.setExplosion(mUpgradeManager.getExplosionCoef());
        }
    }

    private void applyAntigravity(float x, float y) {

        for (int i = 0; i < mArPlanet.size(); i++) {
            Planet planet = mArPlanet.get(i);
            if (planet == null)
                continue;

            if (planet.getDistance(new Position(x, y)) < ANTIGRAVITY_RANGE) {
                planet.setHSpeed(planet.getHSpeed() * ANTIGRAVITY_RATIO);
            }
        }
    }

    private void applySplashDamage(float x, float y, float damage, Planet excluded) {

        for (int i = 0; i < mArPlanet.size(); i++) {
            Planet planet = mArPlanet.get(i);
            if (planet == null || planet == excluded)
                continue;

            if (planet.getDistance(new Position(x, y)) < SPLASH_RANGE) {
                planet.setHitPoint(planet.getHitPoint() - damage);
            }
        }
    }

    // Values

    public int getPlanetNumberByStage(int stage) {
        switch (stage) {
            case 0:
                return 0;
            case 1:
                return 1;
            case 2:
                return 15;
            case 3:
                return 20;
            default:
                return 20 + stage * 2;
        }
    }

    public long getPlanetRecallPeriodByStage(int stage) {
        return (long) (2500 / (0.2 * stage + 0.6));
    }

    public float getPlanetAverageSpeedByStage(int stage) {
        if (stage <= 1)
            return 100;

        return (float) (180 + 90 * Math.sqrt(stage - 2));
    }

    public float getPlanetAverageHitPointByStage(int stage) {
        if (stage <= 1)
            return 150;


        return (BASE_POWER[LAUNCHER_TYPE_M8000] * (1 + (stage - 2)));
    }

    public Planet generatePlanet(int stage) {

        float rand = (float) (0.6 + 0.8 * Math.random());
        float hitPoint = getPlanetAverageHitPointByStage(stage) * rand;
        float radius = 100 * rand;
        float rand2 = (float) (0.6 + 0.8 * Math.random());
        float speed = getPlanetAverageSpeedByStage(stage) * rand2;

        Planet newPlanet = new Planet(radius, hitPoint);
        newPlanet.setHSpeed(-speed);
        newPlanet.setSpinSpeed(newPlanet.getHSpeed() / 2);

        return newPlanet;
    }

    public int getGainByStage(int stage) {
        int min, var;

        min = 20;
        var = 30;

        return (int) Math.round(min + var * Math.random());
    }

    public int getIncentiveByStage(int stage) {
        switch (stage) {
            case 0:
                return 0;
            case 1:
                return 500;
        }
        return 200 + (100 * stage);
    }

    // Upgrade Manager class

    static class UpgradeManager implements Serializable {

        private int levelPower;
        private int levelDelay;
        private int levelThrust;
        private int levelExplosion;

        public UpgradeManager() {
        }

        public UpgradeManager(UpgradeManager upgradeManager) {
            init(upgradeManager.levelPower, upgradeManager.levelDelay,
                    upgradeManager.levelThrust, upgradeManager.levelExplosion);
        }

        private void init(int levelPower, int levelDelay, int levelThrust, int levelExplosion) {
            this.levelPower = levelPower;
            this.levelDelay = levelDelay;
            this.levelThrust = levelThrust;
            this.levelExplosion = levelExplosion;
        }

        public static float getPowerCoefByLevel(int level) {
            return (1 + level * 0.2f);
        }

        public static float getDelayCoefByLevel(int level) {
            return 1 / (1 + level * 0.2f);
        }

        public static float getThrustCoefByLevel(int level) {
            return (1 + level * 0.4f);
        }

        public static float getExplosionCoefByLevel(int level) {
            return (float) (1 - Math.exp(-0.3 * level));
        }

        public static int getPowerPriceByLevel(int level) {
            return (200 + 100 * level);
        }

        public static int getDelayPriceByLevel(int level) {
            return (200 + 200 * level);
        }

        public static int getThrustPriceByLevel(int level) {
            return (500 + 500 * level);
        }

        public static int getExplosionPriceByLevel(int level) {
            return 500 + (1000 * level);
        }

        public float getPowerCoef() {
            return UpgradeManager.getPowerCoefByLevel(levelPower);
        }

        public float getDelayCoef() {
            return UpgradeManager.getDelayCoefByLevel(levelDelay);
        }

        public float getThrustCoef() {
            return UpgradeManager.getThrustCoefByLevel(levelThrust);
        }

        public float getExplosionCoef() {
            return UpgradeManager.getExplosionCoefByLevel(levelExplosion);
        }

        public int getPowerPrice() {
            return getPowerPriceByLevel(levelPower);
        }

        public int getDelayPrice() {
            return getDelayPriceByLevel(levelDelay);
        }

        public int getThrustPrice() {
            return getThrustPriceByLevel(levelThrust);
        }

        public int getExplosionPrice() {
            return getExplosionPriceByLevel(levelExplosion);
        }
    }

    // Event Class

    static class Event {

        private int code;
        private Bundle args;

        public Event(int code, Bundle args) {
            this.code = code;
            this.args = args;
        }

        public int getCode() {
            return code;
        }

        public Bundle getArgs() {
            return args;
        }
    }

    // Serialization Data Class

    static class SerializationData implements Serializable {

        // Game Objects
        private Planet.SerializationData earthData;
        private List<Missile.SerializationData> missilesData;
        private List<Planet.SerializationData> planetsData;
        private List<Launcher.SerializationData> launcherData;

        // Game Variables
        private int stage;
        private boolean startStage;
        private int recallRemains;
        private long recallTimeRemaining;
        private float boundaryWidth;
        private float boundaryHeight;
        private boolean[][] installData;
        private boolean magneticShield;
        private int mMagneticShieldChances;

        // Game Assets / Upgrades
        private int ore;
        private UpgradeManager upgradeManager;

        public SerializationData(GameManager gameManager) {
            // Game objects
            earthData = new Planet.SerializationData(gameManager.getEarthObj());
            planetsData = new ArrayList<>();
            missilesData = new ArrayList<>();
            launcherData = new ArrayList<>();

            for (int i = 0; i < gameManager.getPlanetNumber(); i++) {
                planetsData.add(new Planet.SerializationData(gameManager.getPlanetObj(i)));
            }
            for (int i = 0; i < gameManager.getMissileNumber(); i++) {
                missilesData.add(new Missile.SerializationData(gameManager.getMissileObj(i)));
            }
            for (int i = 0; i < gameManager.getLauncherNumber(); i++) {
                launcherData.add(new Launcher.SerializationData(gameManager.getLauncherObj(i)));
            }

            // Game variables
            stage = gameManager.mStage;
            startStage = gameManager.mStartStage;
            recallRemains = gameManager.mRecallRemains;
            recallTimeRemaining = gameManager.mRecallTimeRemaining;
            boundaryWidth = gameManager.getBoundaryWidth();
            boundaryHeight = gameManager.getBoundaryHeight();
            installData = new boolean[LAUNCHER_GRID_ROWS][LAUNCHER_GRID_COLUMNS];
            for (int row = 0; row < LAUNCHER_GRID_ROWS; row++) {
                System.arraycopy(gameManager.mInstallData[row], 0,
                        installData[row], 0, LAUNCHER_GRID_COLUMNS);
            }
            magneticShield = gameManager.mMagneticShield;
            mMagneticShieldChances = gameManager.mMagneticShieldChances;

            // Assets / Upgrades
            ore = gameManager.getOre();
            upgradeManager = gameManager.mUpgradeManager;
        }
    }

}
