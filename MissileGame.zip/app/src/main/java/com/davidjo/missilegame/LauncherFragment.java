package com.davidjo.missilegame;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;

import com.android.billingclient.api.Purchase;


/**
 * A simple {@link Fragment} subclass.
 */
public class LauncherFragment extends DialogFragment implements Button.OnClickListener {

    public interface Callback {
        void onLauncherFragmentDismiss();
        void onLauncherSelected(int type);
    }

    private Callback mCallback;
    private GameManager mGameManager;


    public LauncherFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_launcher, container, false);

        hideSystemUI(v);

        // Initialize buttons.
        ImageButton m8000Button = v.findViewById(R.id.btn_launcher_m8000);
        m8000Button.setOnClickListener(this);

        ImageButton wf500Button = v.findViewById(R.id.btn_launcher_wf500);
        wf500Button.setOnClickListener(this);

        getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        return v;
    }

    private void hideSystemUI(View v) {
        v.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    private void updateViews() {


    }

    void setGameManager(GameManager gameManager) {
        mGameManager = gameManager;
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        if (mCallback != null) {
            mCallback.onLauncherFragmentDismiss();
        }
    }

    @Override
    public void onClick(View v) {

        if (mCallback == null || mGameManager == null)
            return;

        int price;

        switch (v.getId()) {
            case R.id.btn_launcher_m8000:
                price = GameManager.PRICE_LAUNCHER[GameManager.LAUNCHER_TYPE_M8000];
                if (mGameManager.getOre() >= price) {
                    mCallback.onLauncherSelected(GameManager.LAUNCHER_TYPE_M8000);
                    dismiss();
                }
                break;
            case R.id.btn_launcher_wf500:
                price = GameManager.PRICE_LAUNCHER[GameManager.LAUNCHER_TYPE_WF500];
                if (mGameManager.getOre() >= price) {
                    mCallback.onLauncherSelected(GameManager.LAUNCHER_TYPE_WF500);
                    dismiss();
                }
                break;
            case R.id.btn_magnetic_shield:
                break;
        }
    }

    void setCallback(Callback callback) {
        mCallback = callback;
    }

}
