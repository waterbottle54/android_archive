package com.davidjo.missilegame;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AspectRatioLayout extends FrameLayout {

    private float aspectRatio;

    public AspectRatioLayout(@NonNull Context context) {
        super(context);
        init(context, null);
    }

    public AspectRatioLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public AspectRatioLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {

        if (attrs == null) {
            aspectRatio = 1.0f;
        }

        TypedArray ar = context.obtainStyledAttributes(attrs, R.styleable.AspectRatioLayout);
        aspectRatio = ar.getFloat(R.styleable.AspectRatioLayout_layout_aspectRatio, 1.0f);
        ar.recycle();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);

        int width, height;
        int drawingWidth, drawingHeight;
        width = View.MeasureSpec.getSize(widthMeasureSpec);
        height = View.MeasureSpec.getSize(heightMeasureSpec);

        double aspect = (double)width / height;
        if (aspect > aspectRatio) {
            drawingHeight = height;
            drawingWidth = (int)(height * aspectRatio);
        } else {
            drawingWidth = width;
            drawingHeight = (int)(width / aspectRatio);
        }

        setMeasuredDimension(drawingWidth, drawingHeight);
    }

}
