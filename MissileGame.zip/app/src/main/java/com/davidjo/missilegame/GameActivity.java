package com.davidjo.missilegame;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.LoadAdError;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.lang.ref.WeakReference;
import java.util.Date;
import java.util.Locale;

public class GameActivity extends AppCompatActivity implements
        Button.OnClickListener, LauncherFragment.Callback, UpgradeFragment.Callback {

    public static final int REQUEST_INTRO_ACTIVITY = 100;
    public static final int REQUEST_FAILURE_ACTIVITY = 101;
    public static final int SOUND_MAX_STREAM = 8;
    public static final String EXTRA_STAGE = "com.davidjo.extra_stage";
    public static final String FRAGMENT_POPUP_DIALOG = "com.davidjo.fragment_popup_dialog";
    public static final float BOUNDARY_WIDTH = 2000f;
    public static final int DELAY_START_FAILURE = 500;
    public static final int DELAY_START_INTRO = 1000;
    public static final long ELAPSE_TIMER = 20;

    private GameView mGameView;
    private GameManager mGameManager;
    private GameEventHandler mGameEventHandler;
    private TimerHandler mTimerHandler;

    // Views / Fragments
    private TextView mOreText;
    private View mMoveNextText;
    private View mNavigationView;
    private View[] mLifeImages;
    private LauncherFragment mLauncherFragment;
    private UpgradeFragment mUpgradeFragment;

    // Sound objects
    private SoundPool mSoundPool;
    private int mSoundBomb;

    // Control variables
    long mStartIntroDelay;
    long mStartFailureDelay;
    boolean mUserPaused;

    // Interstitial ad for this activity
    private InterstitialAd mInterstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        mGameManager = initGameManager();
        mGameEventHandler = new GameEventHandler(this);
        mTimerHandler = new TimerHandler(this);

        initializeGameView(mGameManager);
        initializeViews();

        loadSounds();
        mInterstitialAd = newInterstitialAd();

        // Start first intro.
        if (!mGameManager.isStageStarted()) {
            startIntroActivity(mGameManager.getStage());
        }
    }

    private void loadSounds() {
        // Load sounds.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();

            mSoundPool = new SoundPool.Builder()
                    .setMaxStreams(SOUND_MAX_STREAM)
                    .setAudioAttributes(audioAttributes)
                    .build();
        } else {
            mSoundPool = new SoundPool(SOUND_MAX_STREAM, AudioManager.STREAM_MUSIC, 0);
        }
        mSoundBomb = mSoundPool.load(this, R.raw.bomb, 1);
    }

    private GameManager initGameManager() {

        if (isNewGame()) {

            return new GameManager(BOUNDARY_WIDTH, BOUNDARY_WIDTH / 1.618f);

        } else {

            GameManager.SerializationData gameData = (GameManager.SerializationData)
                    getIntent().getSerializableExtra(MainActivity.EXTRA_GAME_MANAGER_DATA);

            return new GameManager(gameData);
        }
    }

    private void initializeGameView(GameManager gameManager) {
        mGameView = findViewById(R.id.game_view);
        mGameView.setGameManager(gameManager);
        mGameView.setGameEventHandler(mGameEventHandler);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void initializeViews() {

        mOreText = findViewById(R.id.txt_ore);
        mMoveNextText = findViewById(R.id.txt_next_stage);
        mMoveNextText.setOnClickListener(this);

        mLifeImages = new View[]{
                findViewById(R.id.image_life_1),
                findViewById(R.id.image_life_2),
                findViewById(R.id.image_life_3)
        };

        // Initialize buttons.
        Button installButton = findViewById(R.id.btn_install);
        Button upgradeButton = findViewById(R.id.btn_upgrade);
        Button showNavButton = findViewById(R.id.btn_show_nav);
        Button navReturnButton = findViewById(R.id.btn_continue);
        Button navExitButton = findViewById(R.id.btn_exit);

        installButton.setOnClickListener(this);
        upgradeButton.setOnClickListener(this);
        showNavButton.setOnClickListener(this);

        navReturnButton.setOnClickListener(this);
        navExitButton.setOnClickListener(this);

        // Initialize Navigation view.
        mNavigationView = findViewById(R.id.nav_list);
        mNavigationView.setOnClickListener(this);

        // Initialize fragments.
        mLauncherFragment = new LauncherFragment();
        mLauncherFragment.setCallback(this);
        mLauncherFragment.setGameManager(mGameManager);

        mUpgradeFragment = new UpgradeFragment();
        mUpgradeFragment.setCallback(this);
        mUpgradeFragment.setGameManager(mGameManager);

        // Update views
        updateViews();
    }

    private void updateViews() {
        int ore = mGameManager.getOre();
        mOreText.setText(String.valueOf(ore));

        int hitPoint = Math.round(mGameManager.getEarthObj().getHitPoint());
        for (int i = 0; i < 3; i++) {
            mLifeImages[i].setVisibility(hitPoint > i ? View.VISIBLE : View.INVISIBLE);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        findViewById(android.R.id.content).setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!mUserPaused) {
            resumeGame();
        }
        mTimerHandler.sendEmptyMessage(0);
    }

    @Override
    protected void onPause() {
        super.onPause();
        pauseGame();
        mTimerHandler.removeMessages(0);

        // Save the game
        if (!mGameManager.isGameFailed()) {
            try {
                writeGameData();
            } catch (IOException e) {
                Toast.makeText(this, "Failed to save game.", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        mSoundPool.release();
        mSoundPool = null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        switch (requestCode) {
            case REQUEST_INTRO_ACTIVITY:
                // Start stage.
                mGameManager.startStage();
                break;
            case REQUEST_FAILURE_ACTIVITY:
                // Finish game.
                finish();
                break;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_install:
                showLauncherFragment();
                break;
            case R.id.btn_upgrade:
                showUpgradeFragment();
                break;
            case R.id.btn_show_nav:
                showNavigation();
                break;
            case R.id.btn_continue:
            case R.id.nav_list:
                hideNavigation();
                break;
            case R.id.btn_exit:
                finish();
                break;
            case R.id.txt_next_stage:
                mMoveNextText.clearAnimation();
                mMoveNextText.setVisibility(View.INVISIBLE);
                showInterstitial();
                break;
        }
    }

    @Override
    public void onLauncherFragmentDismiss() {
        resumeGame();
        mUserPaused = false;
    }

    @Override
    public void onLauncherSelected(int type) {
        if (type != -1) {
            mGameView.setLauncherToInstall(type);
        }
    }

    @Override
    public void onUpgradeFragmentDismiss() {
        resumeGame();
        mUserPaused = false;


    }

    @Override
    public void onUpgradeSucceed() {
        updateViews();
    }

    // Helper methods

    private void showLauncherFragment() {
        if (!mLauncherFragment.isVisible()) {
            pauseGame();
            mUserPaused = true;
            mLauncherFragment.show(getSupportFragmentManager(), FRAGMENT_POPUP_DIALOG);
        }
    }

    private void showUpgradeFragment() {
        if (!mUpgradeFragment.isVisible()) {
            pauseGame();
            mUserPaused = true;
            mUpgradeFragment.show(getSupportFragmentManager(), FRAGMENT_POPUP_DIALOG);
        }
    }

    private void showNavigation() {
        pauseGame();
        mNavigationView.setVisibility(View.VISIBLE);
        mUserPaused = true;
    }

    private void hideNavigation() {
        resumeGame();
        mNavigationView.setVisibility(View.INVISIBLE);
        mUserPaused = false;
    }

    private void pauseGame() {
        mGameView.pause();
    }

    private void resumeGame() {
        pauseGame();
        mGameView.resume();
    }

    @SuppressWarnings("deprecation")
    private void writeGameData() throws IOException {

        // Determine file name based on the created date of game.
        Date date = (Date) getIntent().getSerializableExtra(
                MainActivity.EXTRA_GAME_CREATED_DATE);

        if (date == null) {
            return;
        }

        String fileName = String.format(Locale.getDefault(),
                "%d-%d-%d-%d:%d:%d",
                date.getYear(), date.getMonth(), date.getDate(),
                date.getHours(), date.getMinutes(), date.getSeconds());

        // Open or create the file.
        FileOutputStream fos = openFileOutput(fileName, MODE_PRIVATE);
        ObjectOutputStream oos = new ObjectOutputStream(fos);

        // Write to the file.
        oos.writeObject(date);
        oos.writeObject(new GameManager.SerializationData(mGameManager));

        // Close the file.
        fos.close();
        oos.close();
    }

    private boolean isNewGame() {
        return !getIntent().hasExtra(MainActivity.EXTRA_GAME_MANAGER_DATA);
    }

    @SuppressWarnings("deprecation")
    private void startIntroActivity(int stage) {
        Intent intent = new Intent(this, IntroActivity.class);
        intent.putExtra(EXTRA_STAGE, stage);
        startActivityForResult(intent, REQUEST_INTRO_ACTIVITY);
    }

    @SuppressWarnings("deprecation")
    private void startFailureActivity() {
        Intent intent = new Intent(this, FailureActivity.class);
        startActivityForResult(intent, REQUEST_FAILURE_ACTIVITY);
    }

    // Game Event

    public void updateByTimer() {

        if (mStartIntroDelay > 0 && !mUserPaused) {
            mStartIntroDelay -= ELAPSE_TIMER;
            if (mStartIntroDelay <= 0) {
                if (mGameManager.getStage() <= IntroActivity.getLastIntroStage()) {
                    startIntroActivity(mGameManager.getStage());
                } else {
                    loadInterstitial();
                }
            }
        }
        if (mStartFailureDelay > 0 && !mUserPaused) {
            mStartFailureDelay -= ELAPSE_TIMER;
            if (mStartFailureDelay <= 0) {
                mStartFailureDelay = 0;
                startFailureActivity();
            }
        }
    }

    private void handleGameEvent(GameManager.Event event) {

        int code = event.getCode();

        switch (code) {
            case GameManager.EVENT_MISSILE_DESTROYED:
                mSoundPool.play(mSoundBomb, 1, 1, 0, 0, 1);
                break;
            case GameManager.EVENT_EARTH_HIT:
                mSoundPool.play(mSoundBomb, 1, 1, 0, 0, 1);
                updateViews();
                break;
            case GameManager.EVENT_GAME_FAILED:
                mStartFailureDelay = DELAY_START_FAILURE;
                break;
            case GameManager.EVENT_STAGE_UP:
                mStartIntroDelay = DELAY_START_INTRO;
                break;
            case GameManager.EVENT_STAGE_STARTED:
                try {
                    writeGameData();
                } catch (IOException e) {
                    Toast.makeText(this, "Failed to save game.", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                break;
            case GameManager.EVENT_PAY:
            case GameManager.EVENT_REFUND:
            case GameManager.EVENT_GAIN:
                updateViews();
                break;
        }
    }

    // Methods for interstitial ad

    private InterstitialAd newInterstitialAd() {
        InterstitialAd interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.interstitial_level_id));
        interstitialAd.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                mMoveNextText.startAnimation(AnimationUtils.loadAnimation(
                        GameActivity.this, R.anim.fade_in));
            }

            @Override
            public void onAdClosed() {
                // Start stage.
                mGameManager.startStage();
            }

            @Override
            public void onAdFailedToLoad(LoadAdError loadAdError) {
                super.onAdFailedToLoad(loadAdError);
                mMoveNextText.startAnimation(AnimationUtils.loadAnimation(
                        GameActivity.this, R.anim.fade_in));
            }
        });
        return interstitialAd;
    }

    private void loadInterstitial() {
        // load the ad.
        AdRequest adRequest = new AdRequest.Builder()
                .setRequestAgent("android_studio:ad_template").build();
        mInterstitialAd.loadAd(adRequest);
    }

    private void showInterstitial() {
        // show the ad.
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        } else {
            // Start stage.
            mGameManager.startStage();
        }
    }

    // Game Event Handler Class

    static class GameEventHandler extends Handler {

        private WeakReference<GameActivity> reference;

        GameEventHandler(GameActivity activity) {
            reference = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(@NonNull Message msg) {

            GameActivity activity = reference.get();

            GameManager.Event event = (GameManager.Event) msg.obj;
            activity.handleGameEvent(event);
        }
    }

    static class TimerHandler extends Handler {

        private WeakReference<GameActivity> reference;

        TimerHandler(GameActivity activity) {
            reference = new WeakReference<>(activity);
        }

        @Override
        public void handleMessage(@NonNull Message msg) {

            GameActivity activity = reference.get();

            sendEmptyMessageDelayed(0, ELAPSE_TIMER);
            activity.updateByTimer();
        }
    }
}

