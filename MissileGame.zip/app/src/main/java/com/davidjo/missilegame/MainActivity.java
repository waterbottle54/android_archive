package com.davidjo.missilegame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

public class MainActivity extends AppCompatActivity implements Button.OnClickListener {

    public static final int REQUEST_LOAD_ACTIVITY = 100;
    public static final int REQUEST_GAME_ACTIVITY = 101;
    public static final String EXTRA_GAME_MANAGER_DATA = "com.davidjo.game_manager_data";
    public static final String EXTRA_GAME_CREATED_DATE = "com.davidjo.game_created_date";

    private View mButtonContainer;
    private boolean mButtonClickable;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();

        mButtonClickable = true;
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    private void hideSystemUI() {
        // Make full screen.
        View contentView = findViewById(android.R.id.content);
        contentView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    private void initViews() {

        mButtonContainer = findViewById(R.id.container_button);

        Button newGameButton = findViewById(R.id.btn_new_game);
        Button loadGameButton = findViewById(R.id.btn_load_game);
        Button exitButton = findViewById(R.id.btn_exit);

        newGameButton.setOnClickListener(this);
        loadGameButton.setOnClickListener(this);
        exitButton.setOnClickListener(this);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQUEST_LOAD_ACTIVITY:
                if (resultCode == RESULT_OK && data != null) {
                    startLoadedGame(data);
                }
                break;
            case REQUEST_GAME_ACTIVITY:
                fadeInButtonContainer();
                break;
        }
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btn_new_game:
                startNewGame();
                break;
            case R.id.btn_load_game:
                startLoadActivity();
                break;
            case R.id.btn_exit:
                if (mButtonClickable) {
                    exit();
                }
                break;
        }
    }

    @SuppressWarnings("deprecation")
    private void startNewGame() {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra(EXTRA_GAME_CREATED_DATE, new Date());
        startActivityForResult(intent, REQUEST_GAME_ACTIVITY);
    }

    @SuppressWarnings("deprecation")
    private void startLoadedGame(Intent data) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra(EXTRA_GAME_CREATED_DATE,
                data.getSerializableExtra(EXTRA_GAME_CREATED_DATE));
        intent.putExtra(EXTRA_GAME_MANAGER_DATA,
                data.getSerializableExtra(EXTRA_GAME_MANAGER_DATA));
        startActivityForResult(intent, REQUEST_GAME_ACTIVITY);
    }

    @SuppressWarnings("deprecation")
    private void startLoadActivity() {
        Intent intent = new Intent(this, LoadActivity.class);
        startActivityForResult(intent, REQUEST_LOAD_ACTIVITY);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void exit() {
        finish();
    }

    private void fadeInButtonContainer() {

        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.fade_in_moderate);
        fadeIn.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) { }

            @Override
            public void onAnimationEnd(Animation animation) {
                mButtonClickable = true;
            }

            @Override
            public void onAnimationRepeat(Animation animation) { }
        });

        mButtonClickable = false;
        mButtonContainer.startAnimation(fadeIn);
    }

}
