package com.davidjo.missilegame;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class GameView extends SurfaceView implements Runnable {

    private static final String TAG = "GameView";

    private SurfaceHolder mSurfaceHolder;
    private Thread mGameThread;
    private boolean mRunning;
    private GameManager mGameManager;
    private Handler mGameEventHandler;
    private Rect mViewRect;

    // Graphic objects
    private Matrix mGameMatrix;
    private Paint mPaintPlanetMask;
    private Paint mPaintInstallGrid;
    private Paint mPaintDelayBar;
    private Paint mPaintFocus;
    private Bitmap mBmpBackground;
    private Bitmap mBmpMissile;
    private Bitmap mBmpM8000;
    private Bitmap mBmpWF500;
    private Bitmap mBmpEarth;
    private Bitmap mBmpEarthShield;
    private Bitmap mBmpAsteroidRock;
    private Bitmap mBmpAsteroidMars;
    private Bitmap mBmpAsteroidYellow;
    private Bitmap mBmpAsteroidFlame;
    private Bitmap mBmpAsteroidRadiant;
    private Bitmap mBmpExplosion;
    private Bitmap mBmpExplosionScarlet;
    private Bitmap mBmpExplosionGreen;

    // Animation objects
    private List<SheetAnimation> mArAnimation;
    private List<Rect> mArAnimationDest;
    private int mShakeCount;
    private int mShakeAmplitude;
    private float mBackgroundOffset;

    // Control variables
    private int mLauncher2Install;
    private long mPrevTime;

    private List<RectF> mArInstallGrid;

    private final RectF rectTemp = new RectF();
    private final Rect rectIntTemp = new Rect();
    private final Path pathTemp = new Path();
    private final Region rgnTemp = new Region();
    private final Matrix matTemp = new Matrix();
    private final Rect srcRectTemp = new Rect();
    private final Rect rectDest = new Rect();
    private final Rect rectDestAppend = new Rect();
    private final Rect rectSrc = new Rect();
    private final Rect rectSrcAppend = new Rect();


    public GameView(Context context) {
        super(context);
        init(context);
    }

    public GameView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public GameView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {

        mSurfaceHolder = getHolder();

        mGameMatrix = new Matrix();
        mArInstallGrid = new ArrayList<>();
        mLauncher2Install = -1;

        mPaintPlanetMask = new Paint();
        mPaintPlanetMask.setColor(0xffffffff);
        mPaintPlanetMask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));

        mPaintInstallGrid = new Paint();
        mPaintInstallGrid.setColor(getResources().getColor(R.color.colorDigits));
        mPaintInstallGrid.setStyle(Paint.Style.STROKE);
        mPaintInstallGrid.setStrokeWidth(5);

        mPaintDelayBar = new Paint();
        mPaintDelayBar.setColor(getResources().getColor(R.color.colorDigits));

        mPaintFocus = new Paint();
        mPaintFocus.setColor(getResources().getColor(android.R.color.darker_gray));
        mPaintFocus.setStyle(Paint.Style.STROKE);
        mPaintFocus.setStrokeWidth(5);

        loadBitmaps();

        mArAnimation = new ArrayList<>();
        mArAnimationDest = new ArrayList<>();
    }

    private void loadBitmaps() {
        mBmpBackground = BitmapFactory.decodeResource(getResources(), R.drawable.background_game);
        mBmpEarth = BitmapFactory.decodeResource(getResources(), R.drawable.earth);
        mBmpMissile = BitmapFactory.decodeResource(getResources(), R.drawable.missile);
        mBmpM8000 = BitmapFactory.decodeResource(getResources(), R.drawable.spaceship);
        mBmpWF500 = BitmapFactory.decodeResource(getResources(), R.drawable.satellite);
        mBmpEarth = BitmapFactory.decodeResource(getResources(), R.drawable.earth);
        mBmpEarthShield = BitmapFactory.decodeResource(getResources(), R.drawable.earth_shield);

        mBmpAsteroidRock = BitmapFactory.decodeResource(getResources(), R.drawable.asteroid_rock);
        mBmpAsteroidMars = BitmapFactory.decodeResource(getResources(), R.drawable.asteroid_mars);
        mBmpAsteroidYellow = BitmapFactory.decodeResource(getResources(), R.drawable.asteroid_yellow);
        mBmpAsteroidFlame = BitmapFactory.decodeResource(getResources(), R.drawable.asteroid_flame);
        mBmpAsteroidRadiant = BitmapFactory.decodeResource(getResources(), R.drawable.asteroid_radiant);

        mBmpExplosion = BitmapFactory.decodeResource(getResources(), R.drawable.sheet_explosion);
        mBmpExplosionScarlet = BitmapFactory.decodeResource(getResources(), R.drawable.sheet_explosion_scarlet);
        mBmpExplosionGreen = BitmapFactory.decodeResource(getResources(), R.drawable.sheet_explosion_green);
    }

    private void prescaleBitmaps() {
        mBmpBackground = Bitmap.createScaledBitmap(
                mBmpBackground, mViewRect.width(), mViewRect.height(), false);
    }

    public void setGameManager(GameManager gameManager) {
        mGameManager = gameManager;

        if (getWidth() != 0) {
            setGameMatrix();
            invalidate();
        }

        setInstallGrids();
    }

    public void setGameEventHandler(Handler handler) {
        mGameEventHandler = handler;
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        mViewRect = new Rect(0, 0, w, h);
        prescaleBitmaps();

        if (mGameManager != null) {
            setGameMatrix();
            invalidate();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (mGameManager == null)
            return false;

        float[] gameCursor = {event.getX(), event.getY()};
        boolean succeed;

        Matrix matInv = new Matrix();
        mGameMatrix.invert(matInv);
        matInv.mapPoints(gameCursor);

        if (mLauncher2Install != -1) {
            for (int i = 0; i < mArInstallGrid.size(); i++) {
                if (mArInstallGrid.get(i).contains(gameCursor[0], gameCursor[1])) {
                    if (mGameManager.pay(GameManager.PRICE_LAUNCHER[mLauncher2Install])) {
                        succeed = mGameManager.install(
                                mLauncher2Install,
                                i / GameManager.LAUNCHER_GRID_COLUMNS,
                                i % GameManager.LAUNCHER_GRID_COLUMNS);
                        if (!succeed) {
                            mGameManager.refund(GameManager.PRICE_LAUNCHER[mLauncher2Install]);
                        }
                    }
                }
            }
            mLauncher2Install = -1;

        } else {
            mGameManager.aim(gameCursor[0], gameCursor[1]);
        }

        return super.onTouchEvent(event);
    }

    @Override
    public void run() {

        while (mRunning) {

            // Update game frame.
            if (mPrevTime != 0) {
                long elapsedTime = System.currentTimeMillis() - mPrevTime;
                mGameManager.update(1000f / elapsedTime);
            }
            mPrevTime = System.currentTimeMillis();

            // Get game events.
            while (!mGameManager.isEventQueueEmpty()) {
                GameManager.Event event = mGameManager.pollEvent();
                handleGameEvent(event);

                if (mGameEventHandler != null) {
                    Message message = new Message();
                    message.obj = event;
                    mGameEventHandler.sendMessage(message);
                }
            }

            // Redraw game frame.
            if (mSurfaceHolder.getSurface().isValid()) {

                // Lock and get canvas.
                Canvas canvas = mSurfaceHolder.lockCanvas();

                // Drawing code here.
                drawSurface(canvas);

                // Unlock canvas and post.
                mSurfaceHolder.unlockCanvasAndPost(canvas);
            }
        }
    }

    public void resume() {

        if (!mRunning) {

            mRunning = true;

            mGameThread = new Thread(this);
            mGameThread.start();
        }
    }

    public void pause() {

        boolean done = true;

        if (mRunning) {

            mRunning = false;
            mPrevTime = 0;

            while (done) {
                try {
                    mGameThread.join();
                    done = false;

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void drawSurface(Canvas canvas) {

        if (mGameManager == null)
            return;

        // Draw background.
        drawBackground(canvas);

        // Fit game coordinates to this view.
        canvas.setMatrix(mGameMatrix);

        // Draw game.
        drawGame(canvas);

        if (mLauncher2Install != -1) {
            drawInstallGrid(canvas);
        }
    }

    private void drawBackground(Canvas canvas) {

        getDrawingRect(rectDest);
        rectDestAppend.set(rectDest);
        rectSrc.set(rectDest);
        rectSrcAppend.set(rectDest);
        int outLength = 0;

        rectSrc.offset((int) mBackgroundOffset, 0);
        if (rectSrc.right > mBmpBackground.getWidth()) {
            outLength = rectSrc.right - mBmpBackground.getWidth();
            if (outLength >= rectDest.width()) {
                mBackgroundOffset = 0;
            }

            rectSrc.right -= outLength;
            rectSrcAppend.right = outLength;

            rectDest.right -= outLength;
            rectDestAppend.left = rectDest.right;
        }

        canvas.drawBitmap(mBmpBackground, rectSrc, rectDest, null);
        if (outLength > 0) {
            canvas.drawBitmap(mBmpBackground,
                    rectSrcAppend, rectDestAppend, null);
        }

        mBackgroundOffset += 1;

    }

    private void drawGame(Canvas canvas) {

        // Apply shake.
        if (mShakeCount > 0) {
            mShakeCount--;
            canvas.translate(0, (mShakeCount % 2 == 0) ? mShakeAmplitude : -mShakeAmplitude);
        }

        // Draw Earth.
        Planet earth = mGameManager.getEarthObj();
        if (earth != null) {
            drawPlanet(canvas, earth,
                    mGameManager.hasMagneticShield() ? mBmpEarthShield : mBmpEarth);
        }

        // Draw Planets.
        for (int i = 0; i < mGameManager.getPlanetNumber(); i++) {

            Planet planet = mGameManager.getPlanetObj(i);
            if (planet == null)
                continue;

            drawPlanet(canvas, planet, getPlanetBitmap());
        }

        // Draw Launchers
        for (int i = 0; i < mGameManager.getLauncherNumber(); i++) {

            Launcher launcher = mGameManager.getLauncherObj(i);
            if (launcher == null)
                continue;

            launcher.getTransformation(matTemp);
            canvas.save();
            canvas.concat(matTemp);

            launcher.getShapeBounds(rectTemp);
            canvas.drawBitmap(getLauncherBitmap(launcher), null, rectTemp, null);
            canvas.restore();

            // Draw each delay bar.
            if (!launcher.isReloaded()) {
                long delay = launcher.getDelay();
                long remaining = launcher.getRemainingTime();
                float rate = (float) remaining / delay;

                launcher.getShapeBounds(rectTemp);
                rectTemp.offset(launcher.getHPosition(), launcher.getVPosition());
                rectTemp.bottom = rectTemp.top - 30;
                rectTemp.top = rectTemp.bottom - 15;
                rectTemp.right = rectTemp.left + (rectTemp.width() * rate);

                canvas.drawRect(rectTemp, mPaintDelayBar);
            }

            // Draw focus.
            if (i == mGameManager.getFocusedLauncher()) {
                canvas.drawCircle(launcher.getHPosition(), launcher.getVPosition(),
                        mGameManager.getLauncherGridWidth() / 2, mPaintFocus);
            }
        }

        // Draw Missiles
        for (int i = 0; i < mGameManager.getMissileNumber(); i++) {

            Missile missile = mGameManager.getMissileObj(i);
            if (missile == null)
                continue;

            missile.getShapeBounds(rectTemp);
            missile.getTransformation(matTemp);
            canvas.save();
            canvas.concat(matTemp);

            canvas.drawBitmap(mBmpMissile, null, rectTemp, null);

            canvas.restore();
        }

        // draw animations
        for (int i = mArAnimation.size() - 1; i >= 0; i--) {

            SheetAnimation animation = mArAnimation.get(i);

            if (animation == null) {
                continue;
            }

            Bitmap bitmap = animation.getBitmap();
            Rect dstRect = mArAnimationDest.get(i);

            if (animation.toNext(srcRectTemp)) {
                canvas.drawBitmap(bitmap, srcRectTemp, dstRect, null);
            } else {
                mArAnimation.remove(i);
                mArAnimationDest.remove(i);
            }
        }
    }

    private void drawPlanet(Canvas canvas, Planet planet, Bitmap bitmap) {

        // Draw the planet
        planet.getTransformation(matTemp);
        canvas.save();
        canvas.concat(matTemp);

        planet.getOriginalBounds(rectTemp);
        canvas.drawBitmap(bitmap, null, rectTemp, null);

        canvas.restore();

        // Apply Mask which removes damaged part.

        Planet original = new Planet(planet.getRadius(), 0);
        original.setHPosition(planet.getHPosition());
        original.setVPosition(planet.getVPosition());
        original.subtract(planet);
        original.getRegion(rgnTemp);
        pathTemp.reset();
        rgnTemp.getBoundaryPath(pathTemp);

        canvas.drawPath(pathTemp, mPaintPlanetMask);
    }

    private void drawInstallGrid(Canvas canvas) {

        for (RectF grid : mArInstallGrid) {
            canvas.drawRect(grid, mPaintInstallGrid);
        }
    }

    public void setLauncherToInstall(int type) {
        mLauncher2Install = type;
    }

    public void addAnimation(Rect dest, int type, int flags) {

        if (mArAnimation.size() > 8)
            return;

        Bitmap bmpExplosion;

        switch (type) {
            default:
            case GameManager.MISSILE_TYPE_NUCLEAR:
                if ((flags & GameManager.EVENT_FLAG_EXPLOSION) == 0) {
                    bmpExplosion = mBmpExplosion;
                } else {
                    bmpExplosion = mBmpExplosionScarlet;
                }
                break;
            case GameManager.MISSILE_TYPE_ANTIGRAVITY:
                bmpExplosion = mBmpExplosionGreen;
                break;
        }

        mArAnimation.add(new SheetAnimation(bmpExplosion,
                getResources().getInteger(R.integer.explosion_1_rows),
                getResources().getInteger(R.integer.explosion_1_cols))
        );
        mArAnimationDest.add(new Rect(dest));
    }

    public void clearAnimations() {
        mArAnimation.clear();
        mArAnimationDest.clear();
    }

    public void setShake(int count, int amplitude) {
        mShakeCount = count;
        mShakeAmplitude = amplitude;
    }

    public void clearShake() {
        mShakeCount = 0;
    }

    private Bitmap getPlanetBitmap() {
        int stage = mGameManager.getStage();
        switch (stage) {
            case 1:
            case 2:
                return mBmpAsteroidRock;
            case 3:
            case 4:
                return mBmpAsteroidMars;
            case 5:
            case 6:
                return mBmpAsteroidYellow;
            case 7:
            case 8:
                return mBmpAsteroidFlame;
            default:
                return mBmpAsteroidRadiant;
        }
    }

    private Bitmap getLauncherBitmap(Launcher launcher) {
        switch (launcher.getType()) {
            default:
            case GameManager.LAUNCHER_TYPE_M8000:
                return mBmpM8000;
            case GameManager.LAUNCHER_TYPE_WF500:
                return mBmpWF500;
        }
    }

    private void setGameMatrix() {
        float scale = getWidth() / mGameManager.getBoundaryWidth();
        mGameMatrix.setScale(scale, scale);
    }

    private void setInstallGrids() {

        mArInstallGrid.clear();

        float width = mGameManager.getLauncherGridWidth();
        float height = mGameManager.getLauncherGridHeight();
        int rowNum = GameManager.LAUNCHER_GRID_ROWS;
        int colNum = GameManager.LAUNCHER_GRID_COLUMNS;

        for (int row = 0; row < rowNum; row++) {
            for (int col = 0; col < colNum; col++) {
                mArInstallGrid.add(new RectF(
                        col * width,
                        row * height,
                        (col + 1) * width,
                        (row + 1) * height));
            }
        }

        Planet earth = mGameManager.getEarthObj();
        float xStart = earth.getHPosition() + earth.getRadius();

        for (int i = 0; i < mArInstallGrid.size(); i++) {
            mArInstallGrid.get(i).offset(xStart, 0);
        }
    }

    private void handleGameEvent(GameManager.Event event) {

        int code = event.getCode();
        Bundle args = event.getArgs();
        Rect rectTemp = new Rect();
        float x;
        float y;
        int missileType;
        int flags;

        switch (code) {
            case GameManager.EVENT_PLANET_DESTROYED:
                setShake(20, 10);

                x = args.getFloat(GameManager.EVENT_ARG_X);
                y = args.getFloat(GameManager.EVENT_ARG_Y);
                rectTemp.set(
                        (int) x - 300, (int) y - 300,
                        (int) x + 300, (int) y + 300);
                addAnimation(rectTemp, -1, 0);
                break;
            case GameManager.EVENT_MISSILE_DESTROYED:
                setShake(10, 5);

                x = args.getFloat(GameManager.EVENT_ARG_X);
                y = args.getFloat(GameManager.EVENT_ARG_Y);
                missileType = args.getInt(GameManager.EVENT_ARG_MISSILE_TYPE);
                flags = args.getInt(GameManager.EVENT_ARG_FLAGS);
                rectTemp.set(
                        (int) x - 200, (int) y - 200,
                        (int) x + 200, (int) y + 200);
                addAnimation(rectTemp, missileType, flags);
                break;
            case GameManager.EVENT_EARTH_HIT:
                setShake(20, 15);

                x = args.getFloat(GameManager.EVENT_ARG_X);
                y = args.getFloat(GameManager.EVENT_ARG_Y);
                rectTemp.set(
                        (int) x - 400, (int) y - 400,
                        (int) x + 400, (int) y + 400);
                addAnimation(rectTemp, -1, 0);
                break;
        }
    }

}