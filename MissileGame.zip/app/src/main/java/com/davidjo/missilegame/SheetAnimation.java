package com.davidjo.missilegame;

import android.graphics.Bitmap;
import android.graphics.Rect;

@SuppressWarnings("WeakerAccess, unused")
public class SheetAnimation {

    final int mRows;
    final int mColumns;
    final Bitmap mBitmap;
    int mIndex;

    public SheetAnimation(Bitmap bitmap, int rows, int cols) {

        mRows = rows;
        mColumns = cols;
        mBitmap = bitmap;
        toFirst();
    }

    public boolean toFirst() {
        if (mBitmap == null)
            return false;

        mIndex = 0;
        return true;
    }

    public boolean toNext(Rect srcRect) {
        if (mBitmap == null || srcRect == null)
            return false;
        if (isFinished())
            return false;

        int wSrc = mBitmap.getWidth();
        int hSrc = mBitmap.getHeight();
        int wFrame = (wSrc / mColumns);
        int hFrame = (hSrc / mRows);

        srcRect.left = wFrame * (mIndex % mColumns);
        srcRect.top = hFrame * (mIndex / mColumns);
        srcRect.right = srcRect.left + wFrame;
        srcRect.bottom = srcRect.top + hFrame;

        mIndex++;
        return true;
    }

    public int getIndex() { return mIndex; }
    public int getRows() { return mRows; }
    public int getColumns() { return mColumns; }
    public Bitmap getBitmap() { return mBitmap; }
    public boolean isFinished() { return (mIndex == (mRows * mColumns)); }

}