package com.davidjo.missilegame;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.RegionIterator;
import android.graphics.drawable.shapes.PathShape;

import java.io.Serializable;

@SuppressWarnings("WeakerAccess, unused, UnusedReturnValue")
class Position {

    protected float hPos;
    protected float vPos;

    public Position(float hPos, float vPos) {
        this.hPos = hPos;
        this.vPos = vPos;
    }

    public Position setHPosition(float x) { hPos = x; return this; }
    public Position setVPosition(float y) { vPos = y; return this; }

    public float getHPosition() { return hPos; }
    public float getVPosition() { return vPos; }
    public float getDistance(Position p) {
        return (float)Math.hypot(
                p.getHPosition() - this.getHPosition(),
                p.getVPosition() - this.getVPosition());
    }
}

@SuppressWarnings("WeakerAccess, unused")
class Body extends Position {

    protected Path shape;
    protected float hPivot;
    protected float vPivot;
    protected float shapeDegrees;
    protected float spinDegrees;


    public Body(Path shape, float hPivot, float vPivot, float shapeDegrees) {
        super(0, 0);
        init(shape, hPivot, vPivot, shapeDegrees);
    }

    public Body(Body body) {
        super(body.getHPosition(), body.getVPosition());
        Path shape = new Path();
        body.getShape(shape);
        init(shape, body.getHPivot(), body.getVPivot(), body.getShapeDegrees());
    }

    private void init(Path shape, float hPivot, float vPivot, float shapeDegrees) {
        this.shape = (shape == null ? new Path() : new Path(shape));
        this.hPivot = hPivot;
        this.vPivot = vPivot;
        this.shapeDegrees = shapeDegrees;
        this.spinDegrees = 0;
    }

    public void getShape(Path path) { path.set(shape); }
    public void getShapeBounds(RectF rect) {
        shape.computeBounds(rect, true);
    }
    public float getHPivot() { return hPivot; }
    public float getVPivot() { return vPivot; }
    public float getShapeDegrees() { return shapeDegrees; }
    public void getTransformation(Matrix mat) {

        mat.setRotate(spinDegrees - shapeDegrees, hPivot, vPivot);
        mat.postTranslate(hPos, vPos);
    }
    public void getRegion(Region region) {

        Matrix mat = new Matrix();
        Path shape = new Path();
        RectF bound = new RectF();

        getShape(shape);

        getTransformation(mat);
        shape.transform(mat);

        shape.computeBounds(bound, true);
        region.setPath(shape,
                new Region((int)bound.left, (int)bound.top,(int)bound.right, (int)bound.bottom));
    }
    public void setSpinDegrees(float degrees) {
        spinDegrees = degrees;
    }
    public float getSpinDegrees() {
        return spinDegrees;
    }

    boolean contains(float x, float y) {
        Region rgnThis = new Region();
        getRegion(rgnThis);
        return rgnThis.contains((int)x, (int)y);
    }
    boolean isContainedBy(Body other) {
        Region rgnThis = new Region();
        Region rgnOther = new Region();

        this.getRegion(rgnThis);
        other.getRegion(rgnOther);

        return !rgnThis.op(rgnOther, Region.Op.DIFFERENCE);
    }
    boolean touches(Body other, PointF here) {
        Region rgnThis = new Region();
        Region rgnOther = new Region();

        this.getRegion(rgnThis);
        other.getRegion(rgnOther);

        if (!rgnThis.op(rgnOther, Region.Op.INTERSECT))
            return false;

        if (here != null) {
            Rect bound = new Rect();
            rgnThis.getBounds(bound);

            here.x = bound.centerX();
            here.y = bound.centerY();
        }
        return true;
    }
    void subtract(Body other) {
        Region rgnThis = new Region();
        Region rgnOther = new Region();
        Matrix mat = new Matrix();
        Matrix inv = new Matrix();

        this.getRegion(rgnThis);
        other.getRegion(rgnOther);

        rgnThis.op(rgnOther, Region.Op.DIFFERENCE);

        shape.reset();
        rgnThis.getBoundaryPath(shape);

        getTransformation(mat);
        mat.invert(inv);
        shape.transform(inv);
    }
}

@SuppressWarnings("WeakerAccess, unused")
class DynamicBody extends Body {

    protected float hSpeed;
    protected float vSpeed;
    protected float spinSpeed;

    public DynamicBody(Path shape, float hPivot, float vPivot, float shapeDegrees) {
        super(shape, hPivot, vPivot, shapeDegrees);
    }

    public float getHSpeed() { return hSpeed; }
    public float getVSpeed() { return vSpeed; }
    public float getSpinSpeed() {
        return spinSpeed;
    }
    public float getSpeed() { return (float)Math.hypot(hSpeed, vSpeed); }
    public float getSpeedHDirection() {
        return (getSpeed() > 0) ? (hSpeed / getSpeed()) : 0;
    }
    public float getSpeedVDirection() {
        return (getSpeed() > 0) ? (vSpeed / getSpeed()) : 0;
    }
    public float getSpinHDirection() {
        return (float)Math.cos((double)spinDegrees * Math.PI / 180);
    }
    public float getSpinVDirection() {
        return (float)Math.sin((double)spinDegrees * Math.PI / 180);
    }

    public void setHSpeed(float hSpeed) { this.hSpeed = hSpeed; }
    public void setVSpeed(float vSpeed) { this.vSpeed = vSpeed; }
    public void setSpinSpeed(float spinSpeed) { this.spinSpeed = spinSpeed; }

    public void update(float framerate) {
        hPos += hSpeed / framerate;
        vPos += vSpeed / framerate;
        spinDegrees += spinSpeed / framerate;
    }

}

@SuppressWarnings("WeakerAccess, unused")
class ControllableBody extends DynamicBody {

    public static final int SPIN_STOP = 0;
    public static final int SPIN_CLOCKWISE = 1;
    public static final int SPIN_COUNTERCLOCKWISE = 2;

    private float maxSpeed;
    private float maxSpinSpeed;

    public ControllableBody(float maxSpeed, float maxSpinSpeed,
                            Path shape, float hPivot, float vPivot, float shapeDegrees) {
        super(shape, hPivot, vPivot, shapeDegrees);
        init(maxSpeed, maxSpinSpeed);
    }

    private void init(float maxSpeed, float maxSpinSpeed) {
        this.maxSpeed = maxSpeed;
        this.maxSpinSpeed = maxSpinSpeed;
    }

    public void setMaxSpeed(float maxSpeed) { this.maxSpeed = maxSpeed; }
    public void setMaxSpinSpeed(float maxSpinSpeed) { this.maxSpinSpeed = maxSpinSpeed; }
    public float getMaxSpeed() { return maxSpeed; }
    public float getMaxSpinSpeed() { return maxSpinSpeed; }

    public void move() {
        hSpeed = getSpinHDirection() * maxSpeed;
        vSpeed = getSpinVDirection() * maxSpeed;
    }
    public void stop() {
        hSpeed = 0;
        vSpeed = 0;
    }
    public void spin(int state) {
        switch (state) {
            case SPIN_STOP:
                spinSpeed = 0;
                break;
            case SPIN_CLOCKWISE:
                spinSpeed = -maxSpinSpeed;
                break;
            case SPIN_COUNTERCLOCKWISE:
                spinSpeed = maxSpinSpeed;
                break;
        }
    }

}

