package com.davidjo.missilegame;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpgradeFragment extends DialogFragment implements Button.OnClickListener {

    public interface Callback {
        void onUpgradeFragmentDismiss();
        void onUpgradeSucceed();
    }

    private TextView mPricePowerText;
    private TextView mPriceDelayText;
    private TextView mPriceThrustText;
    private TextView mPriceExplosionText;

    private TextView mLevelPowerText;
    private TextView mLevelDelayText;
    private TextView mLevelThrustText;
    private TextView mLevelExplosionText;

    private Callback mCallback;
    private GameManager mGameManager;


    public UpgradeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_upgrade, container, false);

        hideSystemUI(v);
        initViews(v);

        getDialog().getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        return v;
    }

    private void hideSystemUI(View v) {
        v.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    private void initViews(View v) {

        mPricePowerText = v.findViewById(R.id.txt_price_upgrade_power);
        mPriceDelayText = v.findViewById(R.id.txt_price_upgrade_delay);
        mPriceThrustText = v.findViewById(R.id.txt_price_upgrade_thrust);
        mPriceExplosionText = v.findViewById(R.id.txt_price_upgrade_explosion);

        mLevelPowerText = v.findViewById(R.id.txt_level_upgrade_power);
        mLevelDelayText = v.findViewById(R.id.txt_level_upgrade_delay);
        mLevelThrustText = v.findViewById(R.id.txt_level_upgrade_thrust);
        mLevelExplosionText = v.findViewById(R.id.txt_level_upgrade_explosion);

        ImageButton powerButton = v.findViewById(R.id.btn_upgrade_power);
        ImageButton delayButton = v.findViewById(R.id.btn_upgrade_delay);
        ImageButton explosionButton = v.findViewById(R.id.btn_upgrade_explosion);
        ImageButton thrustButton = v.findViewById(R.id.btn_upgrade_thrust);
        powerButton.setOnClickListener(this);
        delayButton.setOnClickListener(this);
        explosionButton.setOnClickListener(this);
        thrustButton.setOnClickListener(this);

        if (mGameManager != null) {
            updateViews();
        }
    }

    private void updateViews() {

        if (mGameManager == null)
            return;

        int levelPower = mGameManager.getUpgradeLevel(GameManager.UPGRADE_POWER);
        int levelDelay = mGameManager.getUpgradeLevel(GameManager.UPGRADE_DELAY);
        int levelThrust = mGameManager.getUpgradeLevel(GameManager.UPGRADE_THRUST);
        int levelExplosion = mGameManager.getUpgradeLevel(GameManager.UPGRADE_EXPLOSION);

        mLevelPowerText.setText(String.valueOf(levelPower));
        mLevelDelayText.setText(String.valueOf(levelDelay));
        mLevelThrustText.setText(String.valueOf(levelThrust));
        mLevelExplosionText.setText(String.valueOf(levelExplosion));

        int pricePower = mGameManager.getUpgradePrice(GameManager.UPGRADE_POWER);
        int priceDelay = mGameManager.getUpgradePrice(GameManager.UPGRADE_DELAY);
        int priceThrust = mGameManager.getUpgradePrice(GameManager.UPGRADE_THRUST);
        int priceExplosion = mGameManager.getUpgradePrice(GameManager.UPGRADE_EXPLOSION);

        mPricePowerText.setText(String.format(Locale.getDefault(), "%d$", pricePower));
        mPriceDelayText.setText(String.format(Locale.getDefault(), "%d$", priceDelay));
        mPriceThrustText.setText(String.format(Locale.getDefault(), "%d$", priceThrust));
        mPriceExplosionText.setText(String.format(Locale.getDefault(), "%d$", priceExplosion));
    }

    void setGameManager(GameManager gameManager) {
        mGameManager = gameManager;
        if (getView() != null) {
            updateViews();
        }
    }

    void setCallback(Callback callback) {
        this.mCallback = callback;
    }

    @Override
    public void onDismiss(@NonNull DialogInterface dialog) {
        super.onDismiss(dialog);
        if (mCallback != null) {
            mCallback.onUpgradeFragmentDismiss();
        }
    }

    @Override
    public void onClick(View v) {

        int price;
        boolean succeed = false;

        switch (v.getId()) {
            case R.id.btn_upgrade_power:
                price = mGameManager.getUpgradePrice(GameManager.UPGRADE_POWER);
                succeed = mGameManager.pay(price);
                if (succeed) {
                    mGameManager.upgrade(GameManager.UPGRADE_POWER);
                }
                break;
            case R.id.btn_upgrade_delay:
                price = mGameManager.getUpgradePrice(GameManager.UPGRADE_DELAY);
                succeed = mGameManager.pay(price);
                if (succeed) {
                    mGameManager.upgrade(GameManager.UPGRADE_DELAY);
                }
                break;
            case R.id.btn_upgrade_thrust:
                price = mGameManager.getUpgradePrice(GameManager.UPGRADE_THRUST);
                succeed = mGameManager.pay(price);
                if (succeed) {
                    mGameManager.upgrade(GameManager.UPGRADE_THRUST);
                }
                break;
            case R.id.btn_upgrade_explosion:
                price = mGameManager.getUpgradePrice(GameManager.UPGRADE_EXPLOSION);
                succeed = mGameManager.pay(price);
                if (succeed) {
                    mGameManager.upgrade(GameManager.UPGRADE_EXPLOSION);
                }
                break;
        }

        updateViews();

        if (mCallback != null && succeed) {
            mCallback.onUpgradeSucceed();
        }
    }

}
