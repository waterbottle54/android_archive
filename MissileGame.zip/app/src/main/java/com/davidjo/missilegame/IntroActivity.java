package com.davidjo.missilegame;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class IntroActivity extends AppCompatActivity {

    private ImageView mIntroImage;
    private ViewGroup mIntroLayout;
    private TextView mIntroText;
    private ViewGroup mIntroMissionLayout;
    private TextView mIntroMissionText;
    private TextView mSkipText;

    private int mIntroStage;
    private int mIntroOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        hideSystemUI();

        // Get current stage this intro is to describe.
        mIntroStage = getIntent().getIntExtra(GameActivity.EXTRA_STAGE, 0);
        if (mIntroStage > getLastStage()) {
            finish();
            return;
        }

        // Initialize view variables.
        mIntroImage = findViewById(R.id.image_intro);
        mIntroLayout = findViewById(R.id.layout_intro);
        mIntroText = findViewById(R.id.txt_intro);
        mIntroMissionLayout = findViewById(R.id.layout_mission_objectives);
        mIntroMissionText = findViewById(R.id.txt_mission_objectives);

        mSkipText = findViewById(R.id.txt_skip_intro);
        mSkipText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mIntroOrder != getLastIntroOrder()) {
                    mIntroOrder++;
                    startCurrentIntro();
                }
            }
        });

        // Start intro.
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                startCurrentIntro();
            }
        });
    }

    private void hideSystemUI() {
        // Make full screen.
        View contentView = findViewById(android.R.id.content);
        contentView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }

    private Animation initIntroLayoutAscendAnim() {

        // Initialize intro text animation.

        Animation anim = AnimationUtils.loadAnimation(this, R.anim.ascend);

        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                // If the animation has finished, start the next intro.
                if (mIntroOrder < getLastIntroOrder()) {
                    mIntroOrder++;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            startCurrentIntro();
                        }
                    });
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });

        return anim;
    }

    private Animation initIntroImageFadeOutAnim() {

        // Initialize intro image animations.
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.fade_out);

        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) { }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (mIntroOrder < getLastIntroOrder()) {
                    // Set new intro image and make it fade in.
                    mIntroImage.setImageResource(getIntroImage(mIntroOrder));
                    mIntroImage.startAnimation(initIntroTextFadeInAnim());
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) { }
        });

        return anim;
    }

    private Animation initIntroTextFadeInAnim() {
        return AnimationUtils.loadAnimation(this, R.anim.fade_in);
    }

    private Animation initIntroMissionTextFadeInAnim() {
        return AnimationUtils.loadAnimation(this, R.anim.fade_in);
    }

    private void startCurrentIntro() {

        if (mIntroOrder < getLastIntroOrder()) {

            // Change current intro text and image
            mIntroText.setText(getIntroText(mIntroOrder));

            if (mIntroOrder == 0) {
                mIntroImage.setImageResource(getIntroImage(mIntroOrder));
            } else {
                // Make current image fade out and the next one fade in.
                mIntroImage.startAnimation(initIntroImageFadeOutAnim());
            }

            // Start ascending intro animation.
            mIntroLayout.startAnimation(initIntroLayoutAscendAnim());
        } else {

            // Hide intro image and show intro mission text.
            mIntroImage.startAnimation(initIntroImageFadeOutAnim());
            mIntroLayout.clearAnimation();
            mIntroLayout.setVisibility(View.GONE);
            mSkipText.setVisibility(View.GONE);

            mIntroMissionText.setText(getIntroMissionText());
            mIntroMissionLayout.startAnimation(initIntroMissionTextFadeInAnim());
        }

    }

    private int getLastIntroOrder() {
        return INTRO_TEXT[mIntroStage].length;
    }

    private int getLastStage() {
        return INTRO_TEXT.length - 1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int action = event.getAction();

        if (action == MotionEvent.ACTION_DOWN) {
            if (mIntroOrder == getLastIntroOrder()) {
                finish();
                return true;
            }
        }
        return super.onTouchEvent(event);
    }

    // Intro image, text resources

    public static int getLastIntroStage() {
        return INTRO_TEXT.length - 1;
    }

    public int getIntroImage(int order) {
        if (order < INTRO_IMAGE[mIntroStage].length) {
            return INTRO_IMAGE[mIntroStage][order];
        }
        return 0;
    }

    public int getIntroText(int order) {
        if (order < INTRO_TEXT[mIntroStage].length) {
            return INTRO_TEXT[mIntroStage][order];
        }
        return 0;
    }

    public int getIntroMissionText() {
        return INTRO_MISSION_TEXT[mIntroStage];
    }

    private static final int[][] INTRO_IMAGE = {
            { R.drawable.background_asteroid, R.drawable.background_white_house, },
            { R.drawable.background_asteroid },
            { R.drawable.background_military_room, R.drawable.background_asteroids },
            { R.drawable.background_asteroids },
    };

    private static final int[][] INTRO_TEXT = {
            { R.string.intro_00_00, R.string.intro_00_01 },
            { R.string.intro_01_00 },
            { R.string.intro_02_00, R.string.intro_02_01 },
            { R.string.intro_03_00 },
    };

    private static final int[] INTRO_MISSION_TEXT = {
            R.string.intro_mission_00,
            R.string.intro_mission_01,
            R.string.intro_mission_02,
            R.string.intro_mission_03,
    };

}
