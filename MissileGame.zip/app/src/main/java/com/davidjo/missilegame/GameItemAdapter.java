package com.davidjo.missilegame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Date;
import java.util.List;
import java.util.Locale;

public class GameItemAdapter extends RecyclerView.Adapter<GameItemAdapter.SavedGameViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(int position);
        void onItemLongClick(int position);
    }

    private Context context;
    private List<GameItem> gameList;
    private OnItemClickListener onItemClickListener;


    GameItemAdapter(Context context, List<GameItem> gameList) {
        this.context = context;
        this.gameList = gameList;
    }

    @NonNull
    @Override
    public SavedGameViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.game_item, parent, false);

        int width = parent.getWidth() / 2;
        int height = (int)(width / 1.618);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(width, height);
        v.setLayoutParams(params);

        return new SavedGameViewHolder(v, onItemClickListener);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBindViewHolder(@NonNull SavedGameViewHolder holder, int position) {

        GameManager game = gameList.get(position).game;

        Bitmap gameBitmap = getGameBitmap(game);
        holder.gameBitmapView.setImageBitmap(gameBitmap);

        String stage = String.format(Locale.getDefault(), "Stage %d", game.getStage());
        holder.stageText.setText(stage);

        String date = gameList.get(position).date.toLocaleString();
        int space = 0;
        for (int i = 0; i < 3; i++) {
            space = date.indexOf(' ', space + 1);
        }
        date = date.substring(0, space);

        holder.dateText.setText(date);
    }

    @Override
    public int getItemCount() {
        return gameList.size();
    }

    void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    private Bitmap getGameBitmap(GameManager game) {

        Bitmap gameBitmap = Bitmap.createBitmap(
                (int)game.getBoundaryWidth(),
                (int)game.getBoundaryHeight(),
                Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(gameBitmap);

        GameView gameView = new GameView(context);
        gameView.setGameManager(game);
        gameView.drawSurface(canvas);

        return gameBitmap;
    }

    // Game Item

    static class GameItem {
        GameManager game;
        Date date;

        GameItem(GameManager game, Date date) {
            this.game = game;
            this.date = date;
        }
    }

    // Custom View Holder

    static class SavedGameViewHolder extends RecyclerView.ViewHolder {

        ImageView gameBitmapView;
        TextView stageText;
        TextView dateText;

        SavedGameViewHolder(@NonNull View itemView, final OnItemClickListener onItemClickListener) {
            super(itemView);
            gameBitmapView = itemView.findViewById(R.id.game_view);
            stageText = itemView.findViewById(R.id.txt_stage);
            dateText = itemView.findViewById(R.id.txt_date);

            if (onItemClickListener != null) {
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int pos = getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION) {
                            onItemClickListener.onItemClick(pos);
                        }
                    }
                });
                itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        int pos = getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION) {
                            onItemClickListener.onItemLongClick(pos);
                            return true;
                        }
                        return false;
                    }
                });
            }
        }
    }

}
