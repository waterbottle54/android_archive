package com.davidjo.missilegame;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

//-------------- Game object classes ---------------//

@SuppressWarnings("WeakerAccess, unused")
class Planet extends DynamicBody {

    private float radius;
    private float hitPoint;
    private List<CollisionData> collisionData;

    static class CollisionData implements Serializable {
        private float x, y;
        private float degrees;
        private float xHit, yHit;
        private float xDir, yDir;
        private float radHit;

        public CollisionData(float x, float y, float degrees,
                             float xHit, float yHit, float xDir, float yDir, float radHit) {
            this.x = x;
            this.y = y;
            this.degrees = degrees;
            this.xHit = xHit;
            this.yHit = yHit;
            this.xDir = xDir;
            this.yDir = yDir;
            this.radHit = radHit;
        }
    }

    public Planet(float radius, float hitPoint) {
        super(null, 0, 0, 0);
        init(radius, hitPoint, null);
    }

    public Planet(SerializationData data) {
        super(null, 0, 0, 0);
        init(data.radius, data.hitPoint, data.collisionData);
        data.dynamicsData.apply(this);
        this.hitPoint = data.hitPoint;
    }

    private void init(float radius, float hitPoint, List<CollisionData> aCollisionData) {
        shape.addArc(new RectF(-radius, -radius, radius, radius),
                0, 360);
        this.radius = radius;
        this.hitPoint = hitPoint;

        collisionData = new ArrayList<>();
        if (aCollisionData != null) {
            for (CollisionData data : aCollisionData) {
                // Apply each collision.
                setHPosition(data.x);
                setVPosition(data.y);
                setSpinDegrees(data.degrees);
                damage(data.xHit, data.yHit, data.radHit, data.xDir, data.yDir);
            }
            setHPosition(0);
            setVPosition(0);
            setSpinDegrees(0);
        }
    }

    public float getRadius() { return radius; }

    public void getOriginalBounds(RectF rect) {
        rect.set(-radius, -radius, radius, radius);
    }

    public float getHitPoint() {
        return hitPoint;
    }

    public void setHitPoint(float hitPoint) {
        this.hitPoint = hitPoint;
    }

    public List<CollisionData> getCollisionData() {
        return new ArrayList<>(collisionData);
    }

    public void damage(float x, float y, float r, float xDir, float yDir) {
        Path pathDamage = new Path();
        Body bodyDamage;
        Matrix mat = new Matrix();
        Matrix matInv = new Matrix();

        // Make a body that represents the damaged part.
        pathDamage.addOval(new RectF(-r, -r, r, r), Path.Direction.CCW);
        bodyDamage = new Body(pathDamage, 0, 0, 0);
        bodyDamage.setHPosition(x);
        bodyDamage.setVPosition(y);

        // Subtract the damaged part from the planet body.
        subtract(bodyDamage);

        // Record collision data for possible serialization.
        collisionData.add(new CollisionData(
                getHPosition(), getVPosition(), getSpinDegrees(),
                x, y, xDir, yDir, r));
    }

    static class SerializationData implements Serializable {

        private DynamicsData dynamicsData;
        private float radius;
        private float hitPoint;
        private List<CollisionData> collisionData;

        public SerializationData(Planet planet) {
            dynamicsData = new DynamicsData(planet);
            radius = planet.getRadius();
            hitPoint = planet.getHitPoint();
            collisionData = planet.getCollisionData();
        }
    }
}

@SuppressWarnings("WeakerAccess, unused")
class Missile extends DynamicBody {

    private int type;
    private float power;
    private float explosion;

    private float hPosTarget;
    private float vPosTarget;
    private boolean hasTarget;

    public Missile(int type, float power, float explosion) {
        super(null, 0, 0, 0);
        init(type, power, explosion);
    }

    public Missile(SerializationData data) {
        super(null, 0, 0, 0);
        data.dynamicsData.apply(this);
        init(data.type, data.power, data.explosion);

        hasTarget = data.hasTarget;
        if (hasTarget) {
            hPosTarget = data.hPosTarget;
            vPosTarget = data.vPosTarget;
        }
    }

    public void init(int type, float power, float explosion) {
        this.type = type;
        this.power = power;
        this.explosion = explosion;
        shape.addRect(-10, -50, 10, 50, Path.Direction.CCW);
        shapeDegrees = -90;
    }


    public float getPower() { return power; }

    public float getExplosion() {
        return explosion;
    }

    public int getType() {
        return type;
    }

    public float getHPosTarget() {
        return hPosTarget;
    }

    public float getVPosTarget() {
        return vPosTarget;
    }

    public void setTarget(float x, float y) {
        hPosTarget = x;
        vPosTarget = y;
        hasTarget = true;
    }

    public void unsetTarget() {
        hasTarget = false;
    }

    public boolean hasTarget() {
        return hasTarget;
    }

    @Override
    public void update(float framerate) {
        super.update(framerate);
        setSpinDegrees( (float)(Math.atan2(getSpeedVDirection(), getSpeedHDirection()) * 180 / Math.PI) );
    }

    static class SerializationData implements Serializable {

        private DynamicsData dynamicsData;
        private int type;
        private float power;
        private float explosion;

        private float hPosTarget;
        private float vPosTarget;
        private boolean hasTarget;

        public SerializationData(Missile missile) {
            dynamicsData = new DynamicsData(missile);
            type = missile.getType();
            power = missile.getPower();
            explosion = missile.getExplosion();

            hasTarget = missile.hasTarget();
            if (hasTarget) {
                hPosTarget = missile.getHPosTarget();
                vPosTarget = missile.getVPosTarget();
            }
        }
    }
}

@SuppressWarnings("WeakerAccess, unused")
class Launcher extends DynamicBody {

    private static final String TAG = "Launcher";

    private float width;
    private float height;

    private int type;
    private int missileType;
    private long delay;
    private long remainingTime;
    private float power;
    private float thrust;
    private float explosion;

    private boolean aimMode;
    private boolean aimReady;
    private float targetDegrees;
    private float hPosTarget;
    private float vPosTarget;
    private float prevCross;


    public Launcher(float width, float height, long delay, float power, float thrust, float explosion,
                    int type, int missileType) {
        super(null, 0, 0, 0);
        init(width, height, delay, power, thrust, explosion, type, missileType);
    }

    public Launcher(SerializationData data) {
        super(null, 0, 0, 0);
        init(data.width, data.height, data.delay, data.power, data.thrust, data.explosion,
                data.type, data.missileType);
        data.dynamicsData.apply(this);

        remainingTime = data.remainingTime;
        aimMode = data.aimMode;
        aimReady = data.aimReady;
        targetDegrees = data.targetDegrees;
        hPosTarget = data.hPosTarget;
        vPosTarget = data.vPosTarget;
        prevCross = data.prevCross;
    }

    private void init(float width, float height, long delay, float power, float thrust, float explosion,
                      int type, int missileType) {
        this.width = width;
        this.height = height;
        shape.addRect(-width/2, -height/2, width/2, height/2,
                Path.Direction.CCW);

        this.delay = delay;
        this.power = power;
        this.thrust = thrust;
        this.explosion = explosion;

        this.type = type;
        this.missileType = missileType;
    }

    @Override
    public void update(float framerate) {
        super.update(framerate);
        if (remainingTime > 0) {
            remainingTime -= (1000 / framerate);
            if (remainingTime < 0)
                remainingTime = 0;
        }

        if (aimMode) {
            float cross = crossOfSpinAndTarget();
            if ((prevCross > 0 && cross < 0) || (prevCross < 0 && cross > 0)) {
                aimMode = false;
                aimReady = true;
                setSpinSpeed(0);
                setSpinDegrees(targetDegrees);
            }
        }
    }

    public void aim(float targetX, float targetY) {
        float dx = targetX - getHPosition();
        float dy = targetY - getVPosition();

        targetDegrees = (float) (Math.atan2(dy, dx) * (180 / Math.PI));
        this.hPosTarget = targetX;
        this.vPosTarget = targetY;

        float cross = crossOfSpinAndTarget();
        if (Math.abs(cross) < 0.001) {
            aimMode = false;
            aimReady = true;
            setSpinSpeed(0);
            setSpinDegrees(targetDegrees);

        } else {
            aimMode = true;
            aimReady = false;

            if (cross > 0.001) {
                setSpinSpeed(500);
            } else if (cross < -0.001) {
                setSpinSpeed(-500);
            }
            prevCross = crossOfSpinAndTarget();
        }
    }

    public boolean isAimReady() {
        return aimReady;
    }

    public Missile launch() {
        if (!isReloaded() || !isAimReady())
            return null;

        Missile missile = new Missile(missileType, power, explosion);
        missile.setHPosition(getHPosition());
        missile.setVPosition(getVPosition());
        missile.setVSpeed(getSpinVDirection() * thrust);
        missile.setHSpeed(getSpinHDirection() * thrust);

        remainingTime = delay;
        aimReady = false;

        return missile;
    }

    public boolean isReloaded() {
        return (remainingTime == 0);
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public long getDelay() {
        return delay;
    }

    public long getRemainingTime() {
        return remainingTime;
    }

    public float getPower() {
        return power;
    }

    public int getType() {
        return type;
    }

    public int getMissileType() {
        return missileType;
    }

    public void setPower(float power) {
        this.power = power;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    public float getThrust() {
        return thrust;
    }

    public void setThrust(float thrust) {
        this.thrust = thrust;
    }

    public float getExplosion() { return explosion; }

    public void setExplosion(float explosion) { this.explosion = explosion; }

    public float getHPosTarget() {
        return hPosTarget;
    }

    public float getVPosTarget() {
        return vPosTarget;
    }

    private float crossOfSpinAndTarget() {
        float xSpin = getSpinHDirection();
        float ySpin = getSpinVDirection();
        float xTarget = (float)Math.cos(targetDegrees * Math.PI / 180);
        float yTarget = (float)Math.sin(targetDegrees * Math.PI / 180);
        return (xSpin * yTarget - xTarget * ySpin);
    }
    
    static class SerializationData implements Serializable {

        private DynamicsData dynamicsData;
        private float width;
        private float height;
        private long delay;
        private long remainingTime;
        private float power;
        private float thrust;
        private float explosion;
        private int type;
        private int missileType;

        private boolean aimMode;
        private boolean aimReady;
        private float targetDegrees;
        private float hPosTarget;
        private float vPosTarget;
        private float prevCross;

        public SerializationData(Launcher launcher) {
            width = launcher.getWidth();
            height = launcher.getHeight();
            dynamicsData = new DynamicsData(launcher);
            delay = launcher.getDelay();
            remainingTime = launcher.getRemainingTime();
            power = launcher.getPower();
            thrust = launcher.getThrust();
            explosion = launcher.getExplosion();
            type = launcher.getType();
            missileType = launcher.getMissileType();

            aimMode = launcher.aimMode;
            aimReady = launcher.aimReady;
            targetDegrees = launcher.targetDegrees;
            hPosTarget = launcher.hPosTarget;
            vPosTarget = launcher.vPosTarget;
            prevCross = launcher.prevCross;
        }
    }
}

//-------------- DynamicsData class ---------------//
// For serialization of dynamics of game objects.

@SuppressWarnings("WeakerAccess, unused")
class DynamicsData implements Serializable {
    protected float x, y;
    protected float degrees;
    protected float xSpeed, ySpeed;
    protected float spinSpeed;

    public DynamicsData(DynamicBody body) {
        x = body.getHPosition();
        y = body.getVPosition();
        degrees = body.getSpinDegrees();
        xSpeed = body.getHSpeed();
        ySpeed = body.getVSpeed();
        spinSpeed = body.getSpinSpeed();
    }

    public void apply(DynamicBody body) {
        body.setHPosition(x);
        body.setVPosition(y);
        body.setSpinDegrees(degrees);
        body.setHSpeed(xSpeed);
        body.setVSpeed(ySpeed);
        body.setSpinSpeed(spinSpeed);
    }
}


