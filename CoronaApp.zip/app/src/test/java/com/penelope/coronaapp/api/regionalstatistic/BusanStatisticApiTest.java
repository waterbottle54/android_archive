package com.penelope.coronaapp.api.regionalstatistic;

import junit.framework.TestCase;

import java.util.Map;

public class BusanStatisticApiTest extends TestCase {

    public void testGet() {

        Map<String, Integer> map = BusanStatisticApi.get();

        System.out.println(map);
    }
}