package com.penelope.coronaapp.api.regionalstatistic;

import junit.framework.TestCase;

import java.util.Map;

public class SeoulStatisticApiTest extends TestCase {

    public void testGet() {

        Map<String, Integer> map = SeoulStatisticApi.get();

        System.out.println(map);
    }
}