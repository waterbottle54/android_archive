package com.penelope.coronaapp.api.regionalstatistic;

import junit.framework.TestCase;

import java.util.Map;

public class GyeongnamStatisticApiTest extends TestCase {

    public void testGet() {

        Map<String, Integer> map = GyeongnamStatisticApi.get();

        System.out.println(map);
    }
}