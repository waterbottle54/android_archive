package com.penelope.coronaapp.api.regionalstatistic;

import junit.framework.TestCase;

import java.util.Map;

public class GyeonggiStatisticApiTest extends TestCase {

    public void testGet() {

        Map<String, Integer> map = GyeonggiStatisticApi.get();

        System.out.println(map);
    }
}