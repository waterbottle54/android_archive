package com.penelope.coronaapp.api.testcenter;

import com.penelope.coronaapp.data.testcenter.TestCenter;

import junit.framework.TestCase;

import java.util.List;

public class TestCenterApiTest extends TestCase {

    public void testGet() {

    }
}