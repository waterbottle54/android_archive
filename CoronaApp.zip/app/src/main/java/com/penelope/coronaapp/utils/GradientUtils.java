package com.penelope.coronaapp.utils;

import android.graphics.Color;

public class GradientUtils {

    public static int getGradientColor(int darkColor, int lightColor, double p) {
        int r = (int) (Color.red(darkColor) * p + Color.red(lightColor) * (1 - p));
        int g = (int) (Color.green(darkColor) * p + Color.green(lightColor) * (1 - p));
        int b = (int) (Color.blue(darkColor) * p + Color.blue(lightColor) * (1 - p));
        return Color.rgb(r, g, b);
    }

}
