package com.penelope.coronaapp.ui.testcenter;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.coronaapp.data.testcenter.TestCenter;
import com.penelope.coronaapp.databinding.TestCenterItemBinding;

public class TestCentersAdapter extends ListAdapter<TestCenter, TestCentersAdapter.TestCenterViewHolder> {

    class TestCenterViewHolder extends RecyclerView.ViewHolder {

        private final TestCenterItemBinding binding;

        public TestCenterViewHolder(TestCenterItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(TestCenter model) {
            binding.textViewTestCenterName.setText(model.name);
            binding.textViewTestCenterLocation.setText(model.address);
            binding.textViewTestCenterTime.setText(model.openTime);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public TestCentersAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public TestCenterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        TestCenterItemBinding binding = TestCenterItemBinding.inflate(layoutInflater, parent, false);
        return new TestCenterViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TestCenterViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<TestCenter> {

        @Override
        public boolean areItemsTheSame(@NonNull TestCenter oldItem, @NonNull TestCenter newItem) {
            return oldItem.name.equals(newItem.name);
        }

        @Override
        public boolean areContentsTheSame(@NonNull TestCenter oldItem, @NonNull TestCenter newItem) {
            return oldItem.equals(newItem);
        }
    }

}