package com.penelope.coronaapp.ui.testcenter;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.coronaapp.data.testcenter.TestCenter;
import com.penelope.coronaapp.data.testcenter.TestCenterRepository;
import com.penelope.coronaapp.utils.OnCompleteListener;
import com.penelope.coronaapp.utils.RegionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class TestCenterViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<List<TestCenter>> testCenters = new MutableLiveData<>();

    private final MutableLiveData<List<String>> regions = new MutableLiveData<>();
    private final LiveData<List<String>> subregions;
    private final MutableLiveData<Integer> indexOfRegion = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> indexOfSubregion = new MutableLiveData<>(0);

    private final TestCenterRepository testCenterRepository;


    @Inject
    public TestCenterViewModel(TestCenterRepository testCenterRepository) {

        Map<String, List<String>> subregionMap = RegionUtils.getSubregionMap();
        regions.setValue(new ArrayList<>(subregionMap.keySet()));
        subregions = Transformations.switchMap(regions, regionList ->
                Transformations.map(indexOfRegion, index -> {
                    if (regionList == null || index == null) {
                        return null;
                    }
                    return subregionMap.get(regionList.get(index));
                })
        );

        this.testCenterRepository = testCenterRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<String>> getRegions() {
        return regions;
    }

    public LiveData<List<String>> getSubregions() {
        return subregions;
    }

    public LiveData<Integer> getIndexOfSubregion() {
        return indexOfSubregion;
    }

    public LiveData<List<TestCenter>> getTestCenters() {
        return testCenters;
    }


    public void onRegionSelected(int index) {
        indexOfRegion.setValue(index);
        indexOfSubregion.setValue(0);
    }

    public void onSubregionSelected(int index) {
        indexOfSubregion.setValue(index);
    }

    public void onSearchClick() {

        List<String> regionList = regions.getValue();
        List<String> subregionList = subregions.getValue();
        Integer indexRegion = indexOfRegion.getValue();
        Integer indexSubregion = indexOfSubregion.getValue();
        if (regionList == null || subregionList == null
                || indexRegion == null || indexSubregion == null) {
            return;
        }

        String region = regionList.get(indexRegion);
        String subregion = subregionList.get(indexSubregion);
        testCenterRepository.getTestCenters(subregion, region, subregion, new OnCompleteListener<List<TestCenter>>() {
            @Override
            public void onSuccess(List<TestCenter> data) {
                List<TestCenter> filtered = new ArrayList<>();
                for (TestCenter testCenter : data) {
                    if (!testCenter.name.contains("보건소")) {
                        filtered.add(testCenter);
                    }
                }
                testCenters.postValue(filtered);
            }

            @Override
            public void onFailure(Exception e) {
                e.printStackTrace();
                testCenters.postValue(null);
            }
        });

        event.setValue(new Event.ShowProgressBar());
    }


    public static class Event {

        public static class ShowProgressBar extends Event {
        }
    }

}