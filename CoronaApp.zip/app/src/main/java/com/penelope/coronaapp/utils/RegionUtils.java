package com.penelope.coronaapp.utils;

import com.naver.maps.geometry.LatLng;
import com.penelope.coronaapp.api.regionalstatistic.SeoulStatisticApi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegionUtils {

    public static Map<String, LatLng> getGpsMap() {

        Map<String, LatLng> map = new HashMap<>();

        map.put("서울", new LatLng(37.75532467089851, 127.11834707459989));
        map.put("인천", new LatLng(37.44570915272915, 126.70502901034423));
        map.put("경기", new LatLng(37.279188142688746, 127.25621655931182));
        map.put("강원", new LatLng(37.70043201403628, 128.29034952288652));
        map.put("대전", new LatLng(36.321515466250986, 127.39779781795298));
        map.put("세종", new LatLng(36.80466231978288, 127.36201278313689));
        map.put("충남", new LatLng(36.53227299842331, 126.86399468475018));
        map.put("충북", new LatLng(36.83938503661107, 127.85081862619895));
        map.put("광주", new LatLng(35.15955952509888, 126.83771689939628));
        map.put("전북", new LatLng(35.83880285634744, 127.09295850804519));
        map.put("전남", new LatLng(34.69447456042295, 126.70227921842167));
        map.put("대구", new LatLng(35.8394009518512, 128.5547056339612));
        map.put("경북", new LatLng(36.462814759824695, 128.61564219138347));
        map.put("부산", new LatLng(35.144836746393445, 129.0504799172953));
        map.put("울산", new LatLng(35.51678011617821, 129.27495839458007));
        map.put("경남", new LatLng(35.34167443786191, 128.28834561537573));
        map.put("제주", new LatLng(33.38714647291332, 126.55808070963701));

        return map;
    }

    public static Map<String, List<String>> getSubregionMap() {

        Map<String, List<String>> map = new HashMap<>();

        String[] seoul = {
                "강남구", "강동구", "강북구", "강서구", "관악구", "광진구", "구로구", "금천구", "노원구", "도봉구",
                "동대문구", "동작구", "마포구", "서대문구", "서초구", "성동구", "성북구", "송파구", "양천구", "영등포구",
                "용산구", "은평구", "종로구", "중구", "중랑구",
        };
        String[] busan = {
                "강서구", "금정구", "남구", "동구", "동래구", "부산진구", "북구", "사상구", "사하구", "서구",
                "수영구", "연제구", "영도구", "중구", "해운대구", "기장군"
        };
        String[] daegu = {
                "중구", "동구", "서구", "남구", "북구", "수성구", "달서구", "달성군",
        };
        String[] incheon = {
                "계양구", "남동구", "동구", "미추홀구", "부평구", "서구", "연수구", "중구", "강화군",
        };
        String[] daejeon = {
                "대덕구", "동구", "서구", "유성구", "중구",
        };
        String[] gwangju = {
                "광산구", "남구", "동구", "북구", "서구",
        };
        String[] ulsan = {
                "남구", "동구", "북구", "울주군",
        };
        String[] sejong = {
                "세종",
        };
        String[] gyeonggi = {
                "수원시", "성남시", "의정부시", "안양시", "부천시", "광명시", "평택시", "동두천시", "안산시",
                "고양시", "과천시", "구리시", "남양주시", "오산시", "시흥시", "군포시", "의왕시", "하남시",
                "용인시", "파주시", "이천시", "안성시", "김포시", "화성시", "광주시", "양주시", "포천시",
                "여주시",
        };
        String[] gangwon = {
                "춘천시", "원주시", "강릉시", "동해시", "태백시", "속초시", "삼척시", "홍천군", "횡성군",
                "영월군", "평창군", "정선군", "철원군", "화천군", "양구군", "인제군", "고성군", "양양군",
        };
        String[] chungbuk = {
                "청주시", "충주시", "제천시", "보은군", "옥천군", "영동군", "증평군", "진천군", "괴산군",
                "음성군", "단양군",
        };
        String[] chungnam = {
                "천안시", "공주시", "보령시", "아산시", "서산시", "논산시", "계룡시", "당진시", "금산군",
                "부여군", "서천군", "청양군", "홍성군", "예산군", "태안군",
        };
        String[] jeonbuk = {
                "전주시", "군산시", "익산시", "정읍시", "남원시", "김제시", "완주군", "진안군", "무주군",
                "장수군", "임실군", "순창군", "고창군", "부안군",
        };
        String[] jeonnam = {
                "목포시", "여수시", "순천시", "나주시", "광양시", "담양군", "곡성군", "구례군", "고흥군",
                "보성군", "화순군", "장흥군", "강진군", "해남군", "영암군", "무안군", "함평군", "영광군",
                "장성군", "완도군", "진도군", "신안군",
        };
        String[] gyeongbuk = {
                "포항시", "경주시", "김천시", "안동시", "구미시", "영주시", "영천시", "상주시", "문경시",
                "경산시", "군위군", "의성군", "청송군", "영양군", "영덕군", "청도군", "고령군", "성주군",
                "칠곡군", "예천군", "봉화군", "울진군", "울릉군",
        };
        String[] gyeongnam = {
                "창원시", "진주시", "통영시", "사천시", "김해시", "밀양시", "거제시", "양산시", "의령군",
                "함안군", "창녕군", "고성군", "남해군", "하동군", "산청군", "함양군", "거창군", "합천군",
        };
        String[] jeju = {
                "제주시", "서귀포시",
        };

        map.put("서울", Arrays.asList(seoul));
        map.put("인천", Arrays.asList(incheon));
        map.put("경기", Arrays.asList(gyeonggi));
        map.put("강원", Arrays.asList(gangwon));
        map.put("대전", Arrays.asList(daejeon));
        map.put("세종", Arrays.asList(sejong));
        map.put("충남", Arrays.asList(chungnam));
        map.put("충북", Arrays.asList(chungbuk));
        map.put("광주", Arrays.asList(gwangju));
        map.put("전북", Arrays.asList(jeonbuk));
        map.put("전남", Arrays.asList(jeonnam));
        map.put("대구", Arrays.asList(daegu));
        map.put("경북", Arrays.asList(gyeongbuk));
        map.put("부산", Arrays.asList(busan));
        map.put("울산", Arrays.asList(ulsan));
        map.put("경남", Arrays.asList(gyeongnam));
        map.put("제주", Arrays.asList(jeju));

        return map;
    }

}
