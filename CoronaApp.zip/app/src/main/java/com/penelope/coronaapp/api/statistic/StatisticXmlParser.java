package com.penelope.coronaapp.api.statistic;

import android.util.Xml;

import com.penelope.coronaapp.data.statistic.Statistic;
import com.penelope.coronaapp.data.statistic.StatisticData;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;

public class StatisticXmlParser {

    private static final String ns = null;

    public static Statistic parse(InputStream in) throws XmlPullParserException, IOException {
        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(in, null);
            parser.nextTag();
            String name = parser.getName();
            if (name.equals("response")) {
                return readResponse(parser);
            }
        } finally {
            in.close();
        }
        return null;
    }

    // response 태그 읽기
    private static Statistic readResponse(XmlPullParser parser) throws XmlPullParserException, IOException {

        parser.require(XmlPullParser.START_TAG, ns, "response");
        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String name = parser.getName();
            // body 태그 찾기
            if (name.equals("body")) {
                return readBody(parser);
            } else {
                skip(parser);
            }
        }
        return null;
    }

    // body 태그 읽기
    private static Statistic readBody(XmlPullParser parser) throws XmlPullParserException, IOException {

        parser.require(XmlPullParser.START_TAG, ns, "body");
        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String name = parser.getName();
            // items 태그 찾기
            if (name.equals("items")) {
                return readItems(parser);
            } else {
                skip(parser);
            }
        }
        return null;
    }

    // items 태그 읽기
    private static Statistic readItems(XmlPullParser parser) throws XmlPullParserException, IOException {

        Map<String, StatisticData> contents = new HashMap<>();
        StatisticData total = null;

        parser.require(XmlPullParser.START_TAG, ns, "items");

        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String name = parser.getName();
            // item 태그 찾기
            if (name.equals("item")) {
                Map.Entry<String, StatisticData> data = readItem(parser);
                if (data != null) {
                    String key = data.getKey();
                    if (key.equals("합계")) {
                        total = data.getValue();
                    } else if (!key.equals("검역")) {
                        contents.put(data.getKey(), data.getValue());
                    }
                }
            } else {
                skip(parser);
            }
        }

        if (contents.isEmpty() || total == null) {
            return null;
        }

        return new Statistic(contents, total);
    }

    private static Map.Entry<String, StatisticData> readItem(XmlPullParser parser) throws XmlPullParserException, IOException {

        String regionName = null;
        int increment = -1;
        int accumulation = -1;
        int death = -1;

        parser.require(XmlPullParser.START_TAG, ns, "item");
        while (parser.next() != XmlPullParser.END_TAG) {
            if (parser.getEventType() != XmlPullParser.START_TAG) {
                continue;
            }
            String name = parser.getName();
            // 태그 찾기
            switch (name) {
                case "gubun":
                    regionName = readText(parser);
                    break;
                case "incDec":
                    increment = readInteger(parser);
                    break;
                case "defCnt":
                    accumulation = readInteger(parser);
                    break;
                case "deathCnt":
                    death = readInteger(parser);
                    break;
                default:
                    skip(parser);
                    break;
            }
        }

        if (regionName == null || increment == -1 || accumulation == -1 || death == -1) {
            return null;
        }

        return new AbstractMap.SimpleEntry<>(regionName, new StatisticData(accumulation, increment, death));
    }

    // 태그 안의 텍스트 읽기
    private static String readText(XmlPullParser parser) throws IOException, XmlPullParserException {

        String result = "";
        if (parser.next() == XmlPullParser.TEXT) {
            result = parser.getText();
            parser.nextTag();
        }
        return result;
    }

    // 태그 안의 정수값 읽기
    private static int readInteger(XmlPullParser parser) throws IOException, XmlPullParserException {

        String result = "";
        if (parser.next() == XmlPullParser.TEXT) {
            result = parser.getText();
            parser.nextTag();
        }
        if (result.trim().isEmpty()) {
            return 0;
        }
        return Integer.parseInt(result);
    }

    // 태그 건너뛰기
    private static void skip(XmlPullParser parser) throws XmlPullParserException, IOException {

        if (parser.getEventType() != XmlPullParser.START_TAG) {
            throw new IllegalStateException();
        }
        int depth = 1;
        while (depth != 0) {
            switch (parser.next()) {
                case XmlPullParser.END_TAG:
                    depth--;
                    break;
                case XmlPullParser.START_TAG:
                    depth++;
                    break;
            }
        }
    }
}
