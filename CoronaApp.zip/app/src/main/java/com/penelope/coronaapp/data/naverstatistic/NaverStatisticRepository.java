package com.penelope.coronaapp.data.naverstatistic;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.penelope.coronaapp.api.naverstatistic.NaverStatisticApi;

import javax.inject.Inject;

public class NaverStatisticRepository {

    @Inject
    public NaverStatisticRepository() {
    }

    public LiveData<NaverStatistic> getNaverStatistic() {

        MutableLiveData<NaverStatistic> statistic = new MutableLiveData<>();

        new Thread(() -> {
            NaverStatistic statisticValue = NaverStatisticApi.get();
            statistic.postValue(statisticValue);
        }).start();

        return statistic;
    }


}
