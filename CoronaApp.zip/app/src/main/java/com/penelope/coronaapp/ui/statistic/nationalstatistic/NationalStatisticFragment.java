package com.penelope.coronaapp.ui.statistic.nationalstatistic;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraPosition;
import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.CircleOverlay;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.overlay.Overlay;
import com.naver.maps.map.overlay.OverlayImage;
import com.penelope.coronaapp.R;
import com.penelope.coronaapp.data.statistic.Statistic;
import com.penelope.coronaapp.data.statistic.StatisticData;
import com.penelope.coronaapp.databinding.FragmentNationalStatisticBinding;
import com.penelope.coronaapp.utils.GradientUtils;
import com.penelope.coronaapp.utils.NameUtils;
import com.penelope.coronaapp.utils.RegionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class NationalStatisticFragment extends Fragment implements OnMapReadyCallback {

    private FragmentNationalStatisticBinding binding;
    private NationalStatisticViewModel viewModel;

    private NaverMap map;
    private final List<Overlay> overlays = new ArrayList<>();
    private final List<Marker> markers = new ArrayList<>();
    private final Map<String, LatLng> gpsMap = RegionUtils.getGpsMap();


    public NationalStatisticFragment() {
        super(R.layout.fragment_national_statistic);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentNationalStatisticBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(NationalStatisticViewModel.class);

        MapFragment mapFragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        viewModel.getStatistic().observe(getViewLifecycleOwner(), statistic -> {
            if (statistic != null) {
                updateOverlays(statistic);
            } else {
                Snackbar.make(requireView(), "데이터를 불러오지 못했습니다", Snackbar.LENGTH_SHORT).show();
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof NationalStatisticViewModel.Event.NavigateToRegionalStatisticScreen) {
                String regionName = ((NationalStatisticViewModel.Event.NavigateToRegionalStatisticScreen) event).regionName;
                StatisticData statisticData = ((NationalStatisticViewModel.Event.NavigateToRegionalStatisticScreen) event).statisticData;
                NavDirections action = NationalStatisticFragmentDirections.actionNationalStatisticFragmentToRegionalStatisticFragment(regionName, statisticData);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {

        map = naverMap;

        naverMap.getUiSettings().setZoomControlEnabled(false);
        naverMap.getUiSettings().setAllGesturesEnabled(false);
        naverMap.setLiteModeEnabled(true);

        final LatLng focus = new LatLng(36.0, 127.9);
        final double zoom = 6;
        naverMap.moveCamera(CameraUpdate.toCameraPosition(new CameraPosition(focus, zoom)));

        Statistic statistic = viewModel.getStatistic().getValue();
        if (statistic != null) {
            updateOverlays(statistic);
        }
    }

    private void updateOverlays(Statistic statistic) {

        if (map == null) {
            return;
        }

        for (Overlay overlay : overlays) {
            overlay.setMap(null);
        }
        for (Marker marker : markers) {
            marker.setMap(null);
        }
        overlays.clear();
        markers.clear();

        Map<String, Double> distributions = statistic.getDistributions();

        for (Map.Entry<String, StatisticData> entry : statistic.contents.entrySet()) {

            String regionName = entry.getKey();
            StatisticData data = entry.getValue();
            LatLng gps = gpsMap.get(regionName);
            if (gps == null) {
                continue;
            }

            CircleOverlay overlay = new CircleOverlay(gps, 30000.0);
            Double distribution = distributions.get(regionName);
            int color = GradientUtils.getGradientColor(0xFF650606, 0xFFE60209, distribution == null ? 0 : distribution * 4);
            overlay.setColor(color);
            overlay.setOutlineWidth(1);
            overlay.setOutlineColor(0xFF777777);
            overlay.setMap(map);
            overlays.add(overlay);

            Marker marker = new Marker(gps.offset(10000, 0), OverlayImage.fromResource(R.drawable.ic_check));
            String caption = String.format(Locale.getDefault(), "%s\n%s", regionName, NameUtils.formatPopulation(data.increment));
            marker.setCaptionText(caption);
            marker.setMap(map);
            markers.add(marker);

            marker.setOnClickListener(o -> {
                viewModel.onRegionClick(regionName, data);
                return true;
            });
        }
    }

}

