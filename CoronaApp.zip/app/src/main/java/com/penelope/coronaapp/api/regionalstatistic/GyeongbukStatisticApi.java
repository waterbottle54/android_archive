package com.penelope.coronaapp.api.regionalstatistic;

import androidx.annotation.WorkerThread;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class GyeongbukStatisticApi {

    public static final String URL = "https://gb.go.kr/corona_main.htm";

    @WorkerThread
    public static Map<String, Integer> get() {

        Map<String, Integer> map = new HashMap<>();

        try {
            Document document = Jsoup.connect(URL).get();

            Elements subregions = document.select("div.city_corona dt");
            Elements numbers = document.select("div.city_corona dd span");

            for (int i = 2; i < subregions.size(); i++) {
                String name = subregions.get(i).text();
                if (name.isEmpty()) {
                    continue;
                }
                String strNumber = numbers.get(i).text();
                if (strNumber.isEmpty()) {
                    continue;
                }
                strNumber = strNumber.replace("+", "");
                int number = Integer.parseInt(strNumber);
                map.put(name, number);
            }

            return map;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

}
