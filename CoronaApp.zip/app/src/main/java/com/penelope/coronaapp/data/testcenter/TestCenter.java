package com.penelope.coronaapp.data.testcenter;

import java.io.Serializable;
import java.util.Objects;

public class TestCenter implements Serializable {

    public final String name;
    public final String address;
    public final String openTime;
    public final String region;
    public final String subregion;
    public final String facility;

    public TestCenter(String name, String address, String openTime, String region, String subregion, String facility) {
        this.name = name;
        this.address = address;
        this.openTime = openTime;
        this.region = region;
        this.subregion = subregion;
        this.facility = facility;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TestCenter that = (TestCenter) o;
        return name.equals(that.name) && address.equals(that.address) && openTime.equals(that.openTime) && region.equals(that.region) && subregion.equals(that.subregion) && facility.equals(that.facility);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, address, openTime, region, subregion, facility);
    }

    @Override
    public String toString() {
        return "TestCenter{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", openTime='" + openTime + '\'' +
                ", region='" + region + '\'' +
                ", subregion='" + subregion + '\'' +
                ", facility='" + facility + '\'' +
                '}';
    }
}
