package com.penelope.coronaapp.api.regionalstatistic;

import androidx.annotation.WorkerThread;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BusanStatisticApi {

    public static final String URL = "https://www.busan.go.kr/covid19/Corona19.do";

    @WorkerThread
    public static Map<String, Integer> get() {

        Map<String, Integer> map = new HashMap<>();

        try {
            Document document = Jsoup.connect(URL).get();

            Elements subregions = document.select("div.covid-state-table th:not(:first-child)");
            Elements tds = document.select("div.covid-state-table td:not(:first-child)");

            for (int i = 0; i < subregions.size(); i++) {
                String name = subregions.get(i).text();
                if (name.isEmpty()) {
                    continue;
                }
                Element td = tds.get(i);
                int number = Integer.parseInt(td.text().replace(",", ""));
                map.put(name, number);
            }

            return map;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
