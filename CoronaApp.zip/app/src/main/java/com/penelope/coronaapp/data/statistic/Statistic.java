package com.penelope.coronaapp.data.statistic;

import java.util.HashMap;
import java.util.Map;

public class Statistic {

    public final Map<String, StatisticData> contents;
    public final StatisticData total;

    public Statistic(Map<String, StatisticData> contents, StatisticData total) {
        this.contents = contents;
        this.total = total;
    }

    public Map<String, Double> getDistributions() {

        Map<String, Double> map = new HashMap<>();

        for (Map.Entry<String, StatisticData> data : contents.entrySet()) {
            int increment = data.getValue().increment;
            double distribution = total.increment == 0 ? 0 : (double) increment / total.increment;
            map.put(data.getKey(), distribution);
        }

        return map;
    }
}
