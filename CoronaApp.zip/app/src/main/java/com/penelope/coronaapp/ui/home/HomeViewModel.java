package com.penelope.coronaapp.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.coronaapp.api.naverstatistic.NaverStatisticApi;
import com.penelope.coronaapp.data.naverstatistic.NaverStatistic;
import com.penelope.coronaapp.data.naverstatistic.NaverStatisticRepository;
import com.penelope.coronaapp.data.statistic.Statistic;
import com.penelope.coronaapp.data.statistic.StatisticRepository;

import java.time.LocalDate;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HomeViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<Statistic> statistic;

    private final LiveData<NaverStatistic> naverStatistic;


    @Inject
    public HomeViewModel(StatisticRepository statisticRepository, NaverStatisticRepository naverStatisticRepository) {

        statistic = statisticRepository.getStatistic(LocalDate.now());

        naverStatistic = naverStatisticRepository.getNaverStatistic();
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Statistic> getStatistic() {
        return statistic;
    }

    public LiveData<NaverStatistic> getNaverStatistic() {
        return naverStatistic;
    }


    public void onSymptomsClick() {
        event.setValue(new Event.NavigateToSymptomsScreen());
    }

    public void onStatisticClick() {
        event.setValue(new Event.NavigateToStatisticScreen());
    }

    public void onTestCenterClick() {
        event.setValue(new Event.NavigateToTestCenterScreen());
    }

    public void onPublicTestCenterClick() {
        event.setValue(new Event.NavigateToPublicTestCenterScreen());
    }


    public static class Event {

        public static class NavigateToSymptomsScreen extends Event {
        }

        public static class NavigateToStatisticScreen extends Event {
        }

        public static class NavigateToTestCenterScreen extends Event {
        }

        public static class NavigateToPublicTestCenterScreen extends Event {
        }
    }

}