package com.penelope.coronaapp.ui.publictestcenter.publicmap;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.LocationTrackingMode;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.naver.maps.map.util.FusedLocationSource;
import com.penelope.coronaapp.R;
import com.penelope.coronaapp.data.testcenter.TestCenter;
import com.penelope.coronaapp.databinding.FragmentPublicMapBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PublicMapFragment extends Fragment implements OnMapReadyCallback, NaverMap.OnLocationChangeListener {

    public static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    private FragmentPublicMapBinding binding;
    private PublicMapViewModel viewModel;

    private final List<String> regions = new ArrayList<>();
    private final List<String> subregions = new ArrayList<>();
    private ArrayAdapter<String> regionAdapter;
    private ArrayAdapter<String> subregionAdapter;

    private NaverMap map;
    private final List<Marker> markers = new ArrayList<>();

    private FusedLocationSource fusedLocationSource;    // GPS 소스
    private ActivityResultLauncher<String> locationPermissionLauncher;


    public PublicMapFragment() {
        super(R.layout.fragment_public_map);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // GPS 소스를 초기화한다
        fusedLocationSource = new FusedLocationSource(this, LOCATION_PERMISSION_REQUEST_CODE);

        // 위치 퍼미션 런처를 정의한다
        locationPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                result -> {
                    if (fusedLocationSource.onRequestPermissionsResult(
                            LOCATION_PERMISSION_REQUEST_CODE,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            new int[]{result ? PackageManager.PERMISSION_GRANTED : PackageManager.PERMISSION_DENIED}
                    )) {
                        // 퍼미션 거절
                        if (!fusedLocationSource.isActivated()) {
                            map.setLocationTrackingMode(LocationTrackingMode.None);
                            return;
                        }
                        // 퍼미션 승인 시 네이버 맵 초기설정 진행
                        configureMap();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPublicMapBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PublicMapViewModel.class);

        MapFragment mapFragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        buildSpinners();

        binding.buttonSearch.setOnClickListener(v -> viewModel.onSearchClick());
        binding.cardViewMyLocation.setOnClickListener(v -> viewModel.onMyLocationClick());

        viewModel.getRegions().observe(getViewLifecycleOwner(), regionList -> {
            regions.clear();
            regions.addAll(regionList);
            regionAdapter.notifyDataSetChanged();
        });

        viewModel.getSubregions().observe(getViewLifecycleOwner(), subregionList -> {
            subregions.clear();
            subregions.addAll(subregionList);
            subregionAdapter.notifyDataSetChanged();
        });

        viewModel.getIndexOfSubregion().observe(getViewLifecycleOwner(), index ->
                binding.spinnerSubregions.setSelection(index));

        viewModel.getTestCenters().observe(getViewLifecycleOwner(), testCenters ->
                viewModel.getTestCentersLocations().observe(getViewLifecycleOwner(), testCentersLocations -> {
                    binding.progressBar.setVisibility(View.INVISIBLE);
                    if (testCenters == null || testCentersLocations == null) {
                        Snackbar.make(requireView(), "데이터를 불러오지 못했습니다", Snackbar.LENGTH_SHORT).show();
                        return;
                    }
                    updateMarkers(testCenters, testCentersLocations);
                    binding.textViewNoSearchResult.setVisibility(testCenters.isEmpty() ? View.VISIBLE : View.INVISIBLE);

                })
        );

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PublicMapViewModel.Event.ShowProgressBar) {
                binding.progressBar.setVisibility(View.VISIBLE);
            } else if (event instanceof PublicMapViewModel.Event.MoveCamera) {
                LatLng latLng = ((PublicMapViewModel.Event.MoveCamera) event).latLng;
                if (map != null && latLng != null) {
                    map.moveCamera(CameraUpdate.scrollTo(latLng));
                }
            } else if (event instanceof PublicMapViewModel.Event.NavigateToPublicDetailScreen) {
                TestCenter testCenter = ((PublicMapViewModel.Event.NavigateToPublicDetailScreen) event).testCenter;
                LatLng latLng = ((PublicMapViewModel.Event.NavigateToPublicDetailScreen) event).latLng;
                NavDirections action = PublicMapFragmentDirections.actionPublicMapFragmentToPublicDetailFragment(
                        testCenter, (float) latLng.latitude, (float) latLng.longitude);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    private void buildSpinners() {

        regionAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                regions
        );
        binding.spinnerRegions.setAdapter(regionAdapter);
        binding.spinnerRegions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                viewModel.onRegionSelected(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        subregionAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                subregions
        );
        binding.spinnerSubregions.setAdapter(subregionAdapter);
        binding.spinnerSubregions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                viewModel.onSubregionSelected(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {

        map = naverMap;
        map.moveCamera(CameraUpdate.zoomTo(10));

        // 퍼미션 여부를 확인하고 초기설정을 진행한다
        if (requireContext().checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            configureMap();
        } else {
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    private void configureMap() {

        // 네이버 맵 초기설정을 진행한다
        map.setLocationSource(fusedLocationSource);
        map.setLocationTrackingMode(LocationTrackingMode.Follow);
        map.getUiSettings().setLocationButtonEnabled(true);
        map.addOnLocationChangeListener(this);
    }

    @Override
    public void onLocationChange(@NonNull Location location) {
        viewModel.onLocationChange(location);
    }

    private void updateMarkers(List<TestCenter> testCenters, Map<String, LatLng> testCentersLocations) {

        if (map == null) {
            return;
        }

        for (Marker marker : markers) {
            marker.setMap(null);
        }
        markers.clear();

        for (TestCenter testCenter : testCenters) {

            LatLng latLng = testCentersLocations.get(testCenter.name);
            if (latLng == null) {
                continue;
            }

            Marker marker = new Marker(latLng);
            marker.setCaptionText(testCenter.name);
            marker.setMap(map);
            markers.add(marker);

            marker.setOnClickListener(overlay -> {
                viewModel.onTestCenterClick(testCenter, latLng);
                return true;
            });
        }
    }

}







