package com.penelope.coronaapp.ui.statistic.regionalstatistic;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.coronaapp.databinding.CountItemBinding;
import com.penelope.coronaapp.utils.NameUtils;

import java.util.Locale;
import java.util.Map;

public class CountsAdapter extends ListAdapter<Map.Entry<String, Integer>, CountsAdapter.CountViewHolder> {

    class CountViewHolder extends RecyclerView.ViewHolder {

        private final CountItemBinding binding;

        public CountViewHolder(CountItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Map.Entry<String, Integer> model) {

            String strName = String.format(Locale.getDefault(), "%s 확진자 ::", model.getKey());
            binding.textViewSubregionName.setText(strName);

            binding.textViewCount.setText(NameUtils.formatPopulation(model.getValue()));
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public CountsAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public CountViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        CountItemBinding binding = CountItemBinding.inflate(layoutInflater, parent, false);
        return new CountViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CountViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Map.Entry<String, Integer>> {

        @Override
        public boolean areItemsTheSame(@NonNull Map.Entry<String, Integer> oldItem, @NonNull Map.Entry<String, Integer> newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Map.Entry<String, Integer> oldItem, @NonNull Map.Entry<String, Integer> newItem) {
            return oldItem.equals(newItem);
        }
    }

}