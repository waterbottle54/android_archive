package com.penelope.coronaapp.ui.statistic.regionalstatistic;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.penelope.coronaapp.data.statistic.StatisticData;
import com.penelope.coronaapp.data.statistic.StatisticRepository;

import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class RegionalStatisticViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String regionName;
    private final StatisticData totalStatistic;

    private final LiveData<Map<String, Integer>> statistic;


    @Inject
    public RegionalStatisticViewModel(SavedStateHandle savedStateHandle, StatisticRepository statisticRepository) {

        regionName = savedStateHandle.get("regionName");
        totalStatistic = savedStateHandle.get("statisticData");

        statistic = statisticRepository.getRegionalStatistic(regionName);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getRegionName() {
        return regionName;
    }

    public StatisticData getTotalStatistic() {
        return totalStatistic;
    }

    public LiveData<Map<String, Integer>> getStatistic() {
        return statistic;
    }


    public static class Event {

    }

}