package com.penelope.coronaapp.utils;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.Locale;

public class NameUtils {

    public static String formatPopulation(int population) {
        return String.format(Locale.getDefault(), "%s명",
                NumberFormat.getInstance().format(population));
    }

    public static String formatPeriod(LocalDate date) {
        int year = date.getYear();
        int month = date.getMonthValue();
        int dayOfMonth = date.getDayOfMonth();
        return String.format(Locale.getDefault(),
                "%d.%02d.%02d 기준",
                year, month, dayOfMonth);
    }
}
