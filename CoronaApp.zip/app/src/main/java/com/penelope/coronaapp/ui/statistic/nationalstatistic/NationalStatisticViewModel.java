package com.penelope.coronaapp.ui.statistic.nationalstatistic;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.coronaapp.data.statistic.Statistic;
import com.penelope.coronaapp.data.statistic.StatisticData;
import com.penelope.coronaapp.data.statistic.StatisticRepository;

import java.time.LocalDate;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class NationalStatisticViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<Statistic> statistic;

    @Inject
    public NationalStatisticViewModel(StatisticRepository statisticRepository) {

        statistic = statisticRepository.getStatistic(LocalDate.now());
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Statistic> getStatistic() {
        return statistic;
    }


    public void onRegionClick(String regionName, StatisticData statisticData) {
        event.setValue(new Event.NavigateToRegionalStatisticScreen(regionName, statisticData));
    }


    public static class Event {

        public static class NavigateToRegionalStatisticScreen extends Event {
            public final String regionName;
            public final StatisticData statisticData;
            public NavigateToRegionalStatisticScreen(String regionName, StatisticData statisticData) {
                this.regionName = regionName;
                this.statisticData = statisticData;
            }
        }

    }

}



