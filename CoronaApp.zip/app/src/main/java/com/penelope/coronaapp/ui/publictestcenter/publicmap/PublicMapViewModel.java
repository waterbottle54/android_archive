package com.penelope.coronaapp.ui.publictestcenter.publicmap;

import android.location.Location;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.naver.maps.geometry.LatLng;
import com.penelope.coronaapp.api.geocoding.GeocodingApi;
import com.penelope.coronaapp.api.reversegeocoding.ReverseGeocodingApi;
import com.penelope.coronaapp.data.testcenter.TestCenter;
import com.penelope.coronaapp.data.testcenter.TestCenterRepository;
import com.penelope.coronaapp.utils.OnCompleteListener;
import com.penelope.coronaapp.utils.RegionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PublicMapViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<List<TestCenter>> testCenters = new MutableLiveData<>();
    private final LiveData<Map<String, LatLng>> testCentersLocations;

    private final MutableLiveData<List<String>> regions = new MutableLiveData<>();
    private final LiveData<List<String>> subregions;
    private final MutableLiveData<Integer> indexOfRegion = new MutableLiveData<>(0);
    private final MutableLiveData<Integer> indexOfSubregion = new MutableLiveData<>(0);

    private final TestCenterRepository testCenterRepository;
    private final GeocodingApi geocodingApi;
    private final ReverseGeocodingApi reverseGeocodingApi;

    private LatLng currentLocation;


    @Inject
    public PublicMapViewModel(TestCenterRepository testCenterRepository,
                              GeocodingApi geocodingApi,
                              ReverseGeocodingApi reverseGeocodingApi
    ) {

        Map<String, List<String>> subregionMap = RegionUtils.getSubregionMap();

        regions.setValue(new ArrayList<>(subregionMap.keySet()));

        subregions = Transformations.switchMap(regions, regionList ->
                Transformations.map(indexOfRegion, index ->
                        subregionMap.get(regionList.get(index)))
        );

        testCentersLocations = Transformations.switchMap(testCenters,
                testCenterRepository::getTestCentersLocations);

        this.testCenterRepository = testCenterRepository;
        this.geocodingApi = geocodingApi;
        this.reverseGeocodingApi = reverseGeocodingApi;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<String>> getRegions() {
        return regions;
    }

    public LiveData<List<String>> getSubregions() {
        return subregions;
    }

    public LiveData<Integer> getIndexOfSubregion() {
        return indexOfSubregion;
    }

    public LiveData<List<TestCenter>> getTestCenters() {
        return testCenters;
    }

    public LiveData<Map<String, LatLng>> getTestCentersLocations() {
        return testCentersLocations;
    }


    public void onRegionSelected(int index) {
        indexOfRegion.setValue(index);
        indexOfSubregion.setValue(0);
    }

    public void onSubregionSelected(int index) {
        indexOfSubregion.setValue(index);
    }

    public void onSearchClick() {

        List<String> regionList = regions.getValue();
        List<String> subregionList = subregions.getValue();
        Integer indexRegion = indexOfRegion.getValue();
        Integer indexSubregion = indexOfSubregion.getValue();
        assert regionList != null && subregionList != null && indexRegion != null && indexSubregion != null;

        String region = regionList.get(indexRegion);
        String subregion = subregionList.get(indexSubregion);

        searchTestCenters(region, subregion);
    }

    public void onTestCenterClick(TestCenter testCenter, LatLng latLng) {
        event.setValue(new Event.NavigateToPublicDetailScreen(testCenter, latLng));
    }

    public void onMyLocationClick() {

        reverseGeocodingApi.get(currentLocation.latitude, currentLocation.longitude,
                pair -> {
                    String region = pair.first;
                    String subregion = pair.second;
                    searchTestCenters(region, subregion);
                },
                Throwable::printStackTrace);
    }

    public void onLocationChange(Location location) {
        currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
    }


    private void searchTestCenters(String region, String subregion) {

        testCenterRepository.getTestCenters("보건소", region, subregion,
                new OnCompleteListener<List<TestCenter>>() {
                    @Override
                    public void onSuccess(List<TestCenter> data) {
                        testCenters.postValue(data);
                    }

                    @Override
                    public void onFailure(Exception e) {
                        e.printStackTrace();
                        testCenters.postValue(null);
                    }
                });

        event.setValue(new Event.ShowProgressBar());

        String address = region + " " + subregion;
        geocodingApi.get(address, latLng ->
                        event.postValue(new Event.MoveCamera(latLng)),
                e -> {
                }
        );
    }


    public static class Event {

        public static class ShowProgressBar extends Event {
        }

        public static class MoveCamera extends Event {
            public final LatLng latLng;

            public MoveCamera(LatLng latLng) {
                this.latLng = latLng;
            }
        }

        public static class NavigateToPublicDetailScreen extends Event {
            public final TestCenter testCenter;
            public final LatLng latLng;

            public NavigateToPublicDetailScreen(TestCenter testCenter, LatLng latLng) {
                this.testCenter = testCenter;
                this.latLng = latLng;
            }
        }
    }

}