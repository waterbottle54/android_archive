package com.penelope.coronaapp;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class CoronaApp extends Application {

}
