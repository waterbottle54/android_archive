package com.penelope.coronaapp.data.statistic;

import java.io.Serializable;

public class StatisticData implements Serializable {

    public final int accumulation;
    public final int increment;
    public final int death;

    public StatisticData(int accumulation, int increment, int death) {
        this.accumulation = accumulation;
        this.increment = increment;
        this.death = death;
    }
}
