package com.penelope.coronaapp.ui.publictestcenter.publicdetail;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.naver.maps.geometry.LatLng;
import com.penelope.coronaapp.data.testcenter.TestCenter;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PublicDetailViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();


    private final TestCenter testCenter;
    private final LatLng latLng;


    @Inject
    public PublicDetailViewModel(SavedStateHandle savedStateHandle) {

        testCenter = savedStateHandle.get("testCenter");
        Float latitude = savedStateHandle.get("latitude");
        Float longitude = savedStateHandle.get("longitude");
        assert latitude != null && longitude != null;
        latLng = new LatLng(latitude, longitude);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getTestCenterName() {
        return testCenter.name;
    }

    public String getTestCenterAddress() {
        return testCenter.address;
    }

    public String getTestCenterOpenTime() {
        return testCenter.openTime;
    }

    public String getTestCenterFacility() {
        return testCenter.facility;
    }

    public LatLng getLocation() {
        return latLng;
    }


    public static class Event {

    }

}