package com.penelope.coronaapp.api.regionalstatistic;

import androidx.annotation.WorkerThread;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class GangwonStatisticApi {

    public static final String URL = "http://www.provin.gangwon.kr/covid-19.html";

    @WorkerThread
    public static Map<String, Integer> get() {

        Map<String, Integer> map = new HashMap<>();

        try {
            Document document = Jsoup.connect(URL).get();

            Element element = document.select("#main > div.inner > div.condition > div > table > tbody > tr:nth-child(2) > td:nth-child(1)").get(0);
            String contents = element.text().replace(" ", "");
            String[] split = contents.split(",");

            System.out.println(contents);

            for (String str : split) {
                String regionName = str.substring(0, 2);
                Integer number = Integer.parseInt(str.substring(2));
                map.put(regionName, number);
            }

            return map;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}