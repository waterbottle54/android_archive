package com.penelope.coronaapp.data.statistic;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.penelope.coronaapp.api.regionalstatistic.BusanStatisticApi;
import com.penelope.coronaapp.api.regionalstatistic.GangwonStatisticApi;
import com.penelope.coronaapp.api.regionalstatistic.GyeongbukStatisticApi;
import com.penelope.coronaapp.api.regionalstatistic.GyeonggiStatisticApi;
import com.penelope.coronaapp.api.regionalstatistic.GyeongnamStatisticApi;
import com.penelope.coronaapp.api.regionalstatistic.SeoulStatisticApi;
import com.penelope.coronaapp.api.statistic.StatisticApi;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Inject;

public class StatisticRepository {

    @Inject
    public StatisticRepository() {
    }

    public LiveData<Statistic> getStatistic(LocalDate date) {

        MutableLiveData<Statistic> statistic = new MutableLiveData<>();

        new Thread(() -> {
            Statistic statisticValue = StatisticApi.get(date);
            statistic.postValue(statisticValue);
        }).start();

        return statistic;
    }

    public LiveData<Map<String, Integer>> getRegionalStatistic(String regionName) {

        MutableLiveData<Map<String, Integer>> statistic = new MutableLiveData<>();

        new Thread(() -> {
            switch (regionName) {
                case "서울":
                    statistic.postValue(SeoulStatisticApi.get());
                    break;
                case "부산":
                    statistic.postValue(BusanStatisticApi.get());
                    break;
                case "경기":
                    statistic.postValue(GyeonggiStatisticApi.get());
                    break;
                case "강원":
                    statistic.postValue(GangwonStatisticApi.get());
                    break;
                case "경북":
                    statistic.postValue(GyeongbukStatisticApi.get());
                    break;
                case "경남":
                    statistic.postValue(GyeongnamStatisticApi.get());
                    break;
                default:
                    statistic.postValue(new HashMap<>());
                    break;
            }
        }).start();

        return statistic;
    }

}
