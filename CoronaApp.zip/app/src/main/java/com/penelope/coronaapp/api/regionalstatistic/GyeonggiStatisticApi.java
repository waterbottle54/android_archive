package com.penelope.coronaapp.api.regionalstatistic;

import androidx.annotation.WorkerThread;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class GyeonggiStatisticApi {

    public static final String URL = "https://www.gg.go.kr/contents/contents.do?ciIdx=1150&menuId=2909";

    @WorkerThread
    public static Map<String, Integer> get() {

        Map<String, Integer> map = new HashMap<>();

        try {
            Document document = Jsoup.connect(URL).get();

            Elements subregions = document.select("div.zone dl:not([class]) dt");
            Elements numbers = document.select("div.zone dl:not([class]) dd small.count");

            for (int i = 0; i < subregions.size(); i++) {
                String name = subregions.get(i).text();
                if (name.isEmpty()) {
                    continue;
                }
                String strNumber = numbers.get(i).text();
                if (strNumber.isEmpty()) {
                    continue;
                }
                strNumber = strNumber.replace(" ", "")
                        .replace(",", "")
                        .replace("+", "")
                        .replace("확진자:", "");
                int number = Integer.parseInt(strNumber);
                map.put(name, number);
            }

            return map;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

}
