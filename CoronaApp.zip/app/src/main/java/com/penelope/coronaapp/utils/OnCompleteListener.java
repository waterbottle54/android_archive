package com.penelope.coronaapp.utils;

public interface OnCompleteListener <T> {

    void onSuccess(T data);
    void onFailure(Exception e);
}
