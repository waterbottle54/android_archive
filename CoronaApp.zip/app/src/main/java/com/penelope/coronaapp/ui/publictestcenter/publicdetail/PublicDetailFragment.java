package com.penelope.coronaapp.ui.publictestcenter.publicdetail;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.penelope.coronaapp.R;
import com.penelope.coronaapp.databinding.FragmentPublicDetailBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PublicDetailFragment extends Fragment implements OnMapReadyCallback {

    private FragmentPublicDetailBinding binding;
    private PublicDetailViewModel viewModel;


    public PublicDetailFragment() {
        super(R.layout.fragment_public_detail);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPublicDetailBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PublicDetailViewModel.class);

        MapFragment mapFragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        binding.textViewPublicTestCenterName.setText(viewModel.getTestCenterName());
        binding.textViewTestCenterAddress.setText(viewModel.getTestCenterAddress());
        binding.textViewTestCenterOpenTime.setText(viewModel.getTestCenterOpenTime());
        if (!viewModel.getTestCenterFacility().isEmpty()) {
            binding.textViewTestCenterFacility.setText(viewModel.getTestCenterFacility());
        } else {
            binding.textViewTestCenterFacility.setText("제공되지 않음");
        }

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {

        naverMap.moveCamera(CameraUpdate.scrollAndZoomTo(viewModel.getLocation(), 14));

        Marker marker = new Marker(viewModel.getLocation());
        marker.setCaptionText(viewModel.getTestCenterName());
        marker.setMap(naverMap);
    }

}