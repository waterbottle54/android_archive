package com.penelope.coronaapp.di;

import android.app.Application;

import com.penelope.coronaapp.api.geocoding.GeocodingApi;
import com.penelope.coronaapp.api.reversegeocoding.ReverseGeocodingApi;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn(SingletonComponent.class)
public class AppModule {

    @Provides
    @Singleton
    public GeocodingApi providesGeocodingApi(Application application) {
        return new GeocodingApi(application);
    }

    @Provides
    @Singleton
    public ReverseGeocodingApi providesReverseGeocodingApi(Application application) {
        return new ReverseGeocodingApi(application);
    }

}
