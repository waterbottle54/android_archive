package com.penelope.coronaapp.data.naverstatistic;

public class NaverStatistic {

    public final int dailyDeaths;
    public final int emergent;


    public NaverStatistic(int dailyDeaths, int emergent) {
        this.dailyDeaths = dailyDeaths;
        this.emergent = emergent;
    }

    public int getDailyDeaths() {
        return dailyDeaths;
    }

    public int getEmergent() {
        return emergent;
    }
}
