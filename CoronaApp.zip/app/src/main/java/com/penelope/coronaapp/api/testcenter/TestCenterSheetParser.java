package com.penelope.coronaapp.api.testcenter;

import com.penelope.coronaapp.data.testcenter.TestCenter;

import java.util.ArrayList;
import java.util.List;

import jxl.Sheet;

public class TestCenterSheetParser {

    public static List<TestCenter> parse(Sheet sheet) {

        List<TestCenter> testCenters = new ArrayList<>();

        for (int row = 1; row < sheet.getRows(); row++) {
            String region = sheet.getCell(1, row).getContents();
            String subregion = sheet.getCell(2, row).getContents();
            String name = sheet.getCell(3, row).getContents();
            String address = sheet.getCell(4, row).getContents();
            String openTime = sheet.getCell(5, row).getContents();
            String facility = sheet.getCell(11, row).getContents();

            if (name.isEmpty()) {
                continue;
            }
            testCenters.add(new TestCenter(name, address, openTime, region, subregion, facility));
        }

        return testCenters;
    }

}

