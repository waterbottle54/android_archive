package com.penelope.coronaapp.api.testcenter;

import androidx.annotation.WorkerThread;

import com.penelope.coronaapp.data.testcenter.TestCenter;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class TestCenterApi {

    public static final String URL_FORMAT = "https://www.mohw.go.kr/react/ncov/selclinic05ex.jsp?tabno=4&SEARCHVALUE={QUERY}";
    public static final String ARG_QUERY = "{QUERY}";


    @WorkerThread
    public static List<TestCenter> get(String query) {

        try {
            String strUrl = URL_FORMAT.replace(ARG_QUERY, query);
            java.net.URL url = new URL(strUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(10000);

            Workbook workbook = Workbook.getWorkbook(conn.getInputStream());
            Sheet sheet = workbook.getSheet(0);

            return TestCenterSheetParser.parse(sheet);

        } catch (IOException | BiffException e) {
            e.printStackTrace();
        }

        return null;
    }

}
