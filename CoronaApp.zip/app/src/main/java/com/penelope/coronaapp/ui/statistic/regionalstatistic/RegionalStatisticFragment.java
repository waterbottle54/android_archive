package com.penelope.coronaapp.ui.statistic.regionalstatistic;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.snackbar.Snackbar;
import com.penelope.coronaapp.R;
import com.penelope.coronaapp.databinding.FragmentRegionalStatisticBinding;
import com.penelope.coronaapp.utils.NameUtils;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RegionalStatisticFragment extends Fragment {

    private FragmentRegionalStatisticBinding binding;
    private RegionalStatisticViewModel viewModel;


    public RegionalStatisticFragment() {
        super(R.layout.fragment_regional_statistic);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentRegionalStatisticBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RegionalStatisticViewModel.class);

        binding.textViewPeriod.setText(NameUtils.formatPeriod(LocalDate.now().minusDays(1)));

        String regionName = String.format(Locale.getDefault(), "%s 확진자", viewModel.getRegionName());
        binding.textViewRegionName.setText(regionName);

        binding.textViewCount.setText(NameUtils.formatPopulation(viewModel.getTotalStatistic().increment));

        CountsAdapter adapter = new CountsAdapter();
        binding.recyclerCount.setAdapter(adapter);
        binding.recyclerCount.setHasFixedSize(true);

        binding.buttonCheckStatistic.setOnClickListener(v -> browseStatistic());

        viewModel.getStatistic().observe(getViewLifecycleOwner(), statistic -> {
            if (statistic != null) {
                adapter.submitList(new ArrayList<>(statistic.entrySet()));
                binding.groupNoRegionalStatistic.setVisibility(statistic.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            } else {
                Snackbar.make(requireView(), "데이터를 불러오지 못했습니다", Snackbar.LENGTH_SHORT).show();
            }
            binding.progressBar2.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void browseStatistic() {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://ncov.mohw.go.kr/bdBoardList_Real.do?brdId=1&brdGubun=13&ncvContSeq=&contSeq=&board_id=&gubun="));
        startActivity(intent);
    }

}