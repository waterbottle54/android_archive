package com.penelope.coronaapp.data.testcenter;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.naver.maps.geometry.LatLng;
import com.penelope.coronaapp.api.geocoding.GeocodingApi;
import com.penelope.coronaapp.api.testcenter.TestCenterApi;
import com.penelope.coronaapp.utils.OnCompleteListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;


public class TestCenterRepository {

    private final GeocodingApi geocodingApi;

    @Inject
    public TestCenterRepository(GeocodingApi geocodingApi) {
        this.geocodingApi = geocodingApi;
    }

    public void getTestCenters(String query, String region, String subregion, OnCompleteListener<List<TestCenter>> onCompleteListener) {

        new Thread(() -> {
            List<TestCenter> testCenterList = TestCenterApi.get(query);
            if (testCenterList != null) {
                List<TestCenter> filtered = new ArrayList<>();
                for (TestCenter testCenter : testCenterList) {
                    if (testCenter.region.equals(region) && testCenter.subregion.equals(subregion)) {
                        filtered.add(testCenter);
                    }
                }
                onCompleteListener.onSuccess(filtered);
            } else {
                onCompleteListener.onFailure(new Exception("Test centers not fetched"));
            }
        }).start();
    }

    public LiveData<Map<String, LatLng>> getTestCentersLocations(List<TestCenter> testCenters) {

        MutableLiveData<Map<String, LatLng>> map = new MutableLiveData<>(new HashMap<>());

        for (TestCenter testCenter : testCenters) {
            geocodingApi.get(testCenter.address,
                    latLng -> {
                        Map<String, LatLng> oldMap = map.getValue();
                        assert oldMap != null;
                        Map<String, LatLng> newMap = new HashMap<>(oldMap);

                        if (latLng != null) {
                            newMap.put(testCenter.name, latLng);
                            map.postValue(newMap);
                        } else {
                            String query = testCenter.region + " " + testCenter.subregion;
                            geocodingApi.get(query,
                                    latLng2 -> {
                                        if (latLng2 != null) {
                                            newMap.put(testCenter.name, latLng2);
                                            map.postValue(newMap);
                                        }
                                    },
                                    e -> {
                                    }
                            );
                        }
                    },
                    e -> {
                    });
        }

        return map;
    }

}
