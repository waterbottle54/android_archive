package com.penelope.coronaapp.ui.symptoms;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.penelope.coronaapp.R;
import com.penelope.coronaapp.databinding.FragmentSymptomsBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SymptomsFragment extends Fragment {

    private FragmentSymptomsBinding binding;
    private SymptomsViewModel viewModel;


    public SymptomsFragment() {
        super(R.layout.fragment_symptoms);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSymptomsBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SymptomsViewModel.class);

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}