package com.penelope.coronaapp.ui.home;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.android.material.snackbar.Snackbar;
import com.penelope.coronaapp.R;
import com.penelope.coronaapp.databinding.FragmentHomeBinding;
import com.penelope.coronaapp.utils.NameUtils;

import java.time.LocalDate;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;


    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentHomeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);
        
        binding.buttonSymptoms.setOnClickListener(v -> viewModel.onSymptomsClick());
        binding.buttonStatistic.setOnClickListener(v -> viewModel.onStatisticClick());
        binding.buttonTestCenter.setOnClickListener(v -> viewModel.onTestCenterClick());
        binding.buttonPublicTestCenter.setOnClickListener(v -> viewModel.onPublicTestCenterClick());

        binding.textViewPeriod.setText(NameUtils.formatPeriod(LocalDate.now().minusDays(1)));

        viewModel.getStatistic().observe(getViewLifecycleOwner(), statistic -> {
            if (statistic != null) {
                int accumulation = statistic.total.accumulation;
                int increment = statistic.total.increment;
                binding.textViewNumberAccumulated.setText(NameUtils.formatPopulation(accumulation));
                binding.textViewNumberToday.setText(NameUtils.formatPopulation(increment));
            } else {
                Snackbar.make(requireView(), "데이터를 불러오지 못했습니다", Snackbar.LENGTH_SHORT).show();
            }
        });

        viewModel.getNaverStatistic().observe(getViewLifecycleOwner(), naverStatistic -> {
            if (naverStatistic != null) {
                binding.textViewNumberDied.setText(NameUtils.formatPopulation(naverStatistic.dailyDeaths));
                binding.textViewEmergent.setText(NameUtils.formatPopulation(naverStatistic.emergent));
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof HomeViewModel.Event.NavigateToSymptomsScreen) {
                NavDirections action = HomeFragmentDirections.actionHomeFragmentToSymptomsFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof HomeViewModel.Event.NavigateToStatisticScreen) {
                NavDirections action = HomeFragmentDirections.actionHomeFragmentToNationalStatisticFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof HomeViewModel.Event.NavigateToTestCenterScreen) {
                NavDirections action = HomeFragmentDirections.actionHomeFragmentToTestCenterFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof HomeViewModel.Event.NavigateToPublicTestCenterScreen) {
                NavDirections action = HomeFragmentDirections.actionHomeFragmentToPublicTestCenterFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}