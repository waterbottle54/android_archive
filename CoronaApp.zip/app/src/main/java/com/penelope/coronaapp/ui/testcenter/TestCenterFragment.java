package com.penelope.coronaapp.ui.testcenter;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.snackbar.Snackbar;
import com.penelope.coronaapp.R;
import com.penelope.coronaapp.databinding.FragmentTestCenterBinding;

import java.util.ArrayList;
import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class TestCenterFragment extends Fragment {

    private FragmentTestCenterBinding binding;
    private TestCenterViewModel viewModel;

    private final List<String> regions = new ArrayList<>();
    private final List<String> subregions = new ArrayList<>();
    private ArrayAdapter<String> regionAdapter;
    private ArrayAdapter<String> subregionAdapter;


    public TestCenterFragment() {
        super(R.layout.fragment_test_center);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentTestCenterBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(TestCenterViewModel.class);

        buildSpinners();

        binding.buttonSearch.setOnClickListener(v -> viewModel.onSearchClick());

        TestCentersAdapter adapter = new TestCentersAdapter();
        binding.recyclerTestCenters.setAdapter(adapter);
        binding.recyclerTestCenters.setHasFixedSize(true);

        viewModel.getRegions().observe(getViewLifecycleOwner(), regionList -> {
            regions.clear();
            regions.addAll(regionList);
            regionAdapter.notifyDataSetChanged();
        });

        viewModel.getSubregions().observe(getViewLifecycleOwner(), subregionList -> {
            subregions.clear();
            subregions.addAll(subregionList);
            subregionAdapter.notifyDataSetChanged();
        });

        viewModel.getIndexOfSubregion().observe(getViewLifecycleOwner(), index ->
                binding.spinnerSubregions.setSelection(index));

        viewModel.getTestCenters().observe(getViewLifecycleOwner(), testCenters -> {
            if (testCenters != null) {
                adapter.submitList(testCenters);
                binding.textViewNoSearchResult.setVisibility(testCenters.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            } else {
                Snackbar.make(requireView(), "데이터를 불러오지 못했습니다", Snackbar.LENGTH_SHORT).show();
            }
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof TestCenterViewModel.Event.ShowProgressBar) {
                binding.progressBar.setVisibility(View.VISIBLE);
            }
        });
    }

    private void buildSpinners() {

        regionAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                regions
        );
        binding.spinnerRegions.setAdapter(regionAdapter);
        binding.spinnerRegions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                viewModel.onRegionSelected(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        subregionAdapter = new ArrayAdapter<>(
                requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                subregions
        );
        binding.spinnerSubregions.setAdapter(subregionAdapter);
        binding.spinnerSubregions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                viewModel.onSubregionSelected(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}