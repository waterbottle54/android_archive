package com.penelope.coronaapp.api.naverstatistic;

import androidx.annotation.WorkerThread;

import com.penelope.coronaapp.data.naverstatistic.NaverStatistic;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.IOException;

public class NaverStatisticApi {

    public static final String URL = "https://search.naver.com/search.naver?where=nexearch&sm=top_sly.hst&fbm=0&acr=1&acq=%EC%BD%94%EB%A1%9C%EB%82%98+&qdt=0&ie=utf8&query=%EC%BD%94%EB%A1%9C%EB%82%98+%ED%98%84%ED%99%A9";

    @WorkerThread
    public static NaverStatistic get() {

        int emergent, deaths;

        try {
            Document document = Jsoup.connect(URL).get();

            Element elemEmergent = document.selectFirst("#_cs_production_type > div > div.main_tab_area > div > div > ul > li.info_02 > p");
            Element elemDeath = document.selectFirst("#_cs_production_type > div > div.main_tab_area > div > div > ul > li.info_04 > p");
            if (elemEmergent == null || elemDeath == null) {
                return null;
            }

            String strEmergent = elemEmergent.text().replace(",", "");
            String strDeaths = elemDeath.text().replace(",", "");

            try {
                emergent = Integer.parseInt(strEmergent);
                deaths = Integer.parseInt(strDeaths);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                return null;
            }

            return new NaverStatistic(deaths, emergent);

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
