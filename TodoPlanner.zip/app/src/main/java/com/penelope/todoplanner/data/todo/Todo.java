package com.penelope.todoplanner.data.todo;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.time.LocalDate;
import java.util.Objects;

@Entity(tableName = "todo_table")
public class Todo {

    @NonNull
    @PrimaryKey
    private final String title;
    private final int year;
    private final int month;
    private final int dayOfMonth;
    private final boolean isCompleted;
    private final long epochDay;
    private final long created;

    public Todo(@NonNull String title, int year, int month, int dayOfMonth, boolean isCompleted, long epochDay, long created) {
        this.title = title;
        this.year = year;
        this.month = month;
        this.dayOfMonth = dayOfMonth;
        this.isCompleted = isCompleted;
        this.epochDay = epochDay;
        this.created = created;
    }

    @Ignore
    public Todo(@NonNull String title, int year, int month, int dayOfMonth) {
        this.title = title;
        this.year = year;
        this.month = month;
        this.dayOfMonth = dayOfMonth;
        this.isCompleted = false;
        this.epochDay = LocalDate.of(year, month, dayOfMonth).toEpochDay();
        this.created = System.currentTimeMillis();
    }

    @NonNull
    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDayOfMonth() {
        return dayOfMonth;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public long getEpochDay() {
        return epochDay;
    }

    public long getCreated() {
        return created;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Todo todo = (Todo) o;
        return year == todo.year && month == todo.month && dayOfMonth == todo.dayOfMonth && isCompleted == todo.isCompleted && created == todo.created && title.equals(todo.title);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, year, month, dayOfMonth, isCompleted, created);
    }
}
