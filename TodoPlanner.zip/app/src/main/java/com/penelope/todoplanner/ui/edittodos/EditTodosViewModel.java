package com.penelope.todoplanner.ui.edittodos;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.data.todo.TodoDao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class EditTodosViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<LocalDate> date = new MutableLiveData<>(LocalDate.now());

    private final LiveData<List<Todo>> todos;

    private String title = "";

    private final TodoDao todoDao;


    @Inject
    public EditTodosViewModel(SavedStateHandle savedStateHandle, TodoDao todoDao) {

        date.setValue(savedStateHandle.get("date"));

        todos = Transformations.switchMap(date, d -> d != null
                ? todoDao.getTodosLive(d.getYear(), d.getMonthValue(), d.getDayOfMonth())
                : new MutableLiveData<>(new ArrayList<>())
        );

        this.todoDao = todoDao;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<LocalDate> getDate() {
        return date;
    }

    public LiveData<List<Todo>> getTodos() {
        return todos;
    }


    public void onDateClick() {
        LocalDate d = date.getValue();
        event.setValue(new Event.PromptDate(d != null ? d : LocalDate.now()));
    }

    public void onDateSelected(LocalDate d) {
        date.setValue(d);
    }

    public void onTitleChange(String text) {
        title = text.trim();
    }

    public void onAddTodoClick() {

        LocalDate d = date.getValue();
        if (d == null) {
            return;
        }

        if (title.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("제목을 입력해주세요"));
            return;
        }

        Todo todo = new Todo(title, d.getYear(), d.getMonthValue(), d.getDayOfMonth());
        new Thread(() -> todoDao.addTodo(todo)).start();
    }

    public void onDeleteAllClick() {
        LocalDate d = date.getValue();
        if (d != null) {
            new Thread(() -> todoDao.deleteAll(d.getYear(), d.getMonthValue(), d.getDayOfMonth())).start();
        }
    }

    public void onDeleteTodoClick(Todo todo) {
        new Thread(() -> todoDao.deleteTodo(todo)).start();
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class PromptDate extends Event {
            public final LocalDate currentDate;

            public PromptDate(LocalDate currentDate) {
                this.currentDate = currentDate;
            }
        }
    }

}


