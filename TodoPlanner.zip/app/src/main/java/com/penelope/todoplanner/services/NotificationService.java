package com.penelope.todoplanner.services;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import androidx.room.Room;

import com.penelope.todoplanner.MainActivity;
import com.penelope.todoplanner.R;
import com.penelope.todoplanner.TodoPlannerApplication;
import com.penelope.todoplanner.data.PreferenceData;
import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.data.todo.TodoDao;
import com.penelope.todoplanner.data.todo.TodoDatabase;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class NotificationService extends Service {

    private TodoDao todoDao;
    private PreferenceData preferenceData;
    private NotificationManager notificationManager;

    private final List<LocalDateTime> notificationHistory = new ArrayList<>();


    public NotificationService() {
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        TodoDatabase todoDatabase = Room.databaseBuilder(this, TodoDatabase.class, "todo_database")
                .fallbackToDestructiveMigration()
                .build();

        todoDao = todoDatabase.todoDao();

        preferenceData = new PreferenceData(this);

        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        new Thread(() -> {
            while (true) {
                try {
                    boolean isNotificationOn = preferenceData.isNotificationOn();
                    if (isNotificationOn) {
                        LocalDateTime now = LocalDateTime.now().withSecond(0).withNano(0);
                        List<LocalTime> times = preferenceData.getTimes();

                        for (LocalTime time : times) {
                            if (now.toLocalTime().equals(time) && !notificationHistory.contains(now)) {
                                List<Todo> todos = todoDao.getTodos(now.getYear(), now.getMonthValue(), now.getDayOfMonth());
                                notificationManager.notify(101, createTimeNotification(todos));
                                notificationHistory.add(now);
                            }
                        }
                    }
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        startForeground(100, createForegroundNotification());

        return START_STICKY;
    }

    private Notification createForegroundNotification() {

        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 100, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

         return new Notification.Builder(this, TodoPlannerApplication.CHANNEL_ID_FOREGROUND)
                .setContentIntent(contentIntent)
                .setSmallIcon(R.drawable.ic_list)
                .setContentTitle("Todo Planner")
                .build();
    }

    private Notification createTimeNotification(List<Todo> dailyTodos) {

        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this, 100, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        String contentText = dailyTodos.isEmpty() ? "오늘 하루 일정을 추가해보세요" : "오늘의 일정을 확인하세요!";

        return new Notification.Builder(this, TodoPlannerApplication.CHANNEL_ID_NOTIFICATION)
                .setContentIntent(contentIntent)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("알림")
                .setContentText(contentText)
                .build();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}