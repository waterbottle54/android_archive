package com.penelope.todoplanner.di;

import android.app.Application;

import androidx.room.Room;

import com.penelope.todoplanner.data.PreferenceData;
import com.penelope.todoplanner.data.todo.TodoDao;
import com.penelope.todoplanner.data.todo.TodoDatabase;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.hilt.InstallIn;
import dagger.hilt.components.SingletonComponent;

@Module
@InstallIn(SingletonComponent.class)
public class AppModule {

    @Provides
    @Singleton
    public TodoDatabase provideTodoDatabase(Application application) {
        return Room.databaseBuilder(application, TodoDatabase.class, "todo_database")
                .fallbackToDestructiveMigration()
                .build();
    }

    @Provides
    public TodoDao provideDao(TodoDatabase database) {
        return database.todoDao();
    }

    @Provides
    @Singleton
    public PreferenceData providePreferenceData(Application application) {
        return new PreferenceData(application);
    }

}
