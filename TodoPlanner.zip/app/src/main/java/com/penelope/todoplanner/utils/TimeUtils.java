package com.penelope.todoplanner.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Locale;

public class TimeUtils {

    public static LocalDate toDate(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static LocalDateTime toDateTime(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static String formatDate(LocalDate date) {
        return String.format(Locale.getDefault(), "%d/%d/%d",
                date.getYear(), date.getMonthValue(), date.getDayOfMonth()
        );
    }

    public static String formatDateDay(LocalDate date) {
        return String.format(Locale.getDefault(), "%d월 %d일 (%s)",
                date.getMonthValue(), date.getDayOfMonth(), formatDay(date)
        );
    }

    public static String formatDay(LocalDate date) {
        String[] names = { "월", "화", "수", "목", "금", "토", "일" };
        int w = date.getDayOfWeek().getValue();
        return names[w - 1];
    }

    public static String formatTime(LocalTime time) {
        return String.format(Locale.getDefault(), "%d시 %d분", time.getHour(), time.getMinute());
    }

}
