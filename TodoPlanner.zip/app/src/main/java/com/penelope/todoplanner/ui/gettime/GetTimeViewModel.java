package com.penelope.todoplanner.ui.gettime;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.time.LocalTime;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class GetTimeViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private int hour;
    private int minute;


    @Inject
    public GetTimeViewModel() {
        LocalTime now = LocalTime.now();
        hour = now.getHour();
        minute = now.getMinute();
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public int getHour() {
        return hour;
    }

    public int getMinute() {
        return minute;
    }


    public void onHourChange(int value) {
        hour = value;
    }

    public void onMinuteChange(int value) {
        minute = value;
    }

    public void onSubmitClick() {
        event.setValue(new Event.NavigateBackWithResult(LocalTime.of(hour, minute)));
    }


    public static class Event {
        public static class NavigateBackWithResult extends Event {
            public final LocalTime time;
            public NavigateBackWithResult(LocalTime time) {
                this.time = time;
            }
        }
    }

}