package com.penelope.todoplanner.data.todo;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface TodoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addTodo(Todo todo);

    @Query("SELECT * FROM todo_table WHERE year == :year AND month == :month AND dayOfMonth == :dayOfMonth ORDER BY created DESC")
    LiveData<List<Todo>> getTodosLive(int year, int month, int dayOfMonth);

    @Query("SELECT * FROM todo_table WHERE year == :year AND month == :month AND dayOfMonth == :dayOfMonth ORDER BY created DESC")
    List<Todo> getTodos(int year, int month, int dayOfMonth);

    @Query("SELECT * FROM todo_table ORDER BY epochDay DESC")
    LiveData<List<Todo>> getAllTodosLive();

    @Query("SELECT * FROM todo_table ORDER BY epochDay DESC")
    List<Todo> getAllTodos();

    @Delete
    void deleteTodo(Todo todo);

    @Query("DELETE FROM todo_table WHERE year == :year AND month == :month AND dayOfMonth == :dayOfMonth")
    void deleteAll(int year, int month, int dayOfMonth);

    @Query("UPDATE todo_table SET isCompleted = :isCompleted WHERE title == :title")
    void updateTodo(String title, boolean isCompleted);

}
