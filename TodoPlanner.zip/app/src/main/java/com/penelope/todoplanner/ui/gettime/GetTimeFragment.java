package com.penelope.todoplanner.ui.gettime;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.penelope.todoplanner.R;
import com.penelope.todoplanner.databinding.FragmentGetTimeBinding;

import java.time.LocalTime;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class GetTimeFragment extends BottomSheetDialogFragment {

    private FragmentGetTimeBinding binding;
    private GetTimeViewModel viewModel;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_get_time, container, false);
        binding = FragmentGetTimeBinding.bind(view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentGetTimeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(GetTimeViewModel.class);

        binding.numberPickerHour.setMinValue(0);
        binding.numberPickerHour.setMaxValue(23);
        binding.numberPickerHour.setValue(viewModel.getHour());

        binding.numberPickerMinute.setMinValue(0);
        binding.numberPickerMinute.setMaxValue(59);
        binding.numberPickerMinute.setValue(viewModel.getMinute());

        binding.numberPickerHour.setOnValueChangedListener((numberPicker, i, newVal) -> viewModel.onHourChange(newVal));
        binding.numberPickerMinute.setOnValueChangedListener((numberPicker, i, newVal) -> viewModel.onMinuteChange(newVal));
        binding.fabSummit.setOnClickListener(v -> viewModel.onSubmitClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof GetTimeViewModel.Event.NavigateBackWithResult) {
                LocalTime time = ((GetTimeViewModel.Event.NavigateBackWithResult) event).time;
                Bundle result = new Bundle();
                result.putSerializable("time", time);
                getParentFragmentManager().setFragmentResult("get_time_fragment", result);
                NavHostFragment.findNavController(this).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}