package com.penelope.todoplanner;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class TodoPlannerApplication extends Application {

    public static final String CHANNEL_NAME_FOREGROUND = "todo planner";
    public static final String CHANNEL_ID_FOREGROUND = "channel_foreground";

    public static final String CHANNEL_NAME_NOTIFICATION = "notification";
    public static final String CHANNEL_ID_NOTIFICATION = "channel_notification";


    @Override
    public void onCreate() {
        super.onCreate();

        // 노티피케이션 채널을 생성한다
        createNotificationChannel();
    }

    private void createNotificationChannel() {

        NotificationManager manager = getSystemService(NotificationManager.class);

        NotificationChannel foregroundChannel = new NotificationChannel(
                CHANNEL_ID_FOREGROUND,
                CHANNEL_NAME_FOREGROUND,
                NotificationManager.IMPORTANCE_LOW
        );

        NotificationChannel notificationChannel = new NotificationChannel(
                CHANNEL_ID_NOTIFICATION,
                CHANNEL_NAME_NOTIFICATION,
                NotificationManager.IMPORTANCE_HIGH
        );

        manager.createNotificationChannel(foregroundChannel);
        manager.createNotificationChannel(notificationChannel);
    }
}
