package com.penelope.todoplanner.ui.setnotification;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.todoplanner.databinding.TimeItemBinding;
import com.penelope.todoplanner.utils.TimeUtils;

import java.time.LocalTime;

public class TimeAdapter extends ListAdapter<LocalTime, TimeAdapter.LocalTimeViewHolder> {

    class LocalTimeViewHolder extends RecyclerView.ViewHolder {

        private final TimeItemBinding binding;

        public LocalTimeViewHolder(TimeItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.cardViewDelete.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onDeleteTimeClick(position);
                }
            });
        }

        public void bind(LocalTime model) {

            String strTime = TimeUtils.formatTime(model);
            binding.textViewTime.setText(strTime);
        }
    }

    public interface OnItemSelectedListener {
        void onDeleteTimeClick(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public TimeAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public LocalTimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        TimeItemBinding binding = TimeItemBinding.inflate(layoutInflater, parent, false);
        return new LocalTimeViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull LocalTimeViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<LocalTime> {

        @Override
        public boolean areItemsTheSame(@NonNull LocalTime oldItem, @NonNull LocalTime newItem) {
            return oldItem.equals(newItem);
        }

        @Override
        public boolean areContentsTheSame(@NonNull LocalTime oldItem, @NonNull LocalTime newItem) {
            return oldItem.equals(newItem);
        }
    }

}