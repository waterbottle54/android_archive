package com.penelope.todoplanner.ui.edittodos;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.databinding.TodoEditItemBinding;

public class TodoEditAdapter extends ListAdapter<Todo, TodoEditAdapter.TodoEditViewHolder> {

    class TodoEditViewHolder extends RecyclerView.ViewHolder {

        private final TodoEditItemBinding binding;

        public TodoEditViewHolder(TodoEditItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.imageViewDelete.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onDeleteItemClick(position);
                }
            });
        }

        public void bind(Todo model) {

            binding.textViewTodoTitle.setText(model.getTitle());
        }
    }

    public interface OnItemSelectedListener {
        void onDeleteItemClick(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public TodoEditAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public TodoEditViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        TodoEditItemBinding binding = TodoEditItemBinding.inflate(layoutInflater, parent, false);
        return new TodoEditViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoEditViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Todo> {

        @Override
        public boolean areItemsTheSame(@NonNull Todo oldItem, @NonNull Todo newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Todo oldItem, @NonNull Todo newItem) {
            return oldItem.equals(newItem);
        }
    }

}