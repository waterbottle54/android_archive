package com.penelope.todoplanner.ui.search;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;

import com.penelope.todoplanner.R;
import com.penelope.todoplanner.databinding.FragmentSearchBinding;
import com.penelope.todoplanner.ui.home.HomeFragmentDirections;
import com.penelope.todoplanner.ui.home.HomeViewModel;
import com.penelope.todoplanner.utils.OnTextChangeListener;

import java.time.LocalDate;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SearchFragment extends Fragment {

    private FragmentSearchBinding binding;
    private SearchViewModel viewModel;
    private GridLayoutManager layoutManager;


    public SearchFragment() {
        super(R.layout.fragment_search);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSearchBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SearchViewModel.class);

        binding.editTextYear.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onYearChange(text);
            }
        });
        binding.editTextMonth.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onMonthChange(text);
            }
        });
        binding.editTextDayOfMonth.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onDayOfMonthChange(text);
            }
        });
        binding.textViewClear.setOnClickListener(v -> viewModel.onClearClick());
        binding.textViewSearch.setOnClickListener(v -> viewModel.onSearchClick());
        binding.textViewDelete.setOnClickListener(v -> viewModel.onDeleteClick());

        DateAdapter adapter = new DateAdapter();
        binding.recyclerDate.setAdapter(adapter);
        binding.recyclerDate.setHasFixedSize(true);

        layoutManager = (GridLayoutManager) binding.recyclerDate.getLayoutManager();
        assert layoutManager != null;
        layoutManager.setSpanCount(2);

        adapter.setOnItemSelectedListener(new DateAdapter.OnItemSelectedListener() {
            @Override
            public void onItemSelected(int position) {
                LocalDate date = adapter.getCurrentList().get(position);
                viewModel.onDateClick(date);
            }

            @Override
            public void onItemLongClick(int position) {
                LocalDate date = adapter.getCurrentList().get(position);
                viewModel.onSelectionChange(date);
            }
        });

        viewModel.getDates().observe(getViewLifecycleOwner(), dates -> {
            if (dates != null) {
                adapter.submitList(dates);
            }
        });

        viewModel.getSelections().observe(getViewLifecycleOwner(), selections -> {
            if (selections != null) {
                for (int i = 0; i < adapter.getItemCount(); i++) {
                    View itemView = layoutManager.findViewByPosition(i);
                    if (itemView != null) {
                        DateAdapter.DateViewHolder viewHolder = (DateAdapter.DateViewHolder)
                                binding.recyclerDate.getChildViewHolder(itemView);
                        LocalDate date = adapter.getCurrentList().get(i);
                        viewHolder.binding.imageViewCheck.setVisibility(selections.contains(date) ? View.VISIBLE : View.INVISIBLE);
                    }
                }
                binding.textViewDelete.setVisibility(selections.isEmpty() ? View.GONE : View.VISIBLE);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SearchViewModel.Event.ClearFilterUI) {
                binding.editTextYear.setText("");
                binding.editTextMonth.setText("");
                binding.editTextDayOfMonth.setText("");
            } else if (event instanceof SearchViewModel.Event.NavigateBackWithResult) {
                LocalDate date = ((SearchViewModel.Event.NavigateBackWithResult) event).date;
                Bundle result = new Bundle();
                result.putSerializable("date", date);
                getParentFragmentManager().setFragmentResult("search_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SearchViewModel.Event.NavigateToEditTodosScreen) {
                LocalDate date = ((SearchViewModel.Event.NavigateToEditTodosScreen) event).date;
                NavDirections navDirections = SearchFragmentDirections.actionGlobalEditTodosFragment(date);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof SearchViewModel.Event.ConfirmDelete) {
                showConfirmDeleteDialog();
            } else if (event instanceof SearchViewModel.Event.NavigateToSetNotificationScreen) {
                NavDirections navDirections = SearchFragmentDirections.actionGlobalSetNotificationFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });

        setHasOptionsMenu(true);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.menu_action, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_set_notification) {
            viewModel.onSetNotificationClick();
            return true;
        } else if (id == R.id.action_today) {
            viewModel.onTodayClick();
            return true;
        } else if (id == R.id.action_add_todo) {
            viewModel.onAddTodoClick();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void showConfirmDeleteDialog() {


        new AlertDialog.Builder(requireContext())
                .setTitle("일정 삭제")
                .setMessage("삭제하시겠습니까?")
                .setPositiveButton("예", (dialogInterface, i) -> viewModel.onDeleteConfirmed())
                .setNegativeButton("아니오", null)
                .show();
    }

}