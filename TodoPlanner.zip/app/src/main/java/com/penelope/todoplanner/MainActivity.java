package com.penelope.todoplanner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavDirections;
import androidx.navigation.NavGraph;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.penelope.todoplanner.databinding.ActivityMainBinding;
import com.penelope.todoplanner.services.NotificationService;

import java.time.LocalDate;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MainActivity extends AppCompatActivity {

    private NavHostFragment navHostFragment;
    private NavController navController;
    private ActionBar actionBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 뷰 바인딩을 실행한다
        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 액션바를 설정한다
        setSupportActionBar(binding.toolBar);
        actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayShowTitleEnabled(false);
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeButtonEnabled(true);
        }

        navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentContainer);
        if (navHostFragment != null) {
            // 네비게이션 컨트롤러를 액션바와 연동한다
            navController = navHostFragment.getNavController();
            NavigationUI.setupActionBarWithNavController(this, navController);
        }

        navController.addOnDestinationChangedListener((navController1, navDestination, bundle) -> {
            binding.textViewSearch.setVisibility(navDestination.getId() == R.id.homeFragment ? View.VISIBLE : View.GONE);
        });

        binding.textViewSearch.setOnClickListener(v -> navController.navigate(R.id.searchFragment));

        Intent serviceIntent = new Intent(this, NotificationService.class);
        startForegroundService(serviceIntent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        return (navController.navigateUp() || super.onSupportNavigateUp());
    }

}