package com.penelope.todoplanner.ui.setnotification;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.todoplanner.R;
import com.penelope.todoplanner.databinding.FragmentSetNotificationBinding;

import java.time.LocalTime;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SetNotificationFragment extends Fragment {

    private FragmentSetNotificationBinding binding;
    private SetNotificationViewModel viewModel;


    public SetNotificationFragment() {
        super(R.layout.fragment_set_notification);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSetNotificationBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SetNotificationViewModel.class);

        binding.textViewOn.setOnClickListener(v -> viewModel.onOnClick());
        binding.textViewOff.setOnClickListener(v -> viewModel.onOffClick());
        binding.cardViewAddTime.setOnClickListener(v -> viewModel.onAddTimeClick());
        binding.cardViewAddTime2.setOnClickListener(v -> viewModel.onAddTimeClick());

        TimeAdapter adapter = new TimeAdapter();
        binding.recyclerTime.setAdapter(adapter);
        binding.recyclerTime.setHasFixedSize(true);

        adapter.setOnItemSelectedListener(position -> {
            LocalTime time = adapter.getCurrentList().get(position);
            viewModel.onDeleteTimeClick(time);
        });

        viewModel.getTimes().observe(getViewLifecycleOwner(), times -> {
            if (times != null) {
                adapter.submitList(times);
                binding.cardViewAddTime.setVisibility(times.isEmpty() ? View.VISIBLE : View.GONE);
                binding.cardViewAddTime2.setVisibility(times.isEmpty() ? View.GONE : View.VISIBLE);
            }
        });

        viewModel.isNotificationOn().observe(getViewLifecycleOwner(), isNotificationOn -> {
            int colorPositive = getResources().getColor(android.R.color.holo_red_light, null);
            int colorNegative = Color.parseColor("#FFAAAAAA");
            binding.textViewOn.setTextColor(isNotificationOn ? colorPositive : colorNegative);
            binding.textViewOff.setTextColor(!isNotificationOn ? colorPositive : colorNegative);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SetNotificationViewModel.Event.NavigateToGetTimeScreen) {
                NavDirections navDirections = SetNotificationFragmentDirections.actionGlobalGetTimeFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });

        getParentFragmentManager().setFragmentResultListener("get_time_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    LocalTime time = (LocalTime) result.getSerializable("time");
                    viewModel.onGetTimeResult(time);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}