package com.penelope.todoplanner.ui.search;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.data.todo.TodoDao;
import com.penelope.todoplanner.ui.home.HomeViewModel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SearchViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private Integer year;
    private Integer month;
    private Integer dayOfMonth;

    private final MutableLiveData<List<LocalDate>> dates = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<LocalDate>> selections = new MutableLiveData<>(new ArrayList<>());

    private final TodoDao todoDao;


    @Inject
    public SearchViewModel(TodoDao todoDao) {

        this.todoDao = todoDao;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<LocalDate>> getDates() {
        return dates;
    }

    public LiveData<List<LocalDate>> getSelections() {
        return selections;
    }


    public void onYearChange(String text) {
        try {
            year = Integer.parseInt(text);
        } catch (NumberFormatException e) {
            year = null;
        }
    }

    public void onMonthChange(String text) {
        try {
            month = Integer.parseInt(text);
        } catch (NumberFormatException e) {
            month = null;
        }
    }

    public void onDayOfMonthChange(String text) {
        try {
            dayOfMonth = Integer.parseInt(text);
        } catch (NumberFormatException e) {
            dayOfMonth = null;
        }
    }

    public void onClearClick() {
        year = null;
        month = null;
        dayOfMonth = null;
        event.setValue(new Event.ClearFilterUI());
    }

    public void onSearchClick() {

        new Thread(() -> {
            List<LocalDate> dateList = new ArrayList<>();
            List<Todo> todoList = todoDao.getAllTodos();
            for (int i = todoList.size() - 1; i >= 0; i--) {
                Todo todo = todoList.get(i);
                if (year != null) {
                    if (todo.getYear() != year) {
                        todoList.remove(i);
                        continue;
                    }
                }
                if (month != null) {
                    if (todo.getMonth() != month) {
                        todoList.remove(i);
                        continue;
                    }
                }
                if (dayOfMonth != null) {
                    if (todo.getDayOfMonth() != dayOfMonth) {
                        todoList.remove(i);
                        continue;
                    }
                }
                LocalDate date = LocalDate.of(todo.getYear(), todo.getMonth(), todo.getDayOfMonth());
                dateList.remove(date);
                dateList.add(date);
            }
            dates.postValue(dateList);
            selections.postValue(new ArrayList<>());
        }).start();
    }

    public void onSelectionChange(LocalDate d) {

        List<LocalDate> oldList = selections.getValue();
        assert oldList != null;

        List<LocalDate> newList = new ArrayList<>(oldList);
        if (newList.contains(d)) {
            newList.remove(d);
        } else {
            newList.add(d);
        }

        selections.setValue(newList);
    }

    public void onDeleteClick() {
        event.setValue(new Event.ConfirmDelete());
    }

    public void onDeleteConfirmed() {

        List<LocalDate> selectionList = selections.getValue();
        List<LocalDate> dateList = dates.getValue();
        assert selectionList != null && dateList != null;

        if (selectionList.isEmpty()) {
            return;
        }

        new Thread(() -> {
            for (LocalDate selection : selectionList) {
                todoDao.deleteAll(selection.getYear(), selection.getMonthValue(), selection.getDayOfMonth());
            }
            onSearchClick();
        }).start();
    }

    public void onDateClick(LocalDate d) {
        event.setValue(new Event.NavigateBackWithResult(d));
    }

    public void onAddTodoClick() {
        event.setValue(new Event.NavigateToEditTodosScreen(null));
    }

    public void onTodayClick() {
        event.setValue(new Event.NavigateBackWithResult(LocalDate.now()));
    }

    public void onSetNotificationClick() {
        event.setValue(new Event.NavigateToSetNotificationScreen());
    }


    public static class Event {

        public static class ClearFilterUI extends Event {
        }

        public static class NavigateBackWithResult extends Event {
            public final LocalDate date;
            public NavigateBackWithResult(LocalDate date) {
                this.date = date;
            }
        }

        public static class NavigateToEditTodosScreen extends Event {
            public final LocalDate date;
            public NavigateToEditTodosScreen(LocalDate date) {
                this.date = date;
            }
        }

        public static class ConfirmDelete extends Event {
        }

        public static class NavigateToSetNotificationScreen extends Event {
        }
    }

}