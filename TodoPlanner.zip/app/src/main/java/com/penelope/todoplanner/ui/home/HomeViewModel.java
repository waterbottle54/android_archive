package com.penelope.todoplanner.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.data.todo.TodoDao;

import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HomeViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<LocalDate> date = new MutableLiveData<>(LocalDate.now());
    private final LiveData<LocalDate> prevDate;
    private final LiveData<LocalDate> nextDate;
    private final LiveData<List<Todo>> todos;

    private final TodoDao todoDao;


    @Inject
    public HomeViewModel(TodoDao todoDao) {

        todos = Transformations.switchMap(date, d -> todoDao.getTodosLive(d.getYear(), d.getMonthValue(), d.getDayOfMonth()));

        LiveData<List<Todo>> allTodos = todoDao.getAllTodosLive();

        prevDate = Transformations.switchMap(date, dateValue ->
                Transformations.map(allTodos, todos -> {
                    LocalDate now = LocalDate.now();
                    for (Todo todo : todos) {
                        LocalDate todoDate = LocalDate.of(todo.getYear(), todo.getMonth(), todo.getDayOfMonth());
                        if (todoDate.isBefore(dateValue)) {
                            if (dateValue.isAfter(now) && todoDate.isBefore(now)) {
                                return now;
                            }
                            return todoDate;
                        }
                    }
                    return dateValue.isAfter(now) ? now : null;
                }));

        nextDate = Transformations.switchMap(date, dateValue ->
                Transformations.map(allTodos, todos -> {
                    LocalDate now = LocalDate.now();
                    for (int i = todos.size() - 1; i >= 0; i--) {
                        Todo todo = todos.get(i);
                        LocalDate todoDate = LocalDate.of(todo.getYear(), todo.getMonth(), todo.getDayOfMonth());
                        if (todoDate.isAfter(dateValue)) {
                            if (dateValue.isBefore(now) && todoDate.isAfter(now)) {
                                return now;
                            }
                            return todoDate;
                        }
                    }
                    return dateValue.isBefore(now) ? now : null;
                }));

        this.todoDao = todoDao;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<LocalDate> getDate() {
        return date;
    }

    public LiveData<LocalDate> getPrevDate() {
        return prevDate;
    }

    public LiveData<LocalDate> getNextDate() {
        return nextDate;
    }

    public LiveData<List<Todo>> getTodos() {
        return todos;
    }


    public void onPrevClick() {
        LocalDate prev = prevDate.getValue();
        if (prev != null) {
            date.setValue(prev);
        }
    }

    public void onNextClick() {
        LocalDate next = nextDate.getValue();
        if (next != null) {
            date.setValue(next);
        }
    }

    public void onEditTodosClick() {
        event.setValue(new Event.NavigateToEditTodosScreen(date.getValue()));
    }

    public void onTodayClick() {
        date.setValue(LocalDate.now());
    }

    public void onAddTodoClick() {
        event.setValue(new Event.NavigateToEditTodosScreen(null));
    }

    public void onTodoChecked(Todo todo, boolean isChecked) {
        new Thread(() -> todoDao.updateTodo(todo.getTitle(), isChecked)).start();
    }

    public void onSearchResult(LocalDate d) {
        date.setValue(d);
    }

    public void onSetNotificationClick() {
        event.setValue(new Event.NavigateToSetNotificationScreen());
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToEditTodosScreen extends Event {
            public final LocalDate date;
            public NavigateToEditTodosScreen(LocalDate date) {
                this.date = date;
            }
        }

        public static class NavigateToSetNotificationScreen extends Event {
        }
    }

}