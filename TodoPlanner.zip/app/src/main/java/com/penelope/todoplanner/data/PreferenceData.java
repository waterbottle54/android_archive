package com.penelope.todoplanner.data;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.penelope.todoplanner.utils.SharedPreferenceBooleanLiveData;
import com.penelope.todoplanner.utils.SharedPreferenceStringLiveData;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.inject.Inject;

public class PreferenceData {

    private final SharedPreferences preferences;
    private final LiveData<List<LocalTime>> times;
    private final LiveData<Boolean> isNotificationOn;


    @Inject
    public PreferenceData(Context context) {
        preferences = PreferenceManager.getDefaultSharedPreferences(context);

        LiveData<String> timeString = new SharedPreferenceStringLiveData(preferences, "times", "");
        times = Transformations.map(timeString, this::toTimes);

        isNotificationOn = new SharedPreferenceBooleanLiveData(preferences, "is_notification_on", false);
    }

    public LiveData<List<LocalTime>> getTimesLive() {
        return times;
    }

    public List<LocalTime> getTimes() {
        String timeString = preferences.getString("times", "");
        return toTimes(timeString);
    }

    public LiveData<Boolean> isNotificationOnLive() {
        return isNotificationOn;
    }

    public boolean isNotificationOn() {
        return preferences.getBoolean("is_notification_on", false);
    }

    public void setTimes(List<LocalTime> list) {
        list.sort(Comparator.naturalOrder());
        preferences.edit().putString("times", toTimeString(list)).apply();
    }

    public void setIsNotificationOn(boolean value) {
        preferences.edit().putBoolean("is_notification_on", value).apply();
    }


    private String toTimeString(List<LocalTime> times) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times.size(); i++) {
            sb.append(times.get(i).toString());
            if (i != times.size() - 1) {
                sb.append(",");
            }
        }
        return sb.toString();
    }

    private List<LocalTime> toTimes(String timeString) {
        List<LocalTime> times = new ArrayList<>();
        String[] split = timeString.split(",");
        for (String s : split) {
            if (!s.isEmpty()) {
                LocalTime time = LocalTime.parse(s);
                times.add(time);
            }
        }
        return times;
    }

}
