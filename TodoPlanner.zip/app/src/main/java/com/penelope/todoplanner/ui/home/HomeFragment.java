package com.penelope.todoplanner.ui.home;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.todoplanner.R;
import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.databinding.FragmentHomeBinding;
import com.penelope.todoplanner.utils.TimeUtils;

import java.time.LocalDate;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;


    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentHomeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding.imageViewPrev.setOnClickListener(v -> viewModel.onPrevClick());
        binding.imageViewNext.setOnClickListener(v -> viewModel.onNextClick());
        binding.fabEditTodos.setOnClickListener(v -> viewModel.onEditTodosClick());

        TodoAdapter adapter = new TodoAdapter();
        binding.recyclerTodo.setAdapter(adapter);
        binding.recyclerTodo.setHasFixedSize(true);

        adapter.setOnItemSelectedListener((position, isChecked) -> {
            Todo todo = adapter.getCurrentList().get(position);
            viewModel.onTodoChecked(todo, isChecked);
        });

        viewModel.getTodos().observe(getViewLifecycleOwner(), todos -> {
            if (todos != null) {
                binding.textViewNoTodo.setVisibility(todos.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                binding.cardViewTodos.setVisibility(todos.isEmpty() ? View.INVISIBLE : View.VISIBLE);
                adapter.submitList(todos);
            }
        });

        viewModel.getDate().observe(getViewLifecycleOwner(), date -> {
            String strDate = TimeUtils.formatDateDay(date);
            binding.textViewDate.setText(strDate);
        });

        viewModel.getPrevDate().observe(getViewLifecycleOwner(), prevDate ->
                binding.imageViewPrev.setVisibility(prevDate != null ? View.VISIBLE : View.INVISIBLE));

        viewModel.getNextDate().observe(getViewLifecycleOwner(), nextDate ->
                binding.imageViewNext.setVisibility(nextDate != null ? View.VISIBLE : View.INVISIBLE));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof HomeViewModel.Event.ShowGeneralMessage) {
                String message = ((HomeViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof HomeViewModel.Event.NavigateToEditTodosScreen) {
                LocalDate date = ((HomeViewModel.Event.NavigateToEditTodosScreen) event).date;
                NavDirections navDirections = HomeFragmentDirections.actionGlobalEditTodosFragment(date);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof HomeViewModel.Event.NavigateToSetNotificationScreen) {
                NavDirections navDirections = HomeFragmentDirections.actionGlobalSetNotificationFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });

        getParentFragmentManager().setFragmentResultListener("search_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    LocalDate date = (LocalDate) result.getSerializable("date");
                    viewModel.onSearchResult(date);
                });

        setHasOptionsMenu(true);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.menu_action, menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.action_set_notification) {
            viewModel.onSetNotificationClick();
            return true;
        } else if (id == R.id.action_today) {
            viewModel.onTodayClick();
            return true;
        } else if (id == R.id.action_add_todo) {
            viewModel.onAddTodoClick();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}