package com.penelope.todoplanner.utils;

import android.content.SharedPreferences;

public class SharedPreferenceBooleanLiveData extends SharedPreferenceLiveData<Boolean> {

    public SharedPreferenceBooleanLiveData(SharedPreferences preferences, String key, Boolean defValue) {
        super(preferences, key, defValue);
    }

    @Override
    Boolean getValueFromPreferences(String key, Boolean defValue) {
        return sharedPrefs.getBoolean(key, defValue);
    }
}