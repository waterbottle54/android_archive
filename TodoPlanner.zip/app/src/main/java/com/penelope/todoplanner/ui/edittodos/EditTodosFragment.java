package com.penelope.todoplanner.ui.edittodos;

import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.penelope.todoplanner.R;
import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.databinding.FragmentEditTodosBinding;
import com.penelope.todoplanner.utils.OnTextChangeListener;
import com.penelope.todoplanner.utils.TimeUtils;

import java.time.LocalDate;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class EditTodosFragment extends Fragment {

    private FragmentEditTodosBinding binding;
    private EditTodosViewModel viewModel;


    public EditTodosFragment() {
        super(R.layout.fragment_edit_todos);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentEditTodosBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(EditTodosViewModel.class);

        binding.textViewDate.setOnClickListener(v -> viewModel.onDateClick());
        binding.editTextTodoTitle.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onTitleChange(text);
            }
        });
        binding.cardViewAddTodo.setOnClickListener(v -> {
            viewModel.onAddTodoClick();
            binding.editTextTodoTitle.setText("");
            hideKeyboard(requireView());
        });
        binding.textViewDeleteAll.setOnClickListener(v -> viewModel.onDeleteAllClick());

        TodoEditAdapter adapter = new TodoEditAdapter();
        binding.recyclerTodo.setAdapter(adapter);
        binding.recyclerTodo.setHasFixedSize(true);

        adapter.setOnItemSelectedListener(position -> {
            Todo todo = adapter.getCurrentList().get(position);
            viewModel.onDeleteTodoClick(todo);
        });

        viewModel.getTodos().observe(getViewLifecycleOwner(), todos -> {
            if (todos != null) {
                binding.textViewDeleteAll.setVisibility(todos.isEmpty() ? View.GONE : View.VISIBLE);
                binding.textViewNoTodo.setVisibility(todos.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                adapter.submitList(todos);
            }
        });

        viewModel.getDate().observe(getViewLifecycleOwner(), date -> {
            if (date != null) {
                String strDate = TimeUtils.formatDateDay(date);
                binding.editTextDate.setText(strDate);
            } else {
                binding.editTextDate.setText("");
            }
            binding.editTextTodoTitle.setHint(date != null ? "할 일을 추가해주세요!" : "날짜를 먼저 입력해주세요!");
            binding.editTextTodoTitle.setEnabled(date != null);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof EditTodosViewModel.Event.ShowGeneralMessage) {
                String message = ((EditTodosViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof EditTodosViewModel.Event.PromptDate) {
                LocalDate currentDate = ((EditTodosViewModel.Event.PromptDate) event).currentDate;
                showDatePickerDialog(currentDate);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void showDatePickerDialog(LocalDate currentDate) {

        DatePickerDialog dialog = new DatePickerDialog(requireContext(),
                (datePicker, i, i1, i2) -> {
                    LocalDate date = LocalDate.of(i, i1 + 1, i2);
                    viewModel.onDateSelected(date);
                },
                currentDate.getYear(),
                currentDate.getMonthValue() - 1,
                currentDate.getDayOfMonth()
        );

        dialog.show();
    }

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}