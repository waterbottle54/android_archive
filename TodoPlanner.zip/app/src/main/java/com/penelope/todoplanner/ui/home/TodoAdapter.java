package com.penelope.todoplanner.ui.home;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.todoplanner.data.todo.Todo;
import com.penelope.todoplanner.databinding.TodoItemBinding;

public class TodoAdapter extends ListAdapter<Todo, TodoAdapter.TodoViewHolder> {

    class TodoViewHolder extends RecyclerView.ViewHolder {

        private final TodoItemBinding binding;

        public TodoViewHolder(TodoItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.checkBoxTodo.setOnCheckedChangeListener((compoundButton, b) -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemChecked(position, b);
                }
            });
        }

        public void bind(Todo model) {

            binding.textViewTodoTitle.setText(model.getTitle());
            binding.checkBoxTodo.setChecked(model.isCompleted());
        }
    }

    public interface OnItemSelectedListener {
        void onItemChecked(int position, boolean isChecked);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public TodoAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public TodoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        TodoItemBinding binding = TodoItemBinding.inflate(layoutInflater, parent, false);
        return new TodoViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TodoViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Todo> {

        @Override
        public boolean areItemsTheSame(@NonNull Todo oldItem, @NonNull Todo newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Todo oldItem, @NonNull Todo newItem) {
            return oldItem.equals(newItem);
        }
    }

}