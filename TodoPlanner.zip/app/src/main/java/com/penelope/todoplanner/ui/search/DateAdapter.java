package com.penelope.todoplanner.ui.search;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.todoplanner.databinding.DateItemBinding;
import com.penelope.todoplanner.utils.TimeUtils;

import java.time.LocalDate;

public class DateAdapter extends ListAdapter<LocalDate, DateAdapter.DateViewHolder> {

    class DateViewHolder extends RecyclerView.ViewHolder {

        public final DateItemBinding binding;

        public DateViewHolder(DateItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });

            binding.getRoot().setOnLongClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemLongClick(position);
                    return true;
                }
                return false;
            });
        }

        public void bind(LocalDate model) {
            String strDate = TimeUtils.formatDate(model);
            binding.textViewDate.setText(strDate);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
        void onItemLongClick(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public DateAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public DateViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        DateItemBinding binding = DateItemBinding.inflate(layoutInflater, parent, false);
        return new DateViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DateViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<LocalDate> {

        @Override
        public boolean areItemsTheSame(@NonNull LocalDate oldItem, @NonNull LocalDate newItem) {
            return oldItem.equals(newItem);
        }

        @Override
        public boolean areContentsTheSame(@NonNull LocalDate oldItem, @NonNull LocalDate newItem) {
            return oldItem.equals(newItem);
        }
    }

}