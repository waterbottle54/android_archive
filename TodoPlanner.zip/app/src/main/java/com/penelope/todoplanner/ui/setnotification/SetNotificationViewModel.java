package com.penelope.todoplanner.ui.setnotification;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.todoplanner.data.PreferenceData;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SetNotificationViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<Boolean> isNotificationOn;
    private final LiveData<List<LocalTime>> times;

    private final PreferenceData preferenceData;


    @Inject
    public SetNotificationViewModel(PreferenceData preferenceData) {
        isNotificationOn = preferenceData.isNotificationOnLive();
        times = preferenceData.getTimesLive();
        this.preferenceData = preferenceData;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Boolean> isNotificationOn() {
        return isNotificationOn;
    }

    public LiveData<List<LocalTime>> getTimes() {
        return times;
    }


    public void onOnClick() {
        preferenceData.setIsNotificationOn(true);
    }

    public void onOffClick() {
        preferenceData.setIsNotificationOn(false);
    }

    public void onAddTimeClick() {
        event.setValue(new Event.NavigateToGetTimeScreen());
    }

    public void onDeleteTimeClick(LocalTime time) {

        List<LocalTime> timeList = times.getValue();
        if (timeList == null) {
            return;
        }

        List<LocalTime> newList = new ArrayList<>(timeList);
        if (newList.contains(time)) {
            newList.remove(time);
            preferenceData.setTimes(newList);
        }
    }

    public void onGetTimeResult(LocalTime value) {

        List<LocalTime> timeList = times.getValue();
        if (timeList == null) {
            return;
        }

        List<LocalTime> newList = new ArrayList<>(timeList);
        if (!newList.contains(value)) {
            newList.add(value);
            preferenceData.setTimes(newList);
        }
    }


    public static class Event {

        public static class NavigateToGetTimeScreen extends Event {
        }
    }

}



