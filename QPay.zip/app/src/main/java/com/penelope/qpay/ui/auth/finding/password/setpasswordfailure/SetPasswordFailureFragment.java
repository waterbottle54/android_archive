package com.penelope.qpay.ui.auth.finding.password.setpasswordfailure;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentSetPasswordFailureBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SetPasswordFailureFragment extends Fragment {

    private FragmentSetPasswordFailureBinding binding;
    private SetPasswordFailureViewModel viewModel;


    public SetPasswordFailureFragment() {
        super(R.layout.fragment_set_password_failure);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSetPasswordFailureBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SetPasswordFailureViewModel.class);

        binding.buttonOk.setOnClickListener(v -> viewModel.onOkClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SetPasswordFailureViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}