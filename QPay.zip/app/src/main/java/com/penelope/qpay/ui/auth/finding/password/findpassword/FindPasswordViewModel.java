package com.penelope.qpay.ui.auth.finding.password.findpassword;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.user.UserRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class FindPasswordViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String name = "";
    private String phone = "";
    private String id = "";

    private final MutableLiveData<Boolean> isFindingInProgress = new MutableLiveData<>(false);

    private final UserRepository userRepository;


    @Inject
    public FindPasswordViewModel(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Boolean> isFindingInProgress() {
        return isFindingInProgress;
    }


    public void onNameChange(String text) {
        name = text.trim();
    }

    public void onPhoneChange(String text) {
        phone = text.trim();
    }

    public void onIdChange(String text) {
        id = text.trim();
    }

    public void onFindClick() {

        // 이미 검색이 진행중이면 리턴한다
        Boolean isFindingInProgressValue = isFindingInProgress.getValue();
        assert isFindingInProgressValue != null;
        if (isFindingInProgressValue) {
            return;
        }

        if (name.isEmpty() || phone.isEmpty() || id.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        isFindingInProgress.setValue(true);

        // 입력된 id 로 회원정보를 조회한다
        userRepository.getUser(id,
                user -> {
                    isFindingInProgress.setValue(false);

                    if (user == null) {
                        // 조회되지 않는 경우 찾지 못했다는 화면으로 이동한다
                        event.setValue(new Event.NavigateToNotFoundScreen());
                        return;
                    }

                    // 조회된 경우 이름, 휴대폰번호가 일치하는지 확인한다
                    if (!name.equals(user.getName()) || !phone.equals(user.getPhone())) {
                        event.setValue(new Event.NavigateToNotFoundScreen());
                        return;
                    }

                    // 일치하면 비밀번호 설정 화면으로 이동한다
                    event.setValue(new Event.NavigateToSetPasswordScreen(id));
                },
                e -> {
                    e.printStackTrace();
                    isFindingInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("회원정보 조회에 실패했습니다"));
                }
        );
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToSetPasswordScreen extends Event {
            public final String id;
            public NavigateToSetPasswordScreen(String id) {
                this.id = id;
            }
        }

        public static class NavigateToNotFoundScreen extends Event {
        }
    }

}