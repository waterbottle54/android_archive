package com.penelope.qpay.ui.home.cart.pay.paysuccess;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PaySuccessViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();


    @Inject
    public PaySuccessViewModel() {

    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    public void onBackClick() {
        event.setValue(new Event.NavigateBack());
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }
    }

}