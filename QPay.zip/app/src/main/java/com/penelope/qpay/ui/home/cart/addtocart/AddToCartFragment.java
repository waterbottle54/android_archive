package com.penelope.qpay.ui.home.cart.addtocart;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.data.product.Product;
import com.penelope.qpay.databinding.FragmentAddToCartBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class AddToCartFragment extends Fragment {

    private FragmentAddToCartBinding binding;
    private AddToCartViewModel viewModel;


    public AddToCartFragment() {
        super(R.layout.fragment_add_to_cart);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentAddToCartBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(AddToCartViewModel.class);

        // 상품명을 텍스트뷰에 보인다
        binding.textViewProductName.setText(viewModel.getProduct().getName());

        // 버튼 클릭시 뷰모델에 통보한다
        binding.buttonYes.setOnClickListener(v -> viewModel.onYesClick());
        binding.buttonNo.setOnClickListener(v -> viewModel.onNoClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof AddToCartViewModel.Event.NavigateBackWithResult) {
                // 추가된 상품을 설정하고 이전 화면으로 되돌아간다
                Product product = ((AddToCartViewModel.Event.NavigateBackWithResult) event).product;
                Bundle result = new Bundle();
                result.putSerializable("product", product);
                getParentFragmentManager().setFragmentResult("add_to_cart_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}