package com.penelope.qpay.data.product;

// DB 의 상품정보에 접근하는 저장소

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class ProductRepository {

    private final CollectionReference productCollection;


    @Inject
    public ProductRepository(FirebaseFirestore firestore) {

        productCollection = firestore.collection("products");
    }

    // 모든 상품 목록을 불러온다

    public void getAllProducts(OnSuccessListener<List<Product>> onSuccessListener, OnFailureListener onFailureListener) {

        productCollection.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Product> products = new ArrayList<>();
                    if (queryDocumentSnapshots == null) {
                        onSuccessListener.onSuccess(products);
                        return;
                    }
                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        Product product = snapshot.toObject(Product.class);
                        if (product != null) {
                            products.add(product);
                        }
                    }
                    onSuccessListener.onSuccess(products);
                })
                .addOnFailureListener(onFailureListener);
    }

    // 위 메소드의 LiveData 버전

    public LiveData<List<Product>> getAllProducts() {

        MutableLiveData<List<Product>> products = new MutableLiveData<>();
        getAllProducts(products::setValue, e -> products.setValue(null));
        return products;
    }

    // 특정 상품을 id 로 검색한다

    public void getProduct(String id, OnSuccessListener<Product> onSuccessListener, OnFailureListener onFailureListener) {

        productCollection.document(id)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot == null) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    Product product = documentSnapshot.toObject(Product.class);
                    if (product != null) {
                        onSuccessListener.onSuccess(product);
                    }
                })
                .addOnFailureListener(onFailureListener);
    }

    // 특정 상품을 상품명으로 검색한다

    public void findProductByName(String name, OnSuccessListener<Product> onSuccessListener, OnFailureListener onFailureListener) {

        productCollection.whereEqualTo("name", name)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots == null || queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    Product product = queryDocumentSnapshots.getDocuments().get(0).toObject(Product.class);
                    onSuccessListener.onSuccess(product);
                })
                .addOnFailureListener(onFailureListener);
    }

}



