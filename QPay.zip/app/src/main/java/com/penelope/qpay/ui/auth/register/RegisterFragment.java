package com.penelope.qpay.ui.auth.register;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.DialogRegisterMessageBinding;
import com.penelope.qpay.databinding.FragmentRegisterBinding;
import com.penelope.qpay.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RegisterFragment extends Fragment {

    public interface RegisterFragmentListener {
        void onLoggedIn();
    }

    private FragmentRegisterBinding binding;
    private RegisterViewModel viewModel;
    private RegisterFragmentListener listener;


    public RegisterFragment() {
        super(R.layout.fragment_register);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩을 실행한다
        binding = FragmentRegisterBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RegisterViewModel.class);

        // 액티비티를 리스너로 캐스팅한다
        try {
            listener = (RegisterFragmentListener) requireActivity();
        } catch (ClassCastException e) {
            e.printStackTrace();
        }

        // 에딧텍스트 값이 변경되면 뷰모델에 통보한다
        binding.editTextId.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onIdChange(text);
            }
        });
        binding.editTextPassword.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPasswordChange(text);
            }
        });
        binding.editTextPasswordConfirm.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPasswordConfirmChange(text);
            }
        });
        binding.editTextName.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onNameChange(text);
            }
        });
        binding.editTextPhone.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPhoneChange(text);
            }
        });

        // 중복, 회원가입 버튼이 클릭되면 뷰모델에 통보한다
        binding.buttonCheckDuplication.setOnClickListener(v -> viewModel.onCheckDuplicationClick());
        binding.buttonRegister.setOnClickListener(v -> viewModel.onRegisterClick());

        // 중복 체크 여부에 따라 버튼색을 업데이트한다
        viewModel.isDuplicationChecked().observe(getViewLifecycleOwner(), isDuplicationChecked -> {
            int buttonColor = isDuplicationChecked ? R.color.colorSafeGreen : R.color.colorYellow;
            binding.buttonCheckDuplication.setBackgroundColor(
                    ResourcesCompat.getColor(getResources(), buttonColor, null));
        });

        // 중복 체크 중이면 로딩바를 보인다
        viewModel.isDuplicationCheckingInProgress().observe(getViewLifecycleOwner(), isDuplicationCheckingInProgress ->
                binding.progressBar.setVisibility(isDuplicationCheckingInProgress ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof RegisterViewModel.Event.ShowGeneralMessage) {
                // 뷰모델이 보낸 메세지를 토스트로 출력한다
                String message = ((RegisterViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof RegisterViewModel.Event.ShowMessageScreen) {
                // 뷰모델이 보낸 메세지를 동반해 메세지 화면으로 이동한다
                String message = ((RegisterViewModel.Event.ShowMessageScreen) event).message;
                showMessageDialog(message);
            } else if (event instanceof RegisterViewModel.Event.NavigateToHomeScreen) {
                // 로그인 되었음을 액티비티에 통보한다
                listener.onLoggedIn();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void showMessageDialog(String message) {

        DialogRegisterMessageBinding binding = DialogRegisterMessageBinding.inflate(getLayoutInflater());

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(binding.getRoot())
                .create();

        binding.textViewMessage.setText(message);
        binding.buttonOk.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

}