package com.penelope.qpay.utils.ui;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;

public class TimeUtils {

    // 시간(밀리초)를 연.월.일 문자열로 바꾼다

    public static String getDateString(long millis) {

        LocalDate ld = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
        return String.format(Locale.getDefault(), "%d.%02d.%02d",
                ld.getYear() % 100,
                ld.getMonthValue(),
                ld.getDayOfMonth()
        );
    }

    // 시간(밀리초)를 시:분 문자열로 바꾼다

    public static String getTimeString(long millis) {

        LocalDateTime ldt = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDateTime();
        return String.format(Locale.getDefault(), "%02d:%02d",
                ldt.getHour(),
                ldt.getMinute()
        );
    }

}
