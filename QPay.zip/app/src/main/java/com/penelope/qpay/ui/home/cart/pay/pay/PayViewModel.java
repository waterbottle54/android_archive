package com.penelope.qpay.ui.home.cart.pay.pay;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.order.Order;
import com.penelope.qpay.data.order.OrderRepository;
import com.penelope.qpay.data.pick.Pick;
import com.penelope.qpay.utils.ui.AuthUtils;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PayViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String currentId;

    private final MutableLiveData<String> cardName = new MutableLiveData<>();

    private final List<Pick> picks;

    private final int totalPrice;

    private final OrderRepository orderRepository;


    @Inject
    public PayViewModel(Application application, SavedStateHandle savedStateHandle, OrderRepository orderRepository) {

        // 현재 사용자 id 를 획득한다
        currentId = AuthUtils.getCurrentId(application);

        // 전달된 장바구니 목록을 획득한다
        picks = savedStateHandle.get("picks");
        assert picks != null;

        // 총 결제금액을 계산한다
        int sum = 0;
        for (Pick pick : picks) {
            sum += pick.getProduct().getPrice() * pick.getCount();
        }
        totalPrice = sum;

        this.orderRepository = orderRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public LiveData<String> getCardName() {
        return cardName;
    }


    public void onSelectCardClick() {

        event.setValue(new Event.NavigateToSelectCardScreen());
    }

    public void onPayClick() {

        if (cardName.getValue() == null) {
            event.setValue(new Event.ShowGeneralMessage("카드를 선택해주세요"));
            return;
        }

        // DB 에 주문내역을 기록한다
        Order order = new Order(picks, totalPrice);
        orderRepository.addOrder(currentId, order,
                unused -> {
                    // 결제 성공 화면으로 이동한다
                    event.setValue(new Event.NavigateToPaySuccessScreen());
                },
                e -> {
                    event.setValue(new Event.ShowGeneralMessage("주문내역을 생성하지 못했습니다"));
                    e.printStackTrace();
                }
        );
    }

    public void onSelectCardResult(String cardName) {
        this.cardName.setValue(cardName);
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToSelectCardScreen extends Event {
        }

        public static class NavigateToPaySuccessScreen extends Event {
        }
    }

}