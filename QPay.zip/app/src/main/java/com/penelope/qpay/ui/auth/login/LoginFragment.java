package com.penelope.qpay.ui.auth.login;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentLoginBinding;
import com.penelope.qpay.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class LoginFragment extends Fragment {

    public interface LoginFragmentListener {
        void onLoggedIn();
    }

    private FragmentLoginBinding binding;
    private LoginViewModel viewModel;
    private LoginFragmentListener host;


    public LoginFragment() {
        super(R.layout.fragment_login);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 뷰 바인딩을 실행한다
        binding = FragmentLoginBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(LoginViewModel.class);

        // 액티비티를 리스너로 캐스팅한다
        try {
            host = (LoginFragmentListener) requireActivity();
        } catch (ClassCastException e) {
            e.printStackTrace();
        }

        // 아이디, 비밀번호 에딧텍스트에 입력되면 뷰모델에 통보한다
        binding.editTextId.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onIdChange(text);
            }
        });
        binding.editTextPassword.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPasswordChange(text);
            }
        });

        // 로그인, 회원가입, ID/PW 찾기 버튼이 클릭되면 뷰모델에 통보한다
        binding.buttonLogin.setOnClickListener(v -> viewModel.onLoginClick());
        binding.buttonRegister.setOnClickListener(v -> viewModel.onRegisterClick());
        binding.textViewFindIdPassword.setOnClickListener(v -> viewModel.onFindClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof LoginViewModel.Event.ShowGeneralMessage) {
                // 뷰모델이 보낸 메세지를 토스트로 출력한다
                String message = ((LoginViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof LoginViewModel.Event.NavigateToHomeScreen) {
                // 액티비티에 로그인 사실을 통지한다
                host.onLoggedIn();
            } else if (event instanceof LoginViewModel.Event.NavigateToRegisterScreen) {
                // 회원가입 화면으로 이동한다
                NavDirections navDirections = LoginFragmentDirections.actionLoginFragmentToRegisterFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof LoginViewModel.Event.NavigateToFindIdPasswordScreen) {
                // 찾기 화면으로 이동한다
                NavDirections navDirections = LoginFragmentDirections.actionLoginFragmentToFindingFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });

        getParentFragmentManager().setFragmentResultListener("navigation", getViewLifecycleOwner(),
                (requestKey, result) -> viewModel.onNavigationResult(result));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}