package com.penelope.qpay.ui.home.cart.cart;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.pick.Pick;
import com.penelope.qpay.data.product.Product;
import com.penelope.qpay.data.product.ProductRepository;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class CartViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    // 장바구니 목록
    private final MutableLiveData<List<Pick>> picks = new MutableLiveData<>(new ArrayList<>());

    // 합계 금액
    private final LiveData<Integer> totalPrice;

    private final ProductRepository productRepository;


    @Inject
    public CartViewModel(ProductRepository productRepository) {

        totalPrice = Transformations.map(picks, pickList -> {
            int sum = 0;
            for (Pick pick : pickList) {
                sum += (pick.getProduct().getPrice() * pick.getCount());
            }
            return sum;
        });

        this.productRepository = productRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Pick>> getPicks() {
        return picks;
    }

    public LiveData<Integer> getTotalPrice() {
        return totalPrice;
    }


    public void onScanQrClick() {
        event.setValue(new Event.NavigateToQrScanScreen());
    }

    public void onPayClick() {

        List<Pick> pickList = picks.getValue();
        assert pickList != null;

        // 결제 화면으로 이동한다
        if (!pickList.isEmpty()) {
            event.setValue(new Event.NavigateToPayScreen(new ArrayList<>(pickList)));
        } else {
            event.setValue(new Event.ShowGeneralMessage("장바구니가 비어있습니다"));
        }
    }

    public void onQrScanResult(String productId) {

        if (productId == null || productId.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("상품을 인식하지 못했습니다"));
            return;
        }

        // 상품 저장소에서 상품을 검색한다
        productRepository.getProduct(productId,
                product -> {
                    if (product != null) {
                        event.setValue(new Event.NavigateToAddToCartScreen(product));
                    } else {
                        event.setValue(new Event.ShowGeneralMessage("등록되지 않은 상품입니다"));
                    }
                },
                e -> {
                    event.setValue(new Event.ShowGeneralMessage("상품이 검색되지 않았습니다"));
                    e.printStackTrace();
                });
    }

    public void onAddToCartResult(Product product) {

        if (product != null) {
            // 상품을 장바구니에 추가한다
            addPick(new Pick(product, 1));
        }
    }

    public void onPickClick(Pick pick) {
        event.setValue(new Event.PromptPickCount(pick));
    }

    public void onPickCountSelected(Pick pick, int count) {

        // 장바구니 품목의 개수를 변경하거나 삭제한다

        List<Pick> oldList = picks.getValue();
        assert oldList != null;

        List<Pick> newList = new ArrayList<>(oldList);

        for (Pick p : oldList) {
            if (p.getProduct().getId().equals(pick.getProduct().getId())) {
                if (count > 1) {
                    newList.set(newList.indexOf(p), new Pick(pick.getProduct(), count));
                } else {
                    newList.remove(p);
                }
                break;
            }
        }

        picks.setValue(newList);
    }


    private void addPick(Pick newPick) {

        List<Pick> oldList = picks.getValue();
        assert oldList != null;

        List<Pick> newList = new ArrayList<>(oldList);

        // 중복을 확인한다
        for (Pick pick : oldList) {
            if (pick.getProduct().getId().equals(newPick.getProduct().getId())) {
                newList.get(newList.indexOf(pick)).addCount(newPick.getCount());
                picks.setValue(newList);
                return;
            }
        }

        newList.add(newPick);
        picks.setValue(newList);
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToQrScanScreen extends Event {
        }

        public static class NavigateToPayScreen extends Event {
            public final ArrayList<Pick> picks;
            public NavigateToPayScreen(ArrayList<Pick> picks) {
                this.picks = picks;
            }
        }

        public static class NavigateToAddToCartScreen extends Event {
            public final Product product;
            public NavigateToAddToCartScreen(Product product) {
                this.product = product;
            }
        }

        public static class PromptPickCount extends Event {
            public final Pick pick;
            public PromptPickCount(Pick pick) {
                this.pick = pick;
            }
        }
    }

}