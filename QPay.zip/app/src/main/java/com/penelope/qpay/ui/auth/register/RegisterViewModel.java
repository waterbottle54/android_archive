package com.penelope.qpay.ui.auth.register;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.user.User;
import com.penelope.qpay.data.user.UserRepository;
import com.penelope.qpay.utils.ui.AuthUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class RegisterViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    // 회원가입 입력값
    private String id = "";
    private String password = "";
    private String passwordConfirm = "";
    private String name = "";
    private String phone = "";

    // 중복 체크 여부
    private final MutableLiveData<Boolean> isDuplicationChecked = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> isDuplicationCheckingInProgress = new MutableLiveData<>(false);

    private final Application application;
    private final UserRepository userRepository;


    @Inject
    public RegisterViewModel(Application application, UserRepository userRepository) {
        this.application = application;
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Boolean> isDuplicationChecked() {
        return isDuplicationChecked;
    }

    public LiveData<Boolean> isDuplicationCheckingInProgress() {
        return isDuplicationCheckingInProgress;
    }


    public void onIdChange(String text) {
        // 아이디가 변경되면 중복 체크를 무효화한다
        id = text.trim();
        isDuplicationChecked.setValue(false);
    }

    public void onPasswordChange(String text) {
        password = text.trim();
    }

    public void onPasswordConfirmChange(String text) {
        passwordConfirm = text.trim();
    }

    public void onNameChange(String text) {
        name = text.trim();
    }

    public void onPhoneChange(String text) {
        phone = text.trim();
    }

    public void onCheckDuplicationClick() {

        Boolean isDuplicationCheckedValue = isDuplicationChecked.getValue();
        assert isDuplicationCheckedValue != null;
        if (isDuplicationCheckedValue) {
            return;
        }

        Boolean isDuplicationCheckingInProgressValue = isDuplicationCheckingInProgress.getValue();
        assert isDuplicationCheckingInProgressValue != null;
        if (isDuplicationCheckingInProgressValue) {
            return;
        }

        if (id.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("아이디를 입력하세요"));
            return;
        }

        isDuplicationCheckingInProgress.setValue(true);

        // 입력된 id 로 중복 가입된 회원이 있는지 확인한다
        userRepository.getUser(id,
                user -> {
                    if (user != null) {
                        // 중복된 경우 메세지 화면으로 이동하도록 한다
                        event.setValue(new Event.ShowMessageScreen("이미 사용중인 아이디입니다"));
                    } else {
                        // 중복되지 않은 경우 중복 체크 완료 처리한다
                        isDuplicationChecked.setValue(true);
                        event.setValue(new Event.ShowMessageScreen("사용 가능한 아이디"));
                    }
                    isDuplicationCheckingInProgress.setValue(false);
                },
                e -> {
                    event.setValue(new Event.ShowGeneralMessage("회원정보 조회에 실패했습니다"));
                    isDuplicationCheckingInProgress.setValue(false);
                }
        );
    }

    public void onRegisterClick() {

        // 회원가입 시 입력값을 체크한다

        if (id.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("아이디를 입력하세요"));
            return;
        }
        if (password.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("비밀번호를 입력하세요"));
            return;
        }
        if (name.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("이름을 입력하세요"));
            return;
        }
        if (phone.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("휴대폰 번호를 입력하세요"));
            return;
        }

        // 비밀번호 확인을 잘못 입력한 경우 메세지 화면으로 이동하도록 한다

        if (!passwordConfirm.equals(password)) {
            event.setValue(new Event.ShowMessageScreen("비밀번호를 정확히 입력해주세요"));
            return;
        }

        // 중복 체크를 완료하지 않은 경우 메세지 화면으로 이동하도록 한다

        Boolean duplicationCheckValue = isDuplicationChecked.getValue();
        assert duplicationCheckValue != null;
        if (!duplicationCheckValue) {
            event.setValue(new Event.ShowMessageScreen("아이디 중복 체크를 해주세요"));
            return;
        }

        // 같은 이름, 전화번호로 가입된 계정이 있는지 검색한다

        userRepository.getUser(name, phone,
                user -> {
                    if (user == null) {
                        // 없으면 회원가입을 진행한다
                        registerUser();
                    } else {
                        // 있으면 메세지 화면으로 이동하도록 한다
                        event.setValue(new Event.ShowMessageScreen("동일한 인적사항으로 가입된 유저가 있습니다"));
                    }
                },
                e -> event.setValue(new Event.ShowGeneralMessage("회원정보 조회에 실패했습니다"))
        );
    }


    private void registerUser() {

        // 회원정보를 구성하여 회원가입을 진행한다

        User user = new User(id, password, name, phone, System.currentTimeMillis());
        userRepository.addUser(user,
                unused -> {
                    // 회원가입 완료 후 로그인 처리하고 홈 화면으로 이동하도록 한다
                    AuthUtils.setCurrentId(application, id);
                    event.setValue(new Event.NavigateToHomeScreen());
                },
                e -> event.setValue(new Event.ShowGeneralMessage("회원가입에 실패했습니다"))
        );

    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowMessageScreen extends Event {
            public final String message;

            public ShowMessageScreen(String message) {
                this.message = message;
            }
        }

        public static class NavigateToHomeScreen extends Event {
        }
    }

}




