package com.penelope.qpay.ui.auth.finding.password.setpasswordfailure;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SetPasswordFailureViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();


    @Inject
    public SetPasswordFailureViewModel() {

    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    public void onOkClick() {
        event.setValue(new Event.NavigateBack());
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }
    }

}