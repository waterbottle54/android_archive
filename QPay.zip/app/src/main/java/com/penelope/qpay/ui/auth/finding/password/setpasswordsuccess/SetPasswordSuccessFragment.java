package com.penelope.qpay.ui.auth.finding.password.setpasswordsuccess;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentSetPasswordSuccessBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SetPasswordSuccessFragment extends Fragment {

    private FragmentSetPasswordSuccessBinding binding;
    private SetPasswordSuccessViewModel viewModel;


    public SetPasswordSuccessFragment() {
        super(R.layout.fragment_set_password_success);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSetPasswordSuccessBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SetPasswordSuccessViewModel.class);

        binding.buttonLogin.setOnClickListener(v -> viewModel.onLoginClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SetPasswordSuccessViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}