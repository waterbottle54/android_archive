package com.penelope.qpay.utils.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class AuthUtils {

    private static SharedPreferences getPref(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void setCurrentId(Context context, String id) {
        getPref(context).edit().putString("id", id).apply();
    }

    public static String getCurrentId(Context context) {
        return getPref(context).getString("id", null);
    }

}
