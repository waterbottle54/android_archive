package com.penelope.qpay.ui.home;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.NavHost;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.ActivityHomeBinding;
import com.penelope.qpay.utils.ui.AuthUtils;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeActivity extends AppCompatActivity {

    private ActivityHomeBinding binding;
    private NavController navController;
    private NavHostFragment navHostFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 액션바 타이틀을 숨긴다
        setSupportActionBar(binding.toolBar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // 네비게이션 호스트 프래그먼트로부터 네비게이션 컨트롤러를 획득한다
        navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {
            navController = navHostFragment.getNavController();
            // 액션바를 네비게이션 컨트롤러와 연동한다
            NavigationUI.setupActionBarWithNavController(this, navController);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 로그인 여부를 확인한다
        if (AuthUtils.getCurrentId(this) == null) {
            onLoggedOut();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        // 네비게이션 컨트롤러에 뒤로가기 버튼 연동
        return navController.navigateUp() || super.onSupportNavigateUp();
    }

    @Override
    public void onBackPressed() {

        // 뒤로가기가 눌린 경우 현재 하위 화면을 확인한다
        NavDestination destination = navController.getCurrentDestination();
        assert destination != null;

        // 하위 화면이 첫 화면이면 로그아웃 대화상자를 띄운다
        if (destination.getId() == R.id.welcomeFragment) {
            showLogoutDialog();
            return;
        }

        super.onBackPressed();
    }

    private void showLogoutDialog() {

        // 로그아웃을 묻는 대화상자를 띄우고, 로그아웃을 클릭하면 로그아웃 처리한다
        new AlertDialog.Builder(this)
                .setTitle("로그아웃")
                .setMessage("로그아웃 하시겠습니까?")
                .setPositiveButton("로그아웃", (dialog, which) -> {
                    AuthUtils.setCurrentId(this, null);
                    onLoggedOut();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void onLoggedOut() {
        // 로그아웃 시 홈 화면을 종료한다
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        // QR 코드 스캔 결과가 전달됨
        // 현재 장바구니 화면이 띄워져 있을때만 결과를 전달한다
        NavDestination destination = navController.getCurrentDestination();
        assert destination != null;

        if (destination.getId() == R.id.cartFragment) {
            Fragment fragment = navHostFragment.getChildFragmentManager().getFragments().get(0);
            fragment.onActivityResult(requestCode, resultCode, data);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}