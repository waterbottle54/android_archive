package com.penelope.qpay.ui.auth.finding.id.findid;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.user.UserRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class FindIdViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String name = "";       // 이름 입력값
    private String phone = "";      // 휴대폰번호 입력값

    private final MutableLiveData<Boolean> isFindingInProgress = new MutableLiveData<>(false);

    private final UserRepository userRepository;


    @Inject
    public FindIdViewModel(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Boolean> isFindingInProgress() {
        return isFindingInProgress;
    }


    public void onNameChange(String text) {
        name = text.trim();
    }

    public void onPhoneChange(String text) {
        phone = text.trim();
    }

    public void onFindClick() {

        // 이미 검색이 진행중이면 리턴한다
        Boolean isFindingInProgressValue = isFindingInProgress.getValue();
        assert isFindingInProgressValue != null;
        if (isFindingInProgressValue) {
            return;
        }

        if (name.isEmpty() || phone.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        isFindingInProgress.setValue(true);

        // 이름과 폰번호로 유저를 검색한다
        userRepository.getUser(name, phone,
                user -> {
                    isFindingInProgress.setValue(false);

                    if (user != null) {
                        // 일치하는 유저가 있으면 ID 를 보여주는 화면으로 이동한다
                        event.setValue(new Event.NavigateToShowIdScreen(user.getId()));
                    } else {
                        // 없으면 아이디가 없다는 화면으로 이동한다
                        event.setValue(new Event.NavigateToNotFoundScreen());
                    }
                },
                e -> {
                    e.printStackTrace();
                    isFindingInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("회원정보 조회에 실패했습니다"));
                }
        );
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToShowIdScreen extends Event {
            public final String id;

            public NavigateToShowIdScreen(String id) {
                this.id = id;
            }
        }

        public static class NavigateToNotFoundScreen extends Event {
        }
    }

}