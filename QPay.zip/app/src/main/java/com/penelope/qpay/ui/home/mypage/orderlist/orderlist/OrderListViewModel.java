package com.penelope.qpay.ui.home.mypage.orderlist.orderlist;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.order.Order;
import com.penelope.qpay.data.order.OrderRepository;
import com.penelope.qpay.utils.ui.AuthUtils;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class OrderListViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<Order>> orders;


    @Inject
    public OrderListViewModel(Application application, OrderRepository orderRepository) {

        // 현재 사용자 id 와 사용자의 주문내역을 획득한다
        String currentId = AuthUtils.getCurrentId(application);
        orders = orderRepository.getAllOrders(currentId);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Order>> getOrders() {
        return orders;
    }


    public void onOrderClick(Order order) {
        event.setValue(new Event.NavigateToOrderDetailScreen(order));
    }


    public static class Event {

        public static class NavigateToOrderDetailScreen extends Event {
            public final Order order;
            public NavigateToOrderDetailScreen(Order order) {
                this.order = order;
            }
        }
    }

}