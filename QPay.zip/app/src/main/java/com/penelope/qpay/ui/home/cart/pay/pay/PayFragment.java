package com.penelope.qpay.ui.home.cart.pay.pay;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentPayBinding;

import java.text.NumberFormat;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PayFragment extends Fragment {

    private FragmentPayBinding binding;
    private PayViewModel viewModel;


    public PayFragment() {
        super(R.layout.fragment_pay);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPayBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PayViewModel.class);

        // 총 결제금액을 표시한다
        String strPrice = String.format(Locale.getDefault(), "%s원",
                NumberFormat.getInstance().format(viewModel.getTotalPrice())
        );
        binding.textViewTotalPrice.setText(strPrice);

        // 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonSelectCard.setOnClickListener(v -> viewModel.onSelectCardClick());
        binding.buttonPay.setOnClickListener(v -> viewModel.onPayClick());

        // 선택된 카드를 표시한다
        viewModel.getCardName().observe(getViewLifecycleOwner(), cardName ->
                binding.textViewCardName.setText(cardName));

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PayViewModel.Event.NavigateToSelectCardScreen) {
                // 카드 선택 화면으로 이동한다
                NavDirections navDirections = PayFragmentDirections.actionPayFragmentToSelectCardFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof PayViewModel.Event.NavigateToPaySuccessScreen) {
                // 결제 성공 화면으로 이동한다
                NavDirections navDirections = PayFragmentDirections.actionPayFragmentToPaySuccessFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
            if (event instanceof PayViewModel.Event.ShowGeneralMessage) {
                // 뷰모델이 보낸 메세지를 토스트로 보인다
                String message = ((PayViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });

        // 카드 선택 화면에서 결과가 등록되면 뷰모델에 통보한다
        getParentFragmentManager().setFragmentResultListener("select_card_fragment",
                getViewLifecycleOwner(),
                (requestKey, result) -> {
                    String cardName = result.getString("card_name");
                    viewModel.onSelectCardResult(cardName);
                }
        );
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}