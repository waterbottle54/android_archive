package com.penelope.qpay.data.order;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

// DB 의 주문내역에 접근하는 저장소

public class OrderRepository {

    private final CollectionReference userCollection;

    @Inject
    public OrderRepository(FirebaseFirestore firestore) {

        userCollection = firestore.collection("users");
    }

    // 특정 유저의 주문내역을 모두 불러온다

    public void getAllOrders(String userId, OnSuccessListener<List<Order>> onSuccessListener, OnFailureListener onFailureListener) {

        // 특정 유저의 주문내역 컬렉션을 획득한다
        CollectionReference orderCollection = userCollection.document(userId)
                .collection("orders");

        orderCollection.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Order> orders = new ArrayList<>();
                    if (queryDocumentSnapshots == null || queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(orders);
                        return;
                    }
                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        Order order = snapshot.toObject(Order.class);
                        if (order != null) {
                            orders.add(order);
                        }
                    }
                    onSuccessListener.onSuccess(orders);
                })
                .addOnFailureListener(onFailureListener);
    }

    // 위 메소드의 LiveData 버전

    public LiveData<List<Order>> getAllOrders(String userId) {

        MutableLiveData<List<Order>> orders = new MutableLiveData<>();
        getAllOrders(userId, orders::setValue, e -> orders.setValue(null));
        return orders;
    }

    // 특정 유저의 주문내역을 추가한다

    public void addOrder(String userId, Order order, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // 특정 유저의 주문내역 컬렉션을 획득한다
        CollectionReference orderCollection = userCollection.document(userId)
                .collection("orders");

        orderCollection.document(String.valueOf(order.getTime()))
                .set(order)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

}
