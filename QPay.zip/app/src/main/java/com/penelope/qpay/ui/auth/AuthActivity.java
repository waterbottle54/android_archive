package com.penelope.qpay.ui.auth;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.os.Bundle;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.ActivityAuthBinding;
import com.penelope.qpay.ui.auth.login.LoginFragment;
import com.penelope.qpay.ui.auth.register.RegisterFragment;
import com.penelope.qpay.ui.home.HomeActivity;
import com.penelope.qpay.utils.ui.AuthUtils;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class AuthActivity extends AppCompatActivity implements
        LoginFragment.LoginFragmentListener, RegisterFragment.RegisterFragmentListener {

    private NavController navController;
    private ActivityResultLauncher<Intent> homeLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 뷰 바인딩을 실행한다
        ActivityAuthBinding binding = ActivityAuthBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 액션바 타이틀을 숨긴다
        setSupportActionBar(binding.toolBar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // 네비게이션 호스트 프래그먼트로부터 네비게이션 컨트롤러를 획득한다
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {
            navController = navHostFragment.getNavController();
            // 액션바를 네비게이션 컨트롤러와 연동한다
            NavigationUI.setupActionBarWithNavController(this, navController);
        }

        // 홈 액티비티 실행을 위한 런처를 생성한다
        homeLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                // 홈 액티비티가 종료되면 항상 로그인 화면을 보인다
                result -> navController.navigate(R.id.loginFragment));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 로그인 여부를 확인한다
        if (AuthUtils.getCurrentId(this) != null) {
            onLoggedIn();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        // 네비게이션 컨트롤러에 뒤로가기 버튼 연동
        return navController.navigateUp() || super.onSupportNavigateUp();
    }

    @Override
    public void onLoggedIn() {
        // 로그인 처리되면 홈 화면으로 이동한다
        Intent intent = new Intent(this, HomeActivity.class);
        homeLauncher.launch(intent);
    }

}