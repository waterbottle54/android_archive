package com.penelope.qpay.data.user;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import javax.inject.Inject;

// DB 의 회원정보에 접근하는 저장소
public class UserRepository {

    private final CollectionReference userCollection;


    @Inject
    public UserRepository(FirebaseFirestore firestore) {
        // DB 에서 회원정보 컬렉션을 획득한다
        userCollection = firestore.collection("users");
    }

    // 새로운 회원정보를 추가한다

    public void addUser(User user, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        userCollection.document(user.getId())
                .set(user)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    // ID 로 회원정보를 가져온다

    public void getUser(String id, OnSuccessListener<User> onSuccessListener, OnFailureListener onFailureListener) {

        userCollection.document(id)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot != null) {
                        User user = documentSnapshot.toObject(User.class);
                        onSuccessListener.onSuccess(user);
                    } else {
                        onSuccessListener.onSuccess(null);
                    }
                })
                .addOnFailureListener(onFailureListener);
    }

    // 위 메소드의 LiveData 버전

    public LiveData<User> getUser(String id) {

        MutableLiveData<User> user = new MutableLiveData<>();
        getUser(id, user::setValue, e -> user.setValue(null));
        return user;
    }


    // 이름과 휴대폰 번호로 회원정보를 가져온다

    public void getUser(String name, String phone, OnSuccessListener<User> onSuccessListener, OnFailureListener onFailureListener) {

        userCollection
                .whereEqualTo("name", name)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    // 검색된 스냅샷을 회원정보로 변환하여 제공한다
                    if (queryDocumentSnapshots == null || queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        User user = snapshot.toObject(User.class);
                        if (user != null && user.getPhone().equals(phone)) {
                            onSuccessListener.onSuccess(user);
                            return;
                        }
                    }
                    onSuccessListener.onSuccess(null);
                })
                .addOnFailureListener(onFailureListener);
    }

    // 특정 회원의 비밀번호를 변경한다

    public void setUserPassword(String id, String password, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        userCollection.document(id)
                .update("password", password)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

}




