package com.penelope.qpay.ui.auth.finding.notfound;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class NotFoundViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final boolean idOrPassword;


    @Inject
    public NotFoundViewModel(SavedStateHandle savedStateHandle) {
        Boolean idOrPasswordObj = savedStateHandle.get("idOrPassword");
        assert idOrPasswordObj != null;
        idOrPassword = idOrPasswordObj;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    public void onFindAgainClick() {
        if (idOrPassword) {
            event.setValue(new Event.NavigateToFindIdScreen());
        } else {
            event.setValue(new Event.NavigateToFindPasswordScreen());
        }
    }

    public void onRegisterClick() {
        event.setValue(new Event.NavigateToRegisterScreen());
    }

    public void onExitClick() {
        event.setValue(new Event.NavigateToLoginScreen());
    }


    public static class Event {

        public static class NavigateToRegisterScreen extends Event {
        }

        public static class NavigateToFindIdScreen extends Event {
        }

        public static class NavigateToFindPasswordScreen extends Event {
        }

        public static class NavigateToLoginScreen extends Event {
        }
    }

}