package com.penelope.qpay.ui.home.browse;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.product.Product;
import com.penelope.qpay.data.product.ProductRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class BrowseViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    // 모든 상품 목록
    private final LiveData<List<Product>> products;


    @Inject
    public BrowseViewModel(ProductRepository productRepository) {

        // 저장소에서 모든 상품 목록을 가져온다
        products = productRepository.getAllProducts();
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Product>> getProducts() {
        return products;
    }


    public static class Event {

    }

}