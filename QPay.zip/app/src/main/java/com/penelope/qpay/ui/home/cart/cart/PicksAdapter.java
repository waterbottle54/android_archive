package com.penelope.qpay.ui.home.cart.cart;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.qpay.data.pick.Pick;
import com.penelope.qpay.databinding.PickItemBinding;

import java.text.NumberFormat;
import java.util.Locale;

public class PicksAdapter extends ListAdapter<Pick, PicksAdapter.PickViewHolder> {

    class PickViewHolder extends RecyclerView.ViewHolder {

        private final PickItemBinding binding;

        public PickViewHolder(PickItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Pick model) {

            binding.textViewProductName.setText(model.getProduct().getName());

            String strPrice = String.format(Locale.getDefault(), "%s원",
                    NumberFormat.getInstance().format(model.getProduct().getPrice())
            );
            binding.textViewProductPrice.setText(strPrice);

            String strCount = model.getCount() + "개";
            binding.textViewProductCount.setText(strCount);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public PicksAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public PickViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        PickItemBinding binding = PickItemBinding.inflate(layoutInflater, parent, false);
        return new PickViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull PickViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Pick> {

        @Override
        public boolean areItemsTheSame(@NonNull Pick oldItem, @NonNull Pick newItem) {
            return oldItem.getProduct().getId().equals(newItem.getProduct().getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Pick oldItem, @NonNull Pick newItem) {
            return oldItem.equals(newItem);
        }
    }

}