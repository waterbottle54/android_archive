package com.penelope.qpay.ui.home.mypage.orderlist.orderdetail;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentOrderDetailBinding;
import com.penelope.qpay.ui.home.cart.cart.PicksAdapter;
import com.penelope.qpay.utils.ui.TimeUtils;

import java.text.NumberFormat;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class OrderDetailFragment extends Fragment {

    private FragmentOrderDetailBinding binding;
    private OrderDetailViewModel viewModel;


    public OrderDetailFragment() {
        super(R.layout.fragment_order_detail);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentOrderDetailBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(OrderDetailViewModel.class);

        // 주문 일시를 텍스트뷰에 표시한다
        long orderTime = viewModel.getOrderTime();
        String strOrderTime = String.format(Locale.getDefault(), "%s %s",
                TimeUtils.getDateString(orderTime),
                TimeUtils.getTimeString(orderTime)
        );
        binding.textViewOrderTime.setText(strOrderTime);

        // 합계를 텍스트뷰에 표시한다
        int totalPrice = viewModel.getTotalPrice();
        String strTotalPrice = NumberFormat.getInstance().format(totalPrice) + "원";
        binding.textViewTotalPrice.setText(strTotalPrice);

        // 품목 목록 리사이클러 뷰를 어댑터와 연결한다
        PicksAdapter adapter = new PicksAdapter();
        binding.recyclerPick.setAdapter(adapter);
        binding.recyclerPick.setHasFixedSize(true);

        // 품목 목록을 리사이클러 뷰에 띄운다
        adapter.submitList(viewModel.getPicks());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}