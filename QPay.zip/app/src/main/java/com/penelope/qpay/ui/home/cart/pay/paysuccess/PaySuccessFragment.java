package com.penelope.qpay.ui.home.cart.pay.paysuccess;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentPaySuccessBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PaySuccessFragment extends Fragment {

    private FragmentPaySuccessBinding binding;
    private PaySuccessViewModel viewModel;


    public PaySuccessFragment() {
        super(R.layout.fragment_pay_success);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPaySuccessBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PaySuccessViewModel.class);

        binding.buttonBack.setOnClickListener(v -> viewModel.onBackClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PaySuccessViewModel.Event.NavigateBack) {
                // 이전 화면으로 돌아간다
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}