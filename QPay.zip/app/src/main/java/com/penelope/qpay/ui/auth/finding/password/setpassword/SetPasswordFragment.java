package com.penelope.qpay.ui.auth.finding.password.setpassword;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentSetPasswordBinding;
import com.penelope.qpay.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SetPasswordFragment extends Fragment {

    private FragmentSetPasswordBinding binding;
    private SetPasswordViewModel viewModel;


    public SetPasswordFragment() {
        super(R.layout.fragment_set_password);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSetPasswordBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SetPasswordViewModel.class);

        // 에딧 텍스트 입력값이 변경되면 뷰모델에 통보한다
        binding.editTextPassword.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPasswordChange(text);
            }
        });
        binding.editTextPasswordConfirm.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPasswordConfirmChange(text);
            }
        });

        // 변경 버튼이 클릭되면 뷰모델에 통보한다
        binding.buttonSet.setOnClickListener(v -> viewModel.onUpdateClick());

        // 변경 중일 때 로딩 바를 보인다
        viewModel.isUpdateInProgress().observe(getViewLifecycleOwner(), isUpdateInProgress ->
                binding.progressBar4.setVisibility(isUpdateInProgress ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델이 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SetPasswordViewModel.Event.NavigateToSetPasswordSuccessScreen) {
                // 비밀번호 변경 성공 화면으로 이동한다
                NavDirections navDirections = SetPasswordFragmentDirections.actionSetPasswordFragmentToSetPasswordSuccessFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof SetPasswordViewModel.Event.NavigateToSetPasswordFailureScreen) {
                // 비밀번호 변경 실패 화면으로 이동한다
                NavDirections navDirections = SetPasswordFragmentDirections.actionSetPasswordFragmentToSetPasswordFailureFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof SetPasswordViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 보인다
                String message = ((SetPasswordViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}