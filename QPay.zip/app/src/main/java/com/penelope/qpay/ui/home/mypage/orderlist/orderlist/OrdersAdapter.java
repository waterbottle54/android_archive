package com.penelope.qpay.ui.home.mypage.orderlist.orderlist;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.qpay.data.order.Order;
import com.penelope.qpay.databinding.OrderItemBinding;
import com.penelope.qpay.utils.ui.TimeUtils;

import java.text.NumberFormat;
import java.util.Locale;

public class OrdersAdapter extends ListAdapter<Order, OrdersAdapter.OrderViewHolder> {

    class OrderViewHolder extends RecyclerView.ViewHolder {

        private final OrderItemBinding binding;

        public OrderViewHolder(OrderItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            // 아이템 클릭 리스너를 구현한다
            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Order model) {

            // 주문 일시를 표시한다
            String strOrderTime = String.format(Locale.getDefault(), "%s\n%s",
                    TimeUtils.getDateString(model.getTime()),
                    TimeUtils.getTimeString(model.getTime())
            );
            binding.textViewOrderTime.setText(strOrderTime);

            // 주문 품목을 표시한다
            if (model.getPicks().size() == 1) {
                binding.textViewOrderContent.setText(model.getPicks().get(0).getProduct().getName());
            } else if (model.getPicks().size() > 1) {
                String strItems = String.format(Locale.getDefault(), "%s\n외%d",
                        model.getPicks().get(0).getProduct().getName(),
                        model.getPicks().size() - 1
                );
                binding.textViewOrderContent.setText(strItems);
            }

            // 주문 금액을 표시한다
            String strPrice = String.format(Locale.getDefault(), "%s원",
                    NumberFormat.getInstance().format(model.getTotalPrice())
            );
            binding.textViewOrderPrice.setText(strPrice);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public OrdersAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        OrderItemBinding binding = OrderItemBinding.inflate(layoutInflater, parent, false);
        return new OrderViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Order> {

        @Override
        public boolean areItemsTheSame(@NonNull Order oldItem, @NonNull Order newItem) {
            return oldItem.getTime() == newItem.getTime();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Order oldItem, @NonNull Order newItem) {
            return oldItem.equals(newItem);
        }
    }

}