package com.penelope.qpay.ui.home.mypage.inquiry;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentInquiryBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class InquiryFragment extends Fragment {

    private FragmentInquiryBinding binding;
    private InquiryViewModel viewModel;


    public InquiryFragment() {
        super(R.layout.fragment_inquiry);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentInquiryBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(InquiryViewModel.class);

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}