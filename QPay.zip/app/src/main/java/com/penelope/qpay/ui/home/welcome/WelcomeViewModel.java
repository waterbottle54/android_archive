package com.penelope.qpay.ui.home.welcome;

import android.app.Application;
import android.view.animation.Transformation;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.product.Product;
import com.penelope.qpay.data.product.ProductRepository;
import com.penelope.qpay.data.user.User;
import com.penelope.qpay.data.user.UserRepository;
import com.penelope.qpay.utils.ui.AuthUtils;

import java.util.List;
import java.util.Random;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class WelcomeViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<User> currentUser;

    private String query = "";
    private final MutableLiveData<Boolean> isQueryInProgress = new MutableLiveData<>(false);
    private final MutableLiveData<Product> searchedProduct = new MutableLiveData<>();

    private final LiveData<List<Product>> products;
    private final MutableLiveData<Integer> randomIndex = new MutableLiveData<>();
    private final LiveData<Product> randomProduct;

    private final ProductRepository productRepository;


    @Inject
    public WelcomeViewModel(Application application, UserRepository userRepository, ProductRepository productRepository) {

        // 현재 사용자를 획득한다
        String currentId = AuthUtils.getCurrentId(application);
        currentUser = userRepository.getUser(currentId);

        products = productRepository.getAllProducts();
        randomProduct = Transformations.switchMap(products, productList ->
                Transformations.map(randomIndex, productList::get));

        this.productRepository = productRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Boolean> isQueryInProgress() {
        return isQueryInProgress;
    }

    public LiveData<User> getCurrentUser() {
        return currentUser;
    }

    public LiveData<Product> getSearchedProduct() {
        return searchedProduct;
    }

    public LiveData<Product> getRandomProduct() {
        return randomProduct;
    }


    public void onBrowseClick() {
        event.setValue(new Event.NavigateToBrowseScreen());
    }

    public void onMyPageClick() {
        event.setValue(new Event.NavigateToMyPageScreen());
    }

    public void onCartClick() {
        event.setValue(new Event.NavigateToCartScreen());
    }

    public void onQueryChange(String text) {
        query = text.trim();
    }

    public void onSearchClick() {

        // 이미 검색이 진행중이면 리턴한다
        Boolean isQueryInProgressValue = isQueryInProgress.getValue();
        assert isQueryInProgressValue != null;
        if (isQueryInProgressValue) {
            return;
        }

        if (query.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("검색어를 입력해주세요"));
            return;
        }

        // 상품명으로 상품 검색을 실행한다

        isQueryInProgress.setValue(true);

        productRepository.findProductByName(query,
                product -> {
                    isQueryInProgress.setValue(false);
                    searchedProduct.setValue(product);
                    if (product == null) {
                        event.setValue(new Event.ShowGeneralMessage("정확한 상품명을 입력해주세요"));
                    }
                },
                e -> {
                    isQueryInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("상품 검색에 실패했습니다"));
                    e.printStackTrace();
                });
    }

    public void onRotationTick() {

        List<Product> productList = products.getValue();
        if (productList == null) {
            return;
        }

        // 검색한 상품이 있을 경우 로테이션하지 않는다
        if (searchedProduct.getValue() != null) {
            return;
        }

        // 상품 목록 중 몇 번째 상품을 보여줄 지를 랜덤으로 결정한다
        randomIndex.setValue(new Random().nextInt(productList.size()));
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToBrowseScreen extends Event {
        }

        public static class NavigateToMyPageScreen extends Event {
        }

        public static class NavigateToCartScreen extends Event {
        }
    }

}







