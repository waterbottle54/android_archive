package com.penelope.qpay.ui.auth.finding.notfound;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentNotFoundBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class NotFoundFragment extends Fragment {

    private FragmentNotFoundBinding binding;
    private NotFoundViewModel viewModel;


    public NotFoundFragment() {
        super(R.layout.fragment_not_found);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentNotFoundBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(NotFoundViewModel.class);

        // 버튼이 클릭되면 뷰모델에 통보한다
        binding.buttonFindAgain.setOnClickListener(v -> viewModel.onFindAgainClick());
        binding.buttonRegister.setOnClickListener(v -> viewModel.onRegisterClick());
        binding.buttonBack.setOnClickListener(v -> viewModel.onExitClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof NotFoundViewModel.Event.NavigateToFindIdScreen) {
                Bundle result = new Bundle();
                result.putBoolean("find_id", true);
                getParentFragmentManager().setFragmentResult("navigation", result);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof NotFoundViewModel.Event.NavigateToFindPasswordScreen) {
                Bundle result = new Bundle();
                result.putBoolean("find_password", true);
                getParentFragmentManager().setFragmentResult("navigation", result);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof NotFoundViewModel.Event.NavigateToRegisterScreen) {
                Bundle result = new Bundle();
                result.putBoolean("register", true);
                getParentFragmentManager().setFragmentResult("navigation", result);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof NotFoundViewModel.Event.NavigateToLoginScreen) {
                Bundle result = new Bundle();
                result.putBoolean("login", true);
                getParentFragmentManager().setFragmentResult("navigation", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}