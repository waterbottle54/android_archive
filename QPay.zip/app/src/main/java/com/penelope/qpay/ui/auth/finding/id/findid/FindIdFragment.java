package com.penelope.qpay.ui.auth.finding.id.findid;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentFindIdBinding;
import com.penelope.qpay.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class FindIdFragment extends Fragment {

    private FragmentFindIdBinding binding;
    private FindIdViewModel viewModel;


    public FindIdFragment() {
        super(R.layout.fragment_find_id);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentFindIdBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(FindIdViewModel.class);

        // 이름, 폰번호 에딧텍스트가 변경되면 뷰모델에 통보한다
        binding.editTextName.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onNameChange(text);
            }
        });
        binding.editTextPhone.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPhoneChange(text);
            }
        });
        // 찾기 버튼이 클릭되면 뷰모델에 통보한다
        binding.buttonFind.setOnClickListener(v -> viewModel.onFindClick());

        // 검색 진행 중이면 로딩 바를 표시한다
        viewModel.isFindingInProgress().observe(getViewLifecycleOwner(), isFindingInProgress ->
                binding.progressBar3.setVisibility(isFindingInProgress ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델이 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof FindIdViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 보여준다
                String message = ((FindIdViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof FindIdViewModel.Event.NavigateToShowIdScreen) {
                // 찾은 아이디를 보여주는 화면으로 이동한다
                String id = ((FindIdViewModel.Event.NavigateToShowIdScreen) event).id;
                NavDirections navDirections = FindIdFragmentDirections.actionFindIdFragmentToShowIdFragment(id);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof FindIdViewModel.Event.NavigateToNotFoundScreen) {
                // 아이디가 없다는 화면으로 이동한다
                NavDirections navDirections = FindIdFragmentDirections.actionFindIdFragmentToNotFoundFragment(true);
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}