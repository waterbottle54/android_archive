package com.penelope.qpay.ui.auth.finding.id.showid;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ShowIdViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String id;


    @Inject
    public ShowIdViewModel(SavedStateHandle savedStateHandle) {
        id = savedStateHandle.get("id");
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getId() {
        return id;
    }


    public void onLoginClick() {
        event.setValue(new Event.NavigateToLoginScreen());
    }

    public void onFindPasswordClick() {
        event.setValue(new Event.NavigateToFindPasswordScreen());
    }


    public static class Event {

        public static class NavigateToLoginScreen extends Event {
        }

        public static class NavigateToFindPasswordScreen extends Event {
        }
    }

}