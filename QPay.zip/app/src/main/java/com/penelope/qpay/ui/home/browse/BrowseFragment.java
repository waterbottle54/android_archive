package com.penelope.qpay.ui.home.browse;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentBrowseBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class BrowseFragment extends Fragment {

    private FragmentBrowseBinding binding;
    private BrowseViewModel viewModel;


    public BrowseFragment() {
        super(R.layout.fragment_browse);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentBrowseBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(BrowseViewModel.class);

        // 상품 목록 리사이클러 뷰에 어댑터를 연결한다
        ProductsAdapter adapter = new ProductsAdapter();
        binding.recyclerProduct.setAdapter(adapter);
        binding.recyclerProduct.setHasFixedSize(true);

        // 뷰모델의 상품 목록을 리사이클러 뷰에 띄운다
        viewModel.getProducts().observe(getViewLifecycleOwner(), products -> {
            if (products != null) {
                // 상품 목록 어댑터를 업데이트한다
                adapter.submitList(products);
            }
            // 로딩 바를 지운다
            binding.progressBar6.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}