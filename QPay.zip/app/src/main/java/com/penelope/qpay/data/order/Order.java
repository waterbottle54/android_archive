package com.penelope.qpay.data.order;

// 주문내역 정보

import com.penelope.qpay.data.pick.Pick;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

public class Order implements Serializable {

    private List<Pick> picks;
    private int totalPrice;
    private long time;


    public Order() {
    }

    public Order(List<Pick> picks, int totalPrice) {
        this.picks = picks;
        this.totalPrice = totalPrice;
        this.time = System.currentTimeMillis();
    }

    public List<Pick> getPicks() {
        return picks;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public long getTime() {
        return time;
    }

    public void setPicks(List<Pick> picks) {
        this.picks = picks;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public void setTime(long time) {
        this.time = time;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Order order = (Order) o;
        return totalPrice == order.totalPrice && time == order.time && picks.equals(order.picks);
    }

    @Override
    public int hashCode() {
        return Objects.hash(picks, totalPrice, time);
    }
}
