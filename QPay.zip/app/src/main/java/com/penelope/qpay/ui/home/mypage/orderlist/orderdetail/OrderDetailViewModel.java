package com.penelope.qpay.ui.home.mypage.orderlist.orderdetail;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.order.Order;
import com.penelope.qpay.data.pick.Pick;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class OrderDetailViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final Order order;


    @Inject
    public OrderDetailViewModel(SavedStateHandle savedStateHandle) {
        order = savedStateHandle.get("order");
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public List<Pick> getPicks() {
        return order.getPicks();
    }

    public long getOrderTime() {
        return order.getTime();
    }

    public int getTotalPrice() {
        return order.getTotalPrice();
    }


    public static class Event {

    }

}