package com.penelope.qpay.ui.home.cart.addtocart;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.product.Product;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class AddToCartViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final Product product;


    @Inject
    public AddToCartViewModel(SavedStateHandle savedStateHandle) {

        product = savedStateHandle.get("product");
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public Product getProduct() {
        return product;
    }


    public void onYesClick() {
        event.setValue(new Event.NavigateBackWithResult(product));
    }

    public void onNoClick() {
        event.setValue(new Event.NavigateBackWithResult(null));
    }


    public static class Event {

        public static class NavigateBackWithResult extends Event {
            public final Product product;
            public NavigateBackWithResult(Product product) {
                this.product = product;
            }
        }
    }

}