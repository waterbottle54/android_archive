package com.penelope.qpay.ui.auth.login;

import android.app.Application;
import android.os.Bundle;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.user.UserRepository;
import com.penelope.qpay.utils.ui.AuthUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class LoginViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String id = "";
    private String password = "";

    private final Application application;
    private final UserRepository userRepository;


    @Inject
    public LoginViewModel(Application application, UserRepository userRepository) {

        this.application = application;
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    public void onIdChange(String text) {
        id = text.trim();
    }

    public void onPasswordChange(String text) {
        password = text.trim();
    }

    public void onLoginClick() {

        if (id.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("아이디를 입력해주세요"));
            return;
        }

        if (password.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("비밀번호를 입력해주세요"));
            return;
        }

        userRepository.getUser(id,
                user -> {
                    if (user == null) {
                        event.setValue(new Event.ShowGeneralMessage("가입되지 않은 회원입니다"));
                        return;
                    }
                    if (!password.equals(user.getPassword())) {
                        event.setValue(new Event.ShowGeneralMessage("비밀번호가 틀립니다"));
                        return;
                    }
                    AuthUtils.setCurrentId(application, id);
                    event.setValue(new Event.NavigateToHomeScreen());
                },
                e -> event.setValue(new Event.ShowGeneralMessage("회원 정보를 불러오지 못했습니다"))
        );


    }

    public void onRegisterClick() {
        event.setValue(new Event.NavigateToRegisterScreen());
    }

    public void onFindClick() {
        event.setValue(new Event.NavigateToFindIdPasswordScreen());
    }

    public void onNavigationResult(Bundle result) {

        if (result.containsKey("register")) {
            event.setValue(new Event.NavigateToRegisterScreen());
        }
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToHomeScreen extends Event {
        }

        public static class NavigateToRegisterScreen extends Event {
        }

        public static class NavigateToFindIdPasswordScreen extends Event {
        }
    }

}