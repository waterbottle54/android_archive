package com.penelope.qpay.ui.auth.finding.finding;

import android.os.Bundle;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class FindingViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();


    @Inject
    public FindingViewModel() {

    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    public void onFindIdClick() {
        event.setValue(new Event.NavigateToFindIdScreen());
    }

    public void onFindPasswordClick() {
        event.setValue(new Event.NavigateToFindPasswordScreen());
    }

    public void onBackClick() {
        event.setValue(new Event.NavigateBack());
    }

    public void onNavigationResult(Bundle result) {

        if (result.containsKey("login")) {
            event.setValue(new Event.NavigateBack());
        } else if (result.containsKey("find_password")) {
            event.setValue(new Event.NavigateToFindPasswordScreen());
        } else if (result.containsKey("find_id")) {
            event.setValue(new Event.NavigateToFindIdScreen());
        } else if (result.containsKey("register")) {
            event.setValue(new Event.NavigateToRegisterScreen());
        }
    }



    public static class Event {

        public static class NavigateToFindIdScreen extends Event {
        }

        public static class NavigateToFindPasswordScreen extends Event {
        }

        public static class NavigateBack extends Event {
        }

        public static class NavigateToRegisterScreen extends Event {
        }
    }

}