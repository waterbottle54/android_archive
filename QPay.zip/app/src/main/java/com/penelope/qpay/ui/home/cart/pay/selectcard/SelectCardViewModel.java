package com.penelope.qpay.ui.home.cart.pay.selectcard;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SelectCardViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final List<String> cardList = new ArrayList<>();


    @Inject
    public SelectCardViewModel() {

        cardList.add("산업은행");
        cardList.add("기업은행");
        cardList.add("신한은행");
        cardList.add("하나은행");
        cardList.add("우리은행");
        cardList.add("농협카드");
        cardList.add("부산은행");
        cardList.add("대구은행");
        cardList.add("경남은행");
        cardList.add("전북은행");
        cardList.add("새마을금고");
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public List<String> getCardList() {
        return cardList;
    }


    public void onCardClick(String cardName) {
        event.setValue(new Event.NavigateBackWithResult(cardName));
    }


    public static class Event {

        public static class NavigateBackWithResult extends Event {
            public final String cardName;
            public NavigateBackWithResult(String cardName) {
                this.cardName = cardName;
            }
        }
    }

}