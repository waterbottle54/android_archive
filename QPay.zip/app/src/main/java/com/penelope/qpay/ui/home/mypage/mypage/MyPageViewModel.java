package com.penelope.qpay.ui.home.mypage.mypage;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.user.User;
import com.penelope.qpay.data.user.UserRepository;
import com.penelope.qpay.utils.ui.AuthUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class MyPageViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    // 현재 사용자
    private final LiveData<User> currentUser;


    @Inject
    public MyPageViewModel(Application application, UserRepository userRepository) {

        // 현재 사용자 정보를 획득한다
        String currentId = AuthUtils.getCurrentId(application);
        currentUser = userRepository.getUser(currentId);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<User> getCurrentUser() {
        return currentUser;
    }


    public void onOrderListClick() {
        event.setValue(new Event.NavigateToOrderListScreen());
    }

    public void onSetPasswordClick() {

        User user = currentUser.getValue();
        if (user == null) {
            return;
        }

        event.setValue(new Event.NavigateToSetPasswordScreen(user.getId()));
    }

    public void onInquiryClick() {
        event.setValue(new Event.NavigateToInquiryScreen());
    }


    public static class Event {

        public static class NavigateToOrderListScreen extends Event {
        }

        public static class NavigateToSetPasswordScreen extends Event {
            public final String id;
            public NavigateToSetPasswordScreen(String id) {
                this.id = id;
            }
        }

        public static class NavigateToInquiryScreen extends Event {
        }
    }

}



