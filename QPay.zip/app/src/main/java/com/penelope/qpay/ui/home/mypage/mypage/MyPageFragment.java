package com.penelope.qpay.ui.home.mypage.mypage;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentMyPageBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MyPageFragment extends Fragment {

    private FragmentMyPageBinding binding;
    private MyPageViewModel viewModel;


    public MyPageFragment() {
        super(R.layout.fragment_my_page);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentMyPageBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(MyPageViewModel.class);

        // 버튼 클릭 시 뷰모델에 통보한다
        binding.imageButtonOrderList.setOnClickListener(v -> viewModel.onOrderListClick());
        binding.imageButtonSetPassword.setOnClickListener(v -> viewModel.onSetPasswordClick());
        binding.imageButtonInquiry.setOnClickListener(v -> viewModel.onInquiryClick());

        // 현재 사용자 이름을 텍스트뷰에 출력한다
        viewModel.getCurrentUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null) {
                String strWelcome = user.getName() + " 고객님 안녕하세요";
                binding.textViewUserName.setText(strWelcome);
            }
        });

        // 뷰모델이 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof MyPageViewModel.Event.NavigateToOrderListScreen) {
                // 주문 내역 화면으로 이동한다
                NavDirections navDirections = MyPageFragmentDirections.actionMyPageFragmentToOrderListFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof MyPageViewModel.Event.NavigateToSetPasswordScreen) {
                // 비밀번호 설정 화면으로 이동한다
                String id = ((MyPageViewModel.Event.NavigateToSetPasswordScreen) event).id;
                NavDirections navDirections = MyPageFragmentDirections.actionMyPageFragmentToSetPasswordFragment2(id);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof MyPageViewModel.Event.NavigateToInquiryScreen) {
                // 문의 화면으로 이동한다
                NavDirections navDirections = MyPageFragmentDirections.actionMyPageFragmentToInquiryFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}