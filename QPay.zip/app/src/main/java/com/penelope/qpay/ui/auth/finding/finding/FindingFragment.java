package com.penelope.qpay.ui.auth.finding.finding;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentFindingBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class FindingFragment extends Fragment {

    private FragmentFindingBinding binding;
    private FindingViewModel viewModel;


    public FindingFragment() {
        super(R.layout.fragment_finding);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentFindingBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(FindingViewModel.class);

        // 버튼이 클릭되면 뷰모델에 통보한다
        binding.buttonFindId.setOnClickListener(v -> viewModel.onFindIdClick());
        binding.buttonFindPassword.setOnClickListener(v -> viewModel.onFindPasswordClick());
        binding.buttonBack.setOnClickListener(v -> viewModel.onBackClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof FindingViewModel.Event.NavigateBack) {
                // 이전 화면으로 돌아간다
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof FindingViewModel.Event.NavigateToFindIdScreen) {
                // 아이디 찾기 화면으로 이동한다
                NavDirections navDirections = FindingFragmentDirections.actionFindingFragmentToFindIdFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof FindingViewModel.Event.NavigateToFindPasswordScreen) {
                // 비밀번호 찾기 화면으로 이동한다
                NavDirections navDirections = FindingFragmentDirections.actionFindingFragmentToFindPasswordFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof FindingViewModel.Event.NavigateToRegisterScreen) {
                Bundle result = new Bundle();
                result.putBoolean("register", true);
                getParentFragmentManager().setFragmentResult("navigation", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });

        getParentFragmentManager().setFragmentResultListener("navigation", getViewLifecycleOwner(),
                (requestKey, result) -> viewModel.onNavigationResult(result));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}