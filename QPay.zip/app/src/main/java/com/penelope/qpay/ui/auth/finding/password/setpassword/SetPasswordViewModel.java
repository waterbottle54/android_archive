package com.penelope.qpay.ui.auth.finding.password.setpassword;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.penelope.qpay.data.user.UserRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SetPasswordViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    // 비밀번호를 변경할 id
    private final String id;

    private String password;
    private String passwordConfirm;

    private final MutableLiveData<Boolean> isUpdateInProgress = new MutableLiveData<>(false);

    private final UserRepository userRepository;


    @Inject
    public SetPasswordViewModel(SavedStateHandle savedStateHandle, UserRepository userRepository) {
        id = savedStateHandle.get("id");
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Boolean> isUpdateInProgress() {
        return isUpdateInProgress;
    }


    public void onPasswordChange(String text) {
        password = text.trim();
    }

    public void onPasswordConfirmChange(String text) {
        passwordConfirm = text.trim();
    }

    public void onUpdateClick() {

        // 이미 변경 진행 중이면 리턴한다
        Boolean isUpdateInProgressValue = isUpdateInProgress.getValue();
        assert isUpdateInProgressValue != null;
        if (isUpdateInProgressValue) {
            return;
        }

        if (password.isEmpty() || passwordConfirm.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        // 비밀번호가 일치하지 않으면 관련 화면으로 이동한다
        if (!password.equals(passwordConfirm)) {
            event.setValue(new Event.NavigateToSetPasswordFailureScreen());
            return;
        }

        isUpdateInProgress.setValue(true);

        userRepository.setUserPassword(id, password,
                unused -> {
                    event.setValue(new Event.NavigateToSetPasswordSuccessScreen());
                },
                e -> event.setValue(new Event.ShowGeneralMessage("회원정보 접근에 실패했습니다"))
        );
    }

    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToSetPasswordSuccessScreen extends Event {
        }

        public static class NavigateToSetPasswordFailureScreen extends Event {
        }
    }

}