package com.penelope.qpay.ui.home.cart.pay.selectcard;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentSelectCardBinding;
import com.penelope.qpay.ui.home.cart.addtocart.CardsAdapter;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SelectCardFragment extends Fragment {

    private FragmentSelectCardBinding binding;
    private SelectCardViewModel viewModel;


    public SelectCardFragment() {
        super(R.layout.fragment_select_card);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSelectCardBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SelectCardViewModel.class);

        // 카드 리사이클러 뷰에 어댑터를 연결하고 카드 목록을 보인다
        CardsAdapter adapter = new CardsAdapter();
        binding.recyclerCard.setAdapter(adapter);
        binding.recyclerCard.setHasFixedSize(true);

        adapter.submitList(viewModel.getCardList());

        // 카드 아이템이 클릭되면 뷰모델에 통보한다
        adapter.setOnItemSelectedListener(position -> {
            String cardName = adapter.getCurrentList().get(position);
            viewModel.onCardClick(cardName);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SelectCardViewModel.Event.NavigateBackWithResult) {
                // 선택된 카드를 결과로 등록하고 이전 화면으로 이동한다
                String cardName = ((SelectCardViewModel.Event.NavigateBackWithResult) event).cardName;
                Bundle result = new Bundle();
                result.putString("card_name", cardName);
                getParentFragmentManager().setFragmentResult("select_card_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}