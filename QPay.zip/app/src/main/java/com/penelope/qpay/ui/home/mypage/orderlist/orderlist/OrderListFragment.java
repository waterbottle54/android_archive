package com.penelope.qpay.ui.home.mypage.orderlist.orderlist;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.data.order.Order;
import com.penelope.qpay.databinding.FragmentOrderListBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class OrderListFragment extends Fragment {

    private FragmentOrderListBinding binding;
    private OrderListViewModel viewModel;


    public OrderListFragment() {
        super(R.layout.fragment_order_list);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentOrderListBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(OrderListViewModel.class);

        // 주문내역 리사이클러 뷰에 어댑터를 연결한다
        OrdersAdapter adapter = new OrdersAdapter();
        binding.recyclerOrder.setAdapter(adapter);
        binding.recyclerOrder.setHasFixedSize(true);

        // 주문내역 클릭 시 뷰모델에 통보한다
        adapter.setOnItemSelectedListener(position -> {
            Order order = adapter.getCurrentList().get(position);
            viewModel.onOrderClick(order);
        });

        // 주문내역을 리사이클러 뷰에 표시한다
        viewModel.getOrders().observe(getViewLifecycleOwner(), orders -> {
            if (orders != null) {
                adapter.submitList(orders);
                binding.textViewNoOrders.setVisibility(orders.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            }
            binding.progressBar7.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof OrderListViewModel.Event.NavigateToOrderDetailScreen) {
                // 주문내역 상세 화면으로 이동한다
                Order order = ((OrderListViewModel.Event.NavigateToOrderDetailScreen) event).order;
                NavDirections navDirections = OrderListFragmentDirections.actionOrderListFragmentToOrderDetailFragment(order);
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}