package com.penelope.qpay.data.user;

// 회원 정보

public class User {

    private String id;          // 아이디
    private String password;    // 비밀번호
    private String name;        // 이름
    private String phone;       // 전화번호
    private long created;       // 가입일자

    // 생성자, 접근자

    public User() {
    }

    public User(String id, String password, String name, String phone, long created) {
        this.id = id;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.created = created;
    }

    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public long getCreated() {
        return created;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setCreated(long created) {
        this.created = created;
    }
}
