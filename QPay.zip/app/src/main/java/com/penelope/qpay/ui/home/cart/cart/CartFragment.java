package com.penelope.qpay.ui.home.cart.cart;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.penelope.qpay.R;
import com.penelope.qpay.data.pick.Pick;
import com.penelope.qpay.data.product.Product;
import com.penelope.qpay.databinding.DialogPickCountBinding;
import com.penelope.qpay.databinding.FragmentCartBinding;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class CartFragment extends Fragment {

    private FragmentCartBinding binding;
    private CartViewModel viewModel;

    // QR 코드 스캐너
    private IntentIntegrator intentIntegrator;


    public CartFragment() {
        super(R.layout.fragment_cart);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // QR 코드 스캐너를 초기화한다
        intentIntegrator = new IntentIntegrator(requireActivity());
        intentIntegrator.setOrientationLocked(true);

        binding = FragmentCartBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(CartViewModel.class);

        // 버튼이 클릭되면 뷰모델에 통보한다
        binding.imageButtonScanQr.setOnClickListener(v -> viewModel.onScanQrClick());
        binding.buttonPay.setOnClickListener(v -> viewModel.onPayClick());

        // 장바구니 리사이클러 뷰를 어댑터와 연결한다
        PicksAdapter adapter = new PicksAdapter();
        binding.recyclerPick.setAdapter(adapter);
        binding.recyclerPick.setHasFixedSize(true);

        // 장바구니 아이템이 선택되면 뷰모델에 통보한다
        adapter.setOnItemSelectedListener(position -> {
            Pick pick = adapter.getCurrentList().get(position);
            viewModel.onPickClick(pick);
        });

        // 장바구니 목록을 리사이클러 뷰에 표시한다
        viewModel.getPicks().observe(getViewLifecycleOwner(), picks -> {
            if (picks != null) {
                adapter.submitList(picks);
                binding.textViewNoPicks.setVisibility(picks.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            }
        });

        // 합계 금액을 표시한다
        viewModel.getTotalPrice().observe(getViewLifecycleOwner(), price -> {
            if (price != null) {
                String strPrice = String.format(Locale.getDefault(), "%s원",
                        NumberFormat.getInstance().format(price)
                );
                binding.buttonTotalPrice.setText(strPrice);
            }
        });

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof CartViewModel.Event.NavigateToQrScanScreen) {
                // QR 코드 스캔 화면을 띄운다
                intentIntegrator.initiateScan();
            } else if (event instanceof CartViewModel.Event.NavigateToAddToCartScreen) {
                // 장바구니 추가를 묻는 화면으로 이동한다
                Product product = ((CartViewModel.Event.NavigateToAddToCartScreen) event).product;
                NavDirections navDirections = CartFragmentDirections.actionCartFragmentToAddToCartFragment(product);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof CartViewModel.Event.NavigateToPayScreen) {
                // 결제 화면으로 이동한다
                ArrayList<Pick> picks = ((CartViewModel.Event.NavigateToPayScreen) event).picks;
                NavDirections navDirections = CartFragmentDirections.actionCartFragmentToPayFragment(picks);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof CartViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 출력한다
                String message = ((CartViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof CartViewModel.Event.PromptPickCount) {
                // 물품 개수를 입력하는 대화상자를 띄운다
                Pick pick = ((CartViewModel.Event.PromptPickCount) event).pick;
                showPickCountDialog(pick);
            }
        });

        // 장바구니 추가를 묻는 화면에서 설정된 결과를 뷰모델에 통보한다
        getParentFragmentManager().setFragmentResultListener("add_to_cart_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    Product product = (Product) result.getSerializable("product");
                    viewModel.onAddToCartResult(product);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        // 인식된 QR 코드를 텍스트로 변환하여 뷰모델에 통보한다
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (result != null) {
            viewModel.onQrScanResult(result.getContents());
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void showPickCountDialog(Pick pick) {

        // 물품 개수를 입력하는 대화상자를 띄운다

        DialogPickCountBinding binding = DialogPickCountBinding.inflate(getLayoutInflater());

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(binding.getRoot())
                .create();

        binding.textViewProductName.setText(pick.getProduct().getName());

        binding.numberPicker.setMinValue(0);
        binding.numberPicker.setMaxValue(10);

        binding.buttonOk.setOnClickListener(v -> {
            // 물품 개수가 확정되면 뷰모델에 통보한다
            int count = binding.numberPicker.getValue();
            viewModel.onPickCountSelected(pick, count);
            dialog.dismiss();
        });

        dialog.show();
    }

}