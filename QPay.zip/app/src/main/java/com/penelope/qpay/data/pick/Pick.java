package com.penelope.qpay.data.pick;

// 상품 정보와 개수로 구성된 장바구니 내부 항목

import com.penelope.qpay.data.product.Product;

import java.io.Serializable;
import java.util.Objects;

public class Pick implements Serializable {

    private Product product;
    private int count;


    public Pick() {
    }

    public Pick(Product product, int count) {
        this.product = product;
        this.count = count;
    }

    public Product getProduct() {
        return product;
    }

    public int getCount() {
        return count;
    }

    public void addCount(int a) {
        count += a;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public void setCount(int count) {
        this.count = count;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pick pick = (Pick) o;
        return count == pick.count && product.equals(pick.product);
    }

    @Override
    public int hashCode() {
        return Objects.hash(product, count);
    }

}
