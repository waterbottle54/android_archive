package com.penelope.qpay.ui.auth.finding.id.showid;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentShowIdBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ShowIdFragment extends Fragment {

    private FragmentShowIdBinding binding;
    private ShowIdViewModel viewModel;


    public ShowIdFragment() {
        super(R.layout.fragment_show_id);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentShowIdBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ShowIdViewModel.class);

        // 아이디를 텍스트뷰에 표시한다
        binding.textViewId.setText(viewModel.getId());

        // 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonLogin.setOnClickListener(v -> viewModel.onLoginClick());
        binding.buttonFindPassword.setOnClickListener(v -> viewModel.onFindPasswordClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ShowIdViewModel.Event.NavigateToLoginScreen) {
                // 로그인 화면으로 돌아간다
                Bundle bundle = new Bundle();
                bundle.putBoolean("login", true);
                getParentFragmentManager().setFragmentResult("navigation", bundle);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof ShowIdViewModel.Event.NavigateToFindPasswordScreen) {
                // 비밀번호 찾기 화면으로 이동하도록 한다
                Bundle bundle = new Bundle();
                bundle.putBoolean("find_password", true);
                getParentFragmentManager().setFragmentResult("navigation", bundle);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}