package com.penelope.qpay.ui.home.welcome;

import android.content.Context;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.penelope.qpay.R;
import com.penelope.qpay.databinding.FragmentWelcomeBinding;
import com.penelope.qpay.utils.ui.OnTextChangeListener;

import java.text.NumberFormat;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class WelcomeFragment extends Fragment {

    private FragmentWelcomeBinding binding;
    private WelcomeViewModel viewModel;
    private CountDownTimer rotationTimer;


    public WelcomeFragment() {
        super(R.layout.fragment_welcome);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentWelcomeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(WelcomeViewModel.class);

        // 버튼 클릭 시 뷰모델에 통보한다
        binding.cardViewBrowse.setOnClickListener(v -> viewModel.onBrowseClick());
        binding.cardViewMyPage.setOnClickListener(v -> viewModel.onMyPageClick());
        binding.cardViewCart.setOnClickListener(v -> viewModel.onCartClick());
        binding.imageButtonSearchProduct.setOnClickListener(v -> {
            viewModel.onSearchClick();
            hideKeyboard(requireView());
        });

        // 에딧텍스트 검색어 변경시 뷰모델에 통보한다
        binding.editTextProductName.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onQueryChange(text);
            }
        });

        // 현재 사용자의 이름을 표시한다
        viewModel.getCurrentUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null) {
                String strWelcome = user.getName() + "님 환영합니다!!";
                binding.textViewWelcome.setText(strWelcome);
            }
        });

        // 검색이 진행중이면 로딩 바를 보인다
        viewModel.isQueryInProgress().observe(getViewLifecycleOwner(), isQueryInProgress ->
                binding.progressBar5.setVisibility(isQueryInProgress ? View.VISIBLE : View.INVISIBLE));

        // 랜덤 상품 또는 검색한 상품을 띄운다
        viewModel.getRandomProduct().observe(getViewLifecycleOwner(), product -> {
            if (product != null) {
                binding.cardViewProduct.setVisibility(View.VISIBLE);
                binding.textViewProductDescription.setText("이달의 인기상품!!");
                // 상품 이미지를 이미지뷰에 띄운다
                Glide.with(this)
                        .load(product.getImageUrl())
                        .into(binding.imageViewProduct);
            }
        });
        viewModel.getSearchedProduct().observe(getViewLifecycleOwner(), product -> {
            if (product != null) {
                binding.cardViewProduct.setVisibility(View.VISIBLE);
                // 상품 가격을 띄운다
                String strPrice = NumberFormat.getInstance().format(product.getPrice()) + "원";
                binding.textViewProductDescription.setText(strPrice);
                // 상품 이미지를 이미지뷰에 띄운다
                Glide.with(this)
                        .load(product.getImageUrl())
                        .transition(DrawableTransitionOptions.withCrossFade())
                        .into(binding.imageViewProduct);
            }
        });

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof WelcomeViewModel.Event.NavigateToBrowseScreen) {
                // 상품 목록 화면으로 이동한다
                NavDirections navDirections = WelcomeFragmentDirections.actionWelcomeFragmentToBrowseFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof WelcomeViewModel.Event.NavigateToMyPageScreen) {
                // 마이페이지 화면으로 이동한다
                NavDirections navDirections = WelcomeFragmentDirections.actionWelcomeFragmentToMyPageFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof WelcomeViewModel.Event.NavigateToCartScreen) {
                // 장바구니 화면으로 이동한다
                NavDirections navDirections = WelcomeFragmentDirections.actionWelcomeFragmentToCartFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof WelcomeViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 보인다
                String message = ((WelcomeViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });

        // 인기상품 로테이션을 위한 카운트다이머를 생성한다
        rotationTimer = new CountDownTimer(86400000, 5000) {
            @Override
            public void onTick(long millisUntilFinished) {
                // 매 5초마다 호출되며, 호출시마다 뷰모델에 통보한다
                viewModel.onRotationTick();
            }

            @Override
            public void onFinish() {
            }
        };
    }

    @Override
    public void onResume() {
        super.onResume();
        rotationTimer.start();
    }

    @Override
    public void onPause() {
        super.onPause();
        rotationTimer.cancel();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    // 키보드 감추기

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}