package com.penelope.happydiary.ui.sharingdiary.friend;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.databinding.FragmentFriendBinding;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;
import com.penelope.happydiary.utils.ui.UiUtils;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class FriendFragment extends AuthListenerFragment {

    private FragmentFriendBinding binding;
    private FriendViewModel viewModel;


    public FriendFragment() {
        super(R.layout.fragment_friend);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentFriendBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(FriendViewModel.class);

        // UI 에 리스너를 지정한다
        UiUtils.addTextChangedListener(binding.editTextNickname, s -> viewModel.onNicknameChange(s));
        binding.buttonAddFriend.setOnClickListener(v -> viewModel.onAddFriendClick());

        // 공유 회원 어댑터를 생성하고 리사이클러 뷰에 연결한다
        UsersAdapter adapter = new UsersAdapter(Glide.with(this));
        binding.recyclerUser.setAdapter(adapter);
        binding.recyclerUser.setHasFixedSize(true);

        // 공유 회원을 리사이클러뷰에 업데이트한다
        viewModel.getWatchers().observe(getViewLifecycleOwner(), watchers -> {
            if (watchers != null) {
                adapter.submitList(watchers);
                binding.textViewNoFriends.setVisibility(watchers.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            }
            binding.progressBar5.setVisibility(View.INVISIBLE);
        });

        // 뷰모델의 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof FriendViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof FriendViewModel.Event.ShowGeneralMessage) {
                String message = ((FriendViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}