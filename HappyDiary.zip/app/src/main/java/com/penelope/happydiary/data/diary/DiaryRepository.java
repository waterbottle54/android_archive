package com.penelope.happydiary.data.diary;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class DiaryRepository {

    private final CollectionReference userCollection;
    private final CollectionReference sharingDiaryCollection;

    @Inject
    public DiaryRepository(FirebaseFirestore firestore) {
        userCollection = firestore.collection("users");
        sharingDiaryCollection = firestore.collection("sharingDiaries");
    }

    // 인수로 전달된 일기를 DB 에 저장하는 메소드 (개인 일기 컬렉션에 저장함)

    public void addPrivateDiary(Diary diary, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        CollectionReference diaryCollection = userCollection.document(diary.getUid())
                .collection("diary");

        diaryCollection.document(diary.getId())
                .set(diary)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    // 인수로 전달된 유저가 date 일자에 작성한 일기를 불러오는 메소드

    public LiveData<Diary> getPrivateDiary(String uid, LocalDate date) {

        CollectionReference diaryCollection = userCollection.document(uid).collection("diary");

        MutableLiveData<Diary> diary = new MutableLiveData<>();

        diaryCollection.whereEqualTo("uid", uid)
                .whereEqualTo("year", date.getYear())
                .whereEqualTo("month", date.getMonthValue())
                .whereEqualTo("dayOfMonth", date.getDayOfMonth())
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null || value.isEmpty()) {
                        if (error != null) {
                            error.printStackTrace();
                        }
                        diary.setValue(null);
                        return;
                    }
                    DocumentSnapshot snapshot = value.getDocuments().get(0);
                    diary.setValue(snapshot.toObject(Diary.class));
                });

        return diary;
    }

    // 인수로 전달된 일기를 DB 에 저장하는 메소드 (공유 일기 컬렉션에 저장함)

    public void addSharingDiary(Diary diary, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        sharingDiaryCollection.document(diary.getId())
                .set(diary)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    // 공유 일기 컬렉션에 있는 모든 일기를 불러오는 메소드

    public LiveData<List<Diary>> getSharingDiaries() {

        MutableLiveData<List<Diary>> diaries = new MutableLiveData<>();

        sharingDiaryCollection
                .orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        error.printStackTrace();
                        diaries.setValue(null);
                        return;
                    }
                    List<Diary> list = new ArrayList<>();
                    if (value == null || value.isEmpty()) {
                        diaries.setValue(list);
                        return;
                    }
                    for (DocumentSnapshot snapshot : value) {
                        Diary diary = snapshot.toObject(Diary.class);
                        if (diary != null) {
                            list.add(diary);
                        }
                    }
                    diaries.setValue(list);
                });

        return diaries;
    }

    // 공유 일기 중 인수로 전달된 회원들이 작성한 일기들만 불러오는 메소드

    public LiveData<List<Diary>> getSharingDiaries(List<String> uids) {

        return Transformations.map(getSharingDiaries(), diaries -> {
            List<Diary> filtered = new ArrayList<>();
            for (Diary diary : diaries) {
                if (uids.contains(diary.getUid())) {
                    filtered.add(diary);
                }
            }
            return filtered;
        });
    }

}




