package com.penelope.happydiary.ui.sharingdiary.detail;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.penelope.happydiary.data.comment.Comment;
import com.penelope.happydiary.data.user.User;
import com.penelope.happydiary.databinding.CommentItemBinding;
import com.penelope.happydiary.utils.ImageUtils;
import com.penelope.happydiary.utils.TimeUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Map;

public class CommentsAdapter extends ListAdapter<Comment, CommentsAdapter.CommentViewHolder> {

    class CommentViewHolder extends RecyclerView.ViewHolder {

        private final CommentItemBinding binding;

        public CommentViewHolder(CommentItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Comment model) {

            User user = userMap.get(model.getUid());

            if (user != null) {
                // 댓글 작성자 닉네임, 프로필을 띄운다
                binding.textViewUserNickname.setText(user.getNickname());
                String profileUrl = ImageUtils.getUserImageUrl(user.getUid());
                glide.load(profileUrl).into(binding.imageViewProfile);
            }

            // 댓글 내용, 날짜를 띄운다
            binding.textViewCommentContent.setText(model.getContent());

            LocalDateTime ldt = Instant.ofEpochMilli(model.getCreated()).atZone(ZoneId.systemDefault()).toLocalDateTime();
            String strDateTime = TimeUtils.formatDateTime(ldt);
            binding.textViewCommentDateTime.setText(strDateTime);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final Map<String, User> userMap;
    private final RequestManager glide;


    public CommentsAdapter(Map<String, User> map, RequestManager glide) {
        super(new DiffUtilCallback());
        this.userMap = map;
        this.glide = glide;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        CommentItemBinding binding = CommentItemBinding.inflate(layoutInflater, parent, false);
        return new CommentViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CommentViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Comment> {

        @Override
        public boolean areItemsTheSame(@NonNull Comment oldItem, @NonNull Comment newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Comment oldItem, @NonNull Comment newItem) {
            return oldItem.equals(newItem);
        }
    }

}