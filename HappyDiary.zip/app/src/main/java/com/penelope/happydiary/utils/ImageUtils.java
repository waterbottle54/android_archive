package com.penelope.happydiary.utils;

import com.penelope.happydiary.R;
import com.penelope.happydiary.data.diary.WeatherType;
import com.penelope.happydiary.data.emotion.EmotionType;

public class ImageUtils {

    public static final String URL_PRIVATE_DIARY_FORMAT = "https://firebasestorage.googleapis.com/v0/b/happy-diary-231b3.appspot.com/o/privateDiaries%2F{ID}.jpg?alt=media";
    public static final String URL_SHARING_DIARY_FORMAT = "https://firebasestorage.googleapis.com/v0/b/happy-diary-231b3.appspot.com/o/sharingDiaries%2F{ID}.jpg?alt=media";
    public static final String URL_USER_FORMAT = "https://firebasestorage.googleapis.com/v0/b/happy-diary-231b3.appspot.com/o/profiles%2F{UID}.jpg?alt=media";

    public static String getPrivateDiaryImageUrl(String id) {
        return URL_PRIVATE_DIARY_FORMAT.replace("{ID}", id);
    }

    public static String getSharingDiaryImageUrl(String id) {
        return URL_SHARING_DIARY_FORMAT.replace("{ID}", id);
    }

    public static String getUserImageUrl(String uid) {
        return URL_USER_FORMAT.replace("{UID}", uid);
    }

    public static int getWeatherImage(WeatherType type) {
        switch (type) {
            default:
            case SUNNY: return R.drawable.ic_sunny;
            case WINDY: return R.drawable.ic_windy;
            case CLOUDY: return R.drawable.ic_cloudy;
            case RAINY: return R.drawable.ic_rainy;
            case SNOWY: return R.drawable.ic_snowy;
        }
    }

    public static int getEmotionImage(EmotionType type) {
        switch (type) {
            default:
            case VERY_SAD: return R.drawable.emoji_1;
            case SAD: return R.drawable.emoji_2;
            case ORDINARY: return R.drawable.emoji_3;
            case HAPPY: return R.drawable.emoji_4;
            case VERY_HAPPY: return R.drawable.emoji_5;
        }
    }

}
