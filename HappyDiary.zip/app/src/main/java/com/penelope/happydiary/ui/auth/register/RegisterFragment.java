package com.penelope.happydiary.ui.auth.register;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.databinding.FragmentRegisterBinding;
import com.penelope.happydiary.utils.BitmapUtils;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;
import com.penelope.happydiary.utils.ui.UiUtils;

import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RegisterFragment extends AuthListenerFragment {

    private FragmentRegisterBinding binding;
    private RegisterViewModel viewModel;

    private ActivityResultLauncher<Intent> imageActivityLauncher;
    private ActivityResultLauncher<String[]> requestPermissionLauncher;


    public RegisterFragment() {
        super(R.layout.fragment_register);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 사진 입력 시 결과값을 처리하는 런처
        imageActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::onImageResult
        );

        // 사진 촬영, 저장소 읽기 퍼미션을 요청하는 런처
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                this::onPermissionResult
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentRegisterBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RegisterViewModel.class);

        // UI 에 리스너를 지정한다
        binding.fabEditProfileImage.setOnClickListener(v -> viewModel.onEditImageClick());
        UiUtils.addTextChangedListener(binding.editTextId, s -> viewModel.onIdChange(s));
        UiUtils.addTextChangedListener(binding.editTextPassword, s -> viewModel.onPasswordChange(s));
        UiUtils.addTextChangedListener(binding.editTextPasswordConfirm, s -> viewModel.onPasswordConfirmChange(s));
        UiUtils.addTextChangedListener(binding.editTextNickname, s -> viewModel.onNicknameChange(s));
        binding.fabSubmit.setOnClickListener(v -> viewModel.onSubmitClick());
        binding.progressBar.setVisibility(View.INVISIBLE);

        // 프로필 이미지를 이미지 뷰에 업데이트한다
        viewModel.getImage().observe(getViewLifecycleOwner(), image ->
                binding.imageView.setImageBitmap(image));

        // 회원가입이 처리중이면 로딩 UI 를 보인다
        viewModel.isUploadInProgress().observe(getViewLifecycleOwner(), isUploadInProgress ->
                binding.progressBar.setVisibility(isUploadInProgress ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof RegisterViewModel.Event.NavigateToHomeScreen) {
                NavDirections navDirections = RegisterFragmentDirections.actionRegisterFragmentToHomeFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof RegisterViewModel.Event.ShowGeneralMessage) {
                String message = ((RegisterViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof RegisterViewModel.Event.PromptImage) {
                promptImage();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void promptImage() {

        if (requireContext().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && requireContext().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showImageDialog();
        } else {
            requestPermissionLauncher.launch(
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA});
        }
    }

    private void showImageDialog() {

        // 업로드 방법 선택 대화상자 보이기
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chooser = Intent.createChooser(galleryIntent, "프로필 이미지 업로드");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        imageActivityLauncher.launch(chooser);
    }

    private void onImageResult(ActivityResult result) {

        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Bitmap bitmap = null;
            if (result.getData().getExtras() != null) {
                // 카메라 결과 획득
                bitmap = (Bitmap) result.getData().getExtras().get("data");
            } else {
                // 갤러리(포토) 결과 획득
                Uri uri = result.getData().getData();
                if (uri != null) {
                    bitmap = BitmapUtils.getBitmapFromUri(requireContext(), uri);
                }
            }
            viewModel.onImageChange(bitmap);
        }
    }

    private void onPermissionResult(Map<String, Boolean> result) {

        Boolean permissionExternalStorage = result.get(Manifest.permission.READ_EXTERNAL_STORAGE);
        Boolean permissionCamera = result.get(Manifest.permission.CAMERA);

        if (permissionExternalStorage != null && permissionExternalStorage
                && permissionCamera != null && permissionCamera) {
            showImageDialog();
        }
    }

}