package com.penelope.happydiary.ui.auth.register;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.data.image.ImageRepository;
import com.penelope.happydiary.data.user.User;
import com.penelope.happydiary.data.user.UserRepository;
import com.penelope.happydiary.utils.AuthUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class RegisterViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String id = "";
    private String password = "";
    private String passwordConfirm = "";
    private String nickname = "";
    private final MutableLiveData<Bitmap> image = new MutableLiveData<>();

    private final MutableLiveData<Boolean> isUploadInProgress = new MutableLiveData<>(false);

    private final FirebaseAuth auth;
    private final UserRepository userRepository;
    private final ImageRepository imageRepository;


    @Inject
    public RegisterViewModel(FirebaseAuth auth, UserRepository userRepository, ImageRepository imageRepository) {
        this.auth = auth;
        this.userRepository = userRepository;
        this.imageRepository = imageRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }

    public LiveData<Boolean> isUploadInProgress() {
        return isUploadInProgress;
    }


    public void onEditImageClick() {
        event.setValue(new Event.PromptImage());
    }

    public void onIdChange(String text) {
        id = text.trim();
    }

    public void onPasswordChange(String text) {
        password = text.trim();
    }

    public void onPasswordConfirmChange(String text) {
        passwordConfirm = text.trim();
    }

    public void onNicknameChange(String text) {
        nickname = text.trim();
    }

    public void onImageChange(Bitmap bitmap) {
        // 프로필 이미지를 변경한다
        if (bitmap != null) {
            image.setValue(bitmap);
        } else {
            event.setValue(new Event.ShowGeneralMessage("이미지 선택에 실패했습니다"));
        }
    }

    public void onSubmitClick() {

        // 회원가입을 진행한다

        // 이미 진행 중이면 리턴한다
        Boolean isUploadInProgressValue = isUploadInProgress.getValue();
        assert isUploadInProgressValue != null;
        if (isUploadInProgressValue) {
            return;
        }

        // 에러 : 개인정보가 비어있음
        if (id.isEmpty() || password.isEmpty() || passwordConfirm.isEmpty() || nickname.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        // 에러 : 프로필 이미지가 없음
        Bitmap imageValue = image.getValue();
        if (imageValue == null) {
            event.setValue(new Event.ShowGeneralMessage("이미지를 선택해주세요"));
            return;
        }

        // 에러 : 아이디가 짧음
        if (id.length() < 4) {
            event.setValue(new Event.ShowGeneralMessage("아이디를 4글자 이상 입력해주세요"));
            return;
        }

        // 에러 : 비밀번호가 짧음
        if (password.length() < 6) {
            event.setValue(new Event.ShowGeneralMessage("비밀번호를 6글자 이상 입력해주세요"));
            return;
        }

        // 에러 : 비밀번호 확인이 일치하지 않음
        if (!password.equals(passwordConfirm)) {
            event.setValue(new Event.ShowGeneralMessage("비밀번호를 정확히 입력해주세요"));
            return;
        }

        isUploadInProgress.setValue(true);

        // Firebase Auth 에 아이디와 비밀번호로 회원가입을 요청한다
        auth.createUserWithEmailAndPassword(AuthUtils.emailize(id), password)
                .addOnSuccessListener(authResult ->
                        // 회원가입된 경우 로그인까지 진행한다
                        auth.signInWithEmailAndPassword(AuthUtils.emailize(id), password))
                .addOnFailureListener(e -> {
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("회원가입에 실패했습니다"));
                });
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

        String uid = firebaseAuth.getUid();

        if (uid != null && image.getValue() != null) {
            // 로그인이 완료된 경우 회원정보 및 프로필 이미지를 DB 에 저장한다
            User newUser = new User(uid, id, nickname);
            userRepository.addUser(newUser,
                    unused -> {
                        // 프로필 이미지 저장
                        imageRepository.addProfileImage(uid, image.getValue(),
                                unused1 -> event.setValue(new Event.NavigateToHomeScreen()),
                                e -> {
                                    // 이미지 저장 실패
                                    e.printStackTrace();
                                    auth.signOut();
                                    isUploadInProgress.setValue(false);
                                    event.setValue(new Event.ShowGeneralMessage("이미지 저장에 실패했습니다"));
                                });
                    },
                    e -> {
                        // 회원정보 저장 실패
                        e.printStackTrace();
                        auth.signOut();
                        isUploadInProgress.setValue(false);
                        event.setValue(new Event.ShowGeneralMessage("회원정보 생성에 실패했습니다"));
                    });
        }
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToHomeScreen extends Event {

        }

        public static class PromptImage extends Event {
        }
    }

}