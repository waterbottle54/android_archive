package com.penelope.happydiary.data.emotion;

import android.util.Pair;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.happydiary.utils.BaseRepository;
import com.penelope.happydiary.utils.ui.EmotionUtils;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class EmotionRepository extends BaseRepository<Emotion> {

    private final CollectionReference userCollection;

    @Inject
    public EmotionRepository(FirebaseFirestore firestore) {
        userCollection = firestore.collection("users");
    }

    // 인수로 전달된 감정 기록을 DB 에 저장하는 메소드

    public void addEmotion(Emotion emotion,
                           OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        CollectionReference emotionCollection = userCollection
                .document(emotion.getUid())
                .collection("emotions");

        emotionCollection.document(emotion.getId())
                .set(emotion)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    // 특정 유저가 특정 월에 기록한 감정을 모두 불러오는 메소드

    public LiveData<List<Emotion>> getMonthlyEmotions(String uid, int year, int month) {

        CollectionReference emotionCollection = userCollection
                .document(uid)
                .collection("emotions");

        MutableLiveData<List<Emotion>> emotions = new MutableLiveData<>();

        emotionCollection.whereEqualTo("year", year)
                .whereEqualTo("month", month)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        error.printStackTrace();
                        emotions.setValue(null);
                        return;
                    }
                    if (value == null || value.isEmpty()) {
                        emotions.setValue(new ArrayList<>());
                        return;
                    }
                    List<Emotion> list = value.toObjects(Emotion.class);
                    list.sort((o1, o2) -> {
                        LocalDate date1 = LocalDate.of(o1.getYear(), o1.getMonth(), o1.getDayOfMonth());
                        LocalDate date2 = LocalDate.of(o2.getYear(), o2.getMonth(), o2.getDayOfMonth());
                        return date1.compareTo(date2);
                    });
                    emotions.setValue(list);
                });

        return emotions;
    }

    // 특정 유저가 특정 일자에 작성한 감정 기록을 불러오는 메소드

    public LiveData<Emotion> getDailyEmotion(String uid, LocalDate date) {

        CollectionReference emotionCollection = userCollection
                .document(uid)
                .collection("emotions");

        MutableLiveData<Emotion> emotion = new MutableLiveData<>();

        emotionCollection.whereEqualTo("year", date.getYear())
                .whereEqualTo("month", date.getMonthValue())
                .whereEqualTo("dayOfMonth", date.getDayOfMonth())
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        error.printStackTrace();
                        emotion.setValue(null);
                        return;
                    }
                    if (value == null || value.isEmpty()) {
                        emotion.setValue(null);
                        return;
                    }
                    DocumentSnapshot snapshot = value.getDocuments().get(0);
                    emotion.setValue(snapshot.toObject(Emotion.class));
                });

        return emotion;
    }

    // 특정 유저의 특정 월에 기록한 감정들을 수치화하고 일자별 감정수치로 정리하여 불러오는 메소드

    public LiveData<List<Pair<LocalDate, Double>>> getStatistic(String uid, int year, int month) {

        CollectionReference emotionCollection = userCollection
                .document(uid)
                .collection("emotions");

        MutableLiveData<List<Pair<LocalDate, Double>>> statistic = new MutableLiveData<>();

        emotionCollection.whereEqualTo("year", year)
                .whereEqualTo("month", month)
                .addSnapshotListener((value, error) -> {
                    if (error != null || value == null) {
                        if (error != null) {
                            error.printStackTrace();
                        }
                        statistic.setValue(null);
                        return;
                    }

                    Map<LocalDate, Emotion> map = new HashMap<>();
                    for (DocumentSnapshot snapshot : value) {
                        Emotion emotion = snapshot.toObject(Emotion.class);
                        if (emotion != null) {
                            int y = emotion.getYear();
                            int m = emotion.getMonth();
                            int d = emotion.getDayOfMonth();
                            map.put(LocalDate.of(y, m, d), emotion);
                        }
                    }

                    List<Pair<LocalDate, Double>> list = new ArrayList<>();

                    for (int day = 1; day <= YearMonth.of(year, month).lengthOfMonth(); day++) {
                        LocalDate date = LocalDate.of(year, month, day);
                        Emotion emotion = map.get(date);
                        if (emotion != null) {
                            double emotionValue = EmotionUtils.getEmotionValue(emotion.getType());
                            list.add(new Pair<>(date, emotionValue));
                        } else {
                            list.add(new Pair<>(date, 0.0));
                        }
                    }

                    statistic.setValue(list);
                });

        return statistic;
    }

}



