package com.penelope.happydiary.ui.privatediary.privatediary;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.data.diary.Diary;
import com.penelope.happydiary.data.diary.DiaryRepository;
import com.penelope.happydiary.data.emotion.Emotion;
import com.penelope.happydiary.data.emotion.EmotionRepository;

import java.time.LocalDate;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PrivateDiaryViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> uid = new MutableLiveData<>();

    private final MutableLiveData<LocalDate> date = new MutableLiveData<>(LocalDate.now());

    private final LiveData<Diary> diary;

    private final LiveData<Emotion> emotion;

    private final MutableLiveData<Boolean> isUploadInProgress = new MutableLiveData<>(false);

    private final DiaryRepository diaryRepository;


    @Inject
    public PrivateDiaryViewModel(DiaryRepository diaryRepository, EmotionRepository emotionRepository) {

        // 해당일의 일기를 불러온다
        diary = Transformations.switchMap(uid, u ->
                Transformations.switchMap(date, d ->
                        diaryRepository.getPrivateDiary(u, d)
                ));

        // 해당일의 감정기록을 불러온다
        emotion = Transformations.switchMap(uid, u ->
                Transformations.switchMap(date, d ->
                        emotionRepository.getDailyEmotion(u, d)
                ));

        this.diaryRepository = diaryRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Diary> getDiary() {
        return diary;
    }

    public LiveData<LocalDate> getDate() {
        return date;
    }

    public LiveData<Emotion> getEmotion() {
        return emotion;
    }

    public LiveData<Boolean> isUploadInProgress() {
        return isUploadInProgress;
    }


    public void onDateClick() {
        event.setValue(new Event.PromptDate(date.getValue()));
    }

    public void onDateSelected(int year, int month, int dayOfMonth) {
        // 날짜를 변경한다
        LocalDate ld = LocalDate.of(year, month, dayOfMonth);
        if (!ld.isAfter(LocalDate.now())) {
            date.setValue(LocalDate.of(year, month, dayOfMonth));
        } else {
            event.setValue(new Event.ShowGeneralMessage("오늘 이전의 날짜를 선택하세요"));
        }
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getUid() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            uid.setValue(firebaseAuth.getUid());
        }
    }

    public void onAddDiaryClick() {
        event.setValue(new Event.PromptDiaryType());
    }

    public void onShortTypeClick() {
        event.setValue(new Event.PromptShortDiary());
    }

    public void onLongTypeClick() {
        event.setValue(new Event.NavigateToAddDiaryScreen(date.getValue()));
    }

    public void onAddDiaryResult(boolean success) {
        if (success) {
            event.setValue(new Event.ShowGeneralMessage("일기가 작성되었습니다"));
        }
    }

    public void onShortDiarySubmit(String title, String content) {

        // 일기 업로드 중이면 리턴한다

        Boolean isUploadInProgressValue = isUploadInProgress.getValue();
        assert isUploadInProgressValue != null;
        if (isUploadInProgressValue) {
            return;
        }

        String uidValue = uid.getValue();
        if (uidValue == null) {
            return;
        }

        // 일기 입력값을 확인한다

        title = title.trim();
        content = content.trim();

        if (title.isEmpty() || content.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력하세요"));
            return;
        }

        LocalDate dateValue = date.getValue();
        assert dateValue != null;

        // 일기 객체를 구성하고 한줄일기를 업로드한다

        Diary diary = new Diary(uidValue, title, content, null, null, dateValue);

        isUploadInProgress.setValue(true);

        diaryRepository.addPrivateDiary(diary,
                unused -> {
                    isUploadInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("한줄일기가 작성되었습니다"));
                },
                e -> {
                    e.printStackTrace();
                    isUploadInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("일기 업로드에 실패했습니다"));
                });
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBack extends Event {
        }

        public static class PromptDate extends Event {
            public final LocalDate date;

            public PromptDate(LocalDate date) {
                this.date = date;
            }
        }

        public static class NavigateToAddDiaryScreen extends Event {
            public final LocalDate date;

            public NavigateToAddDiaryScreen(LocalDate date) {
                this.date = date;
            }
        }

        public static class PromptDiaryType extends Event {
        }

        public static class PromptShortDiary extends Event {
        }
    }

}