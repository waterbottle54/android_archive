package com.penelope.happydiary.data.diary;

import com.penelope.happydiary.data.emotion.EmotionType;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Diary implements Serializable {

    private String id;                  // 고유키
    private String uid;                 // 일기를 작성한 회원의 암호화된 아이디
    private String title;               // 일기 제목
    private String content;             // 일기 내용
    private EmotionType emotionType;    // 일기의 감정상태 (공유일기만 값을 가짐)
    private WeatherType weatherType;    // 날씨 상태
    private int year;                   // 작성연도
    private int month;                  // 작성월
    private int dayOfMonth;             // 작성일
    private long created;               // 작성시간: epoch millis 단위


    public Diary() {
        weatherType = null;
    }

    public Diary(String uid, String title, String content, EmotionType emotionType, WeatherType weatherType, LocalDate date) {
        this.uid = uid;
        this.title = title;
        this.content = content;
        this.emotionType = emotionType;
        this.weatherType = weatherType;
        this.year = date.getYear();
        this.month = date.getMonthValue();
        this.dayOfMonth = date.getDayOfMonth();
        this.created = System.currentTimeMillis();
        this.id = uid + "_" + year + "_" + month + "_" + dayOfMonth;
    }

    public String getId() {
        return id;
    }

    public String getUid() {
        return uid;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public EmotionType getEmotionType() {
        return emotionType;
    }

    public WeatherType getWeatherType() {
        return weatherType;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDayOfMonth() {
        return dayOfMonth;
    }

    public long getCreated() {
        return created;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setEmotionType(EmotionType emotionType) {
        this.emotionType = emotionType;
    }

    public void setWeatherType(WeatherType weatherType) {
        this.weatherType = weatherType;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public void setDayOfMonth(int dayOfMonth) {
        this.dayOfMonth = dayOfMonth;
    }

    public void setCreated(long created) {
        this.created = created;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Diary diary = (Diary) o;
        return year == diary.year && month == diary.month && dayOfMonth == diary.dayOfMonth && created == diary.created && id.equals(diary.id) && uid.equals(diary.uid) && title.equals(diary.title) && content.equals(diary.content) && emotionType == diary.emotionType && weatherType == diary.weatherType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, uid, title, content, emotionType, weatherType, year, month, dayOfMonth, created);
    }
}
