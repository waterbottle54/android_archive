/**
 *
 * 프로젝트 설명
 *
 * @ 프로젝트 구조는 MVVM 아키텍처와 안드로이드 Jetpack 컴포넌트가 사용되었습니다.
 *   사용된 외부 라이브러리는 gradle 모듈 파일 끝에 설명되어 있습니다.
 *
 * @ UI는 하나의 컨테이너 액티비티만 포함하고 네비게이션 컴포넌트를 이용해 필요한 프래그먼트를 보여주는 방식입니다.
 *   (네비게이션 그래프는 nav_graph.xml 에 정의되어 있습니다.)
 *   프래그먼트는 UI 조작을 위한 코드만 포함하고, 뷰모델에는 데이터에 접근하는 코드와 비즈니스 로직만 포함되어 있습니다.
 *
 * @ 사용된 DB는 Firebase Firestore 원격 DB 입니다. 서울에 있는 구글 northwest-3 센터를 사용했습니다
 * @ 사진 (jpg) 저장에는 Firebase Storage 를 이용했습니다
 *
 *
 * 패키지 설명 (알파벳 순서)
 *
 * @ data : 앱에서 사용하는 모든 자료형 및 DB 관련 클래스들
 *
 *  - comment : 공유 일기에 작성되는 댓글 정보 클래스 / DB 에 댓글을 저장하고 불러오기 위한 연산을 하는 Repository 클래스
 *  - diary : 일기 정보 클래스 / Repository (저장소) 클래스
 *  - emotion : 특정 일자의 감정을 나타내는 클래스 / Repository 클래스
 *  - image : Firebase Storage 에 사진을 저장하고 불러오는 Repository 클래스
 *
 * @ di : Dagger-Hilt 의존성 주입을 위한 패키지. AppModule 클래스 하나만 사용합니다.
 *
 * @ ui : 화면을 정의하는 클래스들 (프래그먼트들과 각각의 뷰모델들)
 *  - add : 기록 추가를 위한 화면들
 *      - category : 카테고리를 선택하는 화면
 *      - add : 카테고리를 선택한 후 기록을 최종 추가하는 화면을 정의함
 *      - photo : 사진 검색 및 선택을 위한 화면
 *  - auth : 로그인, 회원가입 화면들
 *      - login : 로그인을 위한 화면
 *      - register : 회원가입을 위한 화면
 *  - privatediary : 개인 일기 관련 화면들
 *      - addprivatediary : 개인일기를 작성하는 화면
 *      - privatediary : 작성된 개인일기를 보는 화면
 *  - sharingdiary : 공유 일기 관련 화면들
 *      - addsharingdiary : 공유 일기를 작성하는 화면
 *      - detail : 공유일기의 상세내용을 보는 화면
 *      - friend : 공유일기를 공유할 회원을 추가하는 화면
 *      - sharingdiary : 나와 공유회원들이 작성한 공유일기 목록을 보는 화면
 *
 * @ util : 위의 패키지에 포함되지 않는, 편의성 및 코드 단축을 위한 클래스들
 *          대부분 클래스는 1~2개의 메소드만 포함하는 짧은 클래스입니다
 *  - AuthListenerFragment/Activity : Firebase 의 로그인, 로그아웃 이벤트 처리를 위한 추상 클래스. 로그인 후의 프래그먼트들이 상속받음
 *  - BaseRepository : 모든 Repository 들이 상속하는 클래스
 *  - TimeUtils : 시간을 문자열로 표현하는 메소드들이 묶인 클래스
 *  - TriConsumer : BaseRepository 에서 사용하기 위한 3인수 Consumer 인터페이스
 *
 * @ HappyDiaryApplication 클래스 : 직접 사용하지 않으나 Dagger-Hilt 의존성 주입을 위해 필요함
 *
 */

package com.penelope.happydiary.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import android.os.Bundle;

import com.penelope.happydiary.R;
import com.penelope.happydiary.databinding.ActivityMainBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MainActivity extends AppCompatActivity {

    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 액션바 설정하기
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // 네비게이션 호스트 설정하기
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {
            navController = navHostFragment.getNavController();
            NavigationUI.setupActionBarWithNavController(this, navController);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        return navController.navigateUp() || super.onSupportNavigateUp();
    }

}