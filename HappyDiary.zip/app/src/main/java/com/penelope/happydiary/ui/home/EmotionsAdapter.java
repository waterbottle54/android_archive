package com.penelope.happydiary.ui.home;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.happydiary.R;
import com.penelope.happydiary.data.emotion.Emotion;
import com.penelope.happydiary.databinding.EmotionItemBinding;
import com.penelope.happydiary.utils.ImageUtils;
import com.penelope.happydiary.utils.ui.Value;

public class EmotionsAdapter extends ListAdapter<Value<Emotion>, EmotionsAdapter.EmotionViewHolder> {

    class EmotionViewHolder extends RecyclerView.ViewHolder {

        private final EmotionItemBinding binding;

        public EmotionViewHolder(EmotionItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Value<Emotion> model) {

            // 감정 아이콘을 이미지 뷰에 띄운다

            Emotion emotion = model.value;

            if (emotion != null) {
                binding.imageView3.setImageResource(ImageUtils.getEmotionImage(emotion.getType()));
            }
            binding.imageView3.setVisibility(emotion != null ? View.VISIBLE : View.INVISIBLE);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public EmotionsAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public EmotionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        EmotionItemBinding binding = EmotionItemBinding.inflate(layoutInflater, parent, false);
        return new EmotionViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull EmotionViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Value<Emotion>> {

        @Override
        public boolean areItemsTheSame(@NonNull Value<Emotion> oldItem, @NonNull Value<Emotion> newItem) {
            return true;
        }

        @Override
        public boolean areContentsTheSame(@NonNull Value<Emotion> oldItem, @NonNull Value<Emotion> newItem) {
            if (oldItem.value == null && newItem.value == null) {
                return true;
            }
            if (oldItem.value == null || newItem.value == null) {
                return false;
            }
            return oldItem.value.equals(newItem.value);
        }
    }

}