package com.penelope.happydiary.ui.sharingdiary.sharingdiary;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.data.diary.Diary;
import com.penelope.happydiary.data.diary.DiaryRepository;
import com.penelope.happydiary.data.emotion.EmotionType;
import com.penelope.happydiary.data.user.User;
import com.penelope.happydiary.data.user.UserRepository;
import com.penelope.happydiary.ui.privatediary.privatediary.PrivateDiaryViewModel;

import java.time.LocalDate;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SharingDiaryViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> uid = new MutableLiveData<>();

    private final LiveData<List<Diary>> diaries;

    private final MutableLiveData<Boolean> isUploadInProgress = new MutableLiveData<>(false);

    private final DiaryRepository diaryRepository;


    @Inject
    public SharingDiaryViewModel(UserRepository userRepository, DiaryRepository diaryRepository) {

        // 현재 회원정보를 획득한다
        LiveData<User> user = Transformations.switchMap(uid, userRepository::getUserLive);

        // 나 자신과 공유회원이 작성한 일기 목록을 불러온다
        diaries = Transformations.switchMap(user, u -> {
            List<String> providers = u.getProviders();
            providers.add(u.getUid());
            return diaryRepository.getSharingDiaries(providers);
        });

        this.diaryRepository = diaryRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Diary>> getDiaries() {
        return diaries;
    }

    public LiveData<Boolean> isUploadInProgress() {
        return isUploadInProgress;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getUid() != null) {
            uid.setValue(firebaseAuth.getUid());
        }
    }

    public void onDiaryClick(Diary diary) {
        event.setValue(new Event.NavigateToDetailScreen(diary));
    }

    public void onAddFriendClick() {
        event.setValue(new Event.NavigateToFriendScreen());
    }

    public void onAddDiaryClick() {
        event.setValue(new Event.PromptDiaryType());
    }

    public void onShortTypeClick() {
        event.setValue(new Event.PromptShortDiary());
    }

    public void onLongTypeClick() {
        event.setValue(new Event.NavigateToAddDiaryScreen());
    }

    public void onAddDiaryResult(boolean success) {
        if (success) {
            event.setValue(new Event.ShowGeneralMessage("공유 일기를 작성했습니다"));
        }
    }

    public void onShortDiarySubmit(String title, String content, EmotionType emotionType) {

        // 이미 업로드 진행중이면 리턴한다

        Boolean isUploadInProgressValue = isUploadInProgress.getValue();
        assert isUploadInProgressValue != null;
        if (isUploadInProgressValue) {
            return;
        }

        String uidValue = uid.getValue();
        if (uidValue == null) {
            return;
        }

        // 한줄일기 입력값을 확인한다

        title = title.trim();
        content = content.trim();

        if (title.isEmpty() || content.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력하세요"));
            return;
        }

        // 일기 객체를 구성하고 DB 에 업로드를 진행한다

        Diary diary = new Diary(uidValue, title, content, emotionType, null, LocalDate.now());

        isUploadInProgress.setValue(true);

        diaryRepository.addSharingDiary(diary,
                unused -> {
                    isUploadInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("한줄일기가 작성되었습니다"));
                },
                e -> {
                    e.printStackTrace();
                    isUploadInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("일기 업로드에 실패했습니다"));
                });
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBack extends Event {
        }

        public static class NavigateToDetailScreen extends Event {
            public final Diary diary;
            public NavigateToDetailScreen(Diary diary) {
                this.diary = diary;
            }
        }

        public static class NavigateToFriendScreen extends Event {
        }

        public static class NavigateToAddDiaryScreen extends Event {
        }

        public static class PromptDiaryType extends Event {
        }

        public static class PromptShortDiary extends Event {
        }
    }

}










