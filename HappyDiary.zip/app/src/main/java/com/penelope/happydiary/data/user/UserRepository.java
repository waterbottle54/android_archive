package com.penelope.happydiary.data.user;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.happydiary.utils.BaseRepository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class UserRepository extends BaseRepository<User> {


    private final CollectionReference userCollection;

    @Inject
    public UserRepository(FirebaseFirestore firestore) {
        userCollection = firestore.collection("users");
    }

    // DB 에 회원정보를 저장하는 메소드

    public void addUser(User user, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {
        userCollection.document(user.getUid())
                .set(user)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    // DB 에서 특정 회원정보를 불러오는 메소드

    public void getUser(String uid, OnSuccessListener<User> onSuccessListener, OnFailureListener onFailureListener) {
        userCollection.document(uid)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot == null) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    User user = documentSnapshot.toObject(User.class);
                    onSuccessListener.onSuccess(user);
                })
                .addOnFailureListener(onFailureListener);
    }

    // 위 메소드의 LiveData 버전

    public LiveData<User> getUserLive(String uid) {

        MutableLiveData<User> user = new MutableLiveData<>();
        userCollection.document(uid)
                .addSnapshotListener((value, error) -> {
                    if (value == null || error != null) {
                        user.setValue(null);
                        return;
                    }
                    user.setValue(value.toObject(User.class));
                });

        return user;
    }

    // 유저의 고유키로 회원정보를 바로 탐색할 수 있도록 Map 을 제공하는 메소드

    public LiveData<Map<String, User>> getUserMap() {

        MutableLiveData<Map<String, User>> userMap = new MutableLiveData<>();

        userCollection.addSnapshotListener((value, error) -> {
            if (error != null) {
                error.printStackTrace();
                userMap.setValue(null);
                return;
            }
            Map<String, User> map = new HashMap<>();
            if (value == null || value.isEmpty()) {
                userMap.setValue(map);
                return;
            }
            for (DocumentSnapshot snapshot : value) {
                User user = snapshot.toObject(User.class);
                if (user != null) {
                    map.put(user.getUid(), user);
                }
            }
            userMap.setValue(map);
        });

        return userMap;
    }

    // 닉네임을 통해 회원정보를 검색하는 메소드

    public void findUserByNickname(String nickname,
                                   OnSuccessListener<User> onSuccessListener, OnFailureListener onFailureListener) {

        userCollection.whereEqualTo("nickname", nickname)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        DocumentSnapshot snapshot = queryDocumentSnapshots.getDocuments().get(0);
                        onSuccessListener.onSuccess(snapshot.toObject(User.class));
                    } else {
                        onSuccessListener.onSuccess(null);
                    }
                })
                .addOnFailureListener(onFailureListener);
    }

    // 특정 유저 (uid) 가 작성한 일기를 다른 유저 (watcherId) 가 볼 수 있도록 공유하는 메소드

    public void addWatcher(String uid, String watcherId, OnSuccessListener<Void> onSuccessListener,
                           OnFailureListener onFailureListener) {

        getUser(uid,
                user -> {
                    if (user == null) {
                        onFailureListener.onFailure(new Exception("No such user " + uid));
                        return;
                    }
                    getUser(watcherId,
                            watcher -> {
                                if (watcher == null) {
                                    onFailureListener.onFailure(new Exception("No such user " + watcherId));
                                    return;
                                }
                                List<String> watcherList = user.getWatchers();
                                watcherList.remove(watcherId);
                                watcherList.add(watcherId);

                                List<String> providerList = watcher.getProviders();
                                providerList.remove(uid);
                                providerList.add(uid);

                                addUser(user,
                                        unused -> addUser(watcher, onSuccessListener, onFailureListener),
                                        onFailureListener);
                            },
                            onFailureListener);
                },
                onFailureListener);
    }

}









