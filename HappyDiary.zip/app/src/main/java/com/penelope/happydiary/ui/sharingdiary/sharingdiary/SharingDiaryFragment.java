package com.penelope.happydiary.ui.sharingdiary.sharingdiary;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.data.diary.Diary;
import com.penelope.happydiary.data.emotion.EmotionType;
import com.penelope.happydiary.databinding.DialogSelectDiaryTypeBinding;
import com.penelope.happydiary.databinding.DialogShortDiaryBinding;
import com.penelope.happydiary.databinding.DialogShortSharingDiaryBinding;
import com.penelope.happydiary.databinding.FragmentSharingDiaryBinding;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SharingDiaryFragment extends AuthListenerFragment {

    private FragmentSharingDiaryBinding binding;
    private SharingDiaryViewModel viewModel;


    public SharingDiaryFragment() {
        super(R.layout.fragment_sharing_diary);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSharingDiaryBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SharingDiaryViewModel.class);

        // UI 에 리스너를 지정한다
        binding.fabAddFriend.setOnClickListener(v -> viewModel.onAddFriendClick());
        binding.fabAddSharingDiary.setOnClickListener(v -> viewModel.onAddDiaryClick());

        // 일기 어댑터를 생성하고 리사이클러 뷰에 연결한다
        DiaryAdapter adapter = new DiaryAdapter(Glide.with(this));
        binding.recyclerDiary.setAdapter(adapter);
        binding.recyclerDiary.setHasFixedSize(true);

        adapter.setOnItemSelectedListener(position -> {
            Diary diary = adapter.getCurrentList().get(position);
            viewModel.onDiaryClick(diary);
        });

        // 일기 목록을 리사이클러 뷰에 업데이트한다
        viewModel.getDiaries().observe(getViewLifecycleOwner(), diaries -> {
            if (diaries != null) {
                adapter.submitList(diaries);
                binding.textViewNoDiaries.setVisibility(diaries.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            }
            binding.progressBar4.setVisibility(View.INVISIBLE);
        });

        // 일기를 업로드 중이면 로딩 UI 를 보인다
        viewModel.isUploadInProgress().observe(getViewLifecycleOwner(), isUploadInProgress ->
                binding.progressBar4.setVisibility(isUploadInProgress ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델의 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SharingDiaryViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SharingDiaryViewModel.Event.NavigateToDetailScreen) {
                Diary diary = ((SharingDiaryViewModel.Event.NavigateToDetailScreen) event).diary;
                NavDirections navDirections = SharingDiaryFragmentDirections.actionSharingDiaryFragmentToDetailFragment(diary);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof SharingDiaryViewModel.Event.NavigateToFriendScreen) {
                NavDirections navDirections = SharingDiaryFragmentDirections.actionSharingDiaryFragmentToFriendFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof SharingDiaryViewModel.Event.NavigateToAddDiaryScreen) {
                NavDirections navDirections = SharingDiaryFragmentDirections.actionSharingDiaryFragmentToAddSharingDiaryFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof SharingDiaryViewModel.Event.PromptDiaryType) {
                showDiaryTypeDialog();
            } else if (event instanceof SharingDiaryViewModel.Event.PromptShortDiary) {
                showShortDiaryDialog();
            }
        });

        // 일기 작성결과를 뷰모델에 통보한다
        getParentFragmentManager().setFragmentResultListener("add_sharing_diary_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("success");
                    viewModel.onAddDiaryResult(success);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }


    private void showDiaryTypeDialog() {

        // 일기 타입을 선택하는 대화상자를 띄운다

        DialogSelectDiaryTypeBinding binding = DialogSelectDiaryTypeBinding.inflate(getLayoutInflater());

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("어떤 일기를 적으시겠습니까?")
                .setView(binding.getRoot())
                .setNegativeButton("취소", null)
                .create();

        binding.textViewShort.setOnClickListener(v -> {
            viewModel.onShortTypeClick();
            dialog.dismiss();
        });

        binding.textViewLong.setOnClickListener(v -> {
            viewModel.onLongTypeClick();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showShortDiaryDialog() {

        // 한줄일기를 입력받는 대화상자를 띄운다

        DialogShortSharingDiaryBinding binding = DialogShortSharingDiaryBinding.inflate(getLayoutInflater());

        MutableLiveData<EmotionType> emotionType = new MutableLiveData<>(EmotionType.VERY_HAPPY);

        // UI 에 리스너를 지정한다
        binding.cardViewVeryHappy.setOnClickListener(v -> emotionType.setValue(EmotionType.VERY_HAPPY));
        binding.cardViewHappy.setOnClickListener(v -> emotionType.setValue(EmotionType.HAPPY));
        binding.cardViewOrdinary.setOnClickListener(v -> emotionType.setValue(EmotionType.ORDINARY));
        binding.cardViewSad.setOnClickListener(v -> emotionType.setValue(EmotionType.SAD));
        binding.cardViewVerySad.setOnClickListener(v -> emotionType.setValue(EmotionType.VERY_SAD));

        // 감정상태에 따라 카드뷰 색상을 업데이트한다
        emotionType.observe(getViewLifecycleOwner(), type -> {
            int colorUnselected = 0xFFEEFFFF;
            int colorSelected = getResources().getColor(R.color.colorDarkSkyLight, null);
            binding.cardViewVeryHappy.setCardBackgroundColor(colorUnselected);
            binding.cardViewHappy.setCardBackgroundColor(colorUnselected);
            binding.cardViewOrdinary.setCardBackgroundColor(colorUnselected);
            binding.cardViewSad.setCardBackgroundColor(colorUnselected);
            binding.cardViewVerySad.setCardBackgroundColor(colorUnselected);
            switch (type) {
                default:
                case VERY_HAPPY:
                    binding.cardViewVeryHappy.setCardBackgroundColor(colorSelected);
                    break;
                case HAPPY:
                    binding.cardViewHappy.setCardBackgroundColor(colorSelected);
                    break;
                case ORDINARY:
                    binding.cardViewOrdinary.setCardBackgroundColor(colorSelected);
                    break;
                case SAD:
                    binding.cardViewSad.setCardBackgroundColor(colorSelected);
                    break;
                case VERY_SAD:
                    binding.cardViewVerySad.setCardBackgroundColor(colorSelected);
                    break;
            }
        });

        new AlertDialog.Builder(requireContext())
                .setTitle("한줄 일기를 작성해주세요")
                .setView(binding.getRoot())
                .setPositiveButton("확인", (dialog, which) -> {
                    String title = binding.editTextDiaryTitle.getText().toString();
                    String content = binding.editTextDiaryContent.getText().toString();
                    viewModel.onShortDiarySubmit(title, content, emotionType.getValue());
                })
                .setNegativeButton("취소", null)
                .show();
    }

}





