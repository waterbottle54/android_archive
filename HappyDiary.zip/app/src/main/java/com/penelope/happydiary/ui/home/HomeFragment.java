package com.penelope.happydiary.ui.home;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.data.emotion.Emotion;
import com.penelope.happydiary.data.emotion.EmotionType;
import com.penelope.happydiary.databinding.DialogPickEmotionBinding;
import com.penelope.happydiary.databinding.FragmentHomeBinding;
import com.penelope.happydiary.utils.TimeUtils;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;
import com.penelope.happydiary.utils.ui.Value;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeFragment extends AuthListenerFragment {

    private FragmentHomeBinding binding;
    private HomeViewModel viewModel;


    public HomeFragment() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                viewModel.onBackClick();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentHomeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        // UI 에 리스너를 지정한다
        binding.fabPrivateDiary.setOnClickListener(v -> viewModel.onPrivateDiaryClick());
        binding.fabSharingDiary.setOnClickListener(v -> viewModel.onSharingDiaryClick());

        binding.calendarView.setOnDateChangedListener((widget, date, selected) ->
                viewModel.onDateClick(date.getYear(), date.getMonth(), date.getDay()));

        binding.calendarView.setOnMonthChangedListener((widget, date) ->
                viewModel.onMonthChange(date.getYear(), date.getMonth()));

        // 감정 아이콘 어댑터를 정의하고 리사이클러 뷰에 연결한다
        EmotionsAdapter emotionAdapter = new EmotionsAdapter();
        binding.recyclerEmotion.setAdapter(emotionAdapter);
        binding.recyclerEmotion.setHasFixedSize(true);
        binding.recyclerEmotion.setLayoutManager(new GridLayoutManager(requireContext(), 7));

        // 감정 기록이 변경되면 리사이클러 뷰를 업데이트한다
        viewModel.getEmotions().observe(getViewLifecycleOwner(), emotions -> {
            if (emotions != null) {
                if (emotions.isEmpty()) {
                    emotionAdapter.submitList(Collections.nCopies(35, new Value<>(null)));
                    return;
                }

                // 일자별 감정기록을 맵으로 정리한다
                Map<Integer, Emotion> map = new HashMap<>();
                for (Emotion emotion : emotions) {
                    map.put(emotion.getDayOfMonth(), emotion);
                }

                // 감정기록의 작성일자를 추출한다
                int year = emotions.get(0).getYear();
                int month = emotions.get(0).getMonth();
                int firstDayIndex = LocalDate.of(year, month, 1).getDayOfWeek().getValue() % 7;

                // 달력에서 감정기록의 위치를 지정하여 정리한다
                List<Value<Emotion>> slots = new ArrayList<>();
                for (int slot = 0; slot < 35; slot++) {
                    int day = slot + 1 - firstDayIndex;
                    Emotion emotion = day > 0 ? map.get(day) : null;
                    slots.add(new Value<>(emotion));
                }
                emotionAdapter.submitList(slots);
            }
        });

        // 닉네임, 프로필 이미지를 UI 에 업데이트한다
        viewModel.getUser().observe(getViewLifecycleOwner(), user ->
                binding.textViewNickname.setText(user.getNickname()));

        viewModel.getImage().observe(getViewLifecycleOwner(), image ->
                binding.imageViewProfile.setImageBitmap(image));

        // 라인 차트의 스타일을 지정한다
        binding.lineChart.getDescription().setEnabled(false);
        binding.lineChart.getLegend().setEnabled(false);
        binding.lineChart.getXAxis().setDrawGridLines(false);
        binding.lineChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);
        binding.lineChart.getXAxis().setTextColor(0xFFCCCCCC);
        binding.lineChart.getAxisRight().setEnabled(false);
        binding.lineChart.getAxisLeft().setAxisMinimum(0);
        binding.lineChart.getAxisLeft().setDrawGridLines(false);
        binding.lineChart.getAxisLeft().setTextColor(0xFFCCCCCC);
        binding.lineChart.getAxisLeft().setValueFormatter(new ValueFormatter() {
            @Override
            public String getAxisLabel(float value, AxisBase axis) {
                int percent = Math.round(value * 100);
                return (percent == 20 || percent == 60 || percent == 100) ? String.valueOf(percent) : "";
            }
        });

        // 감정 기록 통계를 라인 차트에 업데이트한다
        viewModel.getStatistic().observe(getViewLifecycleOwner(), statistic -> {
            if (statistic != null) {
                // 통계 정보를 엔트리로 정리한다
                List<Entry> entries = new ArrayList<>();
                for (int i = 0; i < statistic.size(); i++) {
                    float emotionValue = statistic.get(i).second.floatValue();
                    if (emotionValue > 0) {
                        entries.add(new Entry(i, emotionValue));
                    }
                }
                // 데이터셋의 스타일을 지정하고 다시 그린다
                LineDataSet dataSet = new LineDataSet(entries, "entries");
                dataSet.setLineWidth(1.5f);
                dataSet.setColor(0xFFAAAAAA);
                dataSet.setDrawValues(false);
                binding.lineChart.getXAxis().setValueFormatter(new ValueFormatter() {
                    @Override
                    public String getAxisLabel(float value, AxisBase axis) {
                        int index = (int) value;
                        if (index > statistic.size() - 1) {
                            return "";
                        }
                        LocalDate date = statistic.get((int) value).first;
                        return TimeUtils.formatDate(date.getMonthValue(), date.getDayOfMonth());
                    }
                });
                LineData data = new LineData(dataSet);
                binding.lineChart.setData(data);
                binding.lineChart.invalidate();
            }
        });

        // 뷰모델의 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof HomeViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof HomeViewModel.Event.ConfirmLogout) {
                showConfirmSignOutDialog();
            } else if (event instanceof HomeViewModel.Event.ShowGeneralMessage) {
                String message = ((HomeViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof HomeViewModel.Event.PromptEmotion) {
                LocalDate date = ((HomeViewModel.Event.PromptEmotion) event).date;
                showEmotionDialog(date);
            } else if (event instanceof HomeViewModel.Event.NavigateToPrivateDiary) {
                NavDirections navDirections = HomeFragmentDirections.actionHomeFragmentToPrivateDiaryFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof HomeViewModel.Event.NavigateToSharingDiary) {
                NavDirections navDirections = HomeFragmentDirections.actionHomeFragmentToSharingDiaryFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void showConfirmSignOutDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle("로그아웃")
                .setMessage("로그아웃 하시겠습니까?")
                .setPositiveButton("로그아웃", (dialog, which) -> viewModel.onSignOutConfirmed())
                .setNegativeButton("취소", null)
                .show();
    }

    private void showEmotionDialog(LocalDate date) {

        DialogPickEmotionBinding binding = DialogPickEmotionBinding.inflate(getLayoutInflater());

        String title = "오늘의 기분은 어땠나요?";

        if (!date.equals(LocalDate.now())) {
            title = String.format(Locale.getDefault(), "%d월 %d일의 기분은 어땠나요?",
                    date.getMonthValue(), date.getDayOfMonth());
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle(title)
                .setView(binding.getRoot())
                .setNegativeButton("취소", null)
                .create();

        binding.imageViewEmoji1.setOnClickListener(v -> {
            viewModel.onEmotionClick(date, EmotionType.VERY_SAD);
            dialog.dismiss();
        });
        binding.imageViewEmoji2.setOnClickListener(v -> {
            viewModel.onEmotionClick(date, EmotionType.SAD);
            dialog.dismiss();
        });
        binding.imageViewEmoji3.setOnClickListener(v -> {
            viewModel.onEmotionClick(date, EmotionType.ORDINARY);
            dialog.dismiss();
        });
        binding.imageViewEmoji4.setOnClickListener(v -> {
            viewModel.onEmotionClick(date, EmotionType.HAPPY);
            dialog.dismiss();
        });
        binding.imageViewEmoji5.setOnClickListener(v -> {
            viewModel.onEmotionClick(date, EmotionType.VERY_HAPPY);
            dialog.dismiss();
        });

        dialog.show();
    }

}


