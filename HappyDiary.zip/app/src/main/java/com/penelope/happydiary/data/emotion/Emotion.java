package com.penelope.happydiary.data.emotion;

import java.util.Objects;

public class Emotion {

    private String id;          // 고유키
    private String uid;         // 이 감정을 기록한 유저의 암호화 아이디
    private EmotionType type;   // 감정 타입
    private int year;           // 작성 연도
    private int month;          // 작성월
    private int dayOfMonth;     // 작성일자


    public Emotion() {
    }

    public Emotion(String uid, EmotionType type, int year, int month, int dayOfMonth) {
        this.uid = uid;
        this.type = type;
        this.year = year;
        this.month = month;
        this.dayOfMonth = dayOfMonth;
        this.id = uid + "_" + year + "_" + month + "_" + dayOfMonth;
    }

    public String getId() {
        return id;
    }

    public String getUid() {
        return uid;
    }

    public EmotionType getType() {
        return type;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDayOfMonth() {
        return dayOfMonth;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setType(EmotionType type) {
        this.type = type;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public void setDayOfMonth(int dayOfMonth) {
        this.dayOfMonth = dayOfMonth;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Emotion emotion = (Emotion) o;
        return year == emotion.year && month == emotion.month && dayOfMonth == emotion.dayOfMonth && id.equals(emotion.id) && uid.equals(emotion.uid) && type == emotion.type;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, uid, type, year, month, dayOfMonth);
    }
}
