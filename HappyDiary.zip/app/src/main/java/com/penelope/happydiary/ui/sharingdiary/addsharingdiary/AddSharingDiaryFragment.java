package com.penelope.happydiary.ui.sharingdiary.addsharingdiary;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.data.diary.WeatherType;
import com.penelope.happydiary.data.emotion.EmotionType;
import com.penelope.happydiary.databinding.FragmentAddSharingDiaryBinding;
import com.penelope.happydiary.utils.BitmapUtils;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;
import com.penelope.happydiary.utils.ui.UiUtils;

import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class AddSharingDiaryFragment extends AuthListenerFragment {

    private FragmentAddSharingDiaryBinding binding;
    private AddSharingDiaryViewModel viewModel;

    private ActivityResultLauncher<Intent> imageActivityLauncher;
    private ActivityResultLauncher<String[]> requestPermissionLauncher;


    public AddSharingDiaryFragment() {
        super(R.layout.fragment_add_sharing_diary);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 사진 입력 시 결과값을 처리하는 런처
        imageActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::onImageResult
        );

        // 사진 촬영, 저장소 읽기 퍼미션을 요청하는 런처
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                this::onPermissionResult
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentAddSharingDiaryBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(AddSharingDiaryViewModel.class);

        // UI 에 리스너를 지정한다
        binding.cardViewVeryHappy.setOnClickListener(v -> viewModel.onEmotionClick(EmotionType.VERY_HAPPY));
        binding.cardViewHappy.setOnClickListener(v -> viewModel.onEmotionClick(EmotionType.HAPPY));
        binding.cardViewOrdinary.setOnClickListener(v -> viewModel.onEmotionClick(EmotionType.ORDINARY));
        binding.cardViewVerySad.setOnClickListener(v -> viewModel.onEmotionClick(EmotionType.VERY_SAD));
        binding.cardViewSad.setOnClickListener(v -> viewModel.onEmotionClick(EmotionType.SAD));

        binding.cardViewSunny.setOnClickListener(v -> viewModel.onWeatherClick(WeatherType.SUNNY));
        binding.cardViewWindy.setOnClickListener(v -> viewModel.onWeatherClick(WeatherType.WINDY));
        binding.cardViewCloudy.setOnClickListener(v -> viewModel.onWeatherClick(WeatherType.CLOUDY));
        binding.cardViewRainy.setOnClickListener(v -> viewModel.onWeatherClick(WeatherType.RAINY));
        binding.cardViewSnowy.setOnClickListener(v -> viewModel.onWeatherClick(WeatherType.SNOWY));

        binding.fabUploadImage.setOnClickListener(v -> viewModel.onAddImageClick());
        UiUtils.addTextChangedListener(binding.editTextDiaryTitle, s -> viewModel.onTitleChange(s));
        UiUtils.addTextChangedListener(binding.editTextDiaryContent, s -> viewModel.onContentChange(s));
        binding.fabSubmit.setOnClickListener(v -> viewModel.onSubmitClick());

        // 감정상태에 따라 UI 를 업데이트한다
        viewModel.getEmotionType().observe(getViewLifecycleOwner(), type -> {
            int colorUnselected = 0xFFEEFFFF;
            int colorSelected = getResources().getColor(R.color.colorDarkSkyLight, null);
            binding.cardViewVeryHappy.setCardBackgroundColor(colorUnselected);
            binding.cardViewHappy.setCardBackgroundColor(colorUnselected);
            binding.cardViewOrdinary.setCardBackgroundColor(colorUnselected);
            binding.cardViewSad.setCardBackgroundColor(colorUnselected);
            binding.cardViewVerySad.setCardBackgroundColor(colorUnselected);
            getEmotionCardView(type).setCardBackgroundColor(colorSelected);
        });

        // 날씨에 따라 UI 를 업데이트한다
        viewModel.getWeatherType().observe(getViewLifecycleOwner(), type -> {
            int colorUnselected = 0xFFEEFFFF;
            int colorSelected = getResources().getColor(R.color.colorDarkSkyLight, null);
            binding.cardViewSunny.setCardBackgroundColor(colorUnselected);
            binding.cardViewWindy.setCardBackgroundColor(colorUnselected);
            binding.cardViewCloudy.setCardBackgroundColor(colorUnselected);
            binding.cardViewRainy.setCardBackgroundColor(colorUnselected);
            binding.cardViewSnowy.setCardBackgroundColor(colorUnselected);
            getWeatherCardView(type).setCardBackgroundColor(colorSelected);
        });

        // 이미지를 띄운다
        viewModel.getImage().observe(getViewLifecycleOwner(), image ->
                binding.imageViewDiary.setImageBitmap(image));

        // 업로드 중이면 로딩 UI 를 보인다
        viewModel.isUploadInProgress().observe(getViewLifecycleOwner(), isUploadInProgress ->
                binding.progressBar3.setVisibility(isUploadInProgress ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof AddSharingDiaryViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof AddSharingDiaryViewModel.Event.ShowGeneralMessage) {
                String message = ((AddSharingDiaryViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof AddSharingDiaryViewModel.Event.PromptImage) {
                promptImage();
            } else if (event instanceof AddSharingDiaryViewModel.Event.NavigateBackWithResult) {
                boolean success = ((AddSharingDiaryViewModel.Event.NavigateBackWithResult) event).success;
                Bundle result = new Bundle();
                result.putBoolean("success", success);
                getParentFragmentManager().setFragmentResult("add_sharing_diary_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private CardView getWeatherCardView(WeatherType type) {
        switch (type) {
            default:
            case SUNNY: return binding.cardViewSunny;
            case WINDY: return binding.cardViewWindy;
            case CLOUDY: return binding.cardViewCloudy;
            case RAINY: return binding.cardViewRainy;
            case SNOWY: return binding.cardViewSnowy;
        }
    }

    private CardView getEmotionCardView(EmotionType type) {
        switch (type) {
            default:
            case VERY_HAPPY: return binding.cardViewVeryHappy;
            case HAPPY: return binding.cardViewHappy;
            case ORDINARY: return binding.cardViewOrdinary;
            case SAD: return binding.cardViewSad;
            case VERY_SAD: return binding.cardViewVerySad;
        }
    }

    private void promptImage() {

        if (requireContext().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && requireContext().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showImageDialog();
        } else {
            requestPermissionLauncher.launch(
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA});
        }
    }

    private void showImageDialog() {

        // 업로드 방법 선택 대화상자 보이기
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chooser = Intent.createChooser(galleryIntent, "프로필 이미지 업로드");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        imageActivityLauncher.launch(chooser);
    }

    private void onImageResult(ActivityResult result) {

        if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
            Bitmap bitmap = null;
            if (result.getData().getExtras() != null) {
                // 카메라 결과 획득
                bitmap = (Bitmap) result.getData().getExtras().get("data");
            } else {
                // 갤러리(포토) 결과 획득
                Uri uri = result.getData().getData();
                if (uri != null) {
                    bitmap = BitmapUtils.getBitmapFromUri(requireContext(), uri);
                }
            }
            viewModel.onImageSelected(bitmap);
        }
    }

    private void onPermissionResult(Map<String, Boolean> result) {

        Boolean permissionExternalStorage = result.get(Manifest.permission.READ_EXTERNAL_STORAGE);
        Boolean permissionCamera = result.get(Manifest.permission.CAMERA);

        if (permissionExternalStorage != null && permissionExternalStorage
                && permissionCamera != null && permissionCamera) {
            showImageDialog();
        }
    }


}