package com.penelope.happydiary.utils.ui;

public class Value<T> {

    public final T value;

    public Value(T value) {
        this.value = value;
    }
}
