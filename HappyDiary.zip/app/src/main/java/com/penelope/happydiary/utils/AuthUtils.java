package com.penelope.happydiary.utils;

public class AuthUtils {

    public static String emailize(String phone) {
        return phone + "@seatforu.com";
    }

}
