package com.penelope.happydiary.data.comment;

import java.util.Objects;

public class Comment {

    private String id;          // 고유키
    private String diaryId;     // 이 댓글이 작성된 일기의 아이디
    private String uid;         // 댓글 작성자의 암호화 아이디
    private String content;     // 댓글 내용
    private long created;       // 댓글 작성한 시간: epoch millis 단위

    public Comment() {
    }

    public Comment(String diaryId, String uid, String content) {
        this.diaryId = diaryId;
        this.uid = uid;
        this.content = content;
        this.created = System.currentTimeMillis();
        this.id = diaryId + "_" + uid + "_" + created;
    }

    public String getId() {
        return id;
    }

    public String getDiaryId() {
        return diaryId;
    }

    public String getUid() {
        return uid;
    }

    public String getContent() {
        return content;
    }

    public long getCreated() {
        return created;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setDiaryId(String diaryId) {
        this.diaryId = diaryId;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Comment comment = (Comment) o;
        return created == comment.created && id.equals(comment.id) && diaryId.equals(comment.diaryId) && uid.equals(comment.uid) && content.equals(comment.content);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, diaryId, uid, content, created);
    }
}
