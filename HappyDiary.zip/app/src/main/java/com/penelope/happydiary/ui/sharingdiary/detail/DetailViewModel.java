package com.penelope.happydiary.ui.sharingdiary.detail;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.data.comment.Comment;
import com.penelope.happydiary.data.comment.CommentRepository;
import com.penelope.happydiary.data.diary.Diary;
import com.penelope.happydiary.data.user.User;
import com.penelope.happydiary.data.user.UserRepository;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class DetailViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String uid;

    private final Diary diary;

    private final LiveData<List<Comment>> comment;

    private final LiveData<Map<String, User>> userMap;

    private final CommentRepository commentRepository;


    @Inject
    public DetailViewModel(SavedStateHandle savedStateHandle, CommentRepository commentRepository,
                           UserRepository userRepository) {

        // 보여줄 일기를 획득한다
        diary = savedStateHandle.get("diary");
        assert diary != null;

        // 이 일기에 달린 댓글을 불러온다
        comment = commentRepository.getCommentsLive(diary.getId());

        userMap = userRepository.getUserMap();

        this.commentRepository = commentRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public Diary getDiary() {
        return diary;
    }

    public LiveData<List<Comment>> getComments() {
        return comment;
    }

    public LiveData<Map<String, User>> getUserMap() {
        return userMap;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getUid() != null) {
            uid = firebaseAuth.getUid();
        }
    }

    public void onAddCommentClick() {
        event.setValue(new Event.PromptComment());
    }

    public void onSubmitComment(String text) {

        if (uid == null) {
            return;
        }

        // 댓글을 업로드한다

        text = text.trim();

        if (text.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("내용을 입력해주세요"));
            return;
        }

        Comment comment = new Comment(diary.getId(), uid, text);

        commentRepository.addComment(comment,
                unused -> {},
                e -> {
                    // 댓글 업로드 실패
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("댓글 작성에 실패했습니다"));
                });
    }


    public static class Event {

        public static class PromptComment extends Event {
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }
    }

}





