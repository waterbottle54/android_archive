package com.penelope.happydiary.data.user;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class User implements Serializable {

    private String uid;                 // 암호화된 아이디 (DB 에서 고유키로 이용)
    private String id;                  // 아이디 (로그인 시 입력)
    private String nickname;            // 닉네임
    private List<String> watchers;      // 내 일기를 볼 수 있는 권한을 가진 유저들
    private List<String> providers;     // 나에게 일기를 보여주는 권한을 준 유저들
    private long created;               // 가입시간: epoch millis 단위

    public User() {
    }

    public User(String uid, String id, String nickname) {
        this.uid = uid;
        this.id = id;
        this.nickname = nickname;
        this.watchers = new ArrayList<>();
        this.providers = new ArrayList<>();
        this.created = System.currentTimeMillis();
    }

    public String getUid() {
        return uid;
    }

    public String getId() {
        return id;
    }

    public String getNickname() {
        return nickname;
    }

    public List<String> getWatchers() {
        return watchers;
    }

    public List<String> getProviders() {
        return providers;
    }

    public long getCreated() {
        return created;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setWatchers(List<String> watchers) {
        this.watchers = watchers;
    }

    public void setProviders(List<String> providers) {
        this.providers = providers;
    }

    public void setCreated(long created) {
        this.created = created;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return created == user.created && uid.equals(user.uid) && id.equals(user.id) && nickname.equals(user.nickname) && watchers.equals(user.watchers) && providers.equals(user.providers);
    }

    @Override
    public int hashCode() {
        return Objects.hash(uid, id, nickname, watchers, providers, created);
    }

}
