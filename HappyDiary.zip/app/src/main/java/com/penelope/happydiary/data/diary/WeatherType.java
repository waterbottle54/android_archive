package com.penelope.happydiary.data.diary;

// 날씨 타입: 5가지
public enum WeatherType {
    SUNNY, WINDY, CLOUDY, RAINY, SNOWY,
}

