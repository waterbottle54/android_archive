package com.penelope.happydiary.utils.ui;

import com.penelope.happydiary.data.emotion.EmotionType;

public class EmotionUtils {

    public static double getEmotionValue(EmotionType type) {
        switch (type) {
            case VERY_SAD: return 0.2;
            case SAD: return 0.4;
            case ORDINARY: return 0.6;
            case HAPPY: return 0.8;
            case VERY_HAPPY: return 1.0;
        }
        return 0;
    }
}
