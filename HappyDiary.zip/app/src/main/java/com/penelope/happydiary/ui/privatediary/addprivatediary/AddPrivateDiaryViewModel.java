package com.penelope.happydiary.ui.privatediary.addprivatediary;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.data.diary.Diary;
import com.penelope.happydiary.data.diary.DiaryRepository;
import com.penelope.happydiary.data.diary.WeatherType;
import com.penelope.happydiary.data.emotion.Emotion;
import com.penelope.happydiary.data.emotion.EmotionRepository;
import com.penelope.happydiary.data.image.ImageRepository;

import java.time.LocalDate;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class AddPrivateDiaryViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> uid = new MutableLiveData<>();

    private final LocalDate date;

    private final MutableLiveData<WeatherType> weatherType = new MutableLiveData<>(WeatherType.SUNNY);
    private final MutableLiveData<Bitmap> image = new MutableLiveData<>();

    private String title = "";
    private String content = "";

    private final LiveData<Emotion> emotion;

    private final MutableLiveData<Boolean> isUploadInProgress = new MutableLiveData<>(false);

    private final DiaryRepository diaryRepository;
    private final ImageRepository imageRepository;


    @Inject
    public AddPrivateDiaryViewModel(SavedStateHandle savedStateHandle,
                                    DiaryRepository diaryRepository, EmotionRepository emotionRepository,
                                    ImageRepository imageRepository) {

        date = savedStateHandle.get("date");
        assert date != null;

        // 해당일자의 감정기록을 불러온다
        emotion = Transformations.switchMap(uid, u -> emotionRepository.getDailyEmotion(u, date));

        this.diaryRepository = diaryRepository;
        this.imageRepository = imageRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LocalDate getDate() {
        return date;
    }

    public LiveData<WeatherType> getWeatherType() {
        return weatherType;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }

    public LiveData<Emotion> getEmotion() {
        return emotion;
    }

    public LiveData<Boolean> isUploadInProgress() {
        return isUploadInProgress;
    }


    public void onWeatherClick(WeatherType value) {
        weatherType.setValue(value);
    }

    public void onAddImageClick() {
        event.setValue(new Event.PromptImage());
    }

    public void onImageSelected(Bitmap bitmap) {
        if (bitmap != null) {
            image.setValue(bitmap);
        } else {
            event.setValue(new Event.ShowGeneralMessage("올바른 이미지가 아닙니다"));
        }
    }

    public void onTitleChange(String text) {
        title = text.trim();
    }

    public void onContentChange(String text) {
        content = text.trim();
    }

    public void onSubmitClick() {

        String uidValue = uid.getValue();
        if (uidValue == null) {
            return;
        }

        // 일기 업로드 중이면 리턴한다

        Boolean isUploadInProgressValue = isUploadInProgress.getValue();
        assert isUploadInProgressValue != null;

        if (isUploadInProgressValue) {
            return;
        }

        // 일기 입력값을 확인한다

        WeatherType weatherTypeValue = weatherType.getValue();
        Bitmap imageValue = image.getValue();
        assert weatherTypeValue != null;

        if (title.isEmpty() || content.isEmpty() || imageValue == null) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        // 일기 객체를 구성하고 DB 에 저장한다

        Diary diary = new Diary(uidValue, title, content, null, weatherTypeValue, date);

        isUploadInProgress.setValue(true);

        // 이미지 -> 일기 순으로 업로드한다

        imageRepository.addPrivateDiaryImage(diary.getId(), imageValue,
                unused -> {
                    diaryRepository.addPrivateDiary(diary,
                            unused1 -> event.setValue(new Event.NavigateBackWithResult(true)),
                            e -> {
                                // 일기 업로드 오류
                                e.printStackTrace();
                                event.setValue(new Event.ShowGeneralMessage("일기 업로드에 실패했습니다"));
                                isUploadInProgress.setValue(false);
                            });
                },
                e -> {
                    // 이미지 업로드 오류
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("이미지 업로드에 실패했습니다"));
                    isUploadInProgress.setValue(false);
                });
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getUid() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            uid.setValue(firebaseAuth.getUid());
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class PromptImage extends Event {
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;

            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }
    }

}


