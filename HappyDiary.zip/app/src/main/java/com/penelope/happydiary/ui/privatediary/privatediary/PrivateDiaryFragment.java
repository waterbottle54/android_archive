package com.penelope.happydiary.ui.privatediary.privatediary;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.databinding.DialogSelectDiaryTypeBinding;
import com.penelope.happydiary.databinding.DialogShortDiaryBinding;
import com.penelope.happydiary.databinding.FragmentPrivateDiaryBinding;
import com.penelope.happydiary.utils.ImageUtils;
import com.penelope.happydiary.utils.TimeUtils;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;

import java.time.LocalDate;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PrivateDiaryFragment extends AuthListenerFragment {

    private FragmentPrivateDiaryBinding binding;
    private PrivateDiaryViewModel viewModel;


    public PrivateDiaryFragment() {
        super(R.layout.fragment_private_diary);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPrivateDiaryBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PrivateDiaryViewModel.class);

        // UI 에 리스너를 지정한다
        binding.textViewDate.setOnClickListener(v -> viewModel.onDateClick());
        binding.fabAddDiary.setOnClickListener(v -> viewModel.onAddDiaryClick());

        // 선택된 일자를 UI 에 표시한다
        viewModel.getDate().observe(getViewLifecycleOwner(), date -> {
            String strDate = TimeUtils.formatDateDay(date.getYear(), date.getMonthValue(), date.getDayOfMonth());
            binding.textViewDate.setText(strDate);
        });

        // 작성된 개인 일기를 UI 에 표시한다
        viewModel.getDiary().observe(getViewLifecycleOwner(), diary -> {

            binding.groupDiary.setVisibility(diary != null ? View.VISIBLE : View.INVISIBLE);
            binding.groupNoDiary.setVisibility(diary == null ? View.VISIBLE : View.INVISIBLE);

            if (diary != null) {
                binding.textViewDiaryTitle.setText(diary.getTitle());
                binding.textViewDiaryContent.setText(diary.getContent());
                binding.cardViewImage.setVisibility(diary.getWeatherType() != null ? View.VISIBLE : View.GONE);
                if (diary.getWeatherType() != null) {
                    binding.imageViewDiaryWeather.setImageResource(
                            ImageUtils.getWeatherImage(diary.getWeatherType()));
                }
                Glide.with(this)
                        .load(ImageUtils.getPrivateDiaryImageUrl(diary.getId()))
                        .into(binding.imageViewDiary);
            }
            binding.imageViewEmoji.setAlpha(diary != null ? 1.0f : 0.5f);
            binding.progressBar2.setVisibility(View.INVISIBLE);
        });

        // 해당일의 감정 상태를 UI 에 이미지로 보인다
        viewModel.getEmotion().observe(getViewLifecycleOwner(), emotion -> {
            if (emotion != null) {
                binding.imageViewEmoji.setImageResource(ImageUtils.getEmotionImage(emotion.getType()));
            }
            binding.imageViewEmoji.setVisibility(emotion != null ? View.VISIBLE : View.INVISIBLE);
        });

        // 업로드 중이면 로딩 UI 를 보인다
        viewModel.isUploadInProgress().observe(getViewLifecycleOwner(), isUploadInProgress ->
                binding.progressBar2.setVisibility(isUploadInProgress ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델의 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PrivateDiaryViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof PrivateDiaryViewModel.Event.ShowGeneralMessage) {
                String message = ((PrivateDiaryViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof PrivateDiaryViewModel.Event.PromptDate) {
                LocalDate date = ((PrivateDiaryViewModel.Event.PromptDate) event).date;
                showDatePicker(date);
            } else if (event instanceof PrivateDiaryViewModel.Event.NavigateToAddDiaryScreen) {
                LocalDate date = ((PrivateDiaryViewModel.Event.NavigateToAddDiaryScreen) event).date;
                NavDirections navDirections = PrivateDiaryFragmentDirections.actionPrivateDiaryFragmentToAddPrivateDiaryFragment(date);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof PrivateDiaryViewModel.Event.PromptDiaryType) {
                showDiaryTypeDialog();
            } else if (event instanceof PrivateDiaryViewModel.Event.PromptShortDiary) {
                showShortDiaryDialog();
            }
        });

        getParentFragmentManager().setFragmentResultListener("add_private_diary_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("success");
                    viewModel.onAddDiaryResult(success);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void showDatePicker(LocalDate date) {

        // 날짜 선택을 위한 대화상자를 보인다
        DatePickerDialog dialog = new DatePickerDialog(requireContext(),
                (view, year, month, dayOfMonth) -> viewModel.onDateSelected(year, month + 1, dayOfMonth),
                date.getYear(), date.getMonthValue() - 1, date.getDayOfMonth()
        );

        dialog.show();
    }

    private void showDiaryTypeDialog() {

        // 일기 타입을 선택하는 대화상자를 보인다
        DialogSelectDiaryTypeBinding binding = DialogSelectDiaryTypeBinding.inflate(getLayoutInflater());

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("어떤 일기를 적으시겠습니까?")
                .setView(binding.getRoot())
                .setNegativeButton("취소", null)
                .create();

        binding.textViewShort.setOnClickListener(v -> {
            viewModel.onShortTypeClick();
            dialog.dismiss();
        });

        binding.textViewLong.setOnClickListener(v -> {
            viewModel.onLongTypeClick();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void showShortDiaryDialog() {

        // 짧은 일기를 작성하는 대화상자를 보인다

        DialogShortDiaryBinding binding = DialogShortDiaryBinding.inflate(getLayoutInflater());

        new AlertDialog.Builder(requireContext())
                .setTitle("한줄 일기를 작성해주세요")
                .setView(binding.getRoot())
                .setPositiveButton("확인", (dialog, which) -> {
                    String title = binding.editTextDiaryTitle.getText().toString();
                    String content = binding.editTextDiaryContent.getText().toString();
                    viewModel.onShortDiarySubmit(title, content);
                })
                .setNegativeButton("취소", null)
                .show();
    }

}





