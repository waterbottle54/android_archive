package com.penelope.happydiary.ui.auth.login;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.happydiary.utils.AuthUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class LoginViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String id = "";
    private String password = "";

    private final FirebaseAuth auth;


    @Inject
    public LoginViewModel(FirebaseAuth auth) {
        this.auth = auth;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() != null) {
            event.setValue(new Event.NavigateToHomeScreen());
        }
    }

    public void onIdChange(String text) {
        id = text.trim();
    }

    public void onPasswordChange(String text) {
        password = text.trim();
    }

    public void onLoginClick() {

        // 로그인을 진행한다

        // 에러 : 아이디, 비밀번호가 비어있음
        if (id.isEmpty() || password.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        // 에러 : 아이디가 너무 짧음
        if (id.length() < 4) {
            event.setValue(new Event.ShowGeneralMessage("아이디를 4글자 이상 입력해주세요"));
            return;
        }

        // 에러 : 비밀번호가 너무 짧음
        if (password.length() < 6) {
            event.setValue(new Event.ShowGeneralMessage("패스워드를 6글자 이상 입력해주세요"));
            return;
        }

        // 파이어베이스 Auth 에 아이디와 비밀번호를 전달하여 로그인을 진행함
        auth.signInWithEmailAndPassword(AuthUtils.emailize(id), password)
                .addOnFailureListener(e -> {
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("회원정보를 확인해주세요"));
                });
    }

    public void onRegisterClick() {
        event.setValue(new Event.NavigateToRegisterScreen());
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToRegisterScreen extends Event {
        }

        public static class NavigateToHomeScreen extends Event {
        }
    }

}