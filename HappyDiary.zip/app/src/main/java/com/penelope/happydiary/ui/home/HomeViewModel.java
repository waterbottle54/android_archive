package com.penelope.happydiary.ui.home;

import android.graphics.Bitmap;
import android.util.Pair;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.data.emotion.Emotion;
import com.penelope.happydiary.data.emotion.EmotionRepository;
import com.penelope.happydiary.data.emotion.EmotionType;
import com.penelope.happydiary.data.image.ImageRepository;
import com.penelope.happydiary.data.user.User;
import com.penelope.happydiary.data.user.UserRepository;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class HomeViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<User> user = new MutableLiveData<>();
    private final MutableLiveData<Bitmap> image = new MutableLiveData<>();

    private final MutableLiveData<YearMonth> yearMonth = new MutableLiveData<>(YearMonth.now());
    private final LiveData<List<Emotion>> emotions;

    private final LiveData<List<Pair<LocalDate, Double>>> statistic;

    private final FirebaseAuth auth;
    private final UserRepository userRepository;
    private final ImageRepository imageRepository;
    private final EmotionRepository emotionRepository;


    @Inject
    public HomeViewModel(FirebaseAuth auth, UserRepository userRepository,
                         ImageRepository imageRepository, EmotionRepository emotionRepository) {

        // 현재 사용자의 현재 월에 작성한 감정 상태를 모두 불러온다
        emotions = Transformations.switchMap(user, u ->
                Transformations.switchMap(yearMonth, ym ->
                        emotionRepository.getMonthlyEmotions(u.getUid(), ym.getYear(), ym.getMonthValue())
                ));

        // 현재 사용자의 현재 월에 기록함 감정상태의 통계정보를 불러온다
        statistic = Transformations.switchMap(user, u ->
                Transformations.switchMap(yearMonth, ym ->
                        emotionRepository.getStatistic(u.getUid(), ym.getYear(), ym.getMonthValue())
                ));

        this.auth = auth;
        this.userRepository = userRepository;
        this.imageRepository = imageRepository;
        this.emotionRepository = emotionRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<User> getUser() {
        return user;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }

    public LiveData<List<Emotion>> getEmotions() {
        return emotions;
    }

    public LiveData<List<Pair<LocalDate, Double>>> getStatistic() {
        return statistic;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

        String uid = firebaseAuth.getUid();

        if (uid == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            // uid 가 감지되면 회원정보, 프로필이미지를 불러온다
            userRepository.getUser(uid,
                    userValue -> {
                        if (userValue != null) {
                            user.setValue(userValue);
                        } else {
                            event.setValue(new Event.NavigateBack());
                        }
                    },
                    e -> {
                        e.printStackTrace();
                        event.setValue(new Event.NavigateBack());
                    });
            imageRepository.getProfileImage(uid,
                    bitmap -> {
                        if (bitmap != null) {
                            image.setValue(bitmap);
                        } else {
                            event.setValue(new Event.NavigateBack());
                        }
                    },
                    e -> {
                        e.printStackTrace();
                        event.setValue(new Event.NavigateBack());
                    });
        }
    }

    public void onBackClick() {
        event.setValue(new Event.ConfirmLogout());
    }

    public void onSignOutConfirmed() {
        auth.signOut();
    }

    public void onDateClick(int year, int month, int dayOfMonth) {

        // 날짜를 변경한다

        LocalDate date = LocalDate.of(year, month, dayOfMonth);

        if (!date.isAfter(LocalDate.now())) {
            event.setValue(new Event.PromptEmotion(date));
        } else {
            event.setValue(new Event.ShowGeneralMessage("오늘 이전의 날짜를 선택해주세요"));
        }
    }

    public void onEmotionClick(LocalDate date, EmotionType emotionType) {

        User userValue = user.getValue();
        if (userValue == null) {
            return;
        }

        // 감정상태 이모티콘이 클릭되면 DB 에 저장한다

        Emotion emotion = new Emotion(userValue.getUid(), emotionType,
                date.getYear(), date.getMonthValue(), date.getDayOfMonth());

        emotionRepository.addEmotion(emotion,
                unused -> {
                },
                e -> {
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("업로드에 실패했습니다"));
                });
    }

    public void onMonthChange(int year, int month) {
        yearMonth.setValue(YearMonth.of(year, month));
    }

    public void onPrivateDiaryClick() {
        event.setValue(new Event.NavigateToPrivateDiary());
    }

    public void onSharingDiaryClick() {
        event.setValue(new Event.NavigateToSharingDiary());
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBack extends Event {
        }

        public static class ConfirmLogout extends Event {
        }

        public static class PromptEmotion extends Event {
            public final LocalDate date;

            public PromptEmotion(LocalDate date) {
                this.date = date;
            }
        }

        public static class NavigateToPrivateDiary extends Event {
        }

        public static class NavigateToSharingDiary extends Event {
        }
    }

}