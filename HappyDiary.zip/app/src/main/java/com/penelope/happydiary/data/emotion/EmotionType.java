package com.penelope.happydiary.data.emotion;

// 감정타입 : 5가지
public enum EmotionType {
    VERY_SAD, SAD, ORDINARY, HAPPY, VERY_HAPPY,
}
