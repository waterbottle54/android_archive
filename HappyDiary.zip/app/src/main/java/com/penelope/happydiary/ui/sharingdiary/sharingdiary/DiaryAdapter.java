package com.penelope.happydiary.ui.sharingdiary.sharingdiary;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.penelope.happydiary.data.diary.Diary;
import com.penelope.happydiary.data.emotion.EmotionType;
import com.penelope.happydiary.databinding.DiaryItemBinding;
import com.penelope.happydiary.utils.ImageUtils;

public class DiaryAdapter extends ListAdapter<Diary, DiaryAdapter.DiaryViewHolder> {

    class DiaryViewHolder extends RecyclerView.ViewHolder {

        private final DiaryItemBinding binding;

        public DiaryViewHolder(DiaryItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Diary model) {

            // 일기 제목을 띄운다
            binding.textViewDiaryTitle.setText(model.getTitle());

            // 이모티콘을 띄운다
            EmotionType emotionType = model.getEmotionType();
            binding.imageViewDiaryEmotion.setImageResource(ImageUtils.getEmotionImage(emotionType));

            // 프로필 이미지를 띄운다
            String imageUrl = ImageUtils.getUserImageUrl(model.getUid());
            glide.load(imageUrl).into(binding.imageViewProfile);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final RequestManager glide;


    public DiaryAdapter(RequestManager glide) {
        super(new DiffUtilCallback());
        this.glide = glide;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public DiaryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        DiaryItemBinding binding = DiaryItemBinding.inflate(layoutInflater, parent, false);
        return new DiaryViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DiaryViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Diary> {

        @Override
        public boolean areItemsTheSame(@NonNull Diary oldItem, @NonNull Diary newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Diary oldItem, @NonNull Diary newItem) {
            return oldItem.equals(newItem);
        }
    }

}