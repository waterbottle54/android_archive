package com.penelope.happydiary.ui.sharingdiary.friend;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.data.user.User;
import com.penelope.happydiary.data.user.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class FriendViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> uid = new MutableLiveData<>();

    private final LiveData<List<User>> watchers;

    private String nickname = "";

    private final UserRepository userRepository;


    @Inject
    public FriendViewModel(UserRepository userRepository) {

        // 회원정보 맵과 현재 유저를 획득한다
        LiveData<Map<String, User>> userMap = userRepository.getUserMap();
        LiveData<User> user = Transformations.switchMap(uid, userRepository::getUserLive);

        // 현재 유저의 공유회원 목록을 불러온다
        watchers = Transformations.switchMap(user, userValue ->
                Transformations.map(userMap, map -> {
                    List<User> watchersList = new ArrayList<>();
                    for (String friendUid : userValue.getWatchers()) {
                        User watcher = map.get(friendUid);
                        if (watcher != null) {
                            watchersList.add(watcher);
                        }
                    }
                    return watchersList;
                }));

        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<User>> getWatchers() {
        return watchers;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getUid() != null) {
            uid.setValue(firebaseAuth.getUid());
        }
    }

    public void onNicknameChange(String text) {
        nickname = text.trim();
    }

    public void onAddFriendClick() {

        if (uid.getValue() == null) {
            return;
        }

        // 닉네임으로부터 회원정보를 찾고 공유회원으로 추가한다

        if (nickname.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("닉네임을 입력하세요"));
            return;
        }

        userRepository.findUserByNickname(nickname,
                user -> {
                    if (user == null) {
                        event.setValue(new Event.ShowGeneralMessage("존재하지 않는 유저입니다"));
                        return;
                    }
                    if (user.getUid().equals(uid.getValue())) {
                        event.setValue(new Event.ShowGeneralMessage("자기 자신을 공유자로 추가할 수 없습니다"));
                        return;
                    }
                    userRepository.addWatcher(uid.getValue(), user.getUid(),
                            unused -> event.setValue(new Event.ShowGeneralMessage("공유한 유저로 추가되었습니다")),
                            e -> {
                                e.printStackTrace();
                                event.setValue(new Event.ShowGeneralMessage("공유 유저 추가에 실패했습니다"));
                            });
                },
                e -> {
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("검색에 실패했습니다"));
                });
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }
    }

}