package com.penelope.happydiary.ui.auth.login;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.databinding.FragmentLoginBinding;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;
import com.penelope.happydiary.utils.ui.UiUtils;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class LoginFragment extends AuthListenerFragment {

    private FragmentLoginBinding binding;
    private LoginViewModel viewModel;


    public LoginFragment() {
        super(R.layout.fragment_login);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentLoginBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(LoginViewModel.class);

        // UI 에 리스너를 지정한다
        UiUtils.addTextChangedListener(binding.editTextId, s -> viewModel.onIdChange(s));
        UiUtils.addTextChangedListener(binding.editTextPassword, s -> viewModel.onPasswordChange(s));
        binding.buttonLogin.setOnClickListener(v -> viewModel.onLoginClick());
        binding.textViewRegister.setOnClickListener(v -> viewModel.onRegisterClick());

        // 뷰모델에서 보낸 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof LoginViewModel.Event.NavigateToHomeScreen) {
                NavDirections navDirections = LoginFragmentDirections.actionLoginFragmentToHomeFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof LoginViewModel.Event.NavigateToRegisterScreen) {
                NavDirections navDirections = LoginFragmentDirections.actionLoginFragmentToRegisterFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof LoginViewModel.Event.ShowGeneralMessage) {
                String message = ((LoginViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}