package com.penelope.happydiary.data.image;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.penelope.happydiary.utils.BaseRepository;

import java.io.ByteArrayOutputStream;

import javax.inject.Inject;

public class ImageRepository extends BaseRepository<Bitmap> {

    private static final int MEGABYTES = 1024 * 1024;

    private final StorageReference profileImages;
    private final StorageReference privateDiaryImages;
    private final StorageReference sharingDiaryImages;


    @Inject
    public ImageRepository(FirebaseStorage storage) {
        profileImages = storage.getReference("profiles");
        privateDiaryImages = storage.getReference("privateDiaries");
        sharingDiaryImages = storage.getReference("sharingDiaries");
    }

    // 특정 유저의 프로필 사진을 DB 에 업로드하는 메소드

    public void addProfileImage(String uid, Bitmap bitmap,
                             OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // 스토리지에 프로필 이미지를 업로드한다

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        profileImages.child(uid + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }

    // 특정 유저의 프로필 사진을 DB 로부터 불러오는 메소드

    public void getProfileImage(String uid,
                               OnSuccessListener<Bitmap> onSuccessListener,
                               OnFailureListener onFailureListener) {

        // 스토리지에서 프로필 이미지를 불러온다

        profileImages.child(uid + ".jpg")
                .getBytes(10 * MEGABYTES)
                .addOnSuccessListener(bytes -> {
                    Bitmap image = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    onSuccessListener.onSuccess(image);
                })
                .addOnFailureListener(onFailureListener);
    }

    // 개인 일기의 이미지를 DB 에 업로드하는 메소드

    public void addPrivateDiaryImage(String id, Bitmap bitmap,
                                     OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // 스토리지에 다이어리 이미지를 업로드한다

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        privateDiaryImages.child(id + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }

    // 공유 일기의 이미지를 DB 에 업로드하는 메소드

    public void addSharingDiaryImage(String id, Bitmap bitmap,
                                     OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // 스토리지에 다이어리 이미지를 업로드한다

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        sharingDiaryImages.child(id + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }

}
