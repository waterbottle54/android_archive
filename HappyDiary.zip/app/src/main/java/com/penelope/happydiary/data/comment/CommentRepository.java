package com.penelope.happydiary.data.comment;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.penelope.happydiary.data.diary.DiaryRepository;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class CommentRepository {

    private final CollectionReference diaryCollection;


    @Inject
    public CommentRepository(FirebaseFirestore firestore) {
        this.diaryCollection = firestore.collection("sharingDiaries");
    }

    // 인수로 전달된 댓글을 DB 에 저장하는 메소드

    public void addComment(Comment comment, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

         CollectionReference commentCollection = diaryCollection.document(comment.getDiaryId())
                 .collection("comments");

         commentCollection.document(comment.getId())
                 .set(comment)
                 .addOnSuccessListener(onSuccessListener)
                 .addOnFailureListener(onFailureListener);
    }

    // 인수로 전달된 일기에 달린 댓글을 실시간으로 불러오는 메소드

    public LiveData<List<Comment>> getCommentsLive(String diaryId) {

        CollectionReference commentCollection = diaryCollection.document(diaryId)
                .collection("comments");

        MutableLiveData<List<Comment>> comments = new MutableLiveData<>();

        commentCollection.orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        comments.setValue(null);
                        error.printStackTrace();
                        return;
                    }
                    List<Comment> list = new ArrayList<>();
                    if (value == null || value.isEmpty()) {
                        comments.setValue(list);
                        return;
                    }
                    comments.setValue(value.toObjects(Comment.class));
                });

        return comments;
    }

}









