package com.penelope.happydiary.ui.sharingdiary.detail;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.penelope.happydiary.R;
import com.penelope.happydiary.data.diary.WeatherType;
import com.penelope.happydiary.data.emotion.EmotionType;
import com.penelope.happydiary.databinding.DialogAddCommentBinding;
import com.penelope.happydiary.databinding.FragmentDetailBinding;
import com.penelope.happydiary.utils.ImageUtils;
import com.penelope.happydiary.utils.TimeUtils;
import com.penelope.happydiary.utils.ui.AuthListenerFragment;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class DetailFragment extends AuthListenerFragment {

    private FragmentDetailBinding binding;
    private DetailViewModel viewModel;


    public DetailFragment() {
        super(R.layout.fragment_detail);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentDetailBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(DetailViewModel.class);

        // 일기 제목, 내용, 프로필을 띄운다
        binding.textViewDiaryTitle.setText(viewModel.getDiary().getTitle());
        binding.textViewDiaryContent.setText(viewModel.getDiary().getContent());

        int year = viewModel.getDiary().getYear();
        int month = viewModel.getDiary().getMonth();
        int dayOfMonth = viewModel.getDiary().getDayOfMonth();
        binding.textViewDate.setText(TimeUtils.formatDateDay(year, month, dayOfMonth));

        String profileUrl = ImageUtils.getUserImageUrl(viewModel.getDiary().getUid());
        Glide.with(this).load(profileUrl).into(binding.imageViewProfile);

        // 이모티콘을 띄운다
        EmotionType emotionType = viewModel.getDiary().getEmotionType();
        binding.imageViewEmoji.setImageResource(ImageUtils.getEmotionImage(emotionType));

        // 일기 이미지, 날씨를 띄운다
        if (viewModel.getDiary().getWeatherType() != null) {
            String diaryUrl = ImageUtils.getSharingDiaryImageUrl(viewModel.getDiary().getId());
            Glide.with(this).load(diaryUrl).into(binding.imageViewDiary);

            WeatherType weatherType = viewModel.getDiary().getWeatherType();
            binding.imageViewDiaryWeather.setImageResource(ImageUtils.getWeatherImage(weatherType));
        }

        binding.cardViewImage.setVisibility(viewModel.getDiary().getWeatherType() != null ? View.VISIBLE : View.GONE);

        binding.fabAddComment.setOnClickListener(v -> viewModel.onAddCommentClick());

        // 댓글 내용을 리사이클러 뷰에 업데이트한다

        viewModel.getUserMap().observe(getViewLifecycleOwner(), userMap -> {

            CommentsAdapter adapter = new CommentsAdapter(userMap, Glide.with(this));
            binding.recyclerComment.setAdapter(adapter);
            binding.recyclerComment.setHasFixedSize(true);

            viewModel.getComments().observe(getViewLifecycleOwner(), comments -> {
                if (comments != null) {
                    adapter.submitList(comments);
                    binding.textViewNoComments.setVisibility(comments.isEmpty() ? View.VISIBLE : View.INVISIBLE);

                    String strNumber = String.format(Locale.getDefault(), "댓글 %d개", comments.size());
                    binding.textViewCommentNumber.setText(strNumber);
                }
                binding.progressBar6.setVisibility(View.INVISIBLE);
            });
        });

        // 뷰모델 이벤트를 처리한다
        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof DetailViewModel.Event.PromptComment) {
                showAddCommentDialog();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void showAddCommentDialog() {

        DialogAddCommentBinding binding = DialogAddCommentBinding.inflate(getLayoutInflater());

        new AlertDialog.Builder(requireContext())
                .setTitle("댓글 작성")
                .setView(binding.getRoot())
                .setPositiveButton("확인", (dialog, which) ->
                        viewModel.onSubmitComment(binding.editTextComment.getText().toString()))
                .setNegativeButton("취소", null)
                .show();
    }

}










