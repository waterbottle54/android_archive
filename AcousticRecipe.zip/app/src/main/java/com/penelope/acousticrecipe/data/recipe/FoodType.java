package com.penelope.acousticrecipe.data.recipe;

public enum FoodType {
    MAIN, SIDE, SOUP, DESSERT, ETC,
}
