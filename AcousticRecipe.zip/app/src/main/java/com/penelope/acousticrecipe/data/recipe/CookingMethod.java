package com.penelope.acousticrecipe.data.recipe;

public enum CookingMethod {
    BOIL, STEAM, ROAST, FRY, ETC,
}
