package com.penelope.acousticrecipe.utils;

import com.penelope.acousticrecipe.data.recipe.CookingMethod;
import com.penelope.acousticrecipe.data.recipe.FoodType;

public class NameUtils {

    public static FoodType getFoodType(String name) {
        switch (name) {
            case "밥":
                return FoodType.MAIN;
            case "반찬":
                return FoodType.SIDE;
            case "국&찌개":
                return FoodType.SOUP;
            case "후식":
                return FoodType.DESSERT;
            default:
                return FoodType.ETC;
        }
    }

    public static String getFoodTypeName(FoodType foodType) {
        switch (foodType) {
            case MAIN:
                return "밥";
            case SIDE:
                return "반찬";
            case SOUP:
                return "국&찌개";
            case DESSERT:
                return "후식";
            default:
                return "기타";
        }
    }

    public static CookingMethod getCookingMethod(String name) {
        switch (name) {
            case "끓이기":
                return CookingMethod.BOIL;
            case "찌기":
                return CookingMethod.STEAM;
            case "굽기":
                return CookingMethod.ROAST;
            case "튀기기":
                return CookingMethod.FRY;
            default:
                return CookingMethod.ETC;
        }
    }
}
