package com.penelope.acousticrecipe;

import android.app.Application;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class AcousticRecipeApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
