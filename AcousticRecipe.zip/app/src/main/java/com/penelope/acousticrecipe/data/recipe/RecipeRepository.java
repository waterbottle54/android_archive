package com.penelope.acousticrecipe.data.recipe;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class RecipeRepository {

    private final CollectionReference recipeCollection;

    @Inject
    public RecipeRepository(FirebaseFirestore firestore) {
        recipeCollection = firestore.collection("recipes");
    }

    public void addRecipe(Recipe recipe, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        recipeCollection.document(recipe.getId())
                .set(recipe)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    public void getAllRecipes(OnSuccessListener<List<Recipe>> onSuccessListener, OnFailureListener onFailureListener) {

        recipeCollection.get()
                .addOnSuccessListener(queryDocumentSnapshots -> {

                    List<Recipe> recipes = new ArrayList<>();

                    if (queryDocumentSnapshots == null || queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(recipes);
                        return;
                    }

                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        Recipe recipe = snapshot.toObject(Recipe.class);
                        if (recipe != null) {
                            recipes.add(recipe);
                        }
                    }
                    onSuccessListener.onSuccess(recipes);
                })
                .addOnFailureListener(onFailureListener);
    }


}
