package com.penelope.acousticrecipe.api.recipe;

import com.penelope.acousticrecipe.data.recipe.Recipe;

import junit.framework.TestCase;

import java.util.List;

public class RecipeApiTest extends TestCase {

    public void testGet() {

        List<Recipe> recipes = RecipeApi.get();
        System.out.println(recipes == null ? "null" : recipes.toString());
    }
}