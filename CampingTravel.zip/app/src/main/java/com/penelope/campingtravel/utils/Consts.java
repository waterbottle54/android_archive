package com.penelope.campingtravel.utils;

public class Consts {

    public static final String URL_CAMPING_EMPTY_IMAGE = "https://www.gocamping.or.kr/img/2018/layout/noimg.jpg";

}
