package com.penelope.campingtravel.ui.home.recentopens;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.data.camp.CampRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class RecentOpensViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<Camp>> recentlyOpeningCamps;


    @Inject
    public RecentOpensViewModel(CampRepository campRepository) {

        recentlyOpeningCamps = campRepository.getRecentlyOpeningCamps();
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Camp>> getRecentlyOpeningCamps() {
        return recentlyOpeningCamps;
    }


    public static class Event {

    }

}