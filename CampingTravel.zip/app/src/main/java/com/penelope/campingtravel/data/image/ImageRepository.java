package com.penelope.campingtravel.data.image;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class ImageRepository {

    private static final int MEGABYTES = 1024 * 1024;

    private final StorageReference reviewImages;    // 리뷰 이미지 스토리지


    @Inject
    public ImageRepository(FirebaseStorage storage) {

        // 파이어베이스 스토리지에서 리뷰 이미지 스토리지를 획득한다
        reviewImages = storage.getReference("reviews");
    }

    public void addReviewImage(String reviewId, Bitmap bitmap,
                               OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // 스토리지에 리뷰 이미지를 업로드한다

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();

        reviewImages.child(reviewId + ".jpg")
                .putBytes(data)
                .addOnSuccessListener(taskSnapshot -> onSuccessListener.onSuccess(null))
                .addOnFailureListener(onFailureListener);
    }

    public void getReviewImage(String reviewId,
                               OnSuccessListener<Bitmap> onSuccessListener,
                               OnFailureListener onFailureListener) {

        // 스토리지에서 리뷰 이미지를 불러온다

        reviewImages.child(reviewId + ".jpg")
                .getBytes(10 * MEGABYTES)
                .addOnSuccessListener(bytes -> {
                    Bitmap image = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    onSuccessListener.onSuccess(image);
                })
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<Bitmap> getReviewImage(String reviewId) {
        // 위 메소드의 LiveData 버전
        MutableLiveData<Bitmap> bitmap = new MutableLiveData<>();
        getReviewImage(reviewId, bitmap::setValue, e -> bitmap.setValue(null));
        return bitmap;
    }

    public LiveData<Map<String, Bitmap>> getReviewAlbum(List<String> reviewIds) {

        MutableLiveData<Map<String, Bitmap>> album = new MutableLiveData<>(new HashMap<>());

        for (String reviewId : reviewIds) {
            getReviewImage(reviewId,
                    bitmap -> {
                        if (bitmap != null) {
                            Map<String, Bitmap> oldMap = album.getValue();
                            assert oldMap != null;
                            Map<String, Bitmap> map = new HashMap<>(oldMap);
                            map.put(reviewId, bitmap);
                            album.setValue(map);
                        }
                    },
                    e -> {}
            );
        }

        return album;
    }

}
