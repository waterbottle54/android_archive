package com.penelope.campingtravel.api.recommended;

import androidx.annotation.WorkerThread;

import com.penelope.campingtravel.data.recommended.Recommended;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// 추천 캠핑을 불러오는 API (고캠핑 사이트)

public class RecommendedApi {

    // 추천 캠핑 페이지 URL
    public static final String URL = "https://www.gocamping.or.kr/camp/recomend/list.do";

    // 메인 URL
    public static final String URL_MAIN = "https://www.gocamping.or.kr";


    @WorkerThread
    public static List<Recommended> get() {

        try {
            List<Recommended> recommendedList = new ArrayList<>();

            // URL 에 접속하여 추천 캠핑 페이지의 HTML 을 획득한다
            Document document = Jsoup.connect(URL).get();

            // 추천 캠핑 요소를 모두 획득한다
            Elements campingElems = document.select("div.board_list li > a");

            for (int i = 0; i < campingElems.size(); i++) {
                Element campingElem = campingElems.get(i);

                // 하위 요소를 획득한다
                Element imageElem = campingElem.selectFirst("div.thum_img > img");
                Element titleElem = campingElem.selectFirst("div.cont > p.tt");
                Element contentElem = campingElem.selectFirst("div.cont > p.txt");

                if (imageElem == null || titleElem == null || contentElem == null) {
                    continue;
                }

                // 추천 캠핑의 구성 요소를 추출한다
                String imageUrl = URL_MAIN + imageElem.attr("src");
                String title = titleElem.text().trim();
                String content = contentElem.text().trim();
                String url = campingElem.attr("href");

                // 추천 캠핑 객체를 구성해 리스트에 추가한다
                Recommended recommended =  new Recommended(title, content, imageUrl, url);
                recommendedList.add(recommended);
            }

            return recommendedList;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

}
