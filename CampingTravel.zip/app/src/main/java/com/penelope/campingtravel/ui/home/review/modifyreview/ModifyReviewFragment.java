package com.penelope.campingtravel.ui.home.review.modifyreview;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentModifyReviewBinding;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;
import com.penelope.campingtravel.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ModifyReviewFragment extends AuthListenerFragment {

    private FragmentModifyReviewBinding binding;
    private ModifyReviewViewModel viewModel;


    public ModifyReviewFragment() {
        super(R.layout.fragment_modify_review);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentModifyReviewBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ModifyReviewViewModel.class);

        // 리뷰 내용을 에딧 텍스트에 표기한다
        binding.editTextTitle.setText(viewModel.getOldReview().getTitle());
        binding.editTextContent.setText(viewModel.getOldReview().getContent());

        // 에딧 텍스트 내용이 변경되면 뷰모델에 통보한다
        binding.editTextTitle.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onTitleChange(text);
            }
        });
        binding.editTextContent.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onContentChange(text);
            }
        });

        // 버튼이 클릭되면 뷰모델에 통보한다
        binding.buttonOk.setOnClickListener(v -> viewModel.onOkClick());

        // 업로드가 진행중이면 로딩바를 보인다
        viewModel.isUploadInProgress().observe(getViewLifecycleOwner(), isUploadInProgress ->
                binding.progressBar3.setVisibility(isUploadInProgress ? View.VISIBLE : View.INVISIBLE));

        // 리뷰 이미지를 보인다
        viewModel.getImage().observe(getViewLifecycleOwner(), image -> binding.imageViewUploaded.setImageBitmap(image));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ModifyReviewViewModel.Event.NavigateBack) {
                // 이전 화면으로 되돌아간다
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof ModifyReviewViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 출력한다
                String message = ((ModifyReviewViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof ModifyReviewViewModel.Event.NavigateBackWithResult) {
                // 결과값을 설정하고 이전 화면으로 이동한다
                boolean success = ((ModifyReviewViewModel.Event.NavigateBackWithResult) event).success;
                Bundle result = new Bundle();
                result.putBoolean("success", success);
                getParentFragmentManager().setFragmentResult("modify_review_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}