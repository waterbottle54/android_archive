package com.penelope.campingtravel.api.weather;

import androidx.annotation.WorkerThread;

import com.penelope.campingtravel.data.weather.DailyWeather;
import com.penelope.campingtravel.data.weather.HourlyWeather;
import com.penelope.campingtravel.data.weather.WeatherType;
import com.penelope.campingtravel.utils.WeatherUtils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class WeatherApi {

    public static final String URL_FORMAT = "https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=0&ie=utf8&query={ARG_REGION}+날씨";
    public static final String ARG_REGION = "{ARG_REGION}";


    @WorkerThread
    public static List<HourlyWeather> getHourly(String region) {

        try {
            List<HourlyWeather> weathers = new ArrayList<>();

            // 네이버 날씨 검색 url 을 구성한다
            String strUrl = URL_FORMAT.replace(ARG_REGION, region);

            // 날씨 페이지의 HTML 을 획득한다
            Document document = Jsoup.connect(strUrl).get();

            // 시간별 날씨 요소를 획득한다
            Elements weatherElems = document
                    .select("div._hourly_weather dl.graph_content");

            for (Element weatherElem : weatherElems.subList(0, 8)) {

                // 하위 요소를 획득한다
                Element timeElem = weatherElem.selectFirst("dt.time");
                Element temperatureElem = weatherElem.selectFirst("dd.degree_point span.num");
                Element iconElem = weatherElem.selectFirst("dd.weather_box");

                if (timeElem == null || temperatureElem == null || iconElem == null) {
                    continue;
                }

                // 날씨 구성요소를 추출한다
                String strTime = timeElem.text().replace("시", "").trim();
                if (strTime.equals("내일") || strTime.equals("모레")) {
                    strTime = "0";
                }
                String strTemperature = temperatureElem.ownText();
                String strWeatherType = iconElem.text();
                int hour;
                int temperature;

                try {
                    hour = Integer.parseInt(strTime);
                    temperature = Integer.parseInt(strTemperature);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    continue;
                }

                WeatherType weatherType = WeatherUtils.fromDescription(strWeatherType);

                // 날씨 객체를 구성해 리스트에 추가한다
                HourlyWeather weather = new HourlyWeather(hour, temperature, weatherType);
                weathers.add(weather);
            }

            return weathers;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static List<DailyWeather> getDaily(String region) {

        try {
            List<DailyWeather> weathers = new ArrayList<>();

            // 날씨 검색 url 을 구성한다
            String strUrl = URL_FORMAT.replace(ARG_REGION, region);

            // 날씨 페이지의 HTML 을 획득한다
            Document document = Jsoup.connect(strUrl).get();

            // 일별 날씨 요소를 획득한다
            Elements weatherElems = document
                    .select("ul.week_list div.day_data");

            for (Element weatherElem : weatherElems.subList(0, 8)) {

                // 하위 요소를 획득한다
                Element timeElem = weatherElem.selectFirst("strong.day");
                Element minTemperatureElem = weatherElem.selectFirst("span.lowest");
                Element maxTemperatureElem = weatherElem.selectFirst("span.highest");
                Element iconElem = weatherElem.selectFirst("div.cell_weather i");

                if (timeElem == null || maxTemperatureElem == null || minTemperatureElem == null || iconElem == null) {
                    continue;
                }

                // 날씨 구성요소를 추출한다
                String strTime = timeElem.text().trim();
                String strMinTemperature = minTemperatureElem.ownText().replace("°", "").trim();
                String strMaxTemperature = maxTemperatureElem.ownText().replace("°", "").trim();
                String strWeatherType = iconElem.text();
                int minTemperature;
                int maxTemperature;

                try {
                    minTemperature = Integer.parseInt(strMinTemperature);
                    maxTemperature = Integer.parseInt(strMaxTemperature);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                    continue;
                }

                WeatherType weatherType = WeatherUtils.fromDescription(strWeatherType);

                // 날씨 객체를 구성해 리스트에 추가한다
                DailyWeather weather = new DailyWeather(strTime, maxTemperature, minTemperature, weatherType);
                weathers.add(weather);
            }

            return weathers;

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


}
