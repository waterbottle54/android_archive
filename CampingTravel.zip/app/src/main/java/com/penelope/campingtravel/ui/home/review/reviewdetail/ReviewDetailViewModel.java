package com.penelope.campingtravel.ui.home.review.reviewdetail;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.campingtravel.data.image.ImageRepository;
import com.penelope.campingtravel.data.review.Review;
import com.penelope.campingtravel.data.review.ReviewRepository;
import com.penelope.campingtravel.data.user.User;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ReviewDetailViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> uid = new MutableLiveData<>();
    private final LiveData<Boolean> isMine;

    private final LiveData<Review> review;      // 보여줄 리뷰
    private final LiveData<Bitmap> image;       // 리뷰 이미지


    @Inject
    public ReviewDetailViewModel(SavedStateHandle savedStateHandle,
                                 ReviewRepository reviewRepository,
                                 ImageRepository imageRepository) {

        // 전달된 리뷰 아이디를 획득하고 해당 리뷰를 불러온다
        String reviewId = savedStateHandle.get("reviewId");
        review = reviewRepository.getReview(reviewId);

        // 리뷰 이미지를 불러온다
        image = imageRepository.getReviewImage(reviewId);

        // 리뷰가 현재 사용자가 작성했는지 체크한다
        isMine = Transformations.switchMap(uid, uidValue ->
                Transformations.map(review, reviewValue -> reviewValue.getUid().equals(uidValue))
        );
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Review> getReview() {
        return review;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }

    public LiveData<Boolean> isMine() {
        return isMine;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            uid.setValue(firebaseAuth.getCurrentUser().getUid());
        }
    }

    public void onModifyClick() {

        Boolean isMineValue = isMine.getValue();
        Review reviewValue = review.getValue();
        if (isMineValue == null || !isMineValue || reviewValue == null) {
            return;
        }

        // 리뷰 수정 화면으로 이동하도록 한다
        event.setValue(new Event.NavigateToModifyReviewScreen(reviewValue));
    }

    public void onModifyResult(boolean success) {
        if (success) {
            event.setValue(new Event.ShowGeneralMessage("리뷰가 수정되었습니다"));
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToModifyReviewScreen extends Event {
            public final Review review;
            public NavigateToModifyReviewScreen(Review review) {
                this.review = review;
            }
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }
    }

}