package com.penelope.campingtravel.ui.home.reserve.setperiod;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentSetPeriodBinding;
import com.penelope.campingtravel.utils.TimeUtils;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;
import com.penelope.campingtravel.utils.ui.OnTextChangeListener;

import java.time.LocalDate;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SetPeriodFragment extends AuthListenerFragment {

    private FragmentSetPeriodBinding binding;
    private SetPeriodViewModel viewModel;


    public SetPeriodFragment() {
        super(R.layout.fragment_set_period);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSetPeriodBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SetPeriodViewModel.class);

        // 예약 일자 클릭 시 뷰모델에 통보한다
        binding.textViewReservationStart.setOnClickListener(v -> viewModel.onStartDateClick());
        binding.textViewReservationEnd.setOnClickListener(v -> viewModel.onEndDateClick());

        // 비회원 이름, 전화번호 입력 시 뷰모델에 통보한다
        binding.editTextCustomerName.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onNameChange(text);
            }
        });
        binding.editTextCustomerPhone.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPhoneChange(text);
            }
        });

        // 예약 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonReserve.setOnClickListener(v -> viewModel.onReserveClick());

        // 선택된 날짜를 텍스트뷰에 표시한다
        viewModel.getStartDate().observe(getViewLifecycleOwner(), startDate -> {
            String strDate = TimeUtils.getDateString(startDate);
            binding.textViewReservationStart.setText(strDate);
        });
        viewModel.getEndDate().observe(getViewLifecycleOwner(), endDate -> {
           String strDate = TimeUtils.getDateString(endDate);
           binding.textViewReservationEnd.setText(strDate);
        });

        // 비회원일때만 이름, 전화번호 입력란을 보인다
        viewModel.getUid().observe(getViewLifecycleOwner(), uid -> {
           binding.groupCustomerInfo.setVisibility(uid == null ? View.VISIBLE : View.INVISIBLE);
        });

        // 업로드 중이면 로딩 바를 보인다
        viewModel.isUploadInProgress().observe(getViewLifecycleOwner(), isUploadInProgress ->
                binding.progressBar.setVisibility(isUploadInProgress ? View.VISIBLE : View.INVISIBLE));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SetPeriodViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SetPeriodViewModel.Event.PromptDate) {
                // 날짜 선택 대화상자를 띄운다
                boolean startOrEnd = ((SetPeriodViewModel.Event.PromptDate) event).startOrEnd;
                LocalDate date = ((SetPeriodViewModel.Event.PromptDate) event).date;
                showDatePicker(startOrEnd, date);
            } else if (event instanceof SetPeriodViewModel.Event.NavigateBackWithResult) {
                // 예약 결과를 설정하고 이전 화면으로 이동한다
                boolean success = ((SetPeriodViewModel.Event.NavigateBackWithResult) event).success;
                Bundle result = new Bundle();
                result.putBoolean("success", success);
                getParentFragmentManager().setFragmentResult("set_period_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SetPeriodViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 출력한다
                String message = ((SetPeriodViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void showDatePicker(boolean startOrEnd, LocalDate date) {

        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                .setSelection(date.toEpochDay() * 86400000)
                .build();

        datePicker.addOnPositiveButtonClickListener(selection -> {
            LocalDate selectedDate = TimeUtils.getLocalDate(selection);
            viewModel.onDateSelected(startOrEnd, selectedDate);
        });

        datePicker.show(getParentFragmentManager(), null);
    }

}







