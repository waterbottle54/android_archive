package com.penelope.campingtravel.data.camp;

// 캠핑장 정보 클래스

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

public class Camp implements Serializable {

    private final String id;
    private final String name;
    private final String address;
    private final String phone;
    private final String doName;
    private final String imageUrl;
    private final double latitude;
    private final double longitude;

    private final int glampingCount;
    private final int caravCount;

    private final LocalDate openDate;


    public Camp(String id, String name, String address, String phone, String doName, String imageUrl, double latitude, double longitude, int glampingCount, int caravCount, LocalDate openDate) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.doName = doName;
        this.imageUrl = imageUrl;
        this.latitude = latitude;
        this.longitude = longitude;
        this.glampingCount = glampingCount;
        this.caravCount = caravCount;
        this.openDate = openDate;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getDoName() {
        return doName;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public int getGlampingCount() {
        return glampingCount;
    }

    public int getCaravCount() {
        return caravCount;
    }

    public LocalDate getOpenDate() {
        return openDate;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Camp camp = (Camp) o;
        return Double.compare(camp.latitude, latitude) == 0 && Double.compare(camp.longitude, longitude) == 0 && glampingCount == camp.glampingCount && caravCount == camp.caravCount && id.equals(camp.id) && name.equals(camp.name) && Objects.equals(address, camp.address) && Objects.equals(phone, camp.phone) && doName.equals(camp.doName) && Objects.equals(imageUrl, camp.imageUrl) && Objects.equals(openDate, camp.openDate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, address, phone, doName, imageUrl, latitude, longitude, glampingCount, caravCount, openDate);
    }

    @Override
    public String toString() {
        return "Camp{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                ", doName='" + doName + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", glampingCount=" + glampingCount +
                ", caravCount=" + caravCount +
                ", openDate=" + openDate +
                '}';
    }
}
