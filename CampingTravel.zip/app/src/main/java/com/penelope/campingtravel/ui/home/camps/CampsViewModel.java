package com.penelope.campingtravel.ui.home.camps;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.data.camp.CampRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class CampsViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final List<Camp> camps;


    @Inject
    public CampsViewModel(SavedStateHandle savedStateHandle, CampRepository campRepository) {

        // 전달된 검색어를 획득한다
        camps = savedStateHandle.get("camps");
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public List<Camp> getCamps() {
        return camps;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

    }

    public void onCampClick(Camp camp) {
        event.setValue(new Event.NavigateToReserveScreen(camp));
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToReserveScreen extends Event {
            public final Camp camp;
            public NavigateToReserveScreen(Camp camp) {
                this.camp = camp;
            }
        }
    }

}