package com.penelope.campingtravel.ui.home.camps;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.databinding.FragmentCampsBinding;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class CampsFragment extends AuthListenerFragment {

    private FragmentCampsBinding binding;
    private CampsViewModel viewModel;


    public CampsFragment() {
        super(R.layout.fragment_camps);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentCampsBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(CampsViewModel.class);

        // 캠핑장 어댑터를 생성하고 리사이클러 뷰와 연결한다
        CampsAdapter adapter = new CampsAdapter(Glide.with(this));
        binding.recyclerCamp.setAdapter(adapter);
        binding.recyclerCamp.setHasFixedSize(true);

        adapter.setOnItemSelectedListener(position -> {
            Camp camp = adapter.getCurrentList().get(position);
            viewModel.onCampClick(camp);
        });

        // 리사이클러 뷰에 캠핑장을 모두 띄운다
        if (viewModel.getCamps() != null) {
            adapter.submitList(viewModel.getCamps());
            binding.textViewNoCamps.setVisibility(viewModel.getCamps().isEmpty() ? View.VISIBLE : View.INVISIBLE);
        } else {
            Toast.makeText(requireContext(), "검색에 실패했습니다", Toast.LENGTH_SHORT).show();
        }

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof CampsViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof CampsViewModel.Event.NavigateToReserveScreen) {
                Camp camp = ((CampsViewModel.Event.NavigateToReserveScreen) event).camp;
                NavDirections navDirections = CampsFragmentDirections.actionCampsFragmentToReserveFragment(camp);
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}