package com.penelope.campingtravel.api.covid;

import android.util.Log;

import androidx.annotation.WorkerThread;

import com.penelope.campingtravel.data.covid.CovidStatistic;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.util.Locale;

public class CovidStatisticApi {

    public static final String URL_FORMAT = "http://openapi.data.go.kr/openapi/service/rest/Covid19/getCovid19SidoInfStateJson?serviceKey={SERVICE_KEY}&pageNo=1&numOfRows=100&startCreateDt={START_DATE}&endCreateDt={END_DATE}";
    public static final String ARG_START_DATE = "{START_DATE}";
    public static final String ARG_END_DATE = "{END_DATE}";
    public static final String ARG_SERVICE_KEY = "{SERVICE_KEY}";
    public static final String SERVICE_KEY = "MtVBdtw16Ez1YFEXjvMpB0Zws4eaThA35edKG44NT6A0P3gsproUZBkpaFUUVrHmaPUzkazSncH9iukFY%2BdQfw%3D%3D";

    @WorkerThread
    public static CovidStatistic get(LocalDate date) {

        String strUrl = URL_FORMAT
                .replace(ARG_SERVICE_KEY, SERVICE_KEY)
                .replace(ARG_START_DATE, toDateString(date))
                .replace(ARG_END_DATE, toDateString(date));

        Log.d("TAG", "get: " + strUrl);

        try {
            // 코로나 통계 API 에 Http 연결한다
            URL url = new URL(strUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            // Http 연결로 받은 xml 을 파싱하여 CovidStatistic 객체를 리턴한다
            return CovidStatisticXmlParser.parse(conn.getInputStream());

        } catch (XmlPullParserException | IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private static String toDateString(LocalDate date) {
        // LocalDate 객체를 YYYYMMDD (ex. 20220411) 형태의 문자열로 리턴한다
        int year = date.getYear();
        int month = date.getMonthValue();
        int dayOfMonth = date.getDayOfMonth();
        return String.format(Locale.getDefault(), "%d%02d%02d", year, month, dayOfMonth);
    }
}
