package com.penelope.campingtravel.ui.home.welcome;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.penelope.campingtravel.data.recommended.Recommended;
import com.penelope.campingtravel.databinding.RecommendedItemBinding;

public class RecommendedsAdapter extends ListAdapter<Recommended, RecommendedsAdapter.RecommendedViewHolder> {

    class RecommendedViewHolder extends RecyclerView.ViewHolder {

        private final RecommendedItemBinding binding;

        public RecommendedViewHolder(RecommendedItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Recommended model) {

            // 제목, 내용을 표시한다
            binding.textViewRecommendedTitle.setText(model.getTitle());
            binding.textViewRecommendedContent.setText(model.getContent());

            // 이미지를 표시한다
            if (model.getImageUrl() != null) {
                requestManager.load(model.getImageUrl())
                        .into(binding.imageViewRecommended);
            } else {
                requestManager.clear(binding.imageViewRecommended);
                binding.imageViewRecommended.setImageDrawable(null);
            }
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final RequestManager requestManager;


    public RecommendedsAdapter(RequestManager requestManager) {
        super(new DiffUtilCallback());
        this.requestManager = requestManager;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public RecommendedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        RecommendedItemBinding binding = RecommendedItemBinding.inflate(layoutInflater, parent, false);
        return new RecommendedViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull RecommendedViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Recommended> {

        @Override
        public boolean areItemsTheSame(@NonNull Recommended oldItem, @NonNull Recommended newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Recommended oldItem, @NonNull Recommended newItem) {
            return oldItem.equals(newItem);
        }
    }

}