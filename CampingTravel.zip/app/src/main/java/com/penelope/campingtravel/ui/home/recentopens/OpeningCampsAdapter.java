package com.penelope.campingtravel.ui.home.recentopens;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.databinding.OpenItemBinding;
import com.penelope.campingtravel.utils.TimeUtils;

public class OpeningCampsAdapter extends ListAdapter<Camp, OpeningCampsAdapter.CampViewHolder> {

    class CampViewHolder extends RecyclerView.ViewHolder {

        private final OpenItemBinding binding;

        public CampViewHolder(OpenItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Camp model) {

            binding.textViewOpenCampName.setText(model.getName());

            String strDate = TimeUtils.getDateString(model.getOpenDate());
            binding.textViewOpenDate.setText(strDate);

            String strTime = "09:00";
            binding.textViewOpenTime.setText(strTime);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public OpeningCampsAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public CampViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        OpenItemBinding binding = OpenItemBinding.inflate(layoutInflater, parent, false);
        return new CampViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CampViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Camp> {

        @Override
        public boolean areItemsTheSame(@NonNull Camp oldItem, @NonNull Camp newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Camp oldItem, @NonNull Camp newItem) {
            return oldItem.equals(newItem);
        }
    }

}