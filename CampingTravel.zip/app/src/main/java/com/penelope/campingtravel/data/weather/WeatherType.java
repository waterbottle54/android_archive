package com.penelope.campingtravel.data.weather;

// 날씨 타입 열거형 (맑음, 흐림, ...)

public enum WeatherType {
    SUNNY, SUNNY_CLOUDY, CLOUDY, RAINY, SOMETIMES_RAINY
}
