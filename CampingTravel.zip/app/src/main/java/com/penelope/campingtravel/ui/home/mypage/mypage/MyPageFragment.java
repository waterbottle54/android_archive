package com.penelope.campingtravel.ui.home.mypage.mypage;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.data.user.User;
import com.penelope.campingtravel.databinding.FragmentMyPageBinding;
import com.penelope.campingtravel.ui.home.welcome.ReviewAlbumsAdapter;
import com.penelope.campingtravel.ui.home.welcome.WelcomeFragmentDirections;
import com.penelope.campingtravel.utils.TimeUtils;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MyPageFragment extends AuthListenerFragment {

    public interface MyPageFragmentListener {
        void onSignOutClick();
    }

    private FragmentMyPageBinding binding;
    private MyPageViewModel viewModel;


    public MyPageFragment() {
        super(R.layout.fragment_my_page);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentMyPageBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(MyPageViewModel.class);

        // 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonCheckReservation.setOnClickListener(v -> viewModel.onCheckReservationClick());
        binding.textViewSetPrivacy.setOnClickListener(v -> viewModel.onSetPrivacyClick());
        binding.textViewCertify.setOnClickListener(v -> viewModel.onCertifyClick());
        binding.textViewLogOut.setOnClickListener(v -> viewModel.onLogOutClick());
        binding.imageViewAddReview.setOnClickListener(v -> viewModel.onAddReviewClick());

        // 회원 이름을 표시한다
        viewModel.getUser().observe(getViewLifecycleOwner(), user -> {
            if (user != null) {
                binding.textViewName.setText(user.getName());
            }
        });

        // 내 리뷰 이미지 어댑터를 생성하고 리사이클러 뷰에 연결한다
        ReviewAlbumsAdapter myReviewAlbumsAdapter = new ReviewAlbumsAdapter();
        binding.recyclerReview.setAdapter(myReviewAlbumsAdapter);
        binding.recyclerReview.setHasFixedSize(true);

        // 리뷰가 클릭되면 뷰모델에 통보한다
        myReviewAlbumsAdapter.setOnItemSelectedListener(position -> {
            Map.Entry<String, Bitmap> entry = myReviewAlbumsAdapter.getCurrentList().get(position);
            viewModel.onReviewClick(entry.getKey());
        });

        // 내 리뷰 이미지를 리사이클러 뷰에 표시한다
        viewModel.getMyReviewAlbum().observe(getViewLifecycleOwner(), album -> {
            if (album != null) {
                myReviewAlbumsAdapter.submitList(new ArrayList<>(album.entrySet()));
                binding.textViewNoReviews.setVisibility(album.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            }
            binding.progressBarReview.setVisibility(View.INVISIBLE);
        });

        // 최근 예약정보 1건을 표시한다
        viewModel.getRecentReservation().observe(getViewLifecycleOwner(), reservation -> {
            if (reservation != null) {
                // 예약기간을 표시한다
                String strTerm = String.format(Locale.getDefault(), "%s ~ %s",
                        TimeUtils.getDateString(reservation.getStartDate()),
                        TimeUtils.getDateString(reservation.getEndDate()).substring(5)
                );
                binding.textViewReservationTerm.setText(strTerm);

                // 캠핑장 이름을 표시한다
                binding.textViewReservationCampName.setText(reservation.getCampName());
            }
            binding.textViewNoRerservations.setVisibility(reservation == null ? View.VISIBLE : View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof MyPageViewModel.Event.NavigateBack) {
                // 이전 화면으로 돌아간다
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof MyPageViewModel.Event.NavigateToSetPrivacyScreen) {
                // 개인정보 수정 화면으로 이동한다
                User user = ((MyPageViewModel.Event.NavigateToSetPrivacyScreen) event).user;
                NavDirections navDirections = MyPageFragmentDirections.actionMyPageFragmentToSetPrivacyFragment(user);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof MyPageViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 보인다
                String message = ((MyPageViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof MyPageViewModel.Event.ConfirmSignOut) {
                // 로그아웃 시도를 액티비티에 통보한다
                try {
                    MyPageFragmentListener host = (MyPageFragmentListener) requireActivity();
                    host.onSignOutClick();
                } catch (ClassCastException e) {
                    e.printStackTrace();
                }
            } else if (event instanceof MyPageViewModel.Event.NavigateToAddReviewScreen) {
                // 리뷰 작성 화면으로 이동한다
                NavDirections navDirections = MyPageFragmentDirections.actionMyPageFragmentToAddReviewFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof MyPageViewModel.Event.NavigateToReviewScreen) {
                // 리뷰 상세 화면으로 이동한다
                String reviewId = ((MyPageViewModel.Event.NavigateToReviewScreen) event).reviewId;
                NavDirections navDirections = WelcomeFragmentDirections.actionGlobalReviewDetailFragment(reviewId);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof MyPageViewModel.Event.NavigateToReservationsScreen) {
                // 예약 목록 화면으로 이동한다
                String uid = ((MyPageViewModel.Event.NavigateToReservationsScreen) event).uid;
                NavDirections navDirections = MyPageFragmentDirections.actionGlobalReservationsFragment(uid, null, null);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof MyPageViewModel.Event.NavigateToCertificationScreen) {
                // 코로나 인증 화면으로 이동한다
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://ncv.kdca.go.kr/coov"));
                startActivity(intent);
            }
        });

        // 개인정보 변경 화면에서 설정된 결과값을 뷰모델에 통보한다
        getParentFragmentManager().setFragmentResultListener("set_privacy_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("success");
                    viewModel.onSetPrivacyResult(success);
                });

        // 리뷰 작성 화면에서 설정된 결과값을 뷰모델에 통보한다
        getParentFragmentManager().setFragmentResultListener("add_review_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("success");
                    viewModel.onAddReviewResult(success);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}