package com.penelope.campingtravel.ui.home.mypage.setprivacy;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.campingtravel.data.user.User;
import com.penelope.campingtravel.data.user.UserRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SetPrivacyViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final User userData;       // 전달된 회원정보

    private String newName = "";       // 새로운 이름
    private String newPhone = "";      // 새로운 전화번호

    // 회원정보 업데이트 진행중 여부
    private final MutableLiveData<Boolean> isUpdateInProgress = new MutableLiveData<>(false);

    private final UserRepository userRepository;


    @Inject
    public SetPrivacyViewModel(SavedStateHandle savedStateHandle, UserRepository userRepository) {

        // 전달된 회원정보를 획득한다
        userData = savedStateHandle.get("user");

        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public User getUserData() {
        return userData;
    }

    public LiveData<Boolean> isUpdateInProgress() {
        return isUpdateInProgress;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }

    public void onNameChange(String text) {
        newName = text.trim();
    }

    public void onPhoneChange(String text) {
        newPhone = text.trim();
    }

    public void onOkClick() {

        // 이미 업데이트 진행 중이면 리턴한다
        Boolean isUpdateInProgressValue = isUpdateInProgress.getValue();
        assert isUpdateInProgressValue != null;
        if (isUpdateInProgressValue) {
            return;
        }

        if (newName.isEmpty() || newPhone.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        isUpdateInProgress.setValue(true);

        User newUserData = new User(userData.getUid(), userData.getId(), newName, newPhone);
        newUserData.setCreated(userData.getCreated());
        userRepository.updateUser(newUserData,
                unused -> event.setValue(new Event.NavigateBackWithResult(true)),
                e -> event.setValue(new Event.NavigateBackWithResult(false))
        );
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;
            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }
    }

}