package com.penelope.campingtravel.ui.home;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import android.app.AlertDialog;
import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.ActivityHomeBinding;
import com.penelope.campingtravel.ui.home.mypage.mypage.MyPageFragment;
import com.penelope.campingtravel.ui.home.welcome.WelcomeFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class HomeActivity extends AppCompatActivity implements
        WelcomeFragment.WelcomeFragmentListener, MyPageFragment.MyPageFragmentListener {

    private NavController navController;

    private final FirebaseAuth auth = FirebaseAuth.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 뷰 바인딩을 실행한다
        ActivityHomeBinding binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 액션바 타이틀을 숨긴다
        setSupportActionBar(binding.toolBar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        // 네비게이션 호스트 프래그먼트로부터 네비게이션 컨트롤러를 획득한다
        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {
            navController = navHostFragment.getNavController();
            // 바텀 네비게이션 뷰와 액션바를 네비게이션 컨트롤러와 연동한다
            NavigationUI.setupActionBarWithNavController(this, navController);
        }
    }

    @Override
    public void onBackPressed() {

        // 첫 화면 (채팅 화면) 에서 뒤로가기 버튼이 눌리면 로그아웃 의사를 묻는다
        if (auth.getCurrentUser() != null) {
            NavDestination destination = navController.getCurrentDestination();
            if (destination != null && destination.getId() == R.id.welcomeFragment) {
                showSignOutDialog();
                return;
            }
        }

        super.onBackPressed();
    }

    @Override
    public boolean onSupportNavigateUp() {
        // 네비게이션 컨트롤러에 뒤로가기 버튼 연동
        return navController.navigateUp() || super.onSupportNavigateUp();
    }

    @Override
    public void onSignOutClick() {
        // 로그아웃 의사를 묻는다
        showSignOutDialog();
    }

    private void showSignOutDialog() {
        // 로그아웃을 묻는 대화상자를 띄운다
        new AlertDialog.Builder(this)
                .setTitle("로그아웃")
                .setMessage("로그아웃 하시겠습니까?")
                .setPositiveButton("로그아웃", (dialog, which) -> {
                    auth.signOut();
                    finish();
                })
                .setNegativeButton("취소", null)
                .show();
    }

}

