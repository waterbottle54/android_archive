package com.penelope.campingtravel.data.reservation;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

// DB 의 예약 정보에 접근하는 저장소 클래스

public class ReservationRepository {

    private final CollectionReference reservationCollection;

    @Inject
    public ReservationRepository(FirebaseFirestore firestore) {
        reservationCollection = firestore.collection("reservations");
    }

    public void getReservations(String uid, OnSuccessListener<List<Reservation>> onSuccessListener, OnFailureListener onFailureListener) {

        // 회원 uid 로 예약 목록을 조회한다
        reservationCollection.whereEqualTo("uid", uid)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Reservation> reservations = new ArrayList<>();
                    if (queryDocumentSnapshots == null || queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(reservations);
                        return;
                    }
                    for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                        Reservation reservation = documentSnapshot.toObject(Reservation.class);
                        if (reservation != null) {
                            reservations.add(reservation);
                        }
                    }
                    onSuccessListener.onSuccess(reservations);
                })
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<List<Reservation>> getReservations(String uid) {

        MutableLiveData<List<Reservation>> reservations = new MutableLiveData<>();

        reservationCollection.orderBy("startDate", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (value == null || error != null) {
                        reservations.setValue(null);
                        return;
                    }
                    List<Reservation> list = new ArrayList<>();
                    for (DocumentSnapshot snapshot : value) {
                        Reservation reservation = snapshot.toObject(Reservation.class);
                        if (reservation != null && reservation.getUid() != null) {
                            if (reservation.getUid().equals(uid) && reservation.getEndDate() > System.currentTimeMillis()) {
                                list.add(reservation);
                            }
                        }
                    }
                    reservations.setValue(list);
                });

        return reservations;
    }

    public void getReservations(String name, String phone, OnSuccessListener<List<Reservation>> onSuccessListener, OnFailureListener onFailureListener) {

        // 비회원 이름, 연락처로 예약 목록을 조회한다
        reservationCollection
                .whereEqualTo(
                        "name", name)
                .whereEqualTo("phone", phone)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Reservation> reservations = new ArrayList<>();
                    if (queryDocumentSnapshots == null || queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(reservations);
                        return;
                    }
                    for (DocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                        Reservation reservation = documentSnapshot.toObject(Reservation.class);
                        if (reservation != null) {
                            reservations.add(reservation);
                        }
                    }
                    onSuccessListener.onSuccess(reservations);
                })
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<List<Reservation>> getReservations(String name, String phone) {

        MutableLiveData<List<Reservation>> reservations = new MutableLiveData<>();

        reservationCollection.orderBy("startDate", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (value == null || error != null) {
                        reservations.setValue(null);
                        return;
                    }
                    List<Reservation> list = new ArrayList<>();
                    for (DocumentSnapshot snapshot : value) {
                        Reservation reservation = snapshot.toObject(Reservation.class);
                        if (reservation != null && reservation.getUid() == null) {
                            if (reservation.getName().equals(name) && reservation.getPhone().equals(phone)
                                && reservation.getEndDate() > System.currentTimeMillis()) {
                                list.add(reservation);
                            }
                        }
                    }
                    reservations.setValue(list);
                });

        return reservations;
    }

    public void addReservation(Reservation reservation, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // DB 에 새로운 예약을 추가한다
        reservationCollection.document(reservation.getId())
                .set(reservation)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

}
