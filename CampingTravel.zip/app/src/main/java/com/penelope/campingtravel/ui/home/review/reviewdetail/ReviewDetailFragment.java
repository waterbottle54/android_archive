package com.penelope.campingtravel.ui.home.review.reviewdetail;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.data.review.Review;
import com.penelope.campingtravel.databinding.FragmentReviewDetailBinding;
import com.penelope.campingtravel.utils.TimeUtils;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ReviewDetailFragment extends AuthListenerFragment {

    private FragmentReviewDetailBinding binding;
    private ReviewDetailViewModel viewModel;


    public ReviewDetailFragment() {
        super(R.layout.fragment_review_detail);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentReviewDetailBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ReviewDetailViewModel.class);

        binding.textViewModifyReview.setOnClickListener(v -> viewModel.onModifyClick());

        // 리뷰 이미지를 보인다
        viewModel.getImage().observe(getViewLifecycleOwner(), image -> {
            binding.imageViewReview.setImageBitmap(image);
            binding.progressBar4.setVisibility(View.INVISIBLE);
            if (image == null) {
                Toast.makeText(requireContext(), "이미지를 불러오지 못했습니다", Toast.LENGTH_SHORT).show();
            }
        });

        // 리뷰 내용을 보인다
        viewModel.getReview().observe(getViewLifecycleOwner(), review -> {
            if (review != null) {
                binding.textViewReviewTitle.setText(review.getTitle());
                binding.textViewReviewContent.setText(review.getContent());

                String strDateTime = String.format(Locale.getDefault(), "%s %s",
                        TimeUtils.getDateString(review.getCreated()),
                        TimeUtils.getTimeString(review.getCreated())
                );
                binding.textViewReviewDateTime.setText(strDateTime);
            } else {
                Toast.makeText(requireContext(), "리뷰를 불러오지 못했습니다", Toast.LENGTH_SHORT).show();
            }
        });

        // 수정 버튼을 보인다
        viewModel.isMine().observe(getViewLifecycleOwner(), isMine ->
                binding.textViewModifyReview.setVisibility(isMine ? View.VISIBLE : View.GONE));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ReviewDetailViewModel.Event.NavigateBack) {
                // 이전 화면으로 되돌아간다
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof ReviewDetailViewModel.Event.NavigateToModifyReviewScreen) {
                // 리뷰 수정 화면으로 이동한다
                Review review = ((ReviewDetailViewModel.Event.NavigateToModifyReviewScreen) event).review;
                NavDirections navDirections = ReviewDetailFragmentDirections.actionReviewDetailFragmentToModifyReviewFragment(review);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof ReviewDetailViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 보인다
                String message = ((ReviewDetailViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });

        // 리뷰 수정 화면의 결과값을 뷰모델에 전달한다
        getParentFragmentManager().setFragmentResultListener("modify_review_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("success");
                    viewModel.onModifyResult(success);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}