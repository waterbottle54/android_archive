package com.penelope.campingtravel.ui.home.review.addreview;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.data.image.ImageRepository;
import com.penelope.campingtravel.data.review.Review;
import com.penelope.campingtravel.data.review.ReviewRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class AddReviewViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String uid;                 // 사용자 uid

    private String title = "";          // 리뷰 제목
    private String content = "";        // 내용

    private final MutableLiveData<Bitmap> image = new MutableLiveData<>();  // 이미지

    private final MutableLiveData<Boolean> isUploadInProgress = new MutableLiveData<>(false);

    private final ReviewRepository reviewRepository;
    private final ImageRepository imageRepository;


    @Inject
    public AddReviewViewModel(ReviewRepository reviewRepository, ImageRepository imageRepository) {
        this.reviewRepository = reviewRepository;
        this.imageRepository = imageRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }

    public LiveData<Boolean> isUploadInProgress() {
        return isUploadInProgress;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            uid = firebaseAuth.getCurrentUser().getUid();
        }
    }

    public void onTitleChange(String text) {
        title = text.trim();
    }

    public void onContentChange(String text) {
        content = text.trim();
    }

    public void onUploadImageClick() {
        event.setValue(new Event.PromptImage());
    }

    public void onOkClick() {

        // 이미 리뷰를 업로드 중이면 리턴한다
        Boolean isUploadInProgressValue = isUploadInProgress.getValue();
        assert isUploadInProgressValue != null;
        if (isUploadInProgressValue || uid == null) {
            return;
        }

        if (title.isEmpty() || content.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        if (image.getValue() == null) {
            event.setValue(new Event.ShowGeneralMessage("이미지를 업로드해주세요"));
            return;
        }

        isUploadInProgress.setValue(true);

        // 리뷰 객체를 구성하고 DB 에 업로드한다
        Review review = new Review(uid, title, content);
        reviewRepository.addReview(review,
                unused -> {
                    // 이미지도 스토리지에 업로드한다
                    imageRepository.addReviewImage(review.getId(), image.getValue(),
                            unused1 -> event.setValue(new Event.NavigateBackWithResult(true)),
                            Throwable::printStackTrace);
                },
                e -> {
                    isUploadInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("업로드에 실패했습니다"));
                });
    }

    public void onImageSelected(Bitmap bitmap) {

        if (bitmap != null) {
            image.setValue(bitmap);
        } else {
            event.setValue(new Event.ShowGeneralMessage("이미지를 불러오지 못했습니다"));
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class PromptImage extends Event {
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;
            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }
    }

}