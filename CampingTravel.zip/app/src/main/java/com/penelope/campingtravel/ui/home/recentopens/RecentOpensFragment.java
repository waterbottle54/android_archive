package com.penelope.campingtravel.ui.home.recentopens;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentRecentOpensBinding;
import com.penelope.campingtravel.utils.TimeUtils;

import java.time.LocalDate;
import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RecentOpensFragment extends Fragment {

    private FragmentRecentOpensBinding binding;
    private RecentOpensViewModel viewModel;


    public RecentOpensFragment() {
        super(R.layout.fragment_recent_opens);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentRecentOpensBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RecentOpensViewModel.class);

        // 현재 날짜를 표시한다
        String currentDate = String.format(Locale.getDefault(), "%s 기준",
                TimeUtils.getDateString(LocalDate.now())
        );
        binding.textViewCurrentDate.setText(currentDate);

        // 오픈 캠핑장 어댑터를 생성하고 리사이클러 뷰에 연결한다
        OpeningCampsAdapter adapter = new OpeningCampsAdapter();
        binding.recyclerOpen.setAdapter(adapter);
        binding.recyclerOpen.setHasFixedSize(true);

        // 오픈 캠핑장 목록을 리사이클러 뷰에 띄운다
        viewModel.getRecentlyOpeningCamps().observe(getViewLifecycleOwner(), camps -> {
            if (camps != null) {
                adapter.submitList(camps);
                binding.textViewNoRecentlyOpeningCamps.setVisibility(camps.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            } else {
                Toast.makeText(requireContext(), "데이터를 불러오지 못했습니다", Toast.LENGTH_SHORT).show();
            }
            binding.progressBar6.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {

        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}