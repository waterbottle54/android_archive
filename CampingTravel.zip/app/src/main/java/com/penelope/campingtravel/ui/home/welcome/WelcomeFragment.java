package com.penelope.campingtravel.ui.home.welcome;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.google.firebase.auth.FirebaseAuth;
import com.naver.maps.map.LocationTrackingMode;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.util.FusedLocationSource;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.data.recommended.Recommended;
import com.penelope.campingtravel.data.weather.HourlyWeather;
import com.penelope.campingtravel.databinding.FragmentWelcomeBinding;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;
import com.penelope.campingtravel.utils.ui.OnTextChangeListener;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class WelcomeFragment extends AuthListenerFragment implements OnMapReadyCallback, NaverMap.OnLocationChangeListener {

    public interface WelcomeFragmentListener {
        void onSignOutClick();
    }

    public static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    private FragmentWelcomeBinding binding;
    private WelcomeViewModel viewModel;

    private NaverMap map;                                               // 네이버 맵
    private FusedLocationSource fusedLocationSource;                    // 구글 로케이션 소스
    private ActivityResultLauncher<String> locationPermissionLauncher;  // 위치 퍼미션 런처


    public WelcomeFragment() {
        super(R.layout.fragment_welcome);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        fusedLocationSource = new FusedLocationSource(requireActivity(), LOCATION_PERMISSION_REQUEST_CODE);

        // 위치 퍼미션 런처 정의
        locationPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                result -> {
                    if (fusedLocationSource.onRequestPermissionsResult(
                            LOCATION_PERMISSION_REQUEST_CODE,
                            new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                            new int[]{result ? PackageManager.PERMISSION_GRANTED : PackageManager.PERMISSION_DENIED}
                    )) {
                        if (!fusedLocationSource.isActivated()) {
                            // 퍼미션 거부
                            map.setLocationTrackingMode(LocationTrackingMode.None);
                            return;
                        }
                        // 네이버맵 초기 설정하기
                        configureMap();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentWelcomeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(WelcomeViewModel.class);

        // 네이버 맵 획득
        MapFragment mapFragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonMyPage.setOnClickListener(v -> viewModel.onMyPageClick());
        binding.buttonLogout.setOnClickListener(v -> viewModel.onLogOutClick());
        binding.buttonQuickCheck.setOnClickListener(v -> viewModel.onQuickCheckClick());
        binding.imageViewSubmitQuery.setOnClickListener(v -> viewModel.onSubmitQuery());
        binding.buttonCaravan.setOnClickListener(v -> viewModel.onCaravanClick());
        binding.buttonGlamping.setOnClickListener(v -> viewModel.onGlampingClick());
        binding.buttonKidsCamping.setOnClickListener(v -> viewModel.onKidsCampingClick());
        binding.textViewCheckRecentOpens.setOnClickListener(v -> viewModel.onCheckRecentOpensClick());

        // 회원 여부에 따라 보이는 버튼을 다르게 한다
        viewModel.isMember().observe(getViewLifecycleOwner(), isMember -> {
            binding.buttonLogout.setVisibility(isMember ? View.VISIBLE : View.GONE);
            binding.buttonMyPage.setVisibility(isMember ? View.VISIBLE : View.GONE);
            binding.buttonQuickCheck.setVisibility(isMember ? View.GONE : View.VISIBLE);
        });

        // 에딧 텍스트의 검색어 변경 시 뷰모델에 통보한다
        binding.editTextQuery.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onQueryChange(text);
            }
        });

        // 추천 캠핑 어댑터를 생성하고 리사이클러 뷰에 연결한다
        RecommendedsAdapter recommendedsAdapter = new RecommendedsAdapter(Glide.with(this));
        binding.recyclerRecommended.setAdapter(recommendedsAdapter);

        // 추천 캠핑이 클릭되면 뷰모델에게 통보한다
        recommendedsAdapter.setOnItemSelectedListener(position -> {
            Recommended recommended = recommendedsAdapter.getCurrentList().get(position);
            viewModel.onRecommendedClick(recommended);
        });

        // 뷰모델의 추천 캠핑을 리사이클러 뷰에 표시한다
        viewModel.getRecommendedList().observe(getViewLifecycleOwner(), recommendedList -> {
            if (recommendedList != null) {
                recommendedsAdapter.submitList(recommendedList);
            }
        });

        // 일별 날씨 어댑터를 생성하고 리사이클러 뷰에 연결한다
        DailyWeathersAdapter dailyWeathersAdapter = new DailyWeathersAdapter();
        binding.recyclerViewDailyWeather.setAdapter(dailyWeathersAdapter);
        binding.recyclerViewDailyWeather.setHasFixedSize(true);

        // 뷰모델의 일별 날씨를 리사이클러 뷰에 표시한다
        viewModel.getDailyWeathers().observe(getViewLifecycleOwner(), dailyWeathers -> {
            if (dailyWeathers != null) {
                dailyWeathersAdapter.submitList(dailyWeathers);
            }
            binding.progressBar2.setVisibility(View.INVISIBLE);
        });

        // 시간별 날씨 차트를 초기화한다
        binding.hourlyWeatherChart.getDescription().setEnabled(false);
        binding.hourlyWeatherChart.getAxisLeft().setEnabled(false);
        binding.hourlyWeatherChart.getAxisRight().setEnabled(false);
        binding.hourlyWeatherChart.getXAxis().setEnabled(false);
        binding.hourlyWeatherChart.getLegend().setEnabled(false);

        // 뷰모델의 시간별 날씨를 차트에 표시한다
        viewModel.getHourlyWeathers().observe(getViewLifecycleOwner(), hourlyWeathers -> {
            if (hourlyWeathers != null) {
                updateWeatherChart(hourlyWeathers);
            }
            binding.hourlyWeatherChart.setVisibility(View.VISIBLE);
        });

        // 뷰모델의 코로나 확진자 통계를 표시한다
        viewModel.getCovidStatistic().observe(getViewLifecycleOwner(), covidStatistic -> {
            if (covidStatistic != null) {
                String strDailyCovid = String.format(Locale.getDefault(), "%s명",
                        NumberFormat.getInstance().format(covidStatistic.total.increment));
                binding.textViewDailyCovid.setText(strDailyCovid);
            }
        });

        // 리뷰 이미지 어댑터를 생성하고 리사이클러 뷰에 연결한다
        ReviewAlbumsAdapter reviewAlbumsAdapter = new ReviewAlbumsAdapter();
        binding.recyclerReview.setAdapter(reviewAlbumsAdapter);
        binding.recyclerReview.setHasFixedSize(true);

        // 리뷰가 클릭되면 뷰모델에 통보한다
        reviewAlbumsAdapter.setOnItemSelectedListener(position -> {
            Map.Entry<String, Bitmap> entry = reviewAlbumsAdapter.getCurrentList().get(position);
            viewModel.onReviewClick(entry.getKey());
        });

        // 리뷰 이미지를 리사이클러 뷰에 표시한다
        viewModel.getReviewAlbum().observe(getViewLifecycleOwner(), album -> {
            if (album != null) {
                reviewAlbumsAdapter.submitList(new ArrayList<>(album.entrySet()));
                binding.textViewNoReviews.setVisibility(album.isEmpty() ? View.VISIBLE : View.INVISIBLE);
            }
            binding.progressBarReview.setVisibility(View.INVISIBLE);
        });

        // 필터 버튼의 색상을 업데이트한다
        int colorOn = 0xFFFF8A80;
        int colorOff = getResources().getColor(R.color.colorGray, null);
        viewModel.isCaravanFilterOn().observe(getViewLifecycleOwner(),
                filterOn -> binding.buttonCaravan.setBackgroundColor(filterOn ? colorOn : colorOff));
        viewModel.isGlampingFilterOn().observe(getViewLifecycleOwner(),
                filterOn -> binding.buttonGlamping.setBackgroundColor(filterOn ? colorOn : colorOff));
        viewModel.isKidsCampingFilterOn().observe(getViewLifecycleOwner(),
                filterOn -> binding.buttonKidsCamping.setBackgroundColor(filterOn ? colorOn : colorOff));

        // 현재 지역명을 표시한다
        viewModel.getRegionName().observe(getViewLifecycleOwner(), regionName -> {
            if (regionName != null) {
                binding.textViewRegionName.setText(regionName);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof WelcomeViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof WelcomeViewModel.Event.NavigateToMyPageScreen) {
                // 마이페이지 화면으로 이동한다
                NavDirections navDirections = WelcomeFragmentDirections.actionWelcomeFragmentToMyPageFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof WelcomeViewModel.Event.NavigateToCampsScreen) {
                // 캠핑장 검색결과 화면으로 이동한다
                ArrayList<Camp> camps = ((WelcomeViewModel.Event.NavigateToCampsScreen) event).camps;
                NavDirections navDirections = WelcomeFragmentDirections.actionWelcomeFragmentToCampsFragment(camps);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof WelcomeViewModel.Event.ShowRecommendedPage) {
                // 추천 캠핑 웹 페이지를 띄운다
                String url = ((WelcomeViewModel.Event.ShowRecommendedPage) event).url;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);
            } else if (event instanceof WelcomeViewModel.Event.ConfirmSignOut) {
                // 액티비티에 로그아웃을 통보한다
                try {
                    WelcomeFragmentListener host = (WelcomeFragmentListener) requireActivity();
                    host.onSignOutClick();
                } catch (ClassCastException e) {
                    e.printStackTrace();
                }
            } else if (event instanceof WelcomeViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 출력한다
                String message = ((WelcomeViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            } else if (event instanceof WelcomeViewModel.Event.NavigateToReviewScreen) {
                // 리뷰 상세 화면으로 이동한다
                String reviewId = ((WelcomeViewModel.Event.NavigateToReviewScreen) event).reviewId;
                NavDirections navDirections = WelcomeFragmentDirections.actionGlobalReviewDetailFragment(reviewId);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof WelcomeViewModel.Event.NavigateToQuickCheckScreen) {
                // 빠른조회 화면으로 이동한다
                NavDirections navDirections = WelcomeFragmentDirections.actionWelcomeFragmentToQuickCheckFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof WelcomeViewModel.Event.NavigateToRecentOpensScreen) {
                // 최근 오픈 일정 화면으로 이동한다
                NavDirections navDirections = WelcomeFragmentDirections.actionWelcomeFragmentToRecentOpensFragment();
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {

        map = naverMap;

        if (requireContext().checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // 네이버맵 초기 설정하기
            configureMap();
        } else {
            // 위치 퍼미션 요청하기
            locationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION);
        }
    }

    private void configureMap() {
        // 네이버맵 초기 설정
        map.addOnLocationChangeListener(this);
        map.setLocationSource(fusedLocationSource);
        map.setLocationTrackingMode(LocationTrackingMode.Follow);
    }

    @Override
    public void onLocationChange(@NonNull Location location) {
        // GPS 위치 감지 시 뷰모델에 통보
        viewModel.onLocationChange(location);
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void updateWeatherChart(List<HourlyWeather> weathers) {

        // 시간별 날씨를 라인 차트에 표시한다
        List<Entry> entryList = new ArrayList<>();
        for (int i = 0; i < weathers.size(); i++) {
            entryList.add(new Entry((float) i, weathers.get(i).getTemperature()));
        }
        LineDataSet lineDataSet = new LineDataSet(entryList, "");
        lineDataSet.setColor(0xFFFFEB9E);       // 라인 색상
        lineDataSet.setLineWidth(3.0f);         // 라인 굵기
        lineDataSet.setDrawCircles(false);      // 라인에 마디점을 그리지 않음
        lineDataSet.setDrawFilled(true);        // 라인 아랫부분을 칠함
        lineDataSet.setFillColor(0xFFFFF5CC);   // 라인 아랫부분 색상
        lineDataSet.setMode(LineDataSet.Mode.HORIZONTAL_BEZIER);    // 라인을 부드럽게 그림
        lineDataSet.setValueTextSize(10.0f);    // 기온 텍스트 사이즈
        lineDataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                // 기온에 소수점을 표시하지 않음
                return String.format(Locale.getDefault(), "%.0f", value);
            }
        });
        LineData lineData = new LineData(lineDataSet);
        binding.hourlyWeatherChart.setData(lineData);
        binding.hourlyWeatherChart.invalidate();
    }

}