package com.penelope.campingtravel.ui.home.reservations;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.penelope.campingtravel.api.covid.CovidStatisticRepository;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.data.camp.CampRepository;
import com.penelope.campingtravel.data.covid.CovidStatistic;
import com.penelope.campingtravel.data.reservation.Reservation;
import com.penelope.campingtravel.data.reservation.ReservationRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ReservationsViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<Reservation>> reservations;

    private final LiveData<Map<String, Camp>> campMap;

    private final LiveData<CovidStatistic> covidStatistic;


    @Inject
    public ReservationsViewModel(SavedStateHandle savedStateHandle,
                                 ReservationRepository reservationRepository,
                                 CampRepository campRepository,
                                 CovidStatisticRepository covidStatisticRepository) {

        String uid = savedStateHandle.get("uid");
        String name = savedStateHandle.get("name");
        String phone = savedStateHandle.get("phone");

        // 사용자의 예약 목록을 불러온다
        if (uid != null) {
            reservations = reservationRepository.getReservations(uid);
        } else {
            reservations = reservationRepository.getReservations(name, phone);
        }

        // 캠핑장 정보를 불러온다
        campMap = Transformations.switchMap(reservations, reservationList -> {
            List<String> campIdList = reservationList.stream().map(Reservation::getCampId).collect(Collectors.toList());
            List<String> campNameList = reservationList.stream().map(Reservation::getCampName).collect(Collectors.toList());
            return campRepository.getCampMap(campIdList, campNameList);
        });

        // 코로나 정보를 불러온다
        LocalDateTime now = LocalDateTime.now();
        covidStatistic = covidStatisticRepository.getStatistic(now.getHour() >= 10 ? LocalDate.now() : LocalDate.now().minusDays(1));
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Reservation>> getReservations() {
        return reservations;
    }

    public LiveData<Map<String, Camp>> getCampMap() {
        return campMap;
    }

    public LiveData<CovidStatistic> getCovidStatistic() {
        return covidStatistic;
    }


    public static class Event {
        public static class NavigateBack extends Event {
        }
    }

}