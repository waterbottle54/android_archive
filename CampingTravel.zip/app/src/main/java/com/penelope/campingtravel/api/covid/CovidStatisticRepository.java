package com.penelope.campingtravel.api.covid;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.penelope.campingtravel.data.covid.CovidStatistic;

import java.time.LocalDate;

import javax.inject.Inject;

public class CovidStatisticRepository {

    @Inject
    public CovidStatisticRepository() {
    }

    public LiveData<CovidStatistic> getStatistic(LocalDate date) {

        // API 를 이용해 코로나 통계를 얻고, LiveData 형태로 제공한다

        MutableLiveData<CovidStatistic> statistic = new MutableLiveData<>();

        new Thread(() -> {
            CovidStatistic statisticValue = CovidStatisticApi.get(date);
            statistic.postValue(statisticValue);
        }).start();

        return statistic;
    }
}
