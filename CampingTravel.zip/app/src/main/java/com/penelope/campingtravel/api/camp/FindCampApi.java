package com.penelope.campingtravel.api.camp;

import android.content.Context;
import android.util.Log;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.penelope.campingtravel.data.camp.Camp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

// 캠핑장을 검색하는 API (고캠핑 사이트 이용)

public class FindCampApi {

    // 고캠핑 API 호출 url
    public static final String URL_SEARCH_FORMAT = "http://api.visitkorea.or.kr/openapi/service/rest/GoCamping/searchList?serviceKey={SERVICE_KEY}&_type=json&pageNo=1&numOfRows=30&MobileOS=ETC&MobileApp=AppTest&keyword={KEYWORD}";
    public static final String URL_BASIC_FORMAT = "http://api.visitkorea.or.kr/openapi/service/rest/GoCamping/basedList?serviceKey={SERVICE_KEY}&_type=json&pageNo=1&numOfRows={NUMBER}&MobileOS=ETC&MobileApp=AppTest";
    public static final String ARG_SERVICE_KEY = "{SERVICE_KEY}";
    public static final String ARG_KEYWORD = "{KEYWORD}";
    public static final String ARG_NUMBER = "{NUMBER}";
    public static final String SERVICE_KEY = "MtVBdtw16Ez1YFEXjvMpB0Zws4eaThA35edKG44NT6A0P3gsproUZBkpaFUUVrHmaPUzkazSncH9iukFY%2BdQfw%3D%3D";

    private final RequestQueue requestQueue;


    @Inject
    public FindCampApi(Context context) {
        requestQueue = Volley.newRequestQueue(context);
    }

    public void get(String query, OnSuccessListener<List<Camp>> onSuccessListener, OnFailureListener onFailureListener) {

        // 고캠핑 키워드 검색 API 호출을 위한 URL 구성하기
        String url = URL_SEARCH_FORMAT
                .replace(ARG_SERVICE_KEY, SERVICE_KEY)
                .replace(ARG_KEYWORD, query);

        request(url, onSuccessListener, onFailureListener);
    }

    public void get(int size, OnSuccessListener<List<Camp>> onSuccessListener, OnFailureListener onFailureListener) {

        // 고캠핑 기본정보 검색 API 호출을 위한 URL 구성하기
        String url = URL_BASIC_FORMAT
                .replace(ARG_SERVICE_KEY, SERVICE_KEY)
                .replace(ARG_NUMBER, String.valueOf(size));

        request(url, onSuccessListener, onFailureListener);
    }

    private void request(String url, OnSuccessListener<List<Camp>> onSuccessListener, OnFailureListener onFailureListener) {

        // URL 을 전달하여 json 오브젝트를 획득한다
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.GET, url,
                null,
                jsonObject -> {
                    String json = jsonObject.toString();
                    JSONObject response;

                    try {
                        // json 에서 불필요한 문자열을 제거한다
                        response = new JSONObject(json.substring(json.indexOf("{"), json.lastIndexOf("}") + 1));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        onFailureListener.onFailure(e);
                        return;
                    }

                    try {
                        // 헤더와 바디를 획득한다
                        JSONObject header = response.getJSONObject("response").getJSONObject("header");
                        JSONObject body = response.getJSONObject("response").getJSONObject("body");

                        // 결과 메세지가 OK (정상) 인지 확인한다
                        String resultMessage = header.getString("resultMsg");
                        if (!"OK".equals(resultMessage)) {
                            onFailureListener.onFailure(new Exception(resultMessage));
                            return;
                        }

                        List<Camp> camps = new ArrayList<>();

                        // 검색된 캠핑장 수를 획득한다
                        int totalCount = body.getInt("totalCount");
                        if (totalCount == 0) {
                            onSuccessListener.onSuccess(camps);
                            return;
                        }

                        JSONObject items = body.getJSONObject("items");

                        if (totalCount == 1) {
                            // 캠핑장이 1개이면 단독으로 파싱한다
                            JSONObject item = items.getJSONObject("item");
                            Camp camp = parseCampObject(item);
                            if (camp != null) {
                                camps.add(camp);
                            }
                            onSuccessListener.onSuccess(camps);
                            return;
                        }

                        // 다수 캠핑장이 있는 경우 배열을 파싱한다
                        JSONArray item = items.getJSONArray("item");

                        for (int i = 0; i < item.length(); i++) {
                            Camp camp = parseCampObject(item.getJSONObject(i));
                            if (camp != null) {
                                camps.add(camp);
                            }
                        }

                        onSuccessListener.onSuccess(camps);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        onFailureListener.onFailure(e);
                    }
                },
                onFailureListener::onFailure);

        // Volley 의 요청 큐에 위의 요청을 삽입한다
        jsonObjectRequest.setRetryPolicy(new DefaultRetryPolicy(
                20000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        requestQueue.add(jsonObjectRequest);
    }

    private Camp parseCampObject(JSONObject obj) {

        // 단일 캠핑장 json 오브젝트를 파싱하여 Camp 객체로 리턴한다

        String id;
        String name;
        String address;
        String phone;
        String doName;
        String imageUrl;
        double latitude;
        double longitude;
        int glampingCount;
        int caravCount;
        String strOpenDate;

        try {
            id = obj.getString("contentId");
            name = obj.getString("facltNm");
            address = obj.getString("addr1");
            phone = obj.has("tel") ? obj.getString("tel") : null;
            doName = obj.getString("doNm");
            imageUrl = obj.has("firstImageUrl") ? obj.getString("firstImageUrl") : null;
            latitude = obj.getDouble("mapY");
            longitude = obj.getDouble("mapX");
            glampingCount = obj.getInt("glampSiteCo");
            caravCount = obj.getInt("caravSiteCo");
            strOpenDate = obj.has("hvofEnddle") ? obj.getString("hvofEnddle") : null;
            LocalDate openDate = strOpenDate != null ? LocalDate.parse(strOpenDate) : null;

            if (imageUrl != null) {
                imageUrl = imageUrl.replace("\\", "");
            }

            return new Camp(id, name, address, phone, doName, imageUrl, latitude, longitude, glampingCount, caravCount, openDate);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }

}



