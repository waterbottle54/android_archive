package com.penelope.campingtravel.data.review;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class ReviewRepository {

    private final CollectionReference reviewCollection;


    @Inject
    public ReviewRepository(FirebaseFirestore firestore) {
        reviewCollection = firestore.collection("reviews");
    }

    public void addReview(Review review, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // 새로운 리뷰를 DB 에 추가한다

        reviewCollection.document(review.getId())
                .set(review)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<List<Review>> getAllReviews() {

        // 모든 리뷰를 최신 순으로 정렬하여 불러온다

        MutableLiveData<List<Review>> reviews = new MutableLiveData<>();

        reviewCollection.orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    List<Review> reviewList = new ArrayList<>();
                    if (error != null) {
                        error.printStackTrace();
                        reviews.setValue(null);
                        return;
                    }
                    if (value == null || value.isEmpty()) {
                        reviews.setValue(reviewList);
                        return;
                    }
                    for (DocumentSnapshot snapshot : value) {
                        Review review = snapshot.toObject(Review.class);
                        if (review != null) {
                            reviewList.add(review);
                        }

                    }
                    reviews.setValue(reviewList);
                });

        return reviews;
    }

    public LiveData<List<Review>> getReviewsWrittenBy(String uid) {

        // 특정 유저가 작성한 리뷰를 모두 불러온다

        MutableLiveData<List<Review>> reviews = new MutableLiveData<>();

        reviewCollection.orderBy("created", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    List<Review> reviewList = new ArrayList<>();
                    if (error != null) {
                        error.printStackTrace();
                        reviews.setValue(null);
                        return;
                    }
                    if (value == null || value.isEmpty()) {
                        reviews.setValue(reviewList);
                        return;
                    }
                    for (DocumentSnapshot snapshot : value) {
                        Review review = snapshot.toObject(Review.class);
                        if (review != null && review.getUid().equals(uid)) {
                            reviewList.add(review);
                        }

                    }
                    reviews.setValue(reviewList);
                });

        return reviews;
    }

    public void getReview(String reviewId, OnSuccessListener<Review> onSuccessListener, OnFailureListener onFailureListener) {

        // 리뷰 아이디로 특정 리뷰를 검색한다

        reviewCollection.document(reviewId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot == null) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    onSuccessListener.onSuccess(documentSnapshot.toObject(Review.class));
                })
                .addOnFailureListener(onFailureListener);
    }

    public LiveData<Review> getReview(String reviewId) {

        // 리뷰 아이디로 특정 리뷰를 검색한다

        MutableLiveData<Review> review = new MutableLiveData<>();

        reviewCollection.document(reviewId)
                .addSnapshotListener((value, error) -> {
                    if (value == null) {
                        review.setValue(null);
                        return;
                    }
                    if (error != null) {
                        error.printStackTrace();
                        review.setValue(null);
                        return;
                    }
                    review.setValue(value.toObject(Review.class));
                });

        return review;
    }

    public void updateReview(String reviewId, String newTitle, String newContent,
                             OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // 특정 리뷰의 제목과 내용을 변경한다

        Map<String, Object> map = new HashMap<>();
        map.put("title", newTitle);
        map.put("content", newContent);

        reviewCollection.document(reviewId)
                .update(map)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

}
