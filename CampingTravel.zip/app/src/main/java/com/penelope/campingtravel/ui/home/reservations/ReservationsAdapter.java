package com.penelope.campingtravel.ui.home.reservations;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.data.covid.CovidData;
import com.penelope.campingtravel.data.covid.CovidStatistic;
import com.penelope.campingtravel.data.reservation.Reservation;
import com.penelope.campingtravel.databinding.ReservationItemBinding;
import com.penelope.campingtravel.utils.TimeUtils;
import com.penelope.campingtravel.utils.ui.NameUtils;

import java.util.Locale;
import java.util.Map;

public class ReservationsAdapter extends ListAdapter<Reservation, ReservationsAdapter.ReservationViewHolder> {

    class ReservationViewHolder extends RecyclerView.ViewHolder {

        private final ReservationItemBinding binding;

        public ReservationViewHolder(ReservationItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Reservation model) {

            // 캠핑장 이름을 표시한다
            binding.textViewReservationCampName.setText(model.getCampName());

            // 예약기간을 표시한다
            String strTerm = String.format(Locale.getDefault(), "%s ~ %s",
                    TimeUtils.getDateString(model.getStartDate()),
                    TimeUtils.getDateString(model.getEndDate()).substring(5)
            );
            binding.textViewReservationTerm.setText(strTerm);

            // 캠핑장 정보를 획득한다
            Camp camp = campMap.get(model.getCampId());
            if (camp != null) {
                // 캠핑장 소재지의 코로나 통계를 획득한다
                String standardDoName = NameUtils.getStandardDoName(camp.getDoName());
                CovidData data = covidStatistic.contents.get(standardDoName);
                if (data != null) {
                    String strStatistic = String.format(Locale.getDefault(), "%s %d명",
                            standardDoName, data.increment
                    );
                    binding.textViewReservationCovidNumber.setText(strStatistic);
                }
            }
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final Map<String, Camp> campMap;
    private final CovidStatistic covidStatistic;


    public ReservationsAdapter(Map<String, Camp> campMap, CovidStatistic covidStatistic) {
        super(new DiffUtilCallback());
        this.campMap = campMap;
        this.covidStatistic = covidStatistic;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public ReservationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        ReservationItemBinding binding = ReservationItemBinding.inflate(layoutInflater, parent, false);
        return new ReservationViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ReservationViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Reservation> {

        @Override
        public boolean areItemsTheSame(@NonNull Reservation oldItem, @NonNull Reservation newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Reservation oldItem, @NonNull Reservation newItem) {
            return oldItem.equals(newItem);
        }
    }

}