package com.penelope.campingtravel.data.user;

// 회원 정보

import java.io.Serializable;

public class User implements Serializable {

    private String uid;         // 아이디
    private String id;          // 로그인 아이디
    private String name;        // 이름
    private String phone;       // 전화번호
    private long created;       // 가입일자
    private boolean isCertified; // 코로나 인증 여부

    public User() {
    }

    public User(String uid, String id, String name, String phone) {
        this.uid = uid;
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.created = System.currentTimeMillis();
    }

    public String getUid() {
        return uid;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public long getCreated() {
        return created;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setCreated(long created) {
        this.created = created;
    }
}
