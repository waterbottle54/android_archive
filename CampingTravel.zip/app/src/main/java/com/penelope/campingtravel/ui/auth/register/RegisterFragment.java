package com.penelope.campingtravel.ui.auth.register;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentRegisterBinding;
import com.penelope.campingtravel.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class RegisterFragment extends Fragment {

    private FragmentRegisterBinding binding;
    private RegisterViewModel viewModel;


    public RegisterFragment() {
        super(R.layout.fragment_register);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentRegisterBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(RegisterViewModel.class);

        // 에딧 텍스트들의 값 변경 시 뷰모델에 통보한다
        binding.editTextId.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onIdChange(text);
            }
        });
        binding.editTextPassword.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPasswordChange(text);
            }
        });
        binding.editTextPasswordConfirm.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPasswordConfirmChange(text);
            }
        });
        binding.editTextName.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onNameChange(text);
            }
        });
        binding.editTextPhone.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPhoneChange(text);
            }
        });

        // 회원가입 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonRegister.setOnClickListener(v -> viewModel.onRegisterClick());


        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof RegisterViewModel.Event.NavigateBack) {
                // 로그인 화면으로 뒤로 이동한다
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof  RegisterViewModel.Event.ShowGeneralMessage) {
                // 메세지를 출력한다
                String message = ((RegisterViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

}