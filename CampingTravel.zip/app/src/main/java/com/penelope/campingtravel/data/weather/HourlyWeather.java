package com.penelope.campingtravel.data.weather;

// 시간별 날씨 정보

public class HourlyWeather {

    private final int hour;                 // 시각
    private final int temperature;          // 기온
    private final WeatherType weatherType;  // 날씨형태 (ex. 맑음)

    public HourlyWeather(int hour, int temperature, WeatherType weatherType) {
        this.hour = hour;
        this.temperature = temperature;
        this.weatherType = weatherType;
    }

    public int getHour() {
        return hour;
    }

    public int getTemperature() {
        return temperature;
    }

    public WeatherType getWeatherType() {
        return weatherType;
    }

    @Override
    public String toString() {
        return "HourlyWeather{" +
                "hour=" + hour +
                ", temperature=" + temperature +
                ", weatherType=" + weatherType +
                '}';
    }
}
