package com.penelope.campingtravel.ui.home.welcome;

import android.graphics.Bitmap;
import android.location.Location;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.naver.maps.geometry.LatLng;
import com.penelope.campingtravel.api.covid.CovidStatisticRepository;
import com.penelope.campingtravel.api.reveresgeocoding.ReverseGeocodingApi;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.data.camp.CampRepository;
import com.penelope.campingtravel.data.covid.CovidStatistic;
import com.penelope.campingtravel.data.image.ImageRepository;
import com.penelope.campingtravel.data.recommended.Recommended;
import com.penelope.campingtravel.data.recommended.RecommendedRepository;
import com.penelope.campingtravel.data.review.Review;
import com.penelope.campingtravel.data.review.ReviewRepository;
import com.penelope.campingtravel.data.weather.DailyWeather;
import com.penelope.campingtravel.data.weather.HourlyWeather;
import com.penelope.campingtravel.data.weather.WeatherRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class WelcomeViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<Boolean> isMember = new MutableLiveData<>();  // 회원 여부

    private String query = "";                                                  // 입력한 검색어

    private final LiveData<List<Recommended>> recommendedList;                  // 추천 캠핑 목록

    private final MutableLiveData<LatLng> location = new MutableLiveData<>();   // 현재 GPS 위치
    private final LiveData<String> regionName;                                  // 현재 지역명
    private final LiveData<List<DailyWeather>> dailyWeathers;                   // 일별 날씨
    private final LiveData<List<HourlyWeather>> hourlyWeathers;                 // 시간별 날씨

    private final LiveData<CovidStatistic> covidStatistic;                      // 코로나 확진자 수

    private final LiveData<Map<String, Bitmap>> reviewAlbum;

    private boolean isSearchingInProgress;
    private final MutableLiveData<Boolean> filterGlamping = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> filterCaravan = new MutableLiveData<>(false);
    private final MutableLiveData<Boolean> filterKidsCamping = new MutableLiveData<>(false);

    private final CampRepository campRepository;


    @Inject
    public WelcomeViewModel(RecommendedRepository recommendedRepository,
                            ReverseGeocodingApi reverseGeocodingApi,
                            WeatherRepository weatherRepository,
                            CovidStatisticRepository covidStatisticRepository,
                            ReviewRepository reviewRepository,
                            ImageRepository imageRepository,
                            CampRepository campRepository) {

        // 추천 캠핑 명단을 불러온다
        recommendedList = recommendedRepository.get();

        // 현재 위치로부터 지역명을 불러온다
        regionName = Transformations.switchMap(location, l -> reverseGeocodingApi.get(l.latitude, l.longitude));

        // 현재 지역명으로 일별, 시간별 날씨를 불러온다
        dailyWeathers = Transformations.switchMap(regionName, name -> name != null ? weatherRepository.getDaily(name) : null);
        hourlyWeathers = Transformations.switchMap(regionName, name -> name != null ? weatherRepository.getHourly(name) : null);

        // 코로나 통계를 불러온다
        LocalDateTime ldt = LocalDateTime.now();
        covidStatistic = covidStatisticRepository.getStatistic(ldt.getHour() >= 10 ? LocalDate.now() : LocalDate.now().minusDays(1));

        // 리뷰를 불러온다
        LiveData<List<Review>> reviews = reviewRepository.getAllReviews();
        reviewAlbum = Transformations.switchMap(reviews, reviewList -> {
            List<String> reviewIds = reviewList.stream().map(Review::getId).collect(Collectors.toList());
            return imageRepository.getReviewAlbum(reviewIds);
        });

        this.campRepository = campRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Recommended>> getRecommendedList() {
        return recommendedList;
    }

    public LiveData<String> getRegionName() {
        return regionName;
    }

    public LiveData<List<DailyWeather>> getDailyWeathers() {
        return dailyWeathers;
    }

    public LiveData<List<HourlyWeather>> getHourlyWeathers() {
        return hourlyWeathers;
    }

    public LiveData<CovidStatistic> getCovidStatistic() {
        return covidStatistic;
    }

    public LiveData<Boolean> isMember() {
        return isMember;
    }

    public LiveData<Map<String, Bitmap>> getReviewAlbum() {
        return reviewAlbum;
    }

    public LiveData<Boolean> isCaravanFilterOn() {
        return filterCaravan;
    }

    public LiveData<Boolean> isGlampingFilterOn() {
        return filterGlamping;
    }

    public LiveData<Boolean> isKidsCampingFilterOn() {
        return filterKidsCamping;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        isMember.setValue(firebaseAuth.getCurrentUser() != null);
    }

    public void onMyPageClick() {
        // 멤버인 경우 마이페이지로 이동하도록 한다
        Boolean isMemberValue = isMember.getValue();
        if (isMemberValue != null && isMemberValue) {
            event.setValue(new Event.NavigateToMyPageScreen());
        }
    }

    public void onLogOutClick() {
        // 멤버인 경우 로그아웃을 진행한다
        Boolean isMemberValue = isMember.getValue();
        if (isMemberValue != null && isMemberValue) {
            event.setValue(new Event.ConfirmSignOut());
        }
    }

    public void onQueryChange(String text) {
        query = text.trim();
    }

    public void onSubmitQuery() {

        if (isSearchingInProgress) {
            return;
        }

        if (query.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("검색어를 입력해주세요"));
            return;
        }

        isSearchingInProgress = true;

        campRepository.getCamps(query,
                camps -> {
                    isSearchingInProgress = false;

                    ArrayList<Camp> filtered = new ArrayList<>();
                    Boolean filterCaravanValue = filterCaravan.getValue();
                    Boolean filterGlampingValue = filterGlamping.getValue();
                    Boolean filterKidsCampingValue = filterKidsCamping.getValue();
                    assert filterCaravanValue != null && filterGlampingValue != null && filterKidsCampingValue != null;

                    for (Camp camp : camps) {
                        if (filterCaravanValue && camp.getCaravCount() == 0) {
                            continue;
                        }
                        if (filterGlampingValue && camp.getGlampingCount() == 0) {
                            continue;
                        }
                        if (filterKidsCampingValue && !camp.getName().contains("키즈")) {
                            continue;
                        }
                        filtered.add(camp);
                    }

                    event.setValue(new Event.NavigateToCampsScreen(filtered));
                },
                e -> {
                    isSearchingInProgress = false;
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("검색에 실패했습니다"));
                });
    }

    public void onCaravanClick() {
        Boolean filterValue = filterCaravan.getValue();
        assert filterValue != null;
        filterCaravan.setValue(!filterValue);
    }

    public void onGlampingClick() {
        Boolean filterValue = filterGlamping.getValue();
        assert filterValue != null;
        filterGlamping.setValue(!filterValue);
    }

    public void onKidsCampingClick() {
        Boolean filterValue = filterKidsCamping.getValue();
        assert filterValue != null;
        filterKidsCamping.setValue(!filterValue);
    }

    public void onQuickCheckClick() {
        event.setValue(new Event.NavigateToQuickCheckScreen());
    }

    public void onLocationChange(Location location) {
        if (this.location.getValue() == null) {
            // 기기 위치 변경 시 위치값을 변경한다
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
            this.location.setValue(latLng);
        }
    }

    public void onRecommendedClick(Recommended recommended) {
        // 추천 캠핑 클릭 시 해당 웹페이지로 이동하도록 한다
        event.setValue(new Event.ShowRecommendedPage(recommended.getUrl()));
    }

    public void onReviewClick(String reviewId) {
        event.setValue(new Event.NavigateToReviewScreen(reviewId));
    }

    public void onCheckRecentOpensClick() {
        event.setValue(new Event.NavigateToRecentOpensScreen());
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;

            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBack extends Event {
        }

        public static class NavigateToMyPageScreen extends Event {
        }

        public static class NavigateToCampsScreen extends Event {
            public final ArrayList<Camp> camps;
            public NavigateToCampsScreen(ArrayList<Camp> camps) {
                this.camps = camps;
            }
        }

        public static class ShowRecommendedPage extends Event {
            public final String url;
            public ShowRecommendedPage(String url) {
                this.url = url;
            }
        }

        public static class ConfirmSignOut extends Event {
        }

        public static class NavigateToReviewScreen extends Event {
            public final String reviewId;
            public NavigateToReviewScreen(String reviewId) {
                this.reviewId = reviewId;
            }
        }

        public static class NavigateToQuickCheckScreen extends Event {
        }

        public static class NavigateToRecentOpensScreen extends Event {
        }
    }

}