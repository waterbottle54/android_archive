package com.penelope.campingtravel.ui.home.mypage.mypage;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.data.image.ImageRepository;
import com.penelope.campingtravel.data.reservation.Reservation;
import com.penelope.campingtravel.data.reservation.ReservationRepository;
import com.penelope.campingtravel.data.review.Review;
import com.penelope.campingtravel.data.review.ReviewRepository;
import com.penelope.campingtravel.data.user.User;
import com.penelope.campingtravel.data.user.UserRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class MyPageViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> uid = new MutableLiveData<>();    // 현재 유저 uid
    private final LiveData<User> user;                                      // 현재 회원정보

    private final LiveData<Map<String, Bitmap>> myReviewAlbum;                // 내가 작성한 리뷰 이미지들

    private final LiveData<Reservation> recentReservation;


    @Inject
    public MyPageViewModel(UserRepository userRepository,
                           ReviewRepository reviewRepository,
                           ImageRepository imageRepository,
                           ReservationRepository reservationRepository) {

        // 현재 회원정보를 불러온다
        user = Transformations.switchMap(uid, userRepository::getUser);

        // 현재 사용자가 작성한 리뷰를 모두 불러온다
        LiveData<List<Review>> myReviews = Transformations.switchMap(uid, reviewRepository::getReviewsWrittenBy);
        myReviewAlbum = Transformations.switchMap(myReviews, reviewList -> {
            List<String> reviewIds = reviewList.stream().map(Review::getId).collect(Collectors.toList());
            return imageRepository.getReviewAlbum(reviewIds);
        });

        // 최근 예약정보 1건을 불러온다
        LiveData<List<Reservation>> reservations = Transformations.switchMap(uid, reservationRepository::getReservations);
        recentReservation = Transformations.map(reservations, reservationList -> {
            if (reservationList == null || reservationList.isEmpty()) {
                return null;
            }
            return reservationList.get(0);
        });
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<User> getUser() {
        return user;
    }

    public LiveData<Map<String, Bitmap>> getMyReviewAlbum() {
        return myReviewAlbum;
    }

    public LiveData<Reservation> getRecentReservation() {
        return recentReservation;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        } else {
            uid.setValue(firebaseAuth.getCurrentUser().getUid());
        }
    }

    public void onCheckReservationClick() {
        if (uid.getValue() == null) {
            return;
        }
        event.setValue(new Event.NavigateToReservationsScreen(uid.getValue()));
    }

    public void onSetPrivacyClick() {
        // 개인정보 수정 화면으로 이동하도록 한다
        User userValue = user.getValue();
        if (userValue != null) {
            event.setValue(new Event.NavigateToSetPrivacyScreen(userValue));
        }
    }

    public void onCertifyClick() {
        event.setValue(new Event.NavigateToCertificationScreen());
    }

    public void onSetPrivacyResult(boolean success) {
        if (success) {
            event.setValue(new Event.ShowGeneralMessage("회원정보가 변경되었습니다"));
        } else {
            event.setValue(new Event.ShowGeneralMessage("회원정보 변경에 실패했습니다"));
        }
    }

    public void onLogOutClick() {
        event.setValue(new Event.ConfirmSignOut());
    }

    public void onAddReviewClick() {
        event.setValue(new Event.NavigateToAddReviewScreen());
    }

    public void onAddReviewResult(boolean success) {
        if (success) {
            event.setValue(new Event.ShowGeneralMessage("리뷰 작성이 완료되었습니다"));
        }
    }

    public void onReviewClick(String reviewId) {
        event.setValue(new Event.NavigateToReviewScreen(reviewId));
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class NavigateToSetPrivacyScreen extends Event {
            public final User user;
            public NavigateToSetPrivacyScreen(User user) {
                this.user = user;
            }
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class ConfirmSignOut extends Event {
        }

        public static class NavigateToAddReviewScreen extends Event {
        }

        public static class NavigateToReviewScreen extends Event {
            public final String reviewId;
            public NavigateToReviewScreen(String reviewId) {
                this.reviewId = reviewId;
            }
        }

        public static class NavigateToReservationsScreen extends Event {
            public final String uid;
            public NavigateToReservationsScreen(String uid) {
                this.uid = uid;
            }
        }

        public static class NavigateToCertificationScreen extends Event {
        }
    }

}