package com.penelope.campingtravel.ui.home.review.modifyreview;

import android.graphics.Bitmap;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.campingtravel.data.image.ImageRepository;
import com.penelope.campingtravel.data.review.Review;
import com.penelope.campingtravel.data.review.ReviewRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ModifyReviewViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final Review oldReview;         // 수정할 리뷰
    private final LiveData<Bitmap> image;   // 리뷰 이미지

    private String title = "";              // 리뷰 제목
    private String content = "";            // 내용

    private final MutableLiveData<Boolean> isUploadInProgress = new MutableLiveData<>(false);

    private final ReviewRepository reviewRepository;


    @Inject
    public ModifyReviewViewModel(SavedStateHandle savedStateHandle,
                                 ReviewRepository reviewRepository,
                                 ImageRepository imageRepository) {

        // 전달된 리뷰를 획득한다
        oldReview = savedStateHandle.get("review");
        assert oldReview != null;

        // 리뷰 이미지를 불러온다
        image = imageRepository.getReviewImage(oldReview.getId());

        title = oldReview.getTitle();
        content = oldReview.getContent();

        this.reviewRepository = reviewRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public Review getOldReview() {
        return oldReview;
    }

    public LiveData<Bitmap> getImage() {
        return image;
    }

    public LiveData<Boolean> isUploadInProgress() {
        return isUploadInProgress;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() == null) {
            event.setValue(new Event.NavigateBack());
        }
    }

    public void onTitleChange(String text) {
        title = text.trim();
    }

    public void onContentChange(String text) {
        content = text.trim();
    }

    public void onOkClick() {

        // 이미 업로드 중이면 리턴한다
        Boolean isUploadInProgressValue = isUploadInProgress.getValue();
        if (isUploadInProgressValue == null || isUploadInProgressValue) {
            return;
        }

        if (title.isEmpty() || content.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        // DB 에서 리뷰를 변경한다

        isUploadInProgress.setValue(true);

        reviewRepository.updateReview(oldReview.getId(),
                title, content,
                unused -> event.setValue(new Event.NavigateBackWithResult(true)),
                e -> {
                    e.printStackTrace();
                    event.setValue(new Event.ShowGeneralMessage("업로드에 실패했습니다"));
                    isUploadInProgress.setValue(false);
                });
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;
            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }
    }

}