package com.penelope.campingtravel.ui.home.mypage.setprivacy;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentSetPrivacyBinding;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;
import com.penelope.campingtravel.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SetPrivacyFragment extends AuthListenerFragment {

    private FragmentSetPrivacyBinding binding;
    private SetPrivacyViewModel viewModel;


    public SetPrivacyFragment() {
        super(R.layout.fragment_set_privacy);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSetPrivacyBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SetPrivacyViewModel.class);

        // 기존 회원정보를 에딧 텍스트에 기입한다
        binding.editTextName.setText(viewModel.getUserData().getName());
        binding.editTextPhone.setText(viewModel.getUserData().getPhone());

        // 이름, 전화번호가 변경되면 뷰모델에 통보한다
        binding.editTextName.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onNameChange(text);
            }
        });
        binding.editTextPhone.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPhoneChange(text);
            }
        });

        // 확인 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonOk.setOnClickListener(v -> viewModel.onOkClick());

        // 업데이트가 진행중이면 로딩바를 보인다
        viewModel.isUpdateInProgress().observe(getViewLifecycleOwner(), isUpdateInProgress ->
                binding.progressBar3.setVisibility(isUpdateInProgress ? View.VISIBLE : View.INVISIBLE));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SetPrivacyViewModel.Event.NavigateBack) {
                // 이전 화면으로 되돌아간다
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SetPrivacyViewModel.Event.NavigateBackWithResult) {
                // 결과값을 설정한 후 이전 화면으로 되돌아간다
                boolean success = ((SetPrivacyViewModel.Event.NavigateBackWithResult) event).success;
                Bundle result = new Bundle();
                result.putBoolean("success", success);
                getParentFragmentManager().setFragmentResult("set_privacy_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof SetPrivacyViewModel.Event.ShowGeneralMessage) {
                // 뷰모델에서 보낸 메세지를 토스트로 보인다
                String message = ((SetPrivacyViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

}