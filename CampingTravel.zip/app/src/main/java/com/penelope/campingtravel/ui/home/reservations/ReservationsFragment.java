package com.penelope.campingtravel.ui.home.reservations;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentReservationsBinding;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ReservationsFragment extends Fragment {

    private FragmentReservationsBinding binding;
    private ReservationsViewModel viewModel;


    public ReservationsFragment() {
        super(R.layout.fragment_reservations);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentReservationsBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ReservationsViewModel.class);

        binding.recyclerReservation.setHasFixedSize(true);

        // 예약 목록을 리사이클러 뷰에 표시한다
        viewModel.getCovidStatistic().observe(getViewLifecycleOwner(), covidStatistic -> {
            viewModel.getCampMap().observe(getViewLifecycleOwner(), campMap -> {
                // 예약 목록 어댑터를 생성하고 리사이클러 뷰에 연결한다
                ReservationsAdapter adapter = new ReservationsAdapter(campMap, covidStatistic);
                binding.recyclerReservation.setAdapter(adapter);

                viewModel.getReservations().observe(getViewLifecycleOwner(), reservations -> {
                    if (reservations != null) {
                        adapter.submitList(reservations);
                        binding.textViewNoReservations.setVisibility(reservations.isEmpty() ? View.VISIBLE : View.INVISIBLE);
                    }
                    binding.progressBar5.setVisibility(View.INVISIBLE);
                });
            });
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ReservationsViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

}