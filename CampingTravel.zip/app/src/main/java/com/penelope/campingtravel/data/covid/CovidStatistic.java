package com.penelope.campingtravel.data.covid;

import java.util.HashMap;
import java.util.Map;

// 전국 코로나 통계 데이터

public class CovidStatistic {

    public final Map<String, CovidData> contents;      // 지역명-통계 맵
    public final CovidData total;                      // 전국 합계 데이터

    public CovidStatistic(Map<String, CovidData> contents, CovidData total) {
        this.contents = contents;
        this.total = total;
    }

    public Map<String, Double> getDistributions() {

        Map<String, Double> map = new HashMap<>();

        for (Map.Entry<String, CovidData> data : contents.entrySet()) {
            int increment = data.getValue().increment;
            double distribution = total.increment == 0 ? 0 : (double) increment / total.increment;
            map.put(data.getKey(), distribution);
        }

        return map;
    }

    @Override
    public String toString() {
        return "CovidStatistic{" +
                "contents=" + contents +
                ", total=" + total +
                '}';
    }
}
