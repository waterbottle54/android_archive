package com.penelope.campingtravel.data.weather;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.penelope.campingtravel.api.weather.WeatherApi;

import java.util.List;

import javax.inject.Inject;

// 날씨 정보를 API 를 이용해 접근하는 저장소

public class WeatherRepository {

    @Inject
    public WeatherRepository() {
    }

    public LiveData<List<HourlyWeather>> getHourly(String region) {
        MutableLiveData<List<HourlyWeather>> weathers = new MutableLiveData<>();
        new Thread(() -> {
            // 시간별 날씨를 조회한다
            weathers.postValue(WeatherApi.getHourly(region));
        }).start();
        return weathers;
    }

    public LiveData<List<DailyWeather>> getDaily(String region) {
        MutableLiveData<List<DailyWeather>> weathers = new MutableLiveData<>();
        new Thread(() -> {
            // 일별 날씨를 조회한다
            weathers.postValue(WeatherApi.getDaily(region));
        }).start();
        return weathers;
    }

}
