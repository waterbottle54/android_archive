package com.penelope.campingtravel.ui.home.camps;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.RequestManager;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.databinding.CampItemBinding;
import com.penelope.campingtravel.utils.Consts;

public class CampsAdapter extends ListAdapter<Camp, CampsAdapter.CampViewHolder> {

    class CampViewHolder extends RecyclerView.ViewHolder {

        private final CampItemBinding binding;

        public CampViewHolder(CampItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Camp model) {

            // 캠프 이름 표시
            binding.textViewCampName.setText(model.getName());

            // 주소 표시
            binding.textViewCampAddress.setVisibility(model.getAddress() != null ? View.VISIBLE : View.INVISIBLE);
            if (model.getAddress() != null) {
                binding.textViewCampAddress.setText(model.getAddress());
            }

            // 전화번호 표시
            binding.textViewCampPhone.setVisibility(model.getPhone() != null ? View.VISIBLE : View.INVISIBLE);
            if (model.getPhone() != null) {
                binding.textViewCampPhone.setText(model.getPhone());
            }

            // 이미지 표시
            if (model.getImageUrl() != null) {
                requestManager.load(model.getImageUrl())
                        .into(binding.imageViewCampImage);
            } else {
                requestManager.load(Consts.URL_CAMPING_EMPTY_IMAGE)
                        .into(binding.imageViewCampImage);
            }
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final RequestManager requestManager;


    public CampsAdapter(RequestManager requestManager) {
        super(new DiffUtilCallback());
        this.requestManager = requestManager;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public CampViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        CampItemBinding binding = CampItemBinding.inflate(layoutInflater, parent, false);
        return new CampViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull CampViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Camp> {

        @Override
        public boolean areItemsTheSame(@NonNull Camp oldItem, @NonNull Camp newItem) {
            return oldItem.getName().equals(newItem.getName());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Camp oldItem, @NonNull Camp newItem) {
            return oldItem.equals(newItem);
        }
    }

}