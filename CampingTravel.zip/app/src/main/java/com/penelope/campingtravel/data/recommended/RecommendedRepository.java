package com.penelope.campingtravel.data.recommended;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.penelope.campingtravel.api.recommended.RecommendedApi;

import java.util.List;

import javax.inject.Inject;

// 추천 캠핑을 가져오는 저장소

public class RecommendedRepository {

    @Inject
    public RecommendedRepository() {
    }

    public LiveData<List<Recommended>> get() {

        MutableLiveData<List<Recommended>> recommendedList = new MutableLiveData<>();
        new Thread(() -> {
            List<Recommended> list = RecommendedApi.get();
            recommendedList.postValue(list);
        }).start();
        return recommendedList;
    }


}
