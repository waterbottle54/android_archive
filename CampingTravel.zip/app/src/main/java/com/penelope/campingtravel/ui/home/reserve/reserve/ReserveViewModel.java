package com.penelope.campingtravel.ui.home.reserve.reserve;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.data.camp.Camp;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ReserveViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final Camp camp;


    @Inject
    public ReserveViewModel(SavedStateHandle savedStateHandle) {

        camp = savedStateHandle.get("camp");
        assert camp != null;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public Camp getCamp() {
        return camp;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

    }

    public void onReserveClick() {
        event.setValue(new Event.PromptReservationPeriod(camp));
    }

    public void onReserveResult(boolean success) {
        if (success) {
            event.setValue(new Event.ShowGeneralMessage("예약이 완료되었습니다"));
        }
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class PromptReservationPeriod extends Event {
            public final Camp camp;
            public PromptReservationPeriod(Camp camp) {
                this.camp = camp;
            }
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }
    }

}



