package com.penelope.campingtravel.ui.home.quickcheck;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.penelope.campingtravel.data.reservation.ReservationRepository;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class QuickCheckViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String name = "";
    private String phone = "";


    @Inject
    public QuickCheckViewModel() {
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    public void onNameChange(String text) {
        name = text.trim();
    }

    public void onPhoneChange(String text) {
        phone = text.trim();
    }

    public void onQuickCheckClick() {

        if (name.isEmpty() || phone.isEmpty()) {
            event.setValue(new Event.ShowGeneralMessage("모두 입력해주세요"));
            return;
        }

        event.setValue(new Event.NavigateToReservationsScreen(name, phone));
    }


    public static class Event {

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToReservationsScreen extends Event {
            public final String name;
            public final String phone;
            public NavigateToReservationsScreen(String name, String phone) {
                this.name = name;
                this.phone = phone;
            }
        }
    }

}









