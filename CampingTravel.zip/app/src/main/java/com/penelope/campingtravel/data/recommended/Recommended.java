package com.penelope.campingtravel.data.recommended;

import java.util.Objects;

// 추천 여행지 정보

public class Recommended {

    private final String title;     // 여행지 소개 제목
    private final String content;   // 여행지 소개 내용
    private final String imageUrl;  // 여행지 이미지 url
    private final String url;       // 여행지 홈페이지 url

    public Recommended(String title, String content, String imageUrl, String url) {
        this.title = title;
        this.content = content;
        this.imageUrl = imageUrl;
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getUrl() {
        return url;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Recommended that = (Recommended) o;
        return title.equals(that.title) && content.equals(that.content) && imageUrl.equals(that.imageUrl) && url.equals(that.url);
    }

    @Override
    public int hashCode() {
        return Objects.hash(title, content, imageUrl, url);
    }

}
