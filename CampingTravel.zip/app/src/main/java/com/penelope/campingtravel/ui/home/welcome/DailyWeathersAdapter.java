package com.penelope.campingtravel.ui.home.welcome;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.campingtravel.R;
import com.penelope.campingtravel.data.weather.DailyWeather;
import com.penelope.campingtravel.databinding.DailyWeatherItemBinding;

import java.util.Locale;

public class DailyWeathersAdapter extends ListAdapter<DailyWeather, DailyWeathersAdapter.DailyWeatherViewHolder> {

    class DailyWeatherViewHolder extends RecyclerView.ViewHolder {

        private final DailyWeatherItemBinding binding;

        public DailyWeatherViewHolder(DailyWeatherItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(DailyWeather model) {

            // 요일 표시
            binding.textViewDailyWeatherName.setText(model.getName());

            // 최저온도 표시
            String strMinTemperature = String.format(Locale.getDefault(), "%d˚", model.getMinTemperature());
            binding.textViewDailyWeatherMinTemperature.setText(strMinTemperature);

            // 최고온도 표시
            String strMaxTemperature = String.format(Locale.getDefault(), "%d˚", model.getMaxTemperature());
            binding.textViewDailyWeatherMaxTemperature.setText(strMaxTemperature);

            // 아이콘 표시
            switch (model.getWeatherType()) {
                case CLOUDY:
                    binding.imageViewDailyWeatherIcon.setImageResource(R.drawable.cloudy);
                    break;
                case SUNNY_CLOUDY:
                    binding.imageViewDailyWeatherIcon.setImageResource(R.drawable.sunny_cloudy);
                    break;
                case SUNNY:
                    binding.imageViewDailyWeatherIcon.setImageResource(R.drawable.sunny);
                    break;
                case RAINY:
                    binding.imageViewDailyWeatherIcon.setImageResource(R.drawable.rainy);
                    break;
                case SOMETIMES_RAINY:
                    binding.imageViewDailyWeatherIcon.setImageResource(R.drawable.sometimes_rainy);
                    break;
            }
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public DailyWeathersAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public DailyWeatherViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        DailyWeatherItemBinding binding = DailyWeatherItemBinding.inflate(layoutInflater, parent, false);
        return new DailyWeatherViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DailyWeatherViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<DailyWeather> {

        @Override
        public boolean areItemsTheSame(@NonNull DailyWeather oldItem, @NonNull DailyWeather newItem) {
            return oldItem.getName().equals(newItem.getName());
        }

        @Override
        public boolean areContentsTheSame(@NonNull DailyWeather oldItem, @NonNull DailyWeather newItem) {
            return oldItem.equals(newItem);
        }
    }

}