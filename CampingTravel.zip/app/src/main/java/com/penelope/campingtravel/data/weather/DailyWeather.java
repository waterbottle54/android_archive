package com.penelope.campingtravel.data.weather;

// 일별 날씨 정보

import java.util.Objects;

// 일일 날씨 정보

public class DailyWeather {

    private final String name;              // 요일명
    private final int maxTemperature;       // 최고기온
    private final int minTemperature;       // 최저기온
    private final WeatherType weatherType;  // 날씨 타입 (ex. 맑음)

    public DailyWeather(String name, int maxTemperature, int minTemperature, WeatherType weatherType) {
        this.name = name;
        this.maxTemperature = maxTemperature;
        this.minTemperature = minTemperature;
        this.weatherType = weatherType;
    }

    public String getName() {
        return name;
    }

    public int getMaxTemperature() {
        return maxTemperature;
    }

    public int getMinTemperature() {
        return minTemperature;
    }

    public WeatherType getWeatherType() {
        return weatherType;
    }

    @Override
    public String toString() {
        return "DailyWeather{" +
                "name='" + name + '\'' +
                ", maxTemperature=" + maxTemperature +
                ", minTemperature=" + minTemperature +
                ", weatherType=" + weatherType +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        DailyWeather that = (DailyWeather) o;
        return maxTemperature == that.maxTemperature && minTemperature == that.minTemperature && name.equals(that.name) && weatherType == that.weatherType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, maxTemperature, minTemperature, weatherType);
    }
}
