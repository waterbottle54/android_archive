package com.penelope.campingtravel.ui.home.review.addreview;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentAddReviewBinding;
import com.penelope.campingtravel.utils.BitmapUtils;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;
import com.penelope.campingtravel.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class AddReviewFragment extends AuthListenerFragment {

    private FragmentAddReviewBinding binding;
    private AddReviewViewModel viewModel;

    private ActivityResultLauncher<Intent> imageActivityLauncher;
    private ActivityResultLauncher<String[]> requestPermissionLauncher;


    public AddReviewFragment() {
        super(R.layout.fragment_add_review);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        imageActivityLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK
                            && result.getData() != null) {
                        // 비트맵 획득
                        Bitmap bitmap = null;
                        if (result.getData().getExtras() != null) {
                            // 카메라 결과 획득
                            bitmap = (Bitmap) result.getData().getExtras().get("data");
                        } else {
                            // 갤러리(포토) 결과 획득
                            Uri uri = result.getData().getData();
                            if (uri != null) {
                                String path = BitmapUtils.getRealPathFromUri(requireContext(), uri);
                                bitmap = BitmapUtils.getBitmapFromPath(path);
                            }
                        }
                        viewModel.onImageSelected(bitmap);
                    }
                }
        );

        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    Boolean permissionExternalStorage = result.get(Manifest.permission.READ_EXTERNAL_STORAGE);
                    Boolean permissionCamera = result.get(Manifest.permission.CAMERA);

                    if (permissionExternalStorage != null && permissionExternalStorage
                            && permissionCamera != null && permissionCamera) {
                        showImageDialog();
                    }
                }
        );
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentAddReviewBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(AddReviewViewModel.class);

        // 제목, 내용 에딧텍스트가 변경되면 뷰모델에 통보한다
        binding.editTextTitle.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onTitleChange(text);
            }
        });
        binding.editTextContent.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onContentChange(text);
            }
        });

        // 버튼이 클릭되면 뷰모델에 통보한다
        binding.imageButtonUploadImage.setOnClickListener(v -> viewModel.onUploadImageClick());
        binding.buttonOk.setOnClickListener(v -> viewModel.onOkClick());

        // 선택된 이미지를 띄운다
        viewModel.getImage().observe(getViewLifecycleOwner(), image ->
                binding.imageViewUploaded.setImageBitmap(image));

        // 업로드가 진행중이면 로딩 바를 보인다
        viewModel.isUploadInProgress().observe(getViewLifecycleOwner(), isUploadInProgress ->
                binding.progressBar3.setVisibility(isUploadInProgress ? View.VISIBLE : View.INVISIBLE));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof AddReviewViewModel.Event.NavigateBack) {
                // 이전 화면으로 되돌아간다
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof AddReviewViewModel.Event.PromptImage) {
                // 이미지를 선택받는다
                promptImage();
            } else if (event instanceof AddReviewViewModel.Event.NavigateBackWithResult) {
                // 결과값을 설정하고 이전 화면으로 되돌아간다
                boolean success = ((AddReviewViewModel.Event.NavigateBackWithResult) event).success;
                Bundle result = new Bundle();
                result.putBoolean("success", success);
                getParentFragmentManager().setFragmentResult("add_review_fragment", result);
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    private void promptImage() {

        if (requireContext().checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && requireContext().checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            showImageDialog();
        } else {
            requestPermissionLauncher.launch(
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.CAMERA}
            );
        }
    }

    private void showImageDialog() {

        // 업로드 방법 선택 대화상자 보이기
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        Intent chooser = Intent.createChooser(galleryIntent, "사진 업로드");
        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        imageActivityLauncher.launch(chooser);
    }

}