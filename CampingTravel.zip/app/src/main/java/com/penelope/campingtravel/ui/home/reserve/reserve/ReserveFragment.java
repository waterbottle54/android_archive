package com.penelope.campingtravel.ui.home.reserve.reserve;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.naver.maps.geometry.LatLng;
import com.naver.maps.map.CameraUpdate;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.Marker;
import com.penelope.campingtravel.R;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.databinding.FragmentReserveBinding;
import com.penelope.campingtravel.utils.Consts;
import com.penelope.campingtravel.utils.ui.AuthListenerFragment;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ReserveFragment extends AuthListenerFragment implements OnMapReadyCallback {

    private FragmentReserveBinding binding;
    private ReserveViewModel viewModel;


    public ReserveFragment() {
        super(R.layout.fragment_reserve);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentReserveBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ReserveViewModel.class);

        // 캠프 정보를 UI 에 띄운다
        binding.textViewCampName.setText(viewModel.getCamp().getName());
        binding.textViewCampAddress.setText(viewModel.getCamp().getAddress());
        binding.textViewCampPhone.setText(viewModel.getCamp().getPhone());

        // 글램핑, 카라반 수를 보인다
        String strGlampingCount = String.format(Locale.getDefault(),
                "글램핑 %d개소", viewModel.getCamp().getGlampingCount());
        binding.textViewCampGlampCount.setText(strGlampingCount);

        String strCaravanCount = String.format(Locale.getDefault(),
                "카라반 %d개소", viewModel.getCamp().getCaravCount());
        binding.textViewCampCaravanCount.setText(strCaravanCount);

        // 캠핑 이미지를 보인다
        if (viewModel.getCamp().getImageUrl() != null) {
            Glide.with(this)
                    .load(viewModel.getCamp().getImageUrl())
                    .into(binding.imageViewCamp);
        } else {
            Glide.with(this)
                    .load(Consts.URL_CAMPING_EMPTY_IMAGE)
                    .into(binding.imageViewCamp);
        }

        // 네이버 맵을 준비한다
        MapFragment mapFragment = (MapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonReserve.setOnClickListener(v -> viewModel.onReserveClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ReserveViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            } else if (event instanceof ReserveViewModel.Event.PromptReservationPeriod) {
                // 예약 기간을 입력받는 화면으로 이동한다
                Camp camp = ((ReserveViewModel.Event.PromptReservationPeriod) event).camp;
                NavDirections navDirections = ReserveFragmentDirections.actionReserveFragmentToSetPeriodFragment(camp);
                Navigation.findNavController(requireView()).navigate(navDirections);
            } else if (event instanceof ReserveViewModel.Event.ShowGeneralMessage) {
                String message = ((ReserveViewModel.Event.ShowGeneralMessage) event).message;
                Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
            }
        });

        // 예약 결과를 뷰모델에 통보한다
        getParentFragmentManager().setFragmentResultListener("set_period_fragment", getViewLifecycleOwner(),
                (requestKey, result) -> {
                    boolean success = result.getBoolean("success");
                    viewModel.onReserveResult(success);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        binding = null;
    }

    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        viewModel.onAuthStateChanged(firebaseAuth);
    }

    @Override
    public void onMapReady(@NonNull NaverMap naverMap) {

        // 네이버 맵에 캠핑장의 위치를 표시하고 시점을 옮긴다
        LatLng latLng = new LatLng(viewModel.getCamp().getLatitude(), viewModel.getCamp().getLongitude());

        Marker marker = new Marker(latLng);
        marker.setMap(naverMap);

        naverMap.moveCamera(CameraUpdate.scrollAndZoomTo(latLng, 15.0));
    }

    public void showReservationPeriodDialog(Camp camp) {


    }

}










