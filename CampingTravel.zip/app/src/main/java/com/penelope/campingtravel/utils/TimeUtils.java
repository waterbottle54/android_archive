package com.penelope.campingtravel.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;

public class TimeUtils {

    // 시간(밀리초)를 연.월.일 문자열로 바꾼다

    public static String getDateString(LocalDate date) {
        return String.format(Locale.getDefault(), "%d-%02d-%02d",
                date.getYear(),
                date.getMonthValue(),
                date.getDayOfMonth()
        );
    }

    public static String getDateString(long millis) {
        LocalDate ld = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
        return getDateString(ld);
    }

    // 시간(밀리초)를 시:분 문자열로 바꾼다

    public static String getTimeString(long millis) {

        LocalDateTime ldt = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDateTime();
        boolean isMorning = ldt.getHour() < 12;

        return String.format(Locale.getDefault(), "%s %02d:%02d",
                isMorning ? "오전" : "오후",
                ldt.getHour() == 12 ? 12 : ldt.getHour() % 12,
                ldt.getMinute()
        );
    }

    public static LocalDate getLocalDate(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
    }

}
