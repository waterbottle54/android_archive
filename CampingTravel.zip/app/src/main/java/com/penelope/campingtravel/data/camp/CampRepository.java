package com.penelope.campingtravel.data.camp;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.penelope.campingtravel.api.camp.FindCampApi;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class CampRepository {

    private final FindCampApi findCampApi;

    @Inject
    public CampRepository(FindCampApi findCampApi) {
        this.findCampApi = findCampApi;
    }

    public void getCamps(String query, OnSuccessListener<List<Camp>> onSuccessListener, OnFailureListener onFailureListener) {

        findCampApi.get(query, onSuccessListener, onFailureListener);
    }

    public void getCamp(String id, String name, OnSuccessListener<Camp> onSuccessListener, OnFailureListener onFailureListener) {

        getCamps(name,
                camps -> {
                    if (camps == null) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    for (Camp camp : camps) {
                        if (camp.getId().equals(id)) {
                            onSuccessListener.onSuccess(camp);
                            return;
                        }
                    }
                    onSuccessListener.onSuccess(null);
                },
                onFailureListener);
    }

    public LiveData<Camp> getCamp(String id, String name) {
        MutableLiveData<Camp> camp = new MutableLiveData<>();
        getCamp(id, name, camp::setValue, e -> camp.setValue(null));
        return camp;
    }

    public LiveData<List<Camp>> getRecentlyOpeningCamps() {

        MutableLiveData<List<Camp>> camps = new MutableLiveData<>();
        findCampApi.get(1000, campList -> {
            List<Camp> filtered = new ArrayList<>();
            for (Camp camp : campList) {
                LocalDate openDate = camp.getOpenDate();
                if (openDate != null
                        && openDate.isAfter(LocalDate.now())
                        && openDate.isBefore(LocalDate.now().plusMonths(1))) {
                    filtered.add(camp);
                }
            }
            camps.setValue(filtered);
        }, e -> camps.setValue(null));
        return camps;
    }

    public LiveData<Map<String, Camp>> getCampMap(List<String> campIdList, List<String> campNameList) {

        MutableLiveData<Map<String, Camp>> map = new MutableLiveData<>(new HashMap<>());

        for (int i = 0; i < campIdList.size(); i++) {
            String campId = campIdList.get(i);
            String campName = campNameList.get(i);
            getCamp(campId, campName,
                    camp -> {
                        Map<String, Camp> oldMap = map.getValue();
                        assert oldMap != null;
                        Map<String, Camp> newMap = new HashMap<>(oldMap);
                        newMap.put(camp.getId(), camp);
                        map.setValue(newMap);
                    },
                    Throwable::printStackTrace);
        }

        return map;
    }

}








