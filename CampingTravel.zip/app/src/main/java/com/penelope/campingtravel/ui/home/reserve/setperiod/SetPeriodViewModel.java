package com.penelope.campingtravel.ui.home.reserve.setperiod;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.google.firebase.auth.FirebaseAuth;
import com.penelope.campingtravel.data.camp.Camp;
import com.penelope.campingtravel.data.reservation.Reservation;
import com.penelope.campingtravel.data.reservation.ReservationRepository;

import java.time.LocalDate;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SetPeriodViewModel extends ViewModel implements FirebaseAuth.AuthStateListener {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<String> uid = new MutableLiveData<>();

    private final Camp camp;

    private final MutableLiveData<LocalDate> startDate = new MutableLiveData<>();
    private final MutableLiveData<LocalDate> endDate = new MutableLiveData<>();

    private String name = "";
    private String phone = "";

    private final MutableLiveData<Boolean> isUploadInProgress = new MutableLiveData<>(false);

    private final ReservationRepository reservationRepository;


    @Inject
    public SetPeriodViewModel(SavedStateHandle savedStateHandle, ReservationRepository reservationRepository) {

        camp = savedStateHandle.get("camp");

        this.reservationRepository = reservationRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<LocalDate> getStartDate() {
        return startDate;
    }

    public LiveData<LocalDate> getEndDate() {
        return endDate;
    }

    public LiveData<String> getUid() {
        return uid;
    }

    public LiveData<Boolean> isUploadInProgress() {
        return isUploadInProgress;
    }


    @Override
    public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
        if (firebaseAuth.getCurrentUser() != null) {
            uid.setValue(firebaseAuth.getCurrentUser().getUid());
        } else {
            uid.setValue(null);
        }
    }

    public void onStartDateClick() {

        LocalDate startDateValue = startDate.getValue();
        if (startDateValue == null) {
            startDateValue = LocalDate.now().plusDays(1);
        }

        event.setValue(new Event.PromptDate(true, startDateValue));
    }

    public void onEndDateClick() {

        if (startDate.getValue() == null) {
            event.setValue(new Event.ShowGeneralMessage("시작일을 먼저 설정해주세요"));
            return;
        }

        LocalDate endDateValue = endDate.getValue();
        if (endDateValue == null) {
            endDateValue = startDate.getValue();
        }

        event.setValue(new Event.PromptDate(false, endDateValue));
    }

    public void onDateSelected(boolean startOrEnd, LocalDate date) {

        if (startOrEnd) {
            if (date.isAfter(LocalDate.now())) {
                startDate.setValue(date);
            } else {
                event.setValue(new Event.ShowGeneralMessage("내일부터 예약할 수 있습니다"));
            }
        } else {
            LocalDate startDateValue = startDate.getValue();
            if (!date.isBefore(startDateValue)) {
                endDate.setValue(date);
            } else {
                event.setValue(new Event.ShowGeneralMessage("올바른 날짜를 입력해주세요"));
            }
        }
    }

    public void onNameChange(String text) {
        name = text.trim();
    }

    public void onPhoneChange(String text) {
        phone = text.trim();
    }

    public void onReserveClick() {

        Boolean isUploadInProgressValue = isUploadInProgress.getValue();
        assert isUploadInProgressValue != null;
        if (isUploadInProgressValue) {
            return;
        }

        LocalDate startDateValue = startDate.getValue();
        LocalDate endDateValue = endDate.getValue();

        if (startDateValue == null || endDateValue == null) {
            event.setValue(new Event.ShowGeneralMessage("날짜를 입력해주세요"));
            return;
        }

        if (uid.getValue() == null) {
            if (name.isEmpty() || phone.isEmpty()) {
                event.setValue(new Event.ShowGeneralMessage("예약자 정보를 입력해주세요"));
                return;
            }
        }

        Reservation reservation;
        if (uid.getValue() != null) {
            reservation = new Reservation(uid.getValue(), camp.getId(), camp.getName(),
                    startDateValue.toEpochDay() * 86400000, endDateValue.toEpochDay() * 86400000);
        } else {
            reservation = new Reservation(name, phone, camp.getId(), camp.getName(),
                    startDateValue.toEpochDay() * 86400000, endDateValue.toEpochDay() * 86400000);
        }

        isUploadInProgress.setValue(true);

        reservationRepository.addReservation(reservation,
                unused -> {
                    isUploadInProgress.setValue(false);
                    event.setValue(new Event.NavigateBackWithResult(true));
                },
                e -> {
                    isUploadInProgress.setValue(false);
                    event.setValue(new Event.ShowGeneralMessage("예약 정보 업로드에 실패했습니다"));
                });
    }


    public static class Event {

        public static class NavigateBack extends Event {
        }

        public static class PromptDate extends Event {
            public final boolean startOrEnd;
            public final LocalDate date;

            public PromptDate(boolean startOrEnd, LocalDate date) {
                this.startOrEnd = startOrEnd;
                this.date = date;
            }
        }

        public static class ShowGeneralMessage extends Event {
            public final String message;
            public ShowGeneralMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final boolean success;
            public NavigateBackWithResult(boolean success) {
                this.success = success;
            }
        }

    }

}






