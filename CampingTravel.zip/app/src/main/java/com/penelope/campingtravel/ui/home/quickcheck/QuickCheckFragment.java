package com.penelope.campingtravel.ui.home.quickcheck;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.penelope.campingtravel.R;
import com.penelope.campingtravel.databinding.FragmentQuickCheckBinding;
import com.penelope.campingtravel.utils.ui.OnTextChangeListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class QuickCheckFragment extends Fragment {

    private FragmentQuickCheckBinding binding;
    private QuickCheckViewModel viewModel;


    public QuickCheckFragment() {
        super(R.layout.fragment_quick_check);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentQuickCheckBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(QuickCheckViewModel.class);

        // 개인정보 입력값 변경시 뷰모델에 통보한다
        binding.editTextCustomerName.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onNameChange(text);
            }
        });
        binding.editTextCustomerPhone.addTextChangedListener(new OnTextChangeListener() {
            @Override
            public void onTextChange(String text) {
                viewModel.onPhoneChange(text);
            }
        });

        // 조회 버튼 클릭 시 뷰모델에 통보한다
        binding.buttonQuickCheck.setOnClickListener(v -> viewModel.onQuickCheckClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof QuickCheckViewModel.Event.NavigateToReservationsScreen) {
                // 예약 목록 화면으로 이동한다
                String name = ((QuickCheckViewModel.Event.NavigateToReservationsScreen) event).name;
                String phone = ((QuickCheckViewModel.Event.NavigateToReservationsScreen) event).phone;
                NavDirections navDirections = QuickCheckFragmentDirections.actionGlobalReservationsFragment(null, name, phone);
                Navigation.findNavController(requireView()).navigate(navDirections);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}