package com.penelope.campingtravel.data.review;

// 리뷰 정보 클래스

import java.io.Serializable;

public class Review implements Serializable {

    private String id;          // 리뷰 고유 아이디
    private String uid;         // 작성자 uid
    private String title;       // 제목
    private String content;     // 내용
    private long created;       // 작성시간


    public Review() {
    }

    public Review(String uid, String title, String content) {
        this.uid = uid;
        this.title = title;
        this.content = content;
        this.created = System.currentTimeMillis();
        this.id = uid + "_" + created;
    }

    public String getId() {
        return id;
    }

    public String getUid() {
        return uid;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public long getCreated() {
        return created;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setCreated(long created) {
        this.created = created;
    }

}
