package com.penelope.campingtravel.data.covid;

// 단일 지역 코로나 집계 데이터

public class CovidData {

    public final int accumulation;   // 누적 확진자수
    public final int increment;      // 일일 신규 확진자수
    public final int death;          // 누적 사망자수

    public CovidData(int accumulation, int increment, int death) {
        this.accumulation = accumulation;
        this.increment = increment;
        this.death = death;
    }

    @Override
    public String toString() {
        return "CovidData{" +
                "accumulation=" + accumulation +
                ", increment=" + increment +
                ", death=" + death +
                '}';
    }
}
