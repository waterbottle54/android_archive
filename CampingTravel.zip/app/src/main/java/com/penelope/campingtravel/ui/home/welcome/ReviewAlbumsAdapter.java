package com.penelope.campingtravel.ui.home.welcome;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.penelope.campingtravel.databinding.ReviewAlbumItemBinding;

import java.util.Map;

public class ReviewAlbumsAdapter extends ListAdapter<Map.Entry<String, Bitmap>, ReviewAlbumsAdapter.ReviewAlbumViewHolder> {

    class ReviewAlbumViewHolder extends RecyclerView.ViewHolder {

        private final ReviewAlbumItemBinding binding;

        public ReviewAlbumViewHolder(ReviewAlbumItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(Map.Entry<String, Bitmap> model) {
            binding.imageViewReviewImage.setImageBitmap(model.getValue());
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;


    public ReviewAlbumsAdapter() {
        super(new DiffUtilCallback());
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public ReviewAlbumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        ReviewAlbumItemBinding binding = ReviewAlbumItemBinding.inflate(layoutInflater, parent, false);
        return new ReviewAlbumViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ReviewAlbumViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<Map.Entry<String, Bitmap>> {

        @Override
        public boolean areItemsTheSame(@NonNull Map.Entry<String, Bitmap> oldItem, @NonNull Map.Entry<String, Bitmap> newItem) {
            return oldItem.getKey().equals(newItem.getKey());
        }

        @Override
        public boolean areContentsTheSame(@NonNull Map.Entry<String, Bitmap> oldItem, @NonNull Map.Entry<String, Bitmap> newItem) {
            return oldItem.equals(newItem);
        }
    }

}