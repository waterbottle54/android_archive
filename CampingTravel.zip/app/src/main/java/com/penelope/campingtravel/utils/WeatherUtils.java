package com.penelope.campingtravel.utils;

import com.penelope.campingtravel.data.weather.WeatherType;

public class WeatherUtils {

    // 날씨 묘사로부터 날씨 타입을 리턴한다

    public static WeatherType fromDescription(String description) {
        switch (description) {
            default:
            case "맑음":
                return WeatherType.SUNNY;
            case "구름많음":
                return WeatherType.SUNNY_CLOUDY;
            case "흐림":
                return WeatherType.CLOUDY;
            case "흐리고 가끔 비":
                return WeatherType.SOMETIMES_RAINY;
            case "비":
                return WeatherType.RAINY;
        }
    }
}
