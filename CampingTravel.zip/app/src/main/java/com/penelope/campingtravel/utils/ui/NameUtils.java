package com.penelope.campingtravel.utils.ui;

public class NameUtils {

    public static String getStandardDoName(String name) {
        String suffix = name.substring(name.length() - 1);
        if (suffix.equals("시") || suffix.equals("도")) {
            name = name.substring(0, name.length() - 1);
        }
        name = name.replace("충청", "충")
                .replace("전라", "전")
                .replace("경상", "경");
        return name;
    }


}
