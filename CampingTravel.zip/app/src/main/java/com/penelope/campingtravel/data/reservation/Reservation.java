package com.penelope.campingtravel.data.reservation;

import java.time.LocalDate;
import java.util.Objects;

// 예약 정보 클래스

public class Reservation {

    private String id;
    private String uid;         // 예약자 uid (회원일 시)
    private String name;        // 예약자 이름 (비회원일 시)
    private String phone;       // 예약자 연락처 (비회원일 시)
    private String campId;      // 캠핑장 id
    private String campName;    // 캠핑장 이름
    private long startDate;   // 예약기간 시작일
    private long endDate;     // 예약기간 종료일

    public Reservation() {
    }

    public Reservation(String uid, String campId, String campName, long startDate, long endDate) {
        this.uid = uid;
        this.name = null;
        this.phone = null;
        this.campId = campId;
        this.campName = campName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.id = uid + "_" + campId + "_" + startDate;
    }

    public Reservation(String name, String phone, String campId, String campName, long startDate, long endDate) {
        this.uid = null;
        this.name = name;
        this.phone = phone;
        this.campId = campId;
        this.campName = campName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.id = name + "_" + phone + "_" + campId + "_" + startDate;
    }

    public String getId() {
        return id;
    }

    public String getUid() {
        return uid;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getCampId() {
        return campId;
    }

    public String getCampName() {
        return campName;
    }

    public long getStartDate() {
        return startDate;
    }

    public long getEndDate() {
        return endDate;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setCampId(String campId) {
        this.campId = campId;
    }

    public void setCampName(String campName) {
        this.campName = campName;
    }

    public void setStartDate(long startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(long endDate) {
        this.endDate = endDate;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reservation that = (Reservation) o;
        return startDate == that.startDate && endDate == that.endDate && id.equals(that.id) && uid.equals(that.uid) && name.equals(that.name) && phone.equals(that.phone) && campId.equals(that.campId) && campName.equals(that.campName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, uid, name, phone, campId, campName, startDate, endDate);
    }
}
