package com.penelope.campingtravel.api.camp;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;

import junit.framework.TestCase;

public class FindCampApiTest extends TestCase {


    public void testGet() {

        Context context = ApplicationProvider.getApplicationContext();

        new FindCampApi(context).get("바다야",
                campList -> System.out.println(campList.toString()),
                Throwable::printStackTrace);
    }
}