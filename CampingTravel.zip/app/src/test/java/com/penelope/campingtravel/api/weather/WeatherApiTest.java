package com.penelope.campingtravel.api.weather;

import com.penelope.campingtravel.data.weather.DailyWeather;
import com.penelope.campingtravel.data.weather.HourlyWeather;

import junit.framework.TestCase;

import java.util.List;

public class WeatherApiTest extends TestCase {

    public void testGetHourly() {

        List<HourlyWeather> weathers = WeatherApi.getHourly("창원시 성산구");
        System.out.println(weathers == null ? "null value" : weathers.toString());

    }

    public void testGetDaily() {

        List<DailyWeather> weathers = WeatherApi.getDaily("창원시 성산구");
        System.out.println(weathers == null ? "null value" : weathers.toString());
    }
}