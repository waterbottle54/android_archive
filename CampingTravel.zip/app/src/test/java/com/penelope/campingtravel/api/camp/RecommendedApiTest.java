package com.penelope.campingtravel.api.camp;

import com.penelope.campingtravel.api.recommended.RecommendedApi;
import com.penelope.campingtravel.data.recommended.Recommended;

import junit.framework.TestCase;

import java.util.List;

public class RecommendedApiTest extends TestCase {

    public void testGet() {

        List<Recommended> recommendeds = RecommendedApi.get();

        System.out.println(recommendeds == null ? "null value" : recommendeds.toString());

    }
}