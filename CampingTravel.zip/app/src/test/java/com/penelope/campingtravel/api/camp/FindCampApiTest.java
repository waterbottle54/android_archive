package com.penelope.campingtravel.api.camp;

import com.penelope.campingtravel.data.camp.Camp;

import junit.framework.TestCase;

import org.junit.Before;

import java.util.List;

public class FindCampApiTest extends TestCase {

    public void testGet()

    }

}