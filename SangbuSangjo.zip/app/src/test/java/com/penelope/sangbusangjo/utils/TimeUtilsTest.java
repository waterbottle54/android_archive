package com.penelope.sangbusangjo.utils;

import junit.framework.TestCase;

import java.time.LocalDate;

public class TimeUtilsTest extends TestCase {

    public void testGetMonday() {

    }

}