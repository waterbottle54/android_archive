package com.penelope.sangbusangjo.brs;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.penelope.sangbusangjo.data.alarm.Alarm;
import com.penelope.sangbusangjo.services.AlarmService;

// 알람 발동을 수신하는 리시버

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        // 인텐트로 전달된 알람 정보를 획득한다
        Alarm alarm = (Alarm) intent.getSerializableExtra("alarm");
        int day = intent.getIntExtra("day", 0);

        if (alarm != null) {
            // 알람 서비스를 시작한다
            Intent serviceIntent = new Intent(context, AlarmService.class);
            serviceIntent.putExtra("alarm", alarm);
            serviceIntent.putExtra("day", day);
            context.startForegroundService(serviceIntent);
        }
    }

}