package com.penelope.sangbusangjo.services;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Icon;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.util.Log;

import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.sangbusangjo.R;
import com.penelope.sangbusangjo.SangbuSangjoApplication;
import com.penelope.sangbusangjo.data.alarm.Alarm;
import com.penelope.sangbusangjo.data.chat.Chat;
import com.penelope.sangbusangjo.data.chat.ChatRepository;
import com.penelope.sangbusangjo.data.comment.Comment;
import com.penelope.sangbusangjo.data.comment.CommentRepository;
import com.penelope.sangbusangjo.data.notice.NoticeRepository;
import com.penelope.sangbusangjo.ui.wakeup.WakeupActivity;
import com.penelope.sangbusangjo.utils.TimeUtils;
import com.penelope.sangbusangjo.utils.NameUtils;

import java.util.Locale;

public class AlarmService extends Service {

    private static final String TAG = "MessageService";
    public static final int NOTIFICATION_ID = 100;
    public static final String ACTION_ALARM_STOPPED = "alarm_stopped";

    // 알람 중지 방송 수신자
    public class StopReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            // 알람 중지 방송 수신 시, 관련 필드를 변경한다
            isAlarmStopped = true;
        }
    }

    private Alarm alarm;                                    // 인텐트로 전달된 알람 정보

    private final BroadcastReceiver stopReceiver;           // 알람 중지 방송 수신자
    private boolean isAlarmStopped;                         // 알람 중지 여부
    private long millisBegin;
    private long millisRepeat;

    private final ChatRepository chatRepository;            // 채팅방 저장소
    private final NoticeRepository noticeRepository;
    private final CommentRepository commentRepository;      // 채팅메세지 저장소

    // 생성자

    public AlarmService() {

        stopReceiver = new StopReceiver();

        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        chatRepository = new ChatRepository(firestore);
        noticeRepository = new NoticeRepository(firestore);
        commentRepository = new CommentRepository(firestore, chatRepository, noticeRepository);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        // 인텐트로 전달된 알람 정보를 획득한다
        alarm = (Alarm) intent.getSerializableExtra("alarm");
        int day = intent.getIntExtra("day", 0);

        if (alarm == null) {
            // 알람이 null 이면 서비스 종료
            stopSelf();
            return START_STICKY;
        }

        showNotification(day);

        // 알람 중지를 알리는 방송 (WakeupActivity 가 발송함) 에 대한 수신자를 등록한다
        registerReceiver(stopReceiver, new IntentFilter(ACTION_ALARM_STOPPED));

        // 메세지 발송을 위한 스레드를 시작한다
        new Thread(() -> {
            millisBegin = System.currentTimeMillis();
            while (true) {
                // 알람이 중단되었으면 스레드, 서비스를 종료한다
                if (isAlarmStopped) {
                    stopSelf();
                    break;
                }
                // 알람이 중단되지 않았으면 시간을 체크한다
                long now = System.currentTimeMillis();
                if (now - millisBegin >= 300000) {
                    // 5분이 지났으면 메세지를 송출한다
                    onTimeout();
                    break;
                }
                // 2초마다 노티피케이션 반복
                if (millisRepeat != 0) {
                    if (now - millisRepeat > 2000) {
                        showNotification(day);
                        millisRepeat = now;
                    }
                } else {
                    millisRepeat = now;
                }
            }
        }).start();

        return START_STICKY;
    }

    private void showNotification(int day) {

        // 알람 정보를 표시하는 노티피케이션을 작성한다

        // - 노티피케이션 아이콘
        Icon smallIcon = Icon.createWithResource(this, R.drawable.ic_alarm);

        // - 노티피케이션 메세지
        String content = String.format(Locale.getDefault(), "[%s] %s %s : 알람 중지하기",
                alarm.getName(),
                NameUtils.getDayName(day),
                TimeUtils.getTimeString(alarm.getMinute())
        );

        // - 노티피케이션 펜딩 인텐트 : 클릭 시 알람 중지 화면 (WakeupActivity) 을 띄운다
        Intent notificationIntent = new Intent(this, WakeupActivity.class);
        notificationIntent.putExtra("alarm", alarm);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification notification = new Notification.Builder(this,
                SangbuSangjoApplication.CHANNELS_ALARMS[alarm.getSound()])
                .setContentIntent(pendingIntent)
                .setSmallIcon(smallIcon)
                .setContentText(content)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build();

        // 노티피케이션을 띄운다
        startForeground(NOTIFICATION_ID, notification);
    }

    @Override
    public void onDestroy() {
        unregisterReceiver(stopReceiver);
        super.onDestroy();
    }

    private void onTimeout() {

        // 메세지를 송출한다 (채팅 or SMS)
        if (alarm.isChattingOrSms()) {
            sendChattingMessage();
        } else {
            sendSms();
        }
    }

    private void sendChattingMessage() {

        // 보내는 이와 받는 이를 확인한다
        String fromUid = alarm.getUserId();
        String toUid = alarm.getContact();

        // 메세지를 보낼 채팅방을 검색한다
        chatRepository.getChat(fromUid, toUid, chat -> {
            if (chat != null) {
                // 채팅방이 존재할 경우 메세지를 채팅방에 추가한다
                Comment comment = new Comment(chat.getId(), fromUid, alarm.getMessage());
                commentRepository.addComment(comment, toUid, unused -> stopSelf());
            } else {
                // 채팅방이 없는 경우 새로운 채팅방을 만든다
                Chat newChat = new Chat(fromUid, toUid);
                chatRepository.addChat(newChat, unused1 -> {
                    // 새로운 채팅방이 만들어지면 메세지를 해당 채팅방에 추가한다
                    Log.d(TAG, "chatting added");
                    Comment comment = new Comment(newChat.getId(), fromUid, alarm.getMessage());
                    commentRepository.addComment(comment, toUid, unused2 -> stopSelf());
                });
            }
        });
    }

    private void sendSms() {

        // 발송할 번호로 SMS 를 발송한다
        String phone = alarm.getContact();
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phone, null, alarm.getMessage(), null, null);

        stopSelf();
    }


    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}