package com.penelope.sangbusangjo.services;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.util.Log;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;
import com.penelope.sangbusangjo.R;
import com.penelope.sangbusangjo.SangbuSangjoApplication;
import com.penelope.sangbusangjo.data.notice.Notice;
import com.penelope.sangbusangjo.data.user.User;
import com.penelope.sangbusangjo.data.user.UserRepository;
import com.penelope.sangbusangjo.ui.auth.AuthActivity;

import java.util.Locale;
import java.util.Random;

public class NoticeService extends Service {

    private static final String TAG = "NoticeService";

    public static final int NOTIFICATION_FOREGROUND = 108;

    public static final String EXTRA_USER_ID = "com.penelope.sangbusangjo.user_id";

    private final UserRepository userRepository;
    private final CollectionReference usersCollection;

    private SharedPreferences preferences;

    private boolean noSnapshot = true;


    public NoticeService() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        userRepository = new UserRepository(firestore);
        usersCollection = firestore.collection("users");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        startForeground(NOTIFICATION_FOREGROUND, buildNotification());
        Log.d(TAG, "onStartCommand: start");

        String userId = intent.getStringExtra(EXTRA_USER_ID);

        CollectionReference noticesCollection = usersCollection
                .document(userId)
                .collection("notices");

        // 알림을 확인하고 새로운 알림이 있을 경우 notification 발송

        noticesCollection.addSnapshotListener((value, error) -> {

            boolean isChatting = preferences.getBoolean("isChatting", false);
            Log.d("TAG", "onStartCommand: isChatting : " + isChatting);

            if (value == null || error != null || isChatting) {
                Log.d(TAG, "onStartCommand: return 1");
                return;
            }

            if (noSnapshot) {
                noSnapshot = false;
                Log.d(TAG, "onStartCommand: return 2");
                return;
            }

            for (DocumentChange change : value.getDocumentChanges()) {
                if (change.getType() == DocumentChange.Type.ADDED) {
                    Log.d(TAG, "onStartCommand: recognized");
                    Notice notice = change.getDocument().toObject(Notice.class);
                    userRepository.getUserByUid(notice.getSenderId(), this::notifyNewMessage, Throwable::printStackTrace);
                }
            }
        });

        return START_STICKY;
    }

    private Notification buildNotification() {

        // 포그라운드 서비스 노티피케이션 획득

        Notification notification;

        String contentText = "상부상조";

        Intent activityIntent = new Intent(this, AuthActivity.class);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                activityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        notification = new Notification.Builder(this, SangbuSangjoApplication.CHANNEL_MESSAGE)
                .setContentIntent(pendingIntent)
                .setContentText(contentText)
                .setSmallIcon(R.drawable.ic_notify)
                .build();

        return notification;
    }

    private void notifyNewMessage(User sender) {

        // 기존 노티피케이션 취소

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.cancel(NOTIFICATION_FOREGROUND + 1);

        // 알림 노티피케이션 구성

        Notification notification;

        Intent activityIntent = new Intent(this, AuthActivity.class);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                activityIntent,
                PendingIntent.FLAG_CANCEL_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String strContent = String.format(Locale.getDefault(),
                "%s님이 메세지를 보내셨습니다", sender.getNickname());

        notification = new Notification.Builder(this, SangbuSangjoApplication.CHANNEL_MESSAGE)
                .setContentIntent(pendingIntent)
                .setContentText(strContent)
                .setSmallIcon(R.drawable.ic_notify)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build();

        notificationManager.notify(NOTIFICATION_FOREGROUND + 1,
                notification);
    }

    // 서비스 바인딩 하지 않음

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

}