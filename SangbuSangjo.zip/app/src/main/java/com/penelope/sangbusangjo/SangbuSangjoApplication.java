package com.penelope.sangbusangjo;

import android.app.AlarmManager;
import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.util.Log;

import com.penelope.sangbusangjo.brs.AlarmReceiver;
import com.penelope.sangbusangjo.data.alarm.Alarm;
import com.penelope.sangbusangjo.utils.TimeUtils;
import com.penelope.sangbusangjo.utils.UriUtils;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class SangbuSangjoApplication extends Application {

    public static final String CHANNEL_NAME = "Alarm";
    public static final String[] CHANNELS_ALARMS = {
            "com.penelope.sangbusangjo.notification_alarm0",
            "com.penelope.sangbusangjo.notification_alarm1",
            "com.penelope.sangbusangjo.notification_alarm2",
            "com.penelope.sangbusangjo.notification_alarm3",
            "com.penelope.sangbusangjo.notification_alarm4",
    };
    public static final String CHANNEL_MESSAGE = "com.penelope.sangbusangjo.notification_message";
    public static final String CHANNEL_SILENT = "com.penelope.sangbusangjo.notification_silent";
    public static final int[] SOUNDS_ALARMS = {
            R.raw.noti0, R.raw.noti1, R.raw.noti2, R.raw.noti3, R.raw.noti4
    };

    private AlarmManager alarmManager;


    @Override
    public void onCreate() {
        super.onCreate();

        // 노티피케이션 채널을 생성한다
        createNotificationChannel();

        // 알람 매니저를 획득한다
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
    }

    // notification 채널 생성

    private void createNotificationChannel() {

        // 각 알람음 별 노티피케이션 채널을 생성한다 (알람 노티피케이션 띄우기 위함)

        NotificationManager manager = getSystemService(NotificationManager.class);

        AudioAttributes audioAttributes = new AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build();

        for (int i = 0; i < 5; i++) {

            NotificationChannel channel = new NotificationChannel(
                    CHANNELS_ALARMS[i],
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );

            // 알람음 리소스를 Uri 로 구성하여 알람음으로 설정한다
            Uri soundUri = UriUtils.getResourceUri(this, SOUNDS_ALARMS[i]);
            channel.setSound(soundUri, audioAttributes);
            channel.enableVibration(true);

            manager.createNotificationChannel(channel);
        }

        // 새 메세지 노티피케이션 채널을 생성한다
        NotificationChannel messageChannel = new NotificationChannel(
                CHANNEL_MESSAGE,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
        );
        manager.createNotificationChannel(messageChannel);

        // 무음 노티피케이션
        NotificationChannel silentChannel = new NotificationChannel(
                CHANNEL_SILENT,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
        );
        manager.createNotificationChannel(silentChannel);
    }

    // 알람 매니저에 알람 등록

    public void registerAlarm(Alarm alarm) {

        // 알람 객체의 알람 정보를 참조하여 알람을 등록한다
        // 매주 체크된 요일마다 각자 알람을 등록한다

        Log.d("TAG", "registerAlarm: " + alarm.toString());

        for (int day = 0; day < alarm.getDays().length; day++) {
            if (alarm.getDays()[day]) {
                int hours = alarm.getMinute() / 60;
                int minutes = alarm.getMinute() % 60;
                LocalDateTime ldt = TimeUtils.getWeekDay(day).atTime(hours, minutes);
                long millis = 1000 * ldt.toEpochSecond(ZoneOffset.ofHours(9));
                if (millis < System.currentTimeMillis()) {
                    millis += AlarmManager.INTERVAL_DAY * 7;
                }
                Log.d("TAG", "registerAlarm: " + millis);

                // AlarmReceiver 를 타겟으로 한 Broadcast Intent 작성
                PendingIntent pendingIntent = getAlarmPendingIntent(alarm, day);

                // 매일 반복 알람 설정 (1주 간격)
                alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP, millis,
                        AlarmManager.INTERVAL_DAY * 7, pendingIntent);
            }
        }
    }

    // 알람 매니저로부터 알람 해제

    public void unregisterAlarm(Alarm alarm) {

        // 알람 객체의 정보를 참조하여 모든 알람을 해제한다
        for (int day = 0; day < 7; day++) {
            PendingIntent pendingIntent = getAlarmPendingIntent(alarm, day);
            alarmManager.cancel(pendingIntent);
        }
    }

    // 알람 발송 시 BR 에 전달될 PendingIntent 를 생성한다

    private PendingIntent getAlarmPendingIntent(Alarm alarm, int day) {

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("alarm", alarm);
        intent.putExtra("day", day);

        // 요청 코드는 알람 고유키와 알람 요일을 조합하여 생성한다
        return PendingIntent.getBroadcast(
                this, alarm.getId() * 10 + day, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

}
