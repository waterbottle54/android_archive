package com.penelope.sangbusangjo.ui.wakeup;

import androidx.appcompat.app.AppCompatActivity;

import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.penelope.sangbusangjo.brs.AlarmReceiver;
import com.penelope.sangbusangjo.data.alarm.Alarm;
import com.penelope.sangbusangjo.databinding.ActivityWakeupBinding;
import com.penelope.sangbusangjo.services.AlarmService;

// 알람 노티피케이션 클릭 시 실행되는, 알람 중지를 위한 화면

public class WakeupActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 뷰 바인딩을 실행한다
        ActivityWakeupBinding binding = ActivityWakeupBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 인텐트로 전달된 알람 정보를 획득한다
        Alarm alarm = (Alarm) getIntent().getSerializableExtra("alarm");
        if (alarm == null) {
            finish();
            return;
        }

        // 텍스트뷰에 알람 제목을 표시한다
        binding.textViewAlarmName.setText(alarm.getName());

        // 알람 끄기 버튼에 리스너를 지정한다
        binding.buttonStopAlarm.setOnClickListener(v -> {
            // 알람이 중지되었음을 알리는 방송을 송출한다 (AlarmService 가 수신함)
            Intent intent = new Intent(AlarmService.ACTION_ALARM_STOPPED);
            sendBroadcast(intent);
            // 액티비티를 종료한다
            finish();
        });
    }
}