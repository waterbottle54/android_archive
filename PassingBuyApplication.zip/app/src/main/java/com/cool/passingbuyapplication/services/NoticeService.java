package com.cool.passingbuyapplication.services;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.preference.PreferenceManager;

import com.cool.passingbuyapplication.PassingBuyApplication;
import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.data.notice.Notice;
import com.cool.passingbuyapplication.ui.MainActivity;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Locale;

public class NoticeService extends Service {

    public static final int NOTIFICATION_FOREGROUND = 100;

    public static final String EXTRA_USER_ID = "com.cool.passingbuyapplication.user_id";

    private final CollectionReference usersCollection;

    private SharedPreferences preferences;

    private boolean noSnapshot = true;


    public NoticeService() {
        usersCollection = FirebaseFirestore.getInstance().collection("users");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        startForeground(NOTIFICATION_FOREGROUND, buildNotification());

        String userId = intent.getStringExtra(EXTRA_USER_ID);

        CollectionReference noticesCollection = usersCollection
                .document(userId)
                .collection("notices");

        // 알림을 확인하고 새로운 알림이 있을 경우 notification 발송

        noticesCollection.addSnapshotListener((value, error) -> {

            boolean isNotificationOn = preferences.getBoolean("isNotificationOn", true);
            boolean isChatting = preferences.getBoolean("isChatting", false);

            if (value == null || error != null || !isNotificationOn || isChatting) {
                return;
            }

            if (noSnapshot) {
                noSnapshot = false;
                return;
            }

            for (DocumentChange change : value.getDocumentChanges()) {
                if (change.getType() == DocumentChange.Type.ADDED) {
                    Notice notice = change.getDocument().toObject(Notice.class);
                    notifyNewMessage(notice);
                }
            }
        });

        return START_STICKY;
    }

    private Notification buildNotification() {

        // 포그라운드 서비스 노티피케이션 획득

        Notification notification;

        String contentText = "패싱바이 앱 실행 중";

        Intent activityIntent = new Intent(this, MainActivity.class);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                activityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        notification = new Notification.Builder(this, PassingBuyApplication.CHANNEL_FOREGROUND)
                .setContentIntent(pendingIntent)
                .setContentText(contentText)
                .setSmallIcon(R.drawable.ic_notification)
                .build();

        return notification;
    }

    private void notifyNewMessage(Notice notice) {

        // 알림 노티피케이션 획득

        Notification notification;

        Intent activityIntent = new Intent(this, MainActivity.class);
        activityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                activityIntent,
                PendingIntent.FLAG_CANCEL_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String strContent = String.format(Locale.getDefault(),
                "%s님이 메세지를 보내셨습니다", notice.getSenderId());

        notification = new Notification.Builder(this, PassingBuyApplication.CHANNEL_NEW_MESSAGE)
                .setContentIntent(pendingIntent)
                .setContentText(strContent)
                .setSmallIcon(R.drawable.ic_notification)
                .setTicker(strContent)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .build();

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(NOTIFICATION_FOREGROUND + 1, notification);
    }

    // 서비스 바인딩 하지 않음

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}