package com.cool.passingbuyapplication.ui.board;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.post.DetailedPost;
import com.cool.passingbuyapplication.data.post.DetailedPostRepository;
import com.cool.passingbuyapplication.data.post.ErrandType;
import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class BoardViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<List<DetailedPost>> detailedPosts;


    @Inject
    public BoardViewModel(SavedStateHandle savedStateHandle, UserRepository userRepository, DetailedPostRepository detailedPostRepository) {

        Integer errandTypeInt = savedStateHandle.get("errandType");
        assert errandTypeInt != null;
        ErrandType errandType = errandTypeInt == -1 ? null : ErrandType.values()[errandTypeInt];

        String userId = userRepository.getCurrentId();
        LiveData<User> user = userRepository.getUsersLiveData(userId);

        detailedPosts = Transformations.switchMap(user, userValue ->
                detailedPostRepository.getDetailedPosts(errandType, userValue.isMale())
        );
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<DetailedPost>> getDetailedPosts() {
        return detailedPosts;
    }


    public void onPostClick(DetailedPost detailedPost) {
        event.setValue(new Event.NavigateToPostScreen(detailedPost));
    }


    public static class Event {

        public static class NavigateToPostScreen extends Event {
            public final DetailedPost detailedPost;

            public NavigateToPostScreen(DetailedPost detailedPost) {
                this.detailedPost = detailedPost;
            }
        }
    }

}
