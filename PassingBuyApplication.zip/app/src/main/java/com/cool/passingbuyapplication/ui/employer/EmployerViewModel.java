package com.cool.passingbuyapplication.ui.employer;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.post.ErrandType;
import com.cool.passingbuyapplication.data.post.GenderLimit;
import com.cool.passingbuyapplication.data.post.Post;
import com.cool.passingbuyapplication.data.post.PostRepository;
import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class EmployerViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String userId;
    private final LiveData<User> user;

    private String title = "";
    private String contents = "";
    private ErrandType errandType = ErrandType.CARRYING;    // 심부름 필터
    private LocalDate date = LocalDate.now();
    private LocalTime time = LocalTime.now();
    private GenderLimit genderLimit = GenderLimit.NONE;     // 성별 필터

    private final PostRepository postRepository;


    @Inject
    public EmployerViewModel(UserRepository userRepository, PostRepository postRepository) {

        userId = userRepository.getCurrentId();
        user = userRepository.getUsersLiveData(userId);

        this.postRepository = postRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public ErrandType getErrandType() {
        return errandType;
    }

    public LocalTime getTime() {
        return time;
    }


    // 유저 입력 처리

    public void onTitleChanged(String text) {
        this.title = text;
    }

    public void onErrandTypeChanged(ErrandType errandType) {
        this.errandType = errandType;
    }

    public void onContentsChanged(String text) {
        this.contents = text;
    }

    public void onDateChanged(long millis) {
        this.date =  Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public void onTimeChanged(int hour, int minutes) {
        this.time = LocalTime.of(hour, minutes);
    }

    public void onGenderLimitChanged(boolean sameGender) {
        if (user.getValue() == null) {
            return;
        }
        boolean isMale = user.getValue().isMale();
        if (sameGender) {
            genderLimit = isMale ? GenderLimit.MALE : GenderLimit.FEMALE;
        } else {
            genderLimit = GenderLimit.NONE;
        }
    }

    public void onDateClick() {
        long millis = LocalDateTime.of(date, LocalTime.now())
                .atZone(ZoneId.systemDefault())
                .toInstant().toEpochMilli();
        event.setValue(new Event.ShowDatePicker(millis));
    }

    public void onTimeClick() {
        event.setValue(new Event.ShowTimePicker(time));
    }

    public void onGenderClick() {
        event.setValue(new Event.ShowGenderPicker());
    }

    public void onSubmitClick() {

        if (title.trim().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("제목을 입력해주세요"));
            return;
        }
        if (contents.trim().isEmpty()) {
            event.setValue(new Event.ShowInvalidInputMessage("내용을 입력해주세요"));
            return;
        }

        long deadline = LocalDateTime.of(date, time).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        if (deadline <= System.currentTimeMillis()) {
            event.setValue(new Event.ShowInvalidInputMessage("올바른 시간을 설정해주세요"));
            return;
        }

        Post post = new Post(userId, title, contents, genderLimit, errandType, deadline);

        postRepository.addPost(post,
                unused -> event.setValue(new Event.NavigateToBoardScreen(errandType.ordinal())),
                e -> event.setValue(new Event.ShowPostUploadFailureMessage("업로드에 실패했습니다"))
        );
    }



    public static class Event {

        public static class ShowInvalidInputMessage extends Event {
            public final String message;
            public ShowInvalidInputMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToBoardScreen extends Event {
            public final int errandType;
            public NavigateToBoardScreen(int errandType) {
                this.errandType = errandType;
            }
        }

        public static class ShowPostUploadFailureMessage extends Event {
            public final String message;
            public ShowPostUploadFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowDatePicker extends Event {
            public final long millis;
            public ShowDatePicker(long millis) {
                this.millis = millis;
            }
        }

        public static class ShowTimePicker extends Event {
            public final LocalTime time;
            public ShowTimePicker(LocalTime time) {
                this.time = time;
            }
        }

        public static class ShowGenderPicker extends Event {}
    }

}