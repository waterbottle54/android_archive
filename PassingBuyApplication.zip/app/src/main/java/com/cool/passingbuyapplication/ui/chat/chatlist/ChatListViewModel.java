package com.cool.passingbuyapplication.ui.chat.chatlist;

import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.chat.Chat;
import com.cool.passingbuyapplication.data.chat.DetailedChat;
import com.cool.passingbuyapplication.data.chat.DetailedChatRepository;
import com.cool.passingbuyapplication.data.image.ImageRepository;
import com.cool.passingbuyapplication.data.user.UserRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ChatListViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String userId;

    private final LiveData<List<DetailedChat>> chats;

    private final LiveData<Map<String, Bitmap>> album;


    @Inject
    public ChatListViewModel(UserRepository userRepository,
                             DetailedChatRepository chatRepository,
                             ImageRepository imageRepository) {

        userId = userRepository.getCurrentId();

        chats = chatRepository.getDetailedChats(userId);

        // 프로필 이미지 앨범 획득

        album = Transformations.switchMap(chats, chatList -> {
            List<String> idList = new ArrayList<>();
            for (Chat chat : chatList) {
                String partnerId = userId.equals(chat.getHostId()) ? chat.getGuestId() : chat.getHostId();
                idList.add(partnerId);
            }
            return imageRepository.getAlbum(idList);
        });
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<DetailedChat>> getChats() {
        return chats;
    }

    public String getUserId() {
        return userId;
    }

    public LiveData<Map<String, Bitmap>> getAlbum() {
        return album;
    }


    public void onChatClick(Chat chat) {
        event.setValue(new Event.NavigateToChatScreen(chat.getId()));
    }


    public static class Event {

        public static class NavigateToChatScreen extends Event {
            public final String chatId;
            public NavigateToChatScreen(String chatId) {
                this.chatId = chatId;
            }
        }

    }

}