package com.cool.passingbuyapplication.ui.employer;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SpinnerAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.data.post.ErrandType;
import com.cool.passingbuyapplication.databinding.FragmentEmployerBinding;
import com.cool.passingbuyapplication.databinding.GenderPickerBinding;
import com.cool.passingbuyapplication.util.NameUtils;
import com.cool.passingbuyapplication.util.OnTextChangedListener;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.timepicker.MaterialTimePicker;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.stream.Collectors;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class EmployerFragment extends Fragment {

    private FragmentEmployerBinding binding;
    private EmployerViewModel viewModel;


    public EmployerFragment() {
        super(R.layout.fragment_employer);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentEmployerBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(EmployerViewModel.class);

        // 에딧텍스트에 리스너 부여

        binding.editTextPostTitle.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onTitleChanged(text);
            }
        });

        binding.editTextPostContent.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onContentsChanged(text);
            }
        });

        // 스피너에 카테고리 입력

        SpinnerAdapter adapter = new ArrayAdapter<>(requireContext(),
                android.R.layout.simple_spinner_dropdown_item,
                Arrays.stream(ErrandType.values()).map(errandType ->
                        NameUtils.getErrandTypeName(getResources(), errandType)).collect(Collectors.toList())
        );
        binding.spinnerPostCategory.setAdapter(adapter);
        binding.spinnerPostCategory.setSelection(viewModel.getErrandType().ordinal());
        binding.spinnerPostCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                viewModel.onErrandTypeChanged(ErrandType.values()[i]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) { }
        });

        // 필터 뷰에 리스너 설정

        binding.imageViewPostDate.setOnClickListener(v -> viewModel.onDateClick());
        binding.imageViewPostTime.setOnClickListener(v -> viewModel.onTimeClick());
        binding.imageButtonPostGender.setOnClickListener(v -> viewModel.onGenderClick());

        binding.imageViewSubmitPost.setOnClickListener(v -> viewModel.onSubmitClick());

        // 뷰모델 이벤트 처리

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof EmployerViewModel.Event.ShowInvalidInputMessage) {
                String message = ((EmployerViewModel.Event.ShowInvalidInputMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof EmployerViewModel.Event.NavigateToBoardScreen) {
                int errandType = ((EmployerViewModel.Event.NavigateToBoardScreen) event).errandType;
                NavDirections action = EmployerFragmentDirections.actionEmployerFragmentToBoardFragment(errandType);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof EmployerViewModel.Event.ShowPostUploadFailureMessage) {
                String message = ((EmployerViewModel.Event.ShowPostUploadFailureMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof EmployerViewModel.Event.ShowDatePicker) {
                long millis = ((EmployerViewModel.Event.ShowDatePicker) event).millis;
                showDatePicker(millis);
            } else if (event instanceof EmployerViewModel.Event.ShowTimePicker) {
                LocalTime time = ((EmployerViewModel.Event.ShowTimePicker) event).time;
                showTimePicker(time);
            } else if (event instanceof EmployerViewModel.Event.ShowGenderPicker) {
                showGenderPicker();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void showDatePicker(long millis) {

        MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker()
                        .setSelection(millis)
                        .build();

        datePicker.show(getChildFragmentManager(), "date_picker");
        datePicker.addOnPositiveButtonClickListener(selection ->
                viewModel.onDateChanged(selection));
    }

    private void showTimePicker(LocalTime time) {

        MaterialTimePicker timePicker = new MaterialTimePicker.Builder()
                .setHour(time.getHour())
                .setMinute(time.getMinute())
                .build();

        timePicker.show(getChildFragmentManager(), "time_picker");
        timePicker.addOnPositiveButtonClickListener(selection ->
                viewModel.onTimeChanged(timePicker.getHour(), timePicker.getMinute())
        );
    }

    private void showGenderPicker() {

        GenderPickerBinding genderPickerBinding = GenderPickerBinding.inflate(getLayoutInflater());

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("성별 제한")
                .setView(genderPickerBinding.getRoot())
                .create();

        genderPickerBinding.cardSameGender.setOnClickListener(view -> {
            viewModel.onGenderLimitChanged(true);
            dialog.dismiss();
        });
        genderPickerBinding.cardNoGenderLimit.setOnClickListener(view -> {
            viewModel.onGenderLimitChanged(false);
            dialog.dismiss();
        });

        dialog.show();
    }

}
