package com.cool.passingbuyapplication.ui.mypage.editprofile;

import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.image.ImageRepository;
import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;
import com.cool.passingbuyapplication.ui.MainActivity;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class EditProfileViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final User user;
    private String nickname;
    private boolean isMale;
    private final MutableLiveData<Bitmap> bitmap = new MutableLiveData<>();

    private final UserRepository userRepository;
    private final ImageRepository imageRepository;


    @Inject
    public EditProfileViewModel(SavedStateHandle savedStateHandle,
                                UserRepository userRepository,
                                ImageRepository imageRepository) {

        this.userRepository = userRepository;
        this.imageRepository = imageRepository;

        user = savedStateHandle.get("user");
        assert user != null;
        nickname = user.getNickname() == null ? "" : user.getNickname();
        isMale = user.isMale();

        imageRepository.getProfileImage(user.getId(),
                bitmap::setValue,
                e -> {
                    bitmap.setValue(null);
                    event.setValue(new Event.ShowImageLoadFailureMessage("이미지를 불러오지 못했습니다"));
                }
        );
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getNickname() {
        return nickname;
    }

    public boolean isMale() {
        return isMale;
    }

    public LiveData<Bitmap> getBitmap() {
        return bitmap;
    }


    public void onNicknameChanged(String userId) {
        this.nickname = userId;
    }

    public void onGenderChanged(boolean isMale) {
        this.isMale = isMale;
    }

    public void onSubmitClick() {

        if (nickname.length() < 2) {
            event.setValue(new Event.ShowShortNicknameMessage("닉네임을 두 글자 이상 입력해주세요"));
            return;
        }

        User updatedUser = new User(user.getId(), nickname, isMale);

        userRepository.getUserByNickname(nickname,
                existingUser -> {
                    if (existingUser != null && !existingUser.getId().equals(user.getId())) {
                        event.setValue(new Event.ShowAlreadyExistingNicknameMessage("이미 존재하는 닉네임입니다"));
                        return;
                    }
                    userRepository.updateUser(updatedUser, unused -> saveProfileImage());
                }, e -> {
                });

    }

    public void onBackPressed() {
        event.setValue(new Event.NavigateBackWithResult(MainActivity.RESULT_EDIT_PROFILE_CANCELLED));
    }

    public void onSelectImageClick() {
        event.setValue(new Event.PromptImage());
    }

    public void onImageSelected(Bitmap image) {
        if (image != null) {
            bitmap.setValue(image);
        } else {
            event.setValue(new Event.ShowImageSelectFailureMessage("이미지 선택에 실패했습니다"));
        }
    }


    private void saveProfileImage() {

        if (bitmap.getValue() != null) {
            imageRepository.setProfileImage(user.getId(), bitmap.getValue(),
                    unused -> event.setValue(new Event.NavigateBackWithResult(MainActivity.RESULT_EDIT_PROFILE_OK)),
                    e -> event.setValue(new Event.NavigateBackWithResult(MainActivity.RESULT_EDIT_PROFILE_OK))
            );
        }
    }


    public static class Event {

        public static class ShowShortNicknameMessage extends Event {
            public final String message;

            public ShowShortNicknameMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowAlreadyExistingNicknameMessage extends Event {
            public final String message;

            public ShowAlreadyExistingNicknameMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateBackWithResult extends Event {
            public final int result;

            public NavigateBackWithResult(int result) {
                this.result = result;
            }
        }

        public static class PromptImage extends Event {
        }

        public static class ShowImageSelectFailureMessage extends Event {
            public final String message;

            public ShowImageSelectFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowImageLoadFailureMessage extends Event {
            public final String message;

            public ShowImageLoadFailureMessage(String message) {
                this.message = message;
            }
        }
    }

}







