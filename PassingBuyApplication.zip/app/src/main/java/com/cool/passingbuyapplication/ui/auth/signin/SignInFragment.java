package com.cool.passingbuyapplication.ui.auth.signin;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.databinding.FragmentSignInBinding;
import com.cool.passingbuyapplication.services.NoticeService;
import com.cool.passingbuyapplication.util.OnTextChangedListener;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SignInFragment extends Fragment {

    private FragmentSignInBinding binding;
    private SignInViewModel viewModel;


    public SignInFragment() {
        super(R.layout.fragment_sign_in);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSignInBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SignInViewModel.class);

        buildWebView();
        binding.editTextId.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onIdChanged(text);
            }
        });
        binding.editTextPassword.addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onPasswordChanged(text);
            }
        });
        binding.buttonSignIn.setOnClickListener(v -> {
            viewModel.onSignInClick();
            hideKeyboard(requireView());
        });

        viewModel.isProcessingSignIn().observe(getViewLifecycleOwner(), isProcessingSignIn -> {
                    binding.progressBar.setVisibility(isProcessingSignIn ? View.VISIBLE : View.INVISIBLE);
                    binding.buttonSignIn.setEnabled(!isProcessingSignIn);
                }
        );

        viewModel.getCurrentId().observe(getViewLifecycleOwner(), currentId -> {
            if (currentId != null) {
                NavDirections action = SignInFragmentDirections.actionSignInFragmentToBusinessFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SignInViewModel.Event.ShowEmptyInputMessage) {
                String message = ((SignInViewModel.Event.ShowEmptyInputMessage) event).message;
                hideKeyboard(requireView());
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof SignInViewModel.Event.LoadWebPage) {
                String url = ((SignInViewModel.Event.LoadWebPage) event).url;
                binding.webView.loadUrl(url);
            } else if (event instanceof SignInViewModel.Event.SubmitFormAndCountdown) {
                List<String> javascriptList = ((SignInViewModel.Event.SubmitFormAndCountdown) event).javascriptList;
                for (String javascript : javascriptList) {
                    binding.webView.evaluateJavascript(javascript, null);
                }
                int millis = ((SignInViewModel.Event.SubmitFormAndCountdown) event).millis;
                binding.webView.postDelayed(() -> {
                    if (binding != null) {
                        viewModel.onCountdownFinished(binding.webView.getUrl());
                    }
                }, millis);
            } else if (event instanceof SignInViewModel.Event.NavigateToBusinessScreenAfterStartingService) {
                String userId = ((SignInViewModel.Event.NavigateToBusinessScreenAfterStartingService) event).userId;
                startChatNotificationService(userId);
                NavDirections action = SignInFragmentDirections.actionSignInFragmentToBusinessFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof SignInViewModel.Event.ShowSignInFailureMessage) {
                String message = ((SignInViewModel.Event.ShowSignInFailureMessage) event).message;
                hideKeyboard(requireView());
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            } else if (event instanceof SignInViewModel.Event.ShowAgreementScreen) {
                showAgreementDialog();
            } else if (event instanceof SignInViewModel.Event.NavigateToSignOutScreen) {
                String message = ((SignInViewModel.Event.NavigateToSignOutScreen) event).message;
                NavDirections action = SignInFragmentDirections.actionGlobalSignOutFragment(message);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });

        viewModel.onWebViewBuilt();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        ActionBar actionBar = ((AppCompatActivity) requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        ActionBar actionBar = ((AppCompatActivity) requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.show();
        }
    }

    private void startChatNotificationService(String userId) {
        Intent serviceIntent = new Intent(requireContext(), NoticeService.class);
        serviceIntent.putExtra(NoticeService.EXTRA_USER_ID, userId);
        requireContext().startService(serviceIntent);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void buildWebView() {

        binding.webView.getSettings().setJavaScriptEnabled(true);
        binding.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                result.cancel();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                result.cancel();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                result.cancel();
                return true;
            }
        });
        binding.webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                viewModel.onPageLoaded(url);
            }
        });
    }

    private void showAgreementDialog() {

        new AlertDialog.Builder(requireContext())
                .setTitle("이용약관")
                .setMessage(R.string.privacy_policy_contents)
                .setPositiveButton("확인", (dialogInterface, i) -> viewModel.onAgreementAccepted())
                .setNegativeButton("취소", (dialogInterface, i) -> viewModel.onAgreementRejected())
                .show();
    }

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}