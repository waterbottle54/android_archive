package com.cool.passingbuyapplication.data.post;

import java.io.Serializable;
import java.util.Objects;

public class Post implements Serializable {

    private String id;
    private String userId;      // 작성자 아이디
    private String title;       // 제목
    private String contents;    // 글 내용
    private long created;       // 작성 시간

    private GenderLimit genderLimit;    // 성별 제한
    private ErrandType errandType;      // 심부름 종류
    private long deadline;              // 마감일시

    public Post() {
    }

    public Post(String userId, String title, String contents,
                GenderLimit genderLimit, ErrandType errandType, long deadline
    ) {
        this.userId = userId;
        this.title = title;
        this.contents = contents;
        this.genderLimit = genderLimit;
        this.errandType = errandType;
        this.deadline = deadline;

        this.created = System.currentTimeMillis();
        this.id = userId + "#" + created;
    }

    public Post(Post other) {
        this.id = other.id;
        this.userId = other.userId;
        this.title = other.title;
        this.contents= other.contents;
        this.created = other.created;
        this.genderLimit = other.genderLimit;
        this.errandType = other.errandType;
        this.deadline = other.deadline;
    }


    public String getId() {
        return id;
    }

    public String getUserId() {
        return userId;
    }

    public String getTitle() {
        return title;
    }

    public String getContents() {
        return contents;
    }

    public long getCreated() {
        return created;
    }

    public GenderLimit getGenderLimit() {
        return genderLimit;
    }

    public ErrandType getErrandType() {
        return errandType;
    }

    public long getDeadline() {
        return deadline;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public void setGenderLimit(GenderLimit genderLimit) {
        this.genderLimit = genderLimit;
    }

    public void setErrandType(ErrandType errandType) {
        this.errandType = errandType;
    }

    public void setDeadline(long deadline) {
        this.deadline = deadline;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Post post = (Post) o;
        return created == post.created && deadline == post.deadline && id.equals(post.id) && userId.equals(post.userId) && title.equals(post.title) && contents.equals(post.contents) && genderLimit == post.genderLimit && errandType == post.errandType;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, userId, title, contents, created, genderLimit, errandType, deadline);
    }
}
