package com.cool.passingbuyapplication.data.user;

import android.app.Application;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

public class UserRepository {

    private final CollectionReference usersCollection;
    private final SharedPreferences preferences;

    @Inject
    public UserRepository(FirebaseFirestore firestore, Application application) {
        this.usersCollection = firestore.collection("users");
        preferences = PreferenceManager.getDefaultSharedPreferences(application);
    }

    public LiveData<User> getUsersLiveData(String id) {

        // id 로 검색된 유저 획득

        MutableLiveData<User> user = new MutableLiveData<>();
        usersCollection.whereEqualTo("id", id)
                .addSnapshotListener((value, error) -> {
                    if (value == null || value.isEmpty() || error != null) {
                        user.setValue(null);
                        return;
                    }
                    User userValue = value.getDocuments().get(0).toObject(User.class);
                    if (userValue != null) {
                        user.setValue(userValue);
                    }
                });
        return user;
    }

    public LiveData<List<User>> getUsersLiveData() {

        // 모든 유저 획득

        MutableLiveData<List<User>> users = new MutableLiveData<>();
        usersCollection.addSnapshotListener((value, error) -> {
            if (value == null || error != null) {
                users.setValue(null);
                return;
            }
            List<User> userList = new ArrayList<>();
            for (DocumentSnapshot snapshot : value) {
                User user = snapshot.toObject(User.class);
                if (user != null) {
                    userList.add(user);
                }
            }
            users.setValue(userList);
        });
        return users;
    }

    public void getUser(String id, OnSuccessListener<User> onSuccessListener, OnFailureListener onFailureListener) {

        // getUsersLiveData 의 리스너 버전

        usersCollection.whereEqualTo("id", id).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    User user = queryDocumentSnapshots.getDocuments().get(0).toObject(User.class);
                    onSuccessListener.onSuccess(user);
                })
                .addOnFailureListener(onFailureListener);
    }

    public void getUserByNickname(String nickname, OnSuccessListener<User> onSuccessListener, OnFailureListener onFailureListener) {

        // 닉네임으로 유저 획득

        usersCollection.whereEqualTo("nickname", nickname).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        onSuccessListener.onSuccess(null);
                        return;
                    }
                    User user = queryDocumentSnapshots.getDocuments().get(0).toObject(User.class);
                    onSuccessListener.onSuccess(user);
                })
                .addOnFailureListener(onFailureListener);
    }

    public void addUser(User user, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        // DB에 유저 추가

        usersCollection.document(user.getId())
                .set(user)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    public void updateUser(User user, OnSuccessListener<Void> onSuccessListener) {

        // 유저 정보 업데이트

        usersCollection.document(user.getId())
                .set(user)
                .addOnSuccessListener(onSuccessListener);
    }

    // 현재 로그인된 유저 아이디 획득

    public String getCurrentId() {
        return preferences.getString("signedInId", null);
    }

    // 로그인된 유저 아이디 설정

    public void signIn(String userId) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("signedInId", userId).apply();
    }

    // 로그아웃

    public void signOut() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("signedInId", null).apply();
    }

    public LiveData<Map<String, User>> getUsersMap() {

        // 모든 유저 정보로 id-user Map 을 구성하여 리턴

        MutableLiveData<Map<String, User>> users = new MutableLiveData<>();
        usersCollection.addSnapshotListener((value, error) -> {
            if (value == null || error != null) {
                users.setValue(null);
                return;
            }
            Map<String, User> userMap = new HashMap<>();
            for (DocumentSnapshot snapshot : value) {
                User user = snapshot.toObject(User.class);
                if (user != null) {
                    userMap.put(user.getId(), user);
                }
            }
            users.setValue(userMap);
        });
        return users;
    }

}
