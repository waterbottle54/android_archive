package com.cool.passingbuyapplication;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import dagger.hilt.android.HiltAndroidApp;

@HiltAndroidApp
public class PassingBuyApplication extends Application {


    public static final String CHANNEL_NAME = "패싱바이";
    public static final String CHANNEL_FOREGROUND = "com.davidjo.remedialexercise.passing_buy";
    public static final String CHANNEL_NEW_MESSAGE = "com.davidjo.remedialexercise.new_message";

    @Override
    public void onCreate() {
        super.onCreate();

        createNotificationChannel();
    }

    // notification 채널 생성

    private void createNotificationChannel() {

        // Foreground notification channel
        NotificationChannel foregroundChannel = new NotificationChannel(
                CHANNEL_FOREGROUND,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
        );

        // Time-over notification channel
        NotificationChannel newMessageChannel = new NotificationChannel(
                CHANNEL_NEW_MESSAGE,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
        );

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(foregroundChannel);
        manager.createNotificationChannel(newMessageChannel);
    }

}
