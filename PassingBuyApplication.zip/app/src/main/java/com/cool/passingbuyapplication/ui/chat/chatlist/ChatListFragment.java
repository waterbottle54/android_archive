package com.cool.passingbuyapplication.ui.chat.chatlist;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.databinding.FragmentChatListBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ChatListFragment extends Fragment {

    private FragmentChatListBinding binding;
    private ChatListViewModel viewModel;


    public ChatListFragment() {
        super(R.layout.fragment_chat_list);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentChatListBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ChatListViewModel.class);

        // 채팅 리스트에 프로필 사진과 마지막 채팅내용 표시

        viewModel.getAlbum().observe(getViewLifecycleOwner(), album -> {

            DetailedChatsAdapter adapter = new DetailedChatsAdapter(
                    getResources(), viewModel.getUserId(), album, Glide.with(this));
            adapter.setOnItemSelectedListener(position ->
                    viewModel.onChatClick(adapter.getCurrentList().get(position)));
            binding.recyclerChat.setHasFixedSize(true);
            binding.recyclerChat.setAdapter(adapter);

            viewModel.getChats().observe(getViewLifecycleOwner(), chats -> {
                adapter.submitList(chats);
                binding.progressBar.setVisibility(View.INVISIBLE);
            });
        });


        // 뷰모델 이벤트 처리

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ChatListViewModel.Event.NavigateToChatScreen) {
                String chatId = ((ChatListViewModel.Event.NavigateToChatScreen) event).chatId;
                NavDirections action = ChatListFragmentDirections.actionRoomsFragmentToChatFragment(
                        chatId, null, null, null);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


}