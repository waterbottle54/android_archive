package com.cool.passingbuyapplication.ui.business;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.databinding.FragmentBusinessBinding;
import com.cool.passingbuyapplication.ui.MainActivity;
import com.google.android.material.snackbar.Snackbar;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class BusinessFragment extends Fragment {

    private FragmentBusinessBinding binding;
    private BusinessViewModel viewModel;


    public BusinessFragment() {
        super(R.layout.fragment_business);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                viewModel.onBackPressed();
            }
        };
        requireActivity().getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentBusinessBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(BusinessViewModel.class);

        binding.layoutRequestErrand.setOnClickListener(v -> viewModel.onRequestErrandClick());
        binding.layoutRunErrand.setOnClickListener(v -> viewModel.onRunErrandClick());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof BusinessViewModel.Event.ShowConfirmSignOutMessage) {
                String message = ((BusinessViewModel.Event.ShowConfirmSignOutMessage) event).message;
                showConfirmSignOutDialog(message);
            } else if (event instanceof BusinessViewModel.Event.NavigateToSignOutScreen) {
                NavDirections action = BusinessFragmentDirections.actionGlobalSignOutFragment(null);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof BusinessViewModel.Event.NavigateToEmployerScreen) {
                NavDirections action = BusinessFragmentDirections.actionBusinessFragmentToEmployerFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof BusinessViewModel.Event.NavigateToEmployeeScreen) {
                NavDirections action = BusinessFragmentDirections.actionBusinessFragmentToEmployeeFragment();
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof BusinessViewModel.Event.ShowEditProfileMessage) {
                String message = ((BusinessViewModel.Event.ShowEditProfileMessage) event).message;
                showConfirmEditProfileDialog(message);
            } else if (event instanceof BusinessViewModel.Event.NavigateToEditProfileScreen) {
                User user = ((BusinessViewModel.Event.NavigateToEditProfileScreen) event).user;
                NavDirections action = BusinessFragmentDirections.actionBusinessFragmentToEditProfileFragment(user);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof BusinessViewModel.Event.ShowProfileEditedMessage) {
                String message = ((BusinessViewModel.Event.ShowProfileEditedMessage) event).message;
                Snackbar.make(requireView(), message, Snackbar.LENGTH_SHORT).show();
            }
        });

        getParentFragmentManager().setFragmentResultListener(MainActivity.REQUEST_EDIT_PROFILE, getViewLifecycleOwner(),
                (requestKey, bundle) -> {
                    int result = bundle.getInt(MainActivity.RESULT_EDIT_PROFILE);
                    viewModel.onEditProfileResult(result);
                });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        ActionBar actionBar = ((AppCompatActivity)requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        ActionBar actionBar = ((AppCompatActivity)requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.show();
        }
    }

    private void showConfirmSignOutDialog(String message) {
        new AlertDialog.Builder(requireContext())
                .setMessage(message)
                .setPositiveButton("로그아웃", (dialog, which) -> viewModel.onSignOutClick())
                .setNegativeButton("취소", null)
                .show();
    }

    private void showConfirmEditProfileDialog(String message) {
        new AlertDialog.Builder(requireContext())
                .setTitle("프로필 설정")
                .setMessage(message)
                .setPositiveButton("프로필 설정", (dialog, which) -> viewModel.onEditProfileConfirmed())
                .setOnDismissListener(dialogInterface -> viewModel.onEditProfileConfirmed())
                .show();
    }

}