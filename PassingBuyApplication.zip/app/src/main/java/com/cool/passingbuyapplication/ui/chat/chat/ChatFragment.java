package com.cool.passingbuyapplication.ui.chat.chat;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.NavGraphDirections;
import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.databinding.FragmentChatBinding;
import com.cool.passingbuyapplication.util.OnTextChangedListener;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class ChatFragment extends Fragment {

    private FragmentChatBinding binding;
    private ChatViewModel viewModel;


    public ChatFragment() {
        super(R.layout.fragment_chat);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentChatBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(ChatViewModel.class);

        // 채팅 UI 에 리스너 설정

        binding.messageInput.getInputEditText().addTextChangedListener(new OnTextChangedListener() {
            @Override
            public void onTextChanged(String text) {
                viewModel.onMessageChanged(text);
            }
        });

        binding.messageInput.getButton().setOnClickListener(v -> {
            viewModel.onSubmitClick();
            hideKeyboard(requireView());
        });

        // 뷰모델 이벤트 처리

        viewModel.getProfileImage().observe(getViewLifecycleOwner(), profileImage -> {

            // 프로필 이미지 및 커멘트 획득 시 리스트 표시

            CommentsAdapter adapter = new CommentsAdapter(viewModel.getUserId(), getResources(), profileImage);
            adapter.setOnItemSelectedListener(userId -> viewModel.onProfileSelected(userId));

            binding.recyclerComment.setHasFixedSize(true);
            binding.recyclerComment.setAdapter(adapter);

            viewModel.getComments().observe(getViewLifecycleOwner(), comments -> {
                adapter.submitList(comments);
                binding.recyclerComment.postDelayed(() ->
                        binding.recyclerComment.smoothScrollToPosition(adapter.getItemCount() - 1), 500);
            });

            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof ChatViewModel.Event.NavigateToProfileScreen) {
                String userId = ((ChatViewModel.Event.NavigateToProfileScreen) event).userId;
                NavDirections action = NavGraphDirections.actionGlobalMyPageFragment(userId);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        setIsChatting(true);
    }

    @Override
    public void onPause() {
        super.onPause();
        setIsChatting(false);
    }

    private void setIsChatting(boolean b) {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(requireContext());
        preferences.edit().putBoolean("isChatting", b).apply();
    }

    private void hideKeyboard(View view) {
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

}

