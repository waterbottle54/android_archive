package com.cool.passingbuyapplication.ui.auth.signout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.databinding.FragmentSignOutBinding;
import com.cool.passingbuyapplication.services.NoticeService;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class SignOutFragment extends Fragment {

    private FragmentSignOutBinding binding;
    private SignOutViewModel viewModel;


    public SignOutFragment() {
        super(R.layout.fragment_sign_out);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentSignOutBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(SignOutViewModel.class);

        buildWebView();
        binding.textViewMessage.setText(viewModel.getMessage());

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof SignOutViewModel.Event.LoadWebPage) {
                String url = ((SignOutViewModel.Event.LoadWebPage) event).url;
                binding.webView.loadUrl(url);
            } else if (event instanceof SignOutViewModel.Event.ClickSignOutButton) {
                String javascript = ((SignOutViewModel.Event.ClickSignOutButton) event).javascript;
                binding.webView.evaluateJavascript(javascript, null);
            } else if (event instanceof SignOutViewModel.Event.NavigateToSignInScreenAfterStoppingService) {
                stopChatNotificationService();
                NavDirections action =  SignOutFragmentDirections.actionSignOutFragmentToSignInFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });

        viewModel.onWebViewBuilt();
    }

    private void stopChatNotificationService() {
        Intent serviceIntent = new Intent(requireContext(), NoticeService.class);
        requireContext().stopService(serviceIntent);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void buildWebView() {

        binding.webView.getSettings().setJavaScriptEnabled(true);
        binding.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                result.cancel();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                result.cancel();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                result.cancel();
                return true;
            }
        });
        binding.webView.addJavascriptInterface(new JsInterface(), "JsInterface");
        binding.webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.loadUrl("javascript:window.JsInterface.sendHtml" +
                        "('" + url + "', " + "'<html>'+document.getElementsByTagName('html')[0].innerHTML+'</html>');");
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        ActionBar actionBar = ((AppCompatActivity)requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        ActionBar actionBar = ((AppCompatActivity)requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.show();
        }
    }


    class JsInterface {

        @JavascriptInterface
        public void sendHtml(String url, String html) {
            viewModel.onPageLoaded(url, html);
        }

    }

}





