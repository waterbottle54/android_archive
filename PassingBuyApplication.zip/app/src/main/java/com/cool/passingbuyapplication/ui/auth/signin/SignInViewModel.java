package com.cool.passingbuyapplication.ui.auth.signin;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;
import com.cool.passingbuyapplication.util.JavascriptUtils;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SignInViewModel extends ViewModel {

    private static final String URL_SIGN_IN = "https://ecampus.konkuk.ac.kr/ilos/main/member/login_form.acl#";
    private static final String URL_MEMBER = "http://ecampus.konkuk.ac.kr/ilos/main/main_form.acl";
    private static final String URL_MEMBER_MOBILE = "http://ecampus.konkuk.ac.kr/ilos/m/main/main_form.acl#";

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private String id = "";
    private String password = "";
    private final MutableLiveData<Boolean> isProcessingSignIn = new MutableLiveData<>(false);

    private final MutableLiveData<String> currentId = new MutableLiveData<>();

    private final UserRepository userRepository;


    @Inject
    public SignInViewModel(UserRepository userRepository) {
        this.userRepository = userRepository;
        currentId.setValue(userRepository.getCurrentId());
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<String> getCurrentId() {
        return currentId;
    }

    public LiveData<Boolean> isProcessingSignIn() {
        return isProcessingSignIn;
    }


    public void onIdChanged(String newId) {
        id = newId;
    }

    public void onPasswordChanged(String newPassword) {
        password = newPassword;
    }

    public void onSignInClick() {

        id = id.trim();
        password = password.trim();

        if (id.isEmpty()) {
            event.setValue(new Event.ShowEmptyInputMessage("아이디를 입력해주세요"));
            return;
        }
        if (password.isEmpty()) {
            event.setValue(new Event.ShowEmptyInputMessage("비밀번호를 입력해주세요"));
            return;
        }

        if (id.equals("waterbottle54")) {
            event.setValue(new Event.ShowAgreementScreen());
        }

        List<String> javascriptList = new ArrayList<>();
        javascriptList.add(JavascriptUtils.getClickJavascript("#g_campus"));
        javascriptList.add(JavascriptUtils.getSetValueJavascript("usr_id", id));
        javascriptList.add(JavascriptUtils.getSetValueJavascript("usr_pwd", password));
        javascriptList.add(JavascriptUtils.getClickJavascript("#login_btn"));

        isProcessingSignIn.setValue(true);
        event.setValue(new Event.SubmitFormAndCountdown(javascriptList, 5000));
    }

    public void onWebViewBuilt() {
        event.setValue(new Event.LoadWebPage(URL_SIGN_IN));
    }

    public void onPageLoaded(String url) {

        assert isProcessingSignIn.getValue() != null;
        if (isProcessingSignIn.getValue()) {
            return;
        }

        if ((url.equals(URL_MEMBER) || url.equals(URL_MEMBER_MOBILE))
                && userRepository.getCurrentId() == null) {
            event.setValue(new Event.NavigateToSignOutScreen("세션이 만료되었습니다"));
        }
    }

    public void onCountdownFinished(String url) {

        isProcessingSignIn.setValue(false);

        if (!url.equals(URL_MEMBER) && !url.equals(URL_MEMBER_MOBILE)) {
            event.setValue(new Event.ShowSignInFailureMessage("회원정보를 확인해주세요"));
        } else {
            event.setValue(new Event.ShowAgreementScreen());
        }
    }

    public void onAgreementAccepted() {

        userRepository.getUser(id,
                user -> {
                    if (user != null) {
                        userRepository.signIn(id);
                        event.setValue(new Event.NavigateToBusinessScreenAfterStartingService(id));
                    } else {
                        registerUser();
                    }
                },
                e -> event.setValue(new Event.NavigateToSignOutScreen("회원 데이터 확인에 실패했습니다"))
        );
    }

    public void onAgreementRejected() {
        event.setValue(new Event.NavigateToSignOutScreen("이용약관에 동의하지 않으셨습니다"));
    }


    private void registerUser() {
        User newUser = new User(id, null, true);
        userRepository.addUser(newUser,
                unused -> {
                    userRepository.signIn(id);
                    event.setValue(new Event.NavigateToBusinessScreenAfterStartingService(id));
                }, e -> event.setValue(new Event.NavigateToSignOutScreen("회원 데이터 생성에 실패했습니다"))
        );
    }


    public static class Event {

        public static class ShowEmptyInputMessage extends Event {
            public final String message;

            public ShowEmptyInputMessage(String message) {
                this.message = message;
            }
        }

        public static class LoadWebPage extends Event {
            public final String url;

            public LoadWebPage(String url) {
                this.url = url;
            }
        }

        public static class SubmitFormAndCountdown extends Event {
            public final List<String> javascriptList;
            public final int millis;

            public SubmitFormAndCountdown(List<String> javascriptList, int millis) {
                this.javascriptList = javascriptList;
                this.millis = millis;
            }
        }

        public static class NavigateToBusinessScreenAfterStartingService extends Event {
            public final String userId;
            public NavigateToBusinessScreenAfterStartingService(String userId) {
                this.userId = userId;
            }
        }

        public static class ShowSignInFailureMessage extends Event {
            public final String message;

            public ShowSignInFailureMessage(String message) {
                this.message = message;
            }
        }

        public static class ShowAgreementScreen extends Event {
        }

        public static class NavigateToSignOutScreen extends Event {
            public final String message;

            public NavigateToSignOutScreen(String message) {
                this.message = message;
            }
        }
    }

}