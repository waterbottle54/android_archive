package com.cool.passingbuyapplication.ui;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.databinding.ActivityMainBinding;
import com.cool.passingbuyapplication.services.NoticeService;

import java.util.HashSet;
import java.util.Set;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MainActivity extends AppCompatActivity {

    public static final String REQUEST_EDIT_PROFILE = "com.cool.passingbuyapplication.request_edit_profile";
    public static final String RESULT_EDIT_PROFILE = "com.cool.passingbuyapplication.result_edit_profile";
    public static final int RESULT_EDIT_PROFILE_OK = Activity.RESULT_FIRST_USER;
    public static final int RESULT_EDIT_PROFILE_CANCELLED = Activity.RESULT_FIRST_USER + 1;

    private ActivityMainBinding binding;
    private NavController navController;
    private AppBarConfiguration appBarConfiguration;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 레이아웃의 툴바를 액션바로 설정
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);

        // NavController 획득 후 appBarConfiguration 설정

        NavHostFragment navHostFragment =
                (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {

            navController = navHostFragment.getNavController();

            Set<Integer> topLevelDestinations = new HashSet<>();
            topLevelDestinations.add(R.id.employerFragment);
            topLevelDestinations.add(R.id.employeeFragment);
            appBarConfiguration = new AppBarConfiguration.Builder(topLevelDestinations)
                    .setOpenableLayout(binding.drawerLayout)
                    .build();

            NavigationUI.setupWithNavController(binding.navView, navController);
            NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 포그라운드 서비스 시작
        if (getCurrentId() != null && !isServiceRunning(NoticeService.class)) {
            startChatNotificationService(getCurrentId());
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        // 포그라운드 서비스 중지
        if (!isNotificationOn()) {
            Intent serviceIntent = new Intent(this, NoticeService.class);
            stopService(serviceIntent);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        return NavigationUI.navigateUp(navController, appBarConfiguration);
    }

    @Override
    public void onBackPressed() {
        // 드로어 닫기
        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
            binding.drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    private boolean isNotificationOn() {
        // 알림 on 여부 획득
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        return sharedPreferences.getBoolean("isNotificationOn", false);
    }

    private String getCurrentId() {
        // 현재 id 획득
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        return sharedPreferences.getString("signedInId", null);
    }

    private void startChatNotificationService(String userId) {
        // 서비스 시작
        Intent serviceIntent = new Intent(this, NoticeService.class);
        serviceIntent.putExtra(NoticeService.EXTRA_USER_ID, userId);
        startService(serviceIntent);
    }

    private boolean isServiceRunning(Class<?> serviceClass) {
        // 서비스 가동여부 확인
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

}