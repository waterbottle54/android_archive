package com.cool.passingbuyapplication.ui.intro;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class IntroFragment extends Fragment {

    private static int visits = 0;

    public IntroFragment() {
        super(R.layout.fragment_intro);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.postDelayed(this::navigateToSignInFragment, 2000);
    }

    @Override
    public void onResume() {
        super.onResume();
        ActionBar actionBar = ((AppCompatActivity)requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
        if (++visits > 1) {
            navigateToSignInFragment();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        ActionBar actionBar = ((AppCompatActivity)requireActivity()).getSupportActionBar();
        if (actionBar != null) {
            actionBar.show();
        }
    }

    private void navigateToSignInFragment() {
        NavDirections action = IntroFragmentDirections.actionIntroFragmentToSignInFragment();
        Navigation.findNavController(requireView()).navigate(action);
    }

}
