package com.cool.passingbuyapplication.ui.post;

import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.image.ImageRepository;
import com.cool.passingbuyapplication.data.post.DetailedPost;
import com.cool.passingbuyapplication.data.post.PostRepository;
import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class PostViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final DetailedPost detailedPost;
    private final User writer;
    private final String userId;

    private final LiveData<Bitmap> profileImage;

    private final LiveData<Boolean> isChatable;
    private final LiveData<Boolean> isEditable;

    private final PostRepository postRepository;


    @Inject
    public PostViewModel(SavedStateHandle savedStateHandle, UserRepository userRepository, ImageRepository imageRepository, PostRepository postRepository) {

        this.postRepository = postRepository;

        detailedPost = savedStateHandle.get("detailedPost");
        assert detailedPost != null;

        // 글 내용 획득

        writer = detailedPost.getUser();
        profileImage = imageRepository.getProfileImageLiveData(detailedPost.getUserId());

        userId = userRepository.getCurrentId();

        LiveData<User> user = userRepository.getUsersLiveData(userRepository.getCurrentId());
        isChatable = Transformations.map(user, userValue -> !userValue.getId().equals(writer.getId()));
        isEditable = Transformations.map(user, userValue -> userValue.getId().equals(writer.getId()));
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getNickname() {
        return writer.getNickname();
    }

    public boolean isMale() {
        return writer.isMale();
    }

    public String getTitle() {
        return detailedPost.getTitle();
    }

    public String getContents() {
        return detailedPost.getContents();
    }

    public long getTimeLeft() {
        return detailedPost.getDeadline() - System.currentTimeMillis();
    }

    public LocalDate getCreated() {
        return Instant.ofEpochMilli(detailedPost.getCreated()).atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public LiveData<Bitmap> getProfileImage() {
        return profileImage;
    }

    public LiveData<Boolean> isChatable() {
        return isChatable;
    }

    public LiveData<Boolean> isEditable() {
        return isEditable;
    }

    // 유저 입력 처리

    public void onChatClick() {

        if (isChatable.getValue() != null && !isChatable.getValue()) {
            return;
        }

        String postId = detailedPost.getId();
        String hostId = detailedPost.getUserId();
        String guestId = userId;
        String chatId = postId + "#" + hostId + "#" + guestId;
        event.setValue(new Event.NavigateToChatScreen(chatId, postId, hostId, guestId));
    }

    public void onDeleteClick() {
        if (isEditable.getValue() != null && isEditable.getValue()) {
            postRepository.deletePost(detailedPost, unused -> event.setValue(new Event.NavigateBack()));
        }
    }


    public static class Event {

        public static class NavigateToChatScreen extends Event {
            public final String chatId;
            public final String postId;
            public final String hostId;
            public final String guestId;
            public NavigateToChatScreen(String chatId, String postId, String hostId, String guestId) {
                this.chatId = chatId;
                this.postId = postId;
                this.hostId = hostId;
                this.guestId = guestId;
            }
        }

        public static class NavigateBack extends Event {}
    }

}