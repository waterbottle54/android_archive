package com.cool.passingbuyapplication.data.post;

// 심부름 타입 열거형

public enum ErrandType {
    CARRYING, SHOPPING, IN_CAMPUS, TAKE_OUT, PET, CLEANING, DOWNTOWN, ETC
}
