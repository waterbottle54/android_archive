package com.cool.passingbuyapplication.util;

import android.content.res.Resources;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.data.post.ErrandType;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Locale;

public class NameUtils {

    public static String getErrandTypeName(Resources resources, ErrandType errandType) {
        switch (errandType) {
            case CARRYING:
                return resources.getString(R.string.carrying);
            case CLEANING:
                return resources.getString(R.string.cleaning);
            case IN_CAMPUS:
                return resources.getString(R.string.in_campus);
            case ETC:
                return resources.getString(R.string.etc);
            case TAKE_OUT:
                return resources.getString(R.string.take_out);
            case DOWNTOWN:
                return resources.getString(R.string.downtown);
            case PET:
                return resources.getString(R.string.pet);
            case SHOPPING:
                return resources.getString(R.string.shopping);
        }
        return "";
    }

    public static String getGenderName(Resources resources, boolean isMale) {
        return resources.getString(isMale ? R.string.male : R.string.female);
    }

    public static String getDateString(Resources resources, LocalDate date) {

        int year = date.getYear();
        int month = date.getMonthValue();
        int dayOfMonth = date.getDayOfMonth();
        return String.format(Locale.getDefault(),
                resources.getString(R.string.date_format),
                year, month, dayOfMonth
        );
    }

    public static String getTimeLeftString(Resources resources, long millis) {

        int daysLeft = (int) (millis / 86400000);
        if (daysLeft > 0) {
            return String.format(Locale.getDefault(), resources.getString(R.string.days_left), daysLeft);
        } else {
            int hoursLeft = (int) (millis / 3600000);
            if (hoursLeft > 0) {
                return String.format(Locale.getDefault(), resources.getString(R.string.hours_left), hoursLeft);
            } else {
                int minutesLeft = (int) (millis / 60000);
                return String.format(Locale.getDefault(), resources.getString(R.string.minutes_left), minutesLeft);
            }
        }
    }

    public static String getTimeBeforeString(Resources resources, long millis) {

        int daysLeft = (int) (millis / 86400000);
        if (daysLeft > 0) {
            return String.format(Locale.getDefault(), resources.getString(R.string.days_before), daysLeft);
        } else {
            int hoursLeft = (int) (millis / 3600000);
            if (hoursLeft > 0) {
                return String.format(Locale.getDefault(), resources.getString(R.string.hours_before), hoursLeft);
            } else {
                int minutesLeft = (int) (millis / 60000);
                return String.format(Locale.getDefault(), resources.getString(R.string.minutes_before), minutesLeft);
            }
        }
    }


    public static String getTimeString(Resources resources, long millis) {

        LocalDateTime localDate = Instant.ofEpochMilli(millis)
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();

        int hour = localDate.getHour();
        int minute = localDate.getMinute();
        boolean isMorning = hour < 12;

        return String.format(Locale.getDefault(), resources.getString(R.string.time_format),
                isMorning ? "오전" : "오후",
                hour % 12,
                minute);
    }

}
