package com.cool.passingbuyapplication.util;

import java.util.Locale;

public class JavascriptUtils {

    public static String getSetValueJavascript(String elementId, String value) {
        return Javascript.create(Query.id(elementId), Operation.setValue(value));
    }

    public static String getClickJavascript(String attributeName, String attributeValue) {
        return Javascript.create(Query.attribute(attributeName, attributeValue), Operation.click());
    }

    public static String getClickJavascript(String cssSelector) {
        return Javascript.create(Query.cssSelector(cssSelector), Operation.click());
    }


    static class Javascript {

        public static String create(String query, String operation) {
            return String.format(Locale.getDefault(), "javascript:(function(){%s.%s;})()", query, operation);
        }
    }

    static class Query {

        public static String id(String id) {
            return String.format(Locale.getDefault(),
                    "document.getElementById('%s')",
                    id
            );
        }

        public static String attribute(String attribute, String value) {
            return String.format(Locale.getDefault(),
                    "document.querySelectorAll('[%s=\"%s\"]')[0]",
                    attribute, value
            );
        }

        public static String classIndex(String className, int nth) {
            return String.format(Locale.getDefault(),
                    "document.findElementsByClassName('%s')[%d]",
                    className, nth
            );
        }

        public static String cssSelector(String cssSelector) {
            return String.format(Locale.getDefault(),
                    "document.querySelector('%s')",
                    cssSelector
            );
        }

    }

    static class Operation {

        public static String setValue(String value) {
            return String.format(Locale.getDefault(), "value='%s'", value);
        }

        public static String click() {
            return "click()";
        }

        public static String focus() {
            return "focus()";
        }

        public static String blur() {
            return "blur()";
        }

        public static String addClass(String className) {
            return String.format(Locale.getDefault(), "classList.add('%s')", className);
        }
    }

}
