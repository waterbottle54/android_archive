package com.cool.passingbuyapplication.ui.mypage.mypage;

import android.app.Application;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.preference.PreferenceManager;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.image.ImageRepository;
import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;
import com.cool.passingbuyapplication.ui.MainActivity;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class MyPageViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String userId;
    private final boolean isEditable;

    private final LiveData<User> user;
    private final LiveData<String> nickname;
    private final LiveData<Boolean> isMale;
    private final MutableLiveData<Bitmap> profileImage = new MutableLiveData<>();

    private final ImageRepository imageRepository;

    private final SharedPreferences preferences;


    @Inject
    public MyPageViewModel(Application application,
                           SavedStateHandle savedStateHandle,
                           UserRepository userRepository,
                           ImageRepository imageRepository) {

        this.imageRepository = imageRepository;

        String targetUserId = savedStateHandle.get("targetUserId");
        userId = targetUserId != null ? targetUserId : userRepository.getCurrentId();

        isEditable = targetUserId == null;

        user = userRepository.getUsersLiveData(userId);
        nickname = Transformations.map(user, User::getNickname);
        isMale = Transformations.map(user, User::isMale);
        imageRepository.getProfileImage(userId, profileImage::setValue, e -> profileImage.setValue(null));

        preferences = PreferenceManager.getDefaultSharedPreferences(application);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<String> getNickname() {
        return nickname;
    }

    public LiveData<Boolean> isMale() {
        return isMale;
    }

    public LiveData<Bitmap> getProfileImage() {
        return profileImage;
    }

    public boolean isEditable() {
        return isEditable;
    }

    public boolean isNotificationOn() {
        return preferences.getBoolean("isNotificationOn", true);
    }


    public void onEditProfileClick() {

        if (user.getValue() == null) {
            return;
        }

        event.setValue(new Event.NavigateToEditProfileScreen(user.getValue()));
    }

    public void onEditProfileResult(int result) {
        if (result == MainActivity.RESULT_EDIT_PROFILE_OK) {
            imageRepository.getProfileImage(userId, profileImage::setValue, e -> profileImage.setValue(null));
            event.setValue(new Event.ShowProfileEditedMessage("프로필이 변경되었습니다"));
        }
    }

    public void onNotificationChanged(boolean on) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putBoolean("isNotificationOn", on).apply();
    }


    public static class Event {

        public static class NavigateToEditProfileScreen extends Event {
            public final User user;

            public NavigateToEditProfileScreen(User user) {
                this.user = user;
            }
        }

        public static class ShowProfileEditedMessage extends Event {
            public final String message;
            public ShowProfileEditedMessage(String message) {
                this.message = message;
            }
        }
    }

}