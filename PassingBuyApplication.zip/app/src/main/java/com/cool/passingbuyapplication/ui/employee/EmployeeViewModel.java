package com.cool.passingbuyapplication.ui.employee;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.post.ErrandType;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class EmployeeViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();


    @Inject
    public EmployeeViewModel() { }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }


    // 유저 입력 처리

    public void onSeeAllClick() {
        event.setValue(new Event.NavigateToBoardScreen(-1));
    }

    public void onCarryingClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.CARRYING.ordinal()));
    }

    public void onShoppingClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.SHOPPING.ordinal()));
    }

    public void onInCampusClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.IN_CAMPUS.ordinal()));
    }

    public void onTakeOutClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.TAKE_OUT.ordinal()));
    }

    public void onPetClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.PET.ordinal()));
    }

    public void onCleaningClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.CLEANING.ordinal()));
    }

    public void onDowntownClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.DOWNTOWN.ordinal()));
    }

    public void onEtcClick() {
        event.setValue(new Event.NavigateToBoardScreen(ErrandType.ETC.ordinal()));
    }

    public void onWritePostClick() {
        event.setValue(new Event.NavigateToEmployerScreen());
    }


    public static class Event {

        public static class NavigateToBoardScreen extends Event {
            public final int errandType;
            public NavigateToBoardScreen(int errandType) {
                this.errandType = errandType;
            }
        }

        public static class NavigateToEmployerScreen extends Event { }
    }

}
