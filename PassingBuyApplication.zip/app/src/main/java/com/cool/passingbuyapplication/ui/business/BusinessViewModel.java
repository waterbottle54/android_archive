package com.cool.passingbuyapplication.ui.business;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;
import com.cool.passingbuyapplication.ui.MainActivity;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class BusinessViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String userId;

    private final LiveData<User> user;
    private final Observer<User> userObserver;

    @Inject
    public BusinessViewModel(UserRepository userRepository) {
        userId = userRepository.getCurrentId();
        user = userRepository.getUsersLiveData(userId);
        userObserver = currentUser -> {
            if (currentUser.getNickname() == null) {
                String message = userId + "님 안녕하세요. \n프로필이 설정되어 있지 않습니다. 프로필을 설정해주세요.";
                event.setValue(new Event.ShowEditProfileMessage(message));
            }
        };
        user.observeForever(userObserver);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        user.removeObserver(userObserver);
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getUserId() {
        return userId;
    }


    public void onBackPressed() {
        event.setValue(new Event.ShowConfirmSignOutMessage("로그아웃 하시겠습니까?"));
    }

    public void onSignOutClick() {
        event.setValue(new Event.NavigateToSignOutScreen());
    }

    public void onRequestErrandClick() {
        event.setValue(new Event.NavigateToEmployerScreen());
    }

    public void onRunErrandClick() {
        event.setValue(new Event.NavigateToEmployeeScreen());
    }

    public void onEditProfileConfirmed() {
        assert user.getValue() != null;
        event.setValue(new Event.NavigateToEditProfileScreen(user.getValue()));
    }

    public void onEditProfileResult(int result) {
        if (result == MainActivity.RESULT_EDIT_PROFILE_OK) {
            event.setValue(new Event.ShowProfileEditedMessage("프로필이 설정되었습니다"));
        } else {
            String message = "아직 프로필이 설정되지 않았습니다. 프로필을 설정해주세요.";
            event.setValue(new Event.ShowEditProfileMessage(message));
        }
    }


    public static class Event {

        public static class ShowConfirmSignOutMessage extends Event {
            public final String message;
            public ShowConfirmSignOutMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToSignOutScreen extends Event {
        }

        public static class NavigateToEmployerScreen extends Event {}

        public static class NavigateToEmployeeScreen extends Event {}

        public static class ShowEditProfileMessage extends Event {
            public final String message;
            public ShowEditProfileMessage(String message) {
                this.message = message;
            }
        }

        public static class NavigateToEditProfileScreen extends Event {
            public final User user;
            public NavigateToEditProfileScreen(User user) {
                this.user = user;
            }
        }

        public static class ShowProfileEditedMessage extends Event {
            public final String message;
            public ShowProfileEditedMessage(String message) {
                this.message = message;
            }
        }

    }

}