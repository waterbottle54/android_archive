package com.cool.passingbuyapplication.ui.auth.signout;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.user.UserRepository;
import com.cool.passingbuyapplication.util.JavascriptUtils;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class SignOutViewModel extends ViewModel {

    private static final String URL_MEMBER = "http://ecampus.konkuk.ac.kr/ilos/main/main_form.acl";
    private static final String URL_SIGN_IN = "https://ecampus.konkuk.ac.kr/ilos/main/member/login_form.acl#";
    private static final String URL_SIGN_IN_MOBILE = "http://ecampus.konkuk.ac.kr/ilos/m/main/login_form.acl";


    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String message;

    private final UserRepository userRepository;


    @Inject
    public SignOutViewModel(SavedStateHandle savedStateHandle, UserRepository userRepository) {
        message = savedStateHandle.get("message");
        this.userRepository = userRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getMessage() {
        return message;
    }


    public void onWebViewBuilt() {
        event.setValue(new Event.LoadWebPage(URL_MEMBER));
    }

    public void onPageLoaded(String url, String html) {

        if (url.equals(URL_MEMBER) && html.contains("<div class=\"header_logout\">")) {
            String javascript = JavascriptUtils.getClickJavascript(".welcome-message > a");
            event.postValue(new Event.ClickSignOutButton(javascript));
        } else {
            userRepository.signOut();
            event.postValue(new Event.NavigateToSignInScreenAfterStoppingService());
        }
    }


    public static class Event {

        public static class LoadWebPage extends Event {
            public final String url;
            public LoadWebPage(String url) {
                this.url = url;
            }
        }

        public static class ClickSignOutButton extends Event {
            public final String javascript;
            public ClickSignOutButton(String javascript) {
                this.javascript = javascript;
            }
        }

        public static class NavigateToSignInScreenAfterStoppingService extends Event { }
    }

}
