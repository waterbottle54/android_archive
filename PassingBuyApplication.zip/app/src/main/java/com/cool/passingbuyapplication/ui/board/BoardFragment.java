package com.cool.passingbuyapplication.ui.board;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.data.post.DetailedPost;
import com.cool.passingbuyapplication.databinding.FragmentBoardBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class BoardFragment extends Fragment {

    private FragmentBoardBinding binding;
    private BoardViewModel viewModel;


    public BoardFragment() {
        super(R.layout.fragment_board);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentBoardBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(BoardViewModel.class);

        binding.progressBar.setVisibility(View.VISIBLE);

        DetailedPostsAdapter adapter = new DetailedPostsAdapter(getResources());
        adapter.setOnItemSelectedListener(position ->
                viewModel.onPostClick(adapter.getCurrentList().get(position))
        );
        binding.recyclerDetailedPosts.setHasFixedSize(true);
        binding.recyclerDetailedPosts.setAdapter(adapter);

        viewModel.getDetailedPosts().observe(getViewLifecycleOwner(), detailedPosts -> {
            adapter.submitList(detailedPosts);
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof BoardViewModel.Event.NavigateToPostScreen) {
                DetailedPost detailedPost = ((BoardViewModel.Event.NavigateToPostScreen) event).detailedPost;
                NavDirections action = BoardFragmentDirections.actionBoardFragmentToPostFragment(detailedPost);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
