package com.cool.passingbuyapplication.data.post;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class PostRepository {

    private final CollectionReference postsCollection;

    @Inject
    public PostRepository(FirebaseFirestore firestore) {

        postsCollection = firestore.collection("posts");
    }

    public LiveData<List<Post>> getPosts(ErrandType errandType, boolean isMale) {

        // errandType 과 isMale 필터로 검색된 포스트 리스트 획득

        MutableLiveData<List<Post>> posts = new MutableLiveData<>();

        Query query = postsCollection
                .whereGreaterThan("deadline", System.currentTimeMillis());

        if (errandType != null) {
            query = query.whereEqualTo("errandType", errandType);
        }

        query.addSnapshotListener((value, error) -> {
            if (value == null || error != null) {
                posts.setValue(null);
                return;
            }
            List<Post> postList = new ArrayList<>();
            for (DocumentSnapshot snapshot : value) {
                Post post = snapshot.toObject(Post.class);
                if (post == null) {
                    continue;
                }
                if (post.getGenderLimit() != GenderLimit.NONE) {
                    if ((post.getGenderLimit() == GenderLimit.MALE && !isMale)
                            || (post.getGenderLimit() == GenderLimit.FEMALE && isMale)) {
                        continue;
                    }
                }
                postList.add(post);
            }
            posts.setValue(postList);
        });

        return posts;
    }

    public LiveData<List<Post>> getPosts() {

        MutableLiveData<List<Post>> posts = new MutableLiveData<>();

        postsCollection
                .addSnapshotListener((value, error) -> {
                    if (value == null || error != null) {
                        posts.setValue(null);
                        return;
                    }
                    List<Post> postList = new ArrayList<>();
                    for (DocumentSnapshot snapshot : value) {
                        Post post = snapshot.toObject(Post.class);
                        if (post == null) {
                            continue;
                        }
                        postList.add(post);
                    }
                    posts.setValue(postList);
                });

        return posts;
    }

    public void addPost(Post post, OnSuccessListener<Void> onSuccessListener, OnFailureListener onFailureListener) {

        postsCollection.document(post.getId())
                .set(post)
                .addOnSuccessListener(onSuccessListener)
                .addOnFailureListener(onFailureListener);
    }

    public void deletePost(Post post, OnSuccessListener<Void> onSuccessListener) {

        postsCollection.document(post.getId())
                .delete()
                .addOnSuccessListener(onSuccessListener);
    }


}
