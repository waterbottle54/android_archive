package com.cool.passingbuyapplication.data.post;

import com.cool.passingbuyapplication.data.user.User;

import java.io.Serializable;
import java.util.Objects;

public class DetailedPost extends Post implements Serializable {

    private final User user;    // 추가 정보 (유저)

    public DetailedPost(Post post, User user) {
        super(post);
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        DetailedPost that = (DetailedPost) o;
        return user.equals(that.user);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), user);
    }
}
