package com.cool.passingbuyapplication.data.post;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.Transformations;

import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.data.user.UserRepository;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

public class DetailedPostRepository {

    private final PostRepository postRepository;
    private final UserRepository userRepository;

    @Inject
    public DetailedPostRepository(PostRepository postRepository, UserRepository userRepository) {
        this.postRepository = postRepository;
        this.userRepository = userRepository;
    }

    public LiveData<List<DetailedPost>> getDetailedPosts(ErrandType errandType, boolean isMale) {

        // errandType 과 isMale 필터로 검색된 포스트 리스트 획득

        LiveData<List<Post>> posts = postRepository.getPosts(errandType, isMale);
        LiveData<List<User>> users = userRepository.getUsersLiveData();

        return Transformations.switchMap(posts, postList ->
                Transformations.map(users, userList -> {
                            if (postList == null || userList == null) {
                                return null;
                            }
                            List<DetailedPost> detailedPosts = new ArrayList<>();
                            for (Post post : postList) {
                                User writer = null;
                                for (User user : userList) {
                                    if (user.getId().equals(post.getUserId())) {
                                        writer = user;
                                        break;
                                    }
                                }
                                if (writer != null) {
                                    DetailedPost detailedPost = new DetailedPost(post, writer);
                                    detailedPosts.add(detailedPost);
                                }
                            }
                            return detailedPosts;
                        }
                )
        );
    }

    public LiveData<List<DetailedPost>> getDetailedPosts() {

        LiveData<List<Post>> posts = postRepository.getPosts();
        LiveData<List<User>> users = userRepository.getUsersLiveData();

        return Transformations.switchMap(posts, postList ->
                Transformations.map(users, userList -> {
                            if (postList == null || userList == null) {
                                return null;
                            }
                            List<DetailedPost> detailedPosts = new ArrayList<>();
                            for (Post post : postList) {
                                User writer = null;
                                for (User user : userList) {
                                    if (user.getId().equals(post.getUserId())) {
                                        writer = user;
                                        break;
                                    }
                                }
                                if (writer != null) {
                                    DetailedPost detailedPost = new DetailedPost(post, writer);
                                    detailedPosts.add(detailedPost);
                                }
                            }
                            return detailedPosts;
                        }
                )
        );
    }

}
