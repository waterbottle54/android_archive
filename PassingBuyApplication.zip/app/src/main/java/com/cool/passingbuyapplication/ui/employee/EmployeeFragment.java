package com.cool.passingbuyapplication.ui.employee;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.databinding.FragmentEmployeeBinding;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class EmployeeFragment extends Fragment {

    private FragmentEmployeeBinding binding;
    private EmployeeViewModel viewModel;


    public EmployeeFragment() {
        super(R.layout.fragment_employee);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentEmployeeBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(EmployeeViewModel.class);

        // 카테고리 아이템에 리스너 설정

        binding.viewCategorySeeAll.setOnClickListener(v -> viewModel.onSeeAllClick());
        binding.viewCategoryCarrying.setOnClickListener(v -> viewModel.onCarryingClick());
        binding.viewCategoryShopping.setOnClickListener(v -> viewModel.onShoppingClick());
        binding.viewCategoryInCampus.setOnClickListener(v -> viewModel.onInCampusClick());
        binding.viewCategoryTakeOut.setOnClickListener(v -> viewModel.onTakeOutClick());
        binding.viewCategoryPet.setOnClickListener(v -> viewModel.onPetClick());
        binding.viewCategoryCleaning.setOnClickListener(v -> viewModel.onCleaningClick());
        binding.viewCategoryDowntown.setOnClickListener(v -> viewModel.onDowntownClick());
        binding.viewCategoryEtc.setOnClickListener(v -> viewModel.onEtcClick());

        binding.buttonWritePost.setOnClickListener(v -> viewModel.onWritePostClick());

        // 뷰모델 이벤트 처리

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof EmployeeViewModel.Event.NavigateToBoardScreen) {
                int errandType = ((EmployeeViewModel.Event.NavigateToBoardScreen) event).errandType;
                NavDirections action = EmployeeFragmentDirections.actionEmployeeFragmentToBoardFragment(errandType);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof EmployeeViewModel.Event.NavigateToEmployerScreen) {
                NavDirections action = EmployeeFragmentDirections.actionEmployeeFragmentToEmployerFragment();
                Navigation.findNavController(requireView()).navigate(action);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
