package com.cool.passingbuyapplication.data.post;

// 성별 제한 열거형

public enum GenderLimit {
    NONE, MALE, FEMALE
}
