package com.cool.passingbuyapplication.ui.mypage.mypage;

import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.data.user.User;
import com.cool.passingbuyapplication.databinding.FragmentMyPageBinding;
import com.cool.passingbuyapplication.ui.MainActivity;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class MyPageFragment extends Fragment {

    private FragmentMyPageBinding binding;
    private MyPageViewModel viewModel;


    public MyPageFragment() {
        super(R.layout.fragment_my_page);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentMyPageBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(MyPageViewModel.class);

        binding.buttonEditProfile.setOnClickListener(v -> viewModel.onEditProfileClick());

        binding.progressBar.setVisibility(View.VISIBLE);

        binding.switchNotification.setChecked(viewModel.isNotificationOn());
        binding.switchNotification.setOnCheckedChangeListener((compoundButton, on) ->
                viewModel.onNotificationChanged(on));

        viewModel.getProfileImage().observe(getViewLifecycleOwner(), bitmap -> {
            if (bitmap != null) {
                binding.imageViewProfileImage.setImageBitmap(bitmap);
            }
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.getNickname().observe(getViewLifecycleOwner(), nickname ->
                binding.textViewNickname.setText(nickname));

        viewModel.isMale().observe(getViewLifecycleOwner(), isMale ->
                binding.textViewGender.setText(isMale ? "남성" : "여성"));

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof MyPageViewModel.Event.NavigateToEditProfileScreen) {
                User user = ((MyPageViewModel.Event.NavigateToEditProfileScreen) event).user;
                NavDirections action = MyPageFragmentDirections.actionMyPageFragmentToEditProfileFragment(user);
                Navigation.findNavController(requireView()).navigate(action);
            }
        });

        getParentFragmentManager().setFragmentResultListener(MainActivity.REQUEST_EDIT_PROFILE, getViewLifecycleOwner(),
                (requestKey, bundle) -> {
                    int result = bundle.getInt(MainActivity.RESULT_EDIT_PROFILE);
                    viewModel.onEditProfileResult(result);
                });

        if (!viewModel.isEditable()) {
            binding.groupControl.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!viewModel.isEditable()) {
            ActionBar actionBar = ((AppCompatActivity) requireActivity()).getSupportActionBar();
            if (actionBar != null) {
                actionBar.hide();
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (!viewModel.isEditable()) {
            ActionBar actionBar = ((AppCompatActivity) requireActivity()).getSupportActionBar();
            if (actionBar != null) {
                actionBar.show();
            }
        }
    }

}
