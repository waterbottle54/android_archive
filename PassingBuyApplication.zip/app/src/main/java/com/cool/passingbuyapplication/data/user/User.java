package com.cool.passingbuyapplication.data.user;

import java.io.Serializable;
import java.util.Objects;

public class User implements Serializable {

    private String id;
    private String nickname;    // 닉네임
    private boolean isMale;     // 남성, 여성 여부
    private long created;       // 가입 시간

    public User() {
    }

    public User(String id, String nickname, boolean isMale) {
        this.id = id;
        this.nickname = nickname;
        this.isMale = isMale;
        this.created = System.currentTimeMillis();
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public void setMale(boolean male) {
        isMale = male;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public String getId() {
        return id;
    }

    public String getNickname() {
        return nickname;
    }

    public boolean isMale() {
        return isMale;
    }

    public long getCreated() {
        return created;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return isMale == user.isMale && created == user.created && id.equals(user.id) && Objects.equals(nickname, user.nickname);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, nickname, isMale, created);
    }
}
