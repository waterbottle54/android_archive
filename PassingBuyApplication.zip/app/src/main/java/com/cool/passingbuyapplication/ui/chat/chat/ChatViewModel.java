package com.cool.passingbuyapplication.ui.chat.chat;

import android.graphics.Bitmap;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.SavedStateHandle;
import androidx.lifecycle.Transformations;
import androidx.lifecycle.ViewModel;

import com.cool.passingbuyapplication.data.chat.Chat;
import com.cool.passingbuyapplication.data.chat.ChatRepository;
import com.cool.passingbuyapplication.data.comment.Comment;
import com.cool.passingbuyapplication.data.comment.CommentRepository;
import com.cool.passingbuyapplication.data.comment.DetailedComment;
import com.cool.passingbuyapplication.data.image.ImageRepository;
import com.cool.passingbuyapplication.data.user.UserRepository;

import java.util.List;

import javax.inject.Inject;

import dagger.hilt.android.lifecycle.HiltViewModel;

@HiltViewModel
public class ChatViewModel extends ViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final String chatId;
    private final String userId;

    private final String postId;
    private final String hostId;
    private final String guestId;

    private final LiveData<Chat> chat;
    private final LiveData<List<DetailedComment>> comments;
    private final LiveData<Bitmap> profileImage;

    private final ChatRepository chatRepository;
    private final CommentRepository commentsRepository;

    private String message;


    @Inject
    public ChatViewModel(SavedStateHandle savedStateHandle,
                         UserRepository userRepository,
                         ChatRepository chatRepository,
                         CommentRepository commentRepository,
                         ImageRepository imageRepository) {

        userId = userRepository.getCurrentId();
        chatId = savedStateHandle.get("chatId");
        postId = savedStateHandle.get("postId");
        hostId = savedStateHandle.get("hostId");
        guestId = savedStateHandle.get("guestId");

        // 커멘트 획득

        chat = chatRepository.getChat(chatId);
        comments = Transformations.switchMap(chat, chatValue -> {
            if (chatValue == null) {
                return null;
            }
            return commentRepository.getDetailedComments(chatValue.getId());
        });

        // 프로필 이미지 획득

        profileImage = Transformations.switchMap(chat, chatValue -> {
            String hostId = chatValue == null ? this.hostId : chatValue.getHostId();
            String guestId = chatValue == null ? this.guestId : chatValue.getGuestId();
            return imageRepository.getProfileImageLiveData(userId.equals(hostId) ? guestId : hostId);
        });

        this.chatRepository = chatRepository;
        this.commentsRepository = commentRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public String getUserId() {
        return userId;
    }

    public LiveData<List<DetailedComment>> getComments() {
        return comments;
    }

    public LiveData<Bitmap> getProfileImage() {
        return profileImage;
    }


    public void onMessageChanged(String text) {
        this.message = text;
    }

    public void onSubmitClick() {

        if (message.isEmpty()) {
            return;
        }

        // 확인 클릭 시 채팅 추가

        Chat chatValue = chat.getValue();
        Comment comment = new Comment(chatId, userId, message);

        if (chatValue == null) {
            if (postId != null && hostId != null && guestId != null) {
                Chat chat = new Chat(postId, hostId, guestId);
                String receiverId = userId.equals(hostId) ? guestId : hostId;
                chatRepository.addChat(chat, unused -> commentsRepository.addComment(comment, receiverId));
            }
        } else {
            String hostId = chatValue.getHostId();
            String guestId = chatValue.getGuestId();
            String receiverId = userId.equals(hostId) ? guestId : hostId;
            commentsRepository.addComment(comment, receiverId);
        }
    }

    public void onProfileSelected(String userId) {
        event.setValue(new Event.NavigateToProfileScreen(userId));
    }


    public static class Event {

        public static class NavigateToProfileScreen extends Event {
            public final String userId;
            public NavigateToProfileScreen(String userId) {
                this.userId = userId;
            }
        }
    }

}