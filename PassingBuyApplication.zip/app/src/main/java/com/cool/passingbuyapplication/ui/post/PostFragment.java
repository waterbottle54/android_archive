package com.cool.passingbuyapplication.ui.post;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;

import com.cool.passingbuyapplication.R;
import com.cool.passingbuyapplication.databinding.FragmentPostBinding;
import com.cool.passingbuyapplication.util.NameUtils;

import java.util.Locale;

import dagger.hilt.android.AndroidEntryPoint;

@AndroidEntryPoint
public class PostFragment extends Fragment {

    private FragmentPostBinding binding;
    private PostViewModel viewModel;


    public PostFragment() {
        super(R.layout.fragment_post);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding = FragmentPostBinding.bind(view);
        viewModel = new ViewModelProvider(this).get(PostViewModel.class);

        // 성별 획득 후 표시

        String strNicknameGender = String.format(Locale.getDefault(),
                getString(R.string.nickname_gender),
                viewModel.getNickname(),
                NameUtils.getGenderName(getResources(), viewModel.isMale())
        );
        binding.textViewNicknameGender.setText(strNicknameGender);

        // 제목, 내용, 잔여시간, 작성시간 획득 후 표시

        binding.textViewPostTitle.setText(viewModel.getTitle());

        binding.textViewPostContents.setText(viewModel.getContents());

        String strTimeLeft = NameUtils.getTimeLeftString(getResources(), viewModel.getTimeLeft());
        binding.textViewPostTimeLeft.setText(strTimeLeft);

        String strCreated = NameUtils.getDateString(getResources(), viewModel.getCreated());
        binding.textViewPostCreated.setText(strCreated);

        binding.buttonChat.setOnClickListener(v -> viewModel.onChatClick());
        binding.buttonDeletePost.setOnClickListener(v -> viewModel.onDeleteClick());

        // 프로필 이미지 표시

        viewModel.getProfileImage().observe(getViewLifecycleOwner(), bitmap -> {
            binding.imageViewProfileImage.setImageBitmap(bitmap);
            binding.progressBar.setVisibility(View.INVISIBLE);
        });

        viewModel.isChatable().observe(getViewLifecycleOwner(), isChatable ->
                binding.buttonChat.setEnabled(isChatable));
        viewModel.isEditable().observe(getViewLifecycleOwner(), isEditable ->
                binding.buttonDeletePost.setVisibility(isEditable ? View.VISIBLE : View.INVISIBLE));

        // 뷰모델 이벤트 처리

        viewModel.getEvent().observe(getViewLifecycleOwner(), event -> {
            if (event instanceof PostViewModel.Event.NavigateToChatScreen) {
                String chatId = ((PostViewModel.Event.NavigateToChatScreen) event).chatId;
                String postId = ((PostViewModel.Event.NavigateToChatScreen) event).postId;
                String hostId = ((PostViewModel.Event.NavigateToChatScreen) event).hostId;
                String guestId = ((PostViewModel.Event.NavigateToChatScreen) event).guestId;
                NavDirections action = PostFragmentDirections.actionPostFragmentToChatFragment(
                        chatId, postId, hostId, guestId);
                Navigation.findNavController(requireView()).navigate(action);
            } else if (event instanceof PostViewModel.Event.NavigateBack) {
                Navigation.findNavController(requireView()).popBackStack();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}