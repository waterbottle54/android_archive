package com.cool.passingbuyapplication.ui.board;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.cool.passingbuyapplication.data.post.DetailedPost;
import com.cool.passingbuyapplication.databinding.DetailedPostItemBinding;
import com.cool.passingbuyapplication.util.NameUtils;

public class DetailedPostsAdapter extends ListAdapter<DetailedPost, DetailedPostsAdapter.DetailedPostViewHolder> {

    class DetailedPostViewHolder extends RecyclerView.ViewHolder {

        private final DetailedPostItemBinding binding;

        public DetailedPostViewHolder(DetailedPostItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            binding.getRoot().setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemSelectedListener != null) {
                    onItemSelectedListener.onItemSelected(position);
                }
            });
        }

        public void bind(DetailedPost model) {

            binding.textViewPostTitle.setText(model.getTitle());
            binding.textViewCategory.setText(NameUtils.getErrandTypeName(resources, model.getErrandType()));
            binding.textViewNickname.setText(model.getUser().getNickname());

            long millisLeft = model.getDeadline() - System.currentTimeMillis();
            String strTimeLeft = NameUtils.getTimeLeftString(resources, millisLeft);
            binding.textViewPostTimeLeft.setText(strTimeLeft);
        }
    }

    public interface OnItemSelectedListener {
        void onItemSelected(int position);
    }

    private OnItemSelectedListener onItemSelectedListener;
    private final Resources resources;


    public DetailedPostsAdapter(Resources resources) {
        super(new DiffUtilCallback());
        this.resources = resources;
    }

    public void setOnItemSelectedListener(OnItemSelectedListener listener) {
        this.onItemSelectedListener = listener;
    }

    @NonNull
    @Override
    public DetailedPostViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        DetailedPostItemBinding binding = DetailedPostItemBinding.inflate(layoutInflater, parent, false);
        return new DetailedPostViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull DetailedPostViewHolder holder, int position) {
        holder.bind(getItem(position));
    }


    static class DiffUtilCallback extends DiffUtil.ItemCallback<DetailedPost> {

        @Override
        public boolean areItemsTheSame(@NonNull DetailedPost oldItem, @NonNull DetailedPost newItem) {
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull DetailedPost oldItem, @NonNull DetailedPost newItem) {
            return oldItem.equals(newItem);
        }
    }

}