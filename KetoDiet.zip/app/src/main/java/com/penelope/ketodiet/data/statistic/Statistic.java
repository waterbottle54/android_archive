package com.penelope.ketodiet.data.statistic;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity(tableName = "statistic_table")
public class Statistic {

    @NonNull
    @PrimaryKey
    private final String id;
    private final int year;
    private final int month;
    private final int dayOfMonth;
    private final double carbohydrates;
    private final double protein;
    private final double fat;
    private final long created;

    public Statistic(@NonNull String id, int year, int month, int dayOfMonth, double carbohydrates, double protein, double fat, long created) {
        this.id = id;
        this.year = year;
        this.month = month;
        this.dayOfMonth = dayOfMonth;
        this.carbohydrates = carbohydrates;
        this.protein = protein;
        this.fat = fat;
        this.created = created;
    }

    @Ignore
    public Statistic(int year, int month, int dayOfMonth, double carbohydrates, double protein, double fat, long created) {
        this.id = year + "_" + month + "_" + dayOfMonth;
        this.year = year;
        this.month = month;
        this.dayOfMonth = dayOfMonth;
        this.carbohydrates = carbohydrates;
        this.protein = protein;
        this.fat = fat;
        this.created = created;
    }

    @NonNull
    public String getId() {
        return id;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public int getDayOfMonth() {
        return dayOfMonth;
    }

    public double getCarbohydrates() {
        return carbohydrates;
    }

    public double getProtein() {
        return protein;
    }

    public double getFat() {
        return fat;
    }

    public long getCreated() {
        return created;
    }

}
