package com.penelope.ketodiet.data.statistic;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface StatisticDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addStatistic(Statistic statistic);

    @Query("SELECT * FROM statistic_table WHERE year == :year AND month == :month ORDER BY created ASC")
    LiveData<List<Statistic>> getMonthlyStatistic(int year, int month);

}
