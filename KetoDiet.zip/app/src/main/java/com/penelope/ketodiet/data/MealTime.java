package com.penelope.ketodiet.data;

public enum MealTime {
    BREAKFAST, LUNCH, DINNER
}
