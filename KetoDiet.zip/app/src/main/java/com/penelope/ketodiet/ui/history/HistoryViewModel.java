package com.penelope.ketodiet.ui.history;

import android.app.Application;
import android.util.Pair;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.room.Room;

import com.penelope.ketodiet.data.statistic.Composition;
import com.penelope.ketodiet.data.statistic.Statistic;
import com.penelope.ketodiet.data.statistic.StatisticDao;
import com.penelope.ketodiet.data.statistic.StatisticDatabase;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

public class HistoryViewModel extends AndroidViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final LiveData<Composition> composition;

    private final LiveData<List<Pair<LocalDate, Composition>>> compositionDetail;


    public HistoryViewModel(@NonNull Application application) {

        super(application);

        StatisticDatabase statisticDatabase =
                Room.databaseBuilder(application, StatisticDatabase.class, "statistic_database")
                        .fallbackToDestructiveMigration()
                        .build();

        StatisticDao statisticDao = statisticDatabase.statisticDao();

        YearMonth now = YearMonth.now();
        LiveData<List<Statistic>> statistics = statisticDao.getMonthlyStatistic(now.getYear(), now.getMonthValue());

        composition = Transformations.map(statistics, statisticList -> {
           if (statisticList != null) {
               double carbohydrates = 0;
               double protein = 0;
               double fat = 0;
               for (Statistic statistic : statisticList) {
                   carbohydrates += statistic.getCarbohydrates();
                   protein += statistic.getProtein();
                   fat += statistic.getFat();
               }
               return new Composition(carbohydrates, protein, fat);
           }
           return null;
        });

        compositionDetail = Transformations.map(statistics, statisticList -> {
            if (statisticList != null) {
                List<Pair<LocalDate, Composition>> list = new ArrayList<>();
                for (Statistic s : statisticList) {
                    LocalDate date = LocalDate.of(s.getYear(), s.getMonth(), s.getDayOfMonth());
                    Composition composition = new Composition(s.getCarbohydrates(), s.getProtein(), s.getFat());
                    list.add(new Pair<>(date, composition));
                }
                return list;
            }
            return null;
        });
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<Composition> getComposition() {
        return composition;
    }

    public LiveData<List<Pair<LocalDate, Composition>>> getCompositionDetail() {
        return compositionDetail;
    }


    public static class Event {

    }

}