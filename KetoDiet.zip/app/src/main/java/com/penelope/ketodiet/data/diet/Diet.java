package com.penelope.ketodiet.data.diet;

import java.util.Objects;

public class Diet {

    private final String name;
    private final double carbohydrates;
    private final double protein;
    private final double fat;

    public Diet(String name, double carbohydrates, double protein, double fat) {
        this.name = name;
        this.carbohydrates = carbohydrates;
        this.protein = protein;
        this.fat = fat;
    }

    public String getName() {
        return name;
    }

    public double getCarbohydrates() {
        return carbohydrates;
    }

    public double getProtein() {
        return protein;
    }

    public double getFat() {
        return fat;
    }

    public double getCalories() {
        return (carbohydrates * 4 + protein * 4 + fat * 9);
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Diet diet = (Diet) o;
        return Double.compare(diet.carbohydrates, carbohydrates) == 0 && Double.compare(diet.protein, protein) == 0 && Double.compare(diet.fat, fat) == 0 && name.equals(diet.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, carbohydrates, protein, fat);
    }
}
