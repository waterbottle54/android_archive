package com.penelope.ketodiet.lambda;

import android.util.Log;

import androidx.annotation.WorkerThread;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class CalorieLambda {

    public final static String URL = "https://6wqem7z0fe.execute-api.ap-northeast-2.amazonaws.com/default/addFunc?carbohydrates={CARBOHYDRATES}&protein={PROTEIN}&fat={FAT}";

    @WorkerThread
    public static int get(double carbohydrates, double protein, double fat) {

        String strUrl = URL.replace("{CARBOHYDRATES}", String.valueOf((int) carbohydrates))
                .replace("{PROTEIN}", String.valueOf((int) protein))
                .replace("{FAT}", String.valueOf((int) fat));

        Log.d("TAG", "get: " + strUrl);

        // URL 을 통해 API 를 호출하고 값을 얻는다
        try {
            java.net.URL url = new URL(strUrl);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            return Integer.parseInt(br.readLine());

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

}
