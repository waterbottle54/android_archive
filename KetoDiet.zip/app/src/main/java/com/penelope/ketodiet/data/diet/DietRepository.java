package com.penelope.ketodiet.data.diet;

import androidx.annotation.WorkerThread;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DietRepository {

    public static final String URL = "jdbc:mysql://mydb.czvzgyaetkik.ap-northeast-2.rds.amazonaws.com/mydb?serverTimezone=UTC&useSSL=false";
    public static final String USER_NAME = "waterbottle54";
    public static final String PASSWORD = "masterpassword";
    public static final String TABLE_NAME = "diets";


    public DietRepository() {
    }

    @WorkerThread
    public List<Diet> getAllDiets() {

        List<Diet> list = new ArrayList<>();

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            Statement statement = connection.createStatement();

            ResultSet rs = statement.executeQuery("SELECT * FROM " + TABLE_NAME);
            while (rs.next()) {
                String name = rs.getString(1);
                double carbohydrates = rs.getDouble(2);
                double protein = rs.getDouble(3);
                double fat = rs.getDouble(4);
                Diet diet = new Diet(name, carbohydrates, protein, fat);
                list.add(diet);
            }

            connection.close();
            return list;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    @WorkerThread
    public void addDiet(Diet diet) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            Statement statement = connection.createStatement();

            statement.execute("INSERT INTO " + TABLE_NAME + " (diet_name, carbohydrates, protein, fat) VALUES("
                    + "'" + diet.getName() + "', "
                    + diet.getCarbohydrates() + ", "
                    + diet.getProtein() + ", "
                    + diet.getFat()
                    + ")"
            );

            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @WorkerThread
    public void deleteDiet(Diet diet) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            Statement statement = connection.createStatement();

            statement.execute("DELETE FROM " + TABLE_NAME
                    + " WHERE diet_name = '" + diet.getName() + "'"
            );

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}





