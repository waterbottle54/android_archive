package com.penelope.ketodiet.ui.main;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Transformations;
import androidx.room.Room;

import com.penelope.ketodiet.data.MealTime;
import com.penelope.ketodiet.data.diet.Diet;
import com.penelope.ketodiet.data.diet.DietRepository;
import com.penelope.ketodiet.data.statistic.Composition;
import com.penelope.ketodiet.data.statistic.Statistic;
import com.penelope.ketodiet.data.statistic.StatisticDao;
import com.penelope.ketodiet.data.statistic.StatisticDatabase;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MainViewModel extends AndroidViewModel {

    private final MutableLiveData<Event> event = new MutableLiveData<>();

    private final MutableLiveData<List<Diet>> allDiets = new MutableLiveData<>();

    private final MutableLiveData<List<Diet>> breakfastList = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<Diet>> lunchList = new MutableLiveData<>(new ArrayList<>());
    private final MutableLiveData<List<Diet>> dinnerList = new MutableLiveData<>(new ArrayList<>());

    private final LiveData<Composition> composition;

    private final StatisticDao statisticDao;
    private final DietRepository dietRepository;


    public MainViewModel(@NonNull Application application) {

        super(application);

        DietRepository dietRepository = new DietRepository();

        new Thread(() -> allDiets.postValue(dietRepository.getAllDiets())).start();

        LiveData<List<Diet>> meals = Transformations.switchMap(breakfastList, breakfast ->
                Transformations.switchMap(lunchList, lunch ->
                        Transformations.map(dinnerList, dinner -> {
                            List<Diet> merged = new ArrayList<>();
                            merged.addAll(breakfast);
                            merged.addAll(lunch);
                            merged.addAll(dinner);
                            return merged;
                        })));

        composition = Transformations.map(meals, mealList -> {
            double carbohydrates = 0;
            double proteins = 0;
            double fats = 0;
            for (Diet meal : mealList) {
                carbohydrates += meal.getCarbohydrates();
                proteins += meal.getProtein();
                fats = meal.getFat();
            }
            return new Composition(carbohydrates, proteins, fats);
        });

        StatisticDatabase statisticDatabase =
                Room.databaseBuilder(application, StatisticDatabase.class, "statistic_database")
                .fallbackToDestructiveMigration()
                .build();

        this.statisticDao = statisticDatabase.statisticDao();
        this.dietRepository = dietRepository;
    }

    public LiveData<Event> getEvent() {
        event.setValue(null);
        return event;
    }

    public LiveData<List<Diet>> getAllDiets() {
        return allDiets;
    }

    public LiveData<List<Diet>> getBreakfastList() {
        return breakfastList;
    }

    public LiveData<List<Diet>> getLunchList() {
        return lunchList;
    }

    public LiveData<List<Diet>> getDinnerList() {
        return dinnerList;
    }

    public LiveData<Composition> getComposition() {
        return composition;
    }


    public void onHistoryClick() {

        Composition compositionValue = composition.getValue();
        assert compositionValue != null;

        if (compositionValue.getCalories() == 0) {
            event.setValue(new Event.NavigateToHistoryScreen());
        } else {
            event.setValue(new Event.ConfirmSave());
        }
    }

    public void onSaveClick() {

        Composition compositionValue = composition.getValue();
        assert compositionValue != null;

        Statistic statistic = new Statistic(
                LocalDate.now().getYear(),
                LocalDate.now().getMonthValue(),
                LocalDate.now().getDayOfMonth(),
                compositionValue.getCarbohydrates(),
                compositionValue.getProtein(),
                compositionValue.getFat(),
                System.currentTimeMillis()
        );

        new Thread(() -> {
            statisticDao.addStatistic(statistic);
            event.postValue(new Event.NavigateToHistoryScreen());
        }).start();
    }

    public void onNotSaveClick() {
        event.setValue(new Event.NavigateToHistoryScreen());
    }

    public void onAddDietClick() {
        event.setValue(new Event.NavigateToDietScreen());
    }

    public void onAddMealClick(MealTime mealTime) {
        new Thread(() -> allDiets.postValue(dietRepository.getAllDiets())).start();
        event.setValue(new Event.PromptMeal(mealTime));
    }

    public void onDietClick(MealTime mealTime, int position) {

        List<Diet> diets = allDiets.getValue();
        if (diets == null) {
            return;
        }

        MutableLiveData<List<Diet>> mealList;

        switch (mealTime) {
            default:
            case BREAKFAST:
                mealList = breakfastList;
                break;
            case LUNCH:
                mealList = lunchList;
                break;
            case DINNER:
                mealList = dinnerList;
                break;
        }

        List<Diet> oldList = mealList.getValue();
        assert oldList != null;

        List<Diet> newList = new ArrayList<>(oldList);
        newList.add(diets.get(position));
        mealList.setValue(newList);
    }

    public void onMealSwiped(MealTime mealTime, int position) {

        MutableLiveData<List<Diet>> mealList;

        switch (mealTime) {
            default:
            case BREAKFAST:
                mealList = breakfastList;
                break;
            case LUNCH:
                mealList = lunchList;
                break;
            case DINNER:
                mealList = dinnerList;
                break;
        }

        List<Diet> oldList = mealList.getValue();
        assert oldList != null;

        List<Diet> newList = new ArrayList<>(oldList);
        newList.remove(position);

        mealList.setValue(newList);
    }


    public static class Event {

        public static class NavigateToHistoryScreen extends Event {
        }

        public static class NavigateToDietScreen extends Event {
        }

        public static class PromptMeal extends Event {
            public final MealTime mealTime;

            public PromptMeal(MealTime mealTime) {
                this.mealTime = mealTime;
            }
        }

        public static class ConfirmSave extends Event {
        }
    }

}





